# Paper, implementation and knowledge revision

Use this during L02/L03/L04/L05 and when retained knowledge informs H01/H03.
Extend the existing canonical literature/evidence ledger with useful Markdown
projections; do not create a competing source of gate status or a second paper
identity system. Reuse the project's selected delivery targets and actual saved
notes. Obsidian can display the same Markdown when a vault was explicitly chosen;
it is optional. No OpenClaw, ClawHub, notification or background runner dependency
is installed by this contract.

## Read depth follows the decision

Keep our existing D0/D1/D2/D3 depths. D1 triage may classify relevance and missing
access, but cannot support novelty, method validity, benchmark qualification,
a knowledge rule or experimental success. It is source screening, never a
reduced-rigor scientific test. Consequential closest-work, task, scorer, failure
or conflict assertions require D2 sections and D3 forensic scope where needed,
including supplementary material, actual pinned implementation/config files
and native benchmark contents. Escalate when equations, paper-code differences,
scoring semantics or contradictory findings could change the decision. Do not
use upstream fixed reading durations, note lengths or item counts as completion
criteria; budget the actual relevant read scope and retain inaccessible portions.

Use [paper-implementation-note.md](../assets/templates/paper-implementation-note.md)
for a compact note. Reuse an existing note at the same source version and record
newly read versus reused portions. Bind it to actual work/version/evidence IDs.
Separate author-reported empirical results, our static inspection, executions,
reproductions and independent confirmation. A paper note never supplies a
baseline receipt or native scorer run that did not occur.

## Knowledge cards and typed relations

Store only decision-relevant knowledge with an evidence locator and applicability
conditions. Use [knowledge-change-card.md](../assets/templates/knowledge-change-card.md),
adapted from ScholarSkill's MIT reading/memory templates; the retained license
is [scholar-skill-MIT.txt](../assets/licenses/scholar-skill-MIT.txt).

| Card type | What to retain | What it cannot establish |
|---|---|---|
| Semantic | Sourced proposition, assumptions, task/split/setting, support and conflicting evidence | A reported result is not our measurement; a universal rule needs more than one scene |
| Episodic | Earlier explicit interpretation, observed issue, correcting source, changed decision and unresolved question | No hidden reasoning capture, complete causal history or automatic blame attribution |
| Procedural | Candidate reusable rule, when it applies/fails, supporting checks and counterexamples | A plausible heuristic does not override native evaluation, user direction or confirmation |

Record proposed `add`, `merge`, `update`, `contradict` or `deprecate` actions.
Relations include `supports`, `contradicts`, `extends`, `specializes`, `similar_to`,
`useful_for`, `risky_for` and unresolved `standalone`. Each asserted relation needs
an actual locator and scope; unsupported links remain proposals. Keep old card
IDs, versions, evidence and explicit correction links. Never erase a negative
result or globally deprecate an old claim just because conditions differ.
Before resolving a conflict, compare population, data/split, information, budget,
implementation, parameters, scorer and uncertainty. A scope difference may explain
it; otherwise retain competing explanations and a discriminating design.

## Consolidation, retrieval and impact

Maintain a topic map/MOC as an index of actual cards, papers, implementations,
benchmarks, open obligations and contradictions. Prefer a small current project
brief plus retrievable detailed notes, not every paper in every prompt. The brief
contains qualified constraints and explicit unknowns; it does not make claims
permanently true or guarantee model memory across sessions. Before reuse, fetch
the actual durable record, check versions and confirm task/assumption match.
Cross-project reuse preserves original scope and provenance and requires the
receiving project's own benchmark/baseline qualification.

Consolidate at a scientific round's review, evidence freeze or a material source
change. Merge actual duplicates with identity links, preserve disagreements,
update affected indexes and append a compact "what changed / what remains / next
decision" record. Weekly/monthly schedules are optional explicit automations,
not enabled here. Use the existing S0–S3 impact classes in
[literature-evidence.md](literature-evidence.md): background edits update positioning;
result-affecting evidence invalidates affected projections; thesis/novelty changes
reopen their existing obligations. A Markdown card cannot advance a gate.

## From knowledge to a test

When a supported observation changes an explanation, link the card to the H03
decision and G01 experiment card: residual native-benchmark failure, competing
causes, smallest intervention, strong/simple alternative, decisive control,
information/total-budget match, native metric, precision, falsifier, outcomes,
cost and stopping rule. Do not promote a reading insight directly into a method
or call a proposed experiment completed. Keep theory, diagnosis, necessity,
confirmation and generalization obligations separate.

During the agreed experiment window, record knowledge changes and verify each
returned result under E04 within frozen diagnosis/repair rules. A failed idea or
newly found paper does not automatically restart direction search. At the batch
boundary consolidate these records for the human's choice: eligible validation/
writing, contextual 2→3→4, changed requirements at 1, or unresolved repair at 7.
Apply explicit human steering earlier when supplied. Preserve prior lineage,
caller, goals, resources, failed evidence and unfinished comparisons.
