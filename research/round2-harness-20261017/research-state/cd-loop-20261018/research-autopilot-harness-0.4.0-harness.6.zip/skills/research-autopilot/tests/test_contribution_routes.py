"""Software gate contracts only; no fabricated benchmark or scorer is evaluated."""
import copy
import unittest
from fixtures import C, DATE, ProjectFixture, digest, env, sample_artifacts, write
import _importance as I
from ipcg_fixtures import candidate, census, freeze_parent, importance, parent_card


class ContributionRouteTests(unittest.TestCase):
    def setUp(self):
        self.f = ProjectFixture()
        self.addCleanup(self.f.close)

    def parent(self, kind, thresholds=None):
        card = parent_card()
        card["contribution_type"] = kind
        card["benchmark_contract"]["source_evidence_refs"] = [self.f.source]
        if kind == "theory":
            card.pop("benchmark_contract")
            card.pop("gate_0_thresholds")
            work = copy.deepcopy(sample_artifacts()["work-record"])
            work.update(evidence_refs=[self.f.source])
            wref = write(self.f.root, "evidence/closest-theorem.json", work)
            card["formal_contract"] = {"formal_system":"fixture-proof-kernel",
                "definitions_ref":self.f.source, "theorem_statement_ref":self.f.source,
                "obligation_ids":["lemma-1"], "closest_theorem_work_refs":[wref],
                "strongest_known_alternative_work_ref":wref, "review_max_age_seconds":3600}
            card["value_gate"] = {"route":"formal_obligations", "evidence_refs":[self.f.source],
                "thresholds":thresholds or {"min_obligations":1, "min_strict_improvements":1,
                                            "min_consequential_obligations":1}}
        return card

    def test_new_parent_freeze_requires_a_contribution_type(self):
        card = self.parent("natural_failure")
        card.pop("contribution_type")
        ref = write(self.f.root, "problems/missing-type.json", card)
        with self.assertRaises(C.Failure):
            self.f.transition("freeze_parent_problem", {"parent_problem_ref":ref})

    def test_historical_parent_freeze_keeps_legacy_natural_census_contract(self):
        card = self.parent("natural_failure")
        card.pop("contribution_type")
        ref = write(self.f.root, "problems/legacy.json", card)
        state = C.project(self.f.root)[0]
        try:
            result, _ = I.apply(self.f.root, state, "freeze_parent_problem",
                                {"parent_problem_ref":ref}, historical=True)
        except (C.Failure, TypeError) as error:
            self.fail("Historical contribution compatibility is missing: " + str(error))
        self.assertEqual(result["parent_problem_ref"], ref)

    def test_theory_parent_does_not_require_an_invented_empirical_benchmark(self):
        card = self.parent("theory")
        try:
            C.validate(card, "parent-problem-card")
            ref = write(self.f.root, "problems/theory.json", card)
            self.f.transition("freeze_parent_problem", {"parent_problem_ref":ref})
        except C.Failure as error:
            self.fail("Formal contribution must have a formal evidence path: " + error.code)

    def test_route_cannot_override_the_frozen_contribution_type(self):
        card = self.parent("theory")
        card["value_gate"]["route"] = "performance_frontier"
        ref = write(self.f.root, "problems/wrong-route.json", card)
        with self.assertRaises(C.Failure):
            self.f.transition("freeze_parent_problem", {"parent_problem_ref":ref})


    def gate(self, card, raw, outcome, **kwargs):
        pref = write(self.f.root, "problems/typed.json", card)
        source = write(self.f.root, "evidence/typed-observations.json", raw)
        report = env("natural-gate-0", census_id="typed-screen", parent_problem_ref=pref,
            observations_ref=source, outcome=outcome, evaluated_at=DATE,
            contribution_type=card["contribution_type"], value_gate_route=card["value_gate"]["route"])
        gref = write(self.f.root, "audits/typed-screen.json", report)
        try:
            return I.natural_gate(self.f.root, pref, gref, **kwargs)
        except C.Failure as error:
            if error.code == "NATURAL_GATE_OUTCOME_MISMATCH":
                self.fail("Selected contribution route did not compute its declared screen outcome")
            raise
        except (KeyError, TypeError) as error:
            self.fail("Selected contribution path is not implemented: " + str(error))

    def formal_packet(self, strict=True):
        card = self.parent("theory")
        contract = card["formal_contract"]
        proof = self.f.source
        checker = write(self.f.root, "evidence/formal-checker-output.json", {
            "formal_system":contract["formal_system"], "obligation_id":"lemma-1",
            "statement_sha256":contract["theorem_statement_ref"]["sha256"], "proof_sha256":proof["sha256"],
            "exit_code":0, "unresolved_goals":[], "admitted_axioms":[]})
        review = write(self.f.root, "evidence/formal-review.json", {
            "review_kind":"proof_assistant", "formal_system":contract["formal_system"],
            "obligation_id":"lemma-1", "statement_sha256":contract["theorem_statement_ref"]["sha256"],
            "proof_sha256":proof["sha256"], "checked_at":DATE, "checker_version":"fixture-v1",
            "command":["fixture-proof-kernel", "proof.json"], "checker_output_ref":checker})
        comparison = write(self.f.root, "evidence/closest-theorem-comparison.json", {
            "obligation_id":"lemma-1", "strongest_known_alternative":card["strong_simple_alternative"],
            "closest_theorem_work_ref":contract["strongest_known_alternative_work_ref"],
            "relation":"strict_strengthening" if strict else "equivalent",
            "comparison_proof_ref":proof, "review_ref":review})
        consequence = write(self.f.root, "evidence/formal-consequence.json", {
            "endpoint":card["consequence"]["endpoint"], "scientific_implication":"Engineering fixture obligation",
            "justification":"This is a software contract fixture, not a scientific proof",
            "primary_evidence_refs":[self.f.source]})
        row = {"obligation_id":"lemma-1", "statement_ref":contract["theorem_statement_ref"],
            "proof_ref":proof, "review_ref":review, "comparison_ref":comparison,
            "consequence_ref":consequence}
        raw = {"sampling_kind":"formal_obligations", "formal_system":contract["formal_system"], "obligations":[row]}
        pref = write(self.f.root, "problems/typed.json", card)
        proofs = [proof, contract["theorem_statement_ref"], review, checker, comparison, consequence]
        attestation = write(self.f.root, "evidence/formal-attestation.json", {
            "capture_format":"formal-review-attestation-v1", "status":"verified",
            "parent_problem_sha256":pref["sha256"], "observations_digest":digest(raw),
            "obligation_ids":["lemma-1"], "proof_refs":proofs})
        raw["formal_review_attestation_ref"] = attestation
        def reviewer(root, parent, observations, report):
            # Trusted host double for a contract test; never a proof checker.
            return {"status":"verified", "obligation_ids":["lemma-1"],
                    "attestation_ref":attestation, "proof_refs":proofs}
        return card, raw, reviewer

    def test_theory_boolean_declaration_cannot_self_authorize_pass(self):
        card = self.parent("theory")
        raw = {"sampling_kind":"formal_obligations", "formal_system":"fixture-proof-kernel",
               "obligations":[{"obligation_id":"lemma-1", "proved":True, "important":True}]}
        result = self.gate(card, raw, "INCONCLUSIVE")
        self.assertEqual(result["outcome"], "INCONCLUSIVE")
        self.assertIn("FORMAL_PROOF_REVIEW_EVIDENCE_REQUIRED", result["reason_codes"])

    def test_theory_requires_live_review_for_a_new_gate_record(self):
        card, raw, _ = self.formal_packet()
        result = self.gate(card, raw, "INCONCLUSIVE")
        self.assertIn("FORMAL_REVIEW_VALIDATOR_REQUIRED", result["reason_codes"])

    def test_reviewed_formal_obligations_have_a_real_pass_path(self):
        card, raw, reviewer = self.formal_packet()
        result = self.gate(card, raw, "PASS", formal_review_validator=reviewer)
        self.assertEqual(result["metrics"]["verified_obligations"], 1)
        self.assertEqual(result["metrics"]["strict_improvements"], 1)

    def test_equivalent_theorem_does_not_pass_as_a_strict_contribution(self):
        card, raw, reviewer = self.formal_packet(strict=False)
        result = self.gate(card, raw, "KILL", formal_review_validator=reviewer)
        self.assertIn("KNOWN_THEOREM_ALREADY_SUFFICIENT", result["reason_codes"])

    def test_theory_admitted_axiom_cannot_close_a_proof_obligation(self):
        card, raw, reviewer = self.formal_packet()
        row = raw["obligations"][0]
        review = C.load_file(C.verify_ref(self.f.root, row["review_ref"]))
        checker = C.load_file(C.verify_ref(self.f.root, review["checker_output_ref"]))
        checker["admitted_axioms"] = ["unproved-essential-lemma"]
        review["checker_output_ref"] = write(self.f.root, review["checker_output_ref"]["path"], checker)
        row["review_ref"] = write(self.f.root, row["review_ref"]["path"], review)
        result = self.gate(card, raw, "INCONCLUSIVE", formal_review_validator=reviewer)
        self.assertIn("FORMAL_PROOF_NOT_CLOSED", result["reason_codes"])

    def test_theory_thresholds_cannot_disable_originality_or_consequence(self):
        card = self.parent("theory", {"min_obligations":1, "min_strict_improvements":0,
                                      "min_consequential_obligations":0})
        ref = write(self.f.root, "problems/disabled-theory.json", card)
        with self.assertRaises(C.Failure):
            self.f.transition("freeze_parent_problem", {"parent_problem_ref":ref})

    def test_arxiv_and_final_publication_are_one_major_collision(self):
        pref = freeze_parent(self.f, self.parent("natural_failure"))
        self.f.transition("record_natural_gate_0", {"natural_gate_0_ref":census(self.f, pref)})
        self.f.transition("research_candidate", {"candidate_ref":candidate(self.f)})
        work = copy.deepcopy(sample_artifacts()["work-record"])
        work.update(work_id="arxiv:2401.00001v1", evidence_refs=[self.f.source])
        arxiv = write(self.f.root, "evidence/arxiv-collision.json", work)
        self.f.transition("importance_decision", {"importance_decision_ref":importance(self.f, work_refs=[arxiv])})
        source = write(self.f.root, "evidence/identity-link.json", {
            "capture_format":"work-identity-link-v1", "relation":"same_work", "primary_source":True,
            "identifiers":["arxiv:2401.00001", "doi:10.1234/example"],
            "source_url":"https://arxiv.org/abs/2401.00001", "locator":"DOI field", "excerpt":"Published version DOI"})
        work.update(work_id="doi:10.1234/example", version="published", identity_links=[{
            "from_id":"arxiv:2401.00001", "to_id":"doi:10.1234/example", "relation":"same_work", "evidence_refs":[source]}])
        final = write(self.f.root, "evidence/published-collision.json", work)
        result = self.f.transition("importance_decision", {
            "importance_decision_ref":importance(self.f, work_refs=[final])})
        self.assertEqual(result["state"]["current_route"], "develop_candidate")
        self.assertEqual(result["state"]["major_collision_work_ids"], ["doi:10.1234/example"])

    def empirical_packet(self, kind):
        # Reuse the existing native-evaluation engineering fixtures and host
        # double. No benchmark sample or scoring function is constructed here.
        from test_native_eval import native_contract_fixture, native_run_fixture, trusted_engineering_replay
        import _native_eval as N
        card = self.parent(kind)
        protocol = self.f.protocol()
        native = native_contract_fixture(self.f.root, protocol)
        protocol["protocol_digest"] = C.protocol_hash(protocol)
        route = {"efficiency":"performance_frontier", "systems":"performance_frontier",
                 "phenomenon":"replicated_observations", "data":"data_coverage"}[kind]
        card["benchmark_contract"].update(benchmark_id=native["benchmark_id"], version=native["benchmark_revision"],
            evaluation_split=native["split"], primary_metric=native["primary_metric"],
            scorer_identity=native["scorer"]["identity"], scorer_revision=native["scorer"]["revision"],
            resource_constraints={"seconds":5})
        card["consequence"]["endpoint"] = "scope"
        card["strong_simple_alternative"] = protocol["contrasts"]["baseline"]
        card["simple_alternatives"] = [card["strong_simple_alternative"]]
        thresholds = {"performance_frontier":{"min_observations":2, "min_mean_resource_gap":0.2,
                          "max_quality_shortfall":0.01, "min_mean_consequence":0.1, "min_unresolved_fraction":0.5},
            "replicated_observations":{"min_observations":2, "min_independent_replications":2,
                          "min_mean_effect":0.1, "min_mean_consequence":0.1, "min_unresolved_fraction":0.5},
            "data_coverage":{"min_observations":2, "min_coverage_gap":0.2,
                          "min_mean_consequence":0.1, "min_unresolved_fraction":0.5}}
        card["value_gate"] = {"route":route, "thresholds":thresholds[route], "evidence_refs":[self.f.source],
                              "resource_metric":"seconds", "required_quality":0.75, "effect_direction":"maximize"}
        if route == "data_coverage":
            card["value_gate"]["coverage_definition_ref"] = write(self.f.root, "evidence/engineering-coverage-definition.json", {
                "capture_format":"native-coverage-definition-v1", "benchmark_id":native["benchmark_id"],
                "benchmark_version":native["benchmark_revision"], "source_url":"https://example.org/existing-engineering-fixture",
                "coverage_meaning":"Engineering fixture tests binding to a captured native rule, not scientific dataset coverage",
                "source_evidence_refs":native["published_source_refs"],
                "qualification":{"role":"baseline", "rule":native["baseline_qualification"]}})
        manifests, _ = self.f.runs(protocol)
        pref = write(self.f.root, "problems/typed.json", card)
        protocol_ref = write(self.f.root, "evidence/native-value-protocol.json", protocol)
        rows, receipts, outputs, run_refs, proofs = [], [], [], [], [protocol_ref]
        if route == "data_coverage": proofs.append(card["value_gate"]["coverage_definition_ref"])
        live = trusted_engineering_replay(self.f.root)
        for manifest in manifests:
            manifest["baseline_qualified"] = False
            native_run_fixture(self.f.root, protocol, manifest)
            run_ref = write(self.f.root, "evidence/value-runs/"+manifest["run_id"]+".json", manifest)
            run_refs.append(run_ref); proofs.append(run_ref)
            verified = N.verify_run(self.f.root, protocol, manifest, live)
            proofs += verified["proof_refs"]
            def metric(name, role="treatment"):
                return {"kind":"metric", "run_id":manifest["run_id"], "metric":name, "arm_role":role}
            bindings = {"downstream_loss":metric("scope"), "alternative_solves":{
                "kind":"qualification", "run_id":manifest["run_id"], "role":"baseline"}}
            row = {"observation_id":manifest["run_id"], "population_id":card["population_id"],
                "endpoint":card["consequence"]["endpoint"], "strong_simple_alternative":card["strong_simple_alternative"],
                "downstream_loss":0.25, "alternative_solves":False, "measurement_bindings":bindings}
            if route == "performance_frontier":
                row.update(resource=10, resource_limit=5, quality=0.75)
                bindings.update(resource={"kind":"resource", "run_id":manifest["run_id"],
                                          "metric":"seconds", "arm_role":"treatment"}, quality=metric("accuracy"))
            elif route == "replicated_observations":
                row.update(observed_metric=0.75, reference_metric=0.0, replication_id=manifest["run_id"])
                bindings.update(observed_metric=metric("accuracy"), reference_metric=metric("accuracy", "baseline"))
            else:
                row["covered"] = False
                bindings["covered"] = {"kind":"qualification", "run_id":manifest["run_id"], "role":"baseline"}
            source = write(self.f.root, "evidence/value-observations/"+manifest["run_id"]+".json", row)
            rows.append({**row, "source_ref":source}); proofs.append(source)
            for receipt_ref in manifest["native_eval_receipts"].values():
                receipts.append(receipt_ref)
                outputs.append(C.load_file(C.verify_ref(self.f.root, receipt_ref))["native_output_ref"])
        raw = {"sampling_kind":route, "observations":rows, "benchmark_id":native["benchmark_id"],
            "benchmark_version":native["benchmark_revision"], "evaluation_split":native["split"],
            "primary_metric":native["primary_metric"], "scorer_identity":native["scorer"]["identity"],
            "scorer_revision":native["scorer"]["revision"], "native_output_refs":outputs,
            "native_eval_receipt_refs":receipts, "native_protocol_ref":protocol_ref,
            "native_run_manifest_refs":run_refs}
        proofs = [item for _,item in sorted({(p["path"],p["sha256"]):p for p in proofs}.items())]
        attestation = write(self.f.root, "evidence/value-attestation.json", {
            "capture_format":"value-gate-attestation-v1", "status":"verified",
            "parent_problem_sha256":pref["sha256"], "observations_digest":digest(raw),
            "observations":rows, "proof_refs":proofs})
        raw["native_eval_attestation_ref"] = attestation
        def validator(root, parent, observations):
            return I.native_value_gate_validator(root, parent, observations, replay_context=live)
        return card, raw, validator

    def test_native_resource_frontier_can_pass_for_efficiency_and_systems(self):
        for kind in ("efficiency", "systems"):
            with self.subTest(contribution_type=kind):
                card, raw, validator = self.empirical_packet(kind)
                result = self.gate(card, raw, "PASS", receipt_validator=validator)
                self.assertEqual(result["metrics"]["observations"], 2)
                self.assertEqual(result["metrics"]["mean_resource_gap"], 1.0)

    def test_phenomenon_requires_two_independent_retained_replications(self):
        card, raw, validator = self.empirical_packet("phenomenon")
        result = self.gate(card, raw, "PASS", receipt_validator=validator)
        self.assertEqual(result["metrics"]["independent_replications"], 2)

    def test_data_gate_uses_native_coverage_evidence(self):
        card, raw, validator = self.empirical_packet("data")
        result = self.gate(card, raw, "PASS", receipt_validator=validator)
        self.assertEqual(result["metrics"]["coverage_gap"], 1.0)

    def test_numeric_value_gate_without_native_receipts_is_inconclusive(self):
        card, raw, _ = self.empirical_packet("efficiency")
        raw.pop("native_eval_receipt_refs")
        result = self.gate(card, raw, "INCONCLUSIVE")
        self.assertIn("NATIVE_EVAL_RECEIPTS_REQUIRED", result["reason_codes"])

    def test_saved_native_receipts_cannot_authorize_a_new_numeric_screen(self):
        card, raw, _ = self.empirical_packet("efficiency")
        result = self.gate(card, raw, "INCONCLUSIVE", receipt_validator={"verified":True})
        self.assertIn("NATIVE_EVAL_RECEIPT_VALIDATOR_REQUIRED", result["reason_codes"])

    def test_native_measurement_cannot_be_replaced_by_a_consistent_summary(self):
        card, raw, validator = self.empirical_packet("efficiency")
        row = raw["observations"][0]; row["quality"] = 0.99
        row["source_ref"] = write(self.f.root, row["source_ref"]["path"], {k:v for k,v in row.items() if k!="source_ref"})
        attestation_ref = raw.pop("native_eval_attestation_ref")
        attestation = C.load_file(C.verify_ref(self.f.root, attestation_ref))
        attestation.update(observations=raw["observations"], observations_digest=digest(raw))
        attestation["proof_refs"] = [p for p in attestation["proof_refs"] if p["path"]!=row["source_ref"]["path"]]+[row["source_ref"]]
        raw["native_eval_attestation_ref"] = write(self.f.root, attestation_ref["path"], attestation)
        with self.assertRaises(C.Failure) as raised:
            self.gate(card, raw, "PASS", receipt_validator=validator)
        self.assertEqual(raised.exception.code, "NATIVE_VALUE_MEASUREMENT_DISAGREEMENT")

    def test_formal_history_replays_without_running_a_checker_again(self):
        card, raw, _ = self.formal_packet()
        result = self.gate(card, raw, "PASS", historical=True)
        self.assertEqual(result["outcome"], "PASS")

    def test_failed_control_cannot_replace_the_strong_simple_alternative(self):
        card, raw, validator = self.empirical_packet("efficiency")
        row = raw["observations"][0]
        row["measurement_bindings"]["alternative_solves"]["role"] = "shuffled"
        row["source_ref"] = write(self.f.root, row["source_ref"]["path"], {k:v for k,v in row.items() if k!="source_ref"})
        attestation_ref = raw.pop("native_eval_attestation_ref")
        attestation = C.load_file(C.verify_ref(self.f.root, attestation_ref))
        attestation.update(observations=raw["observations"], observations_digest=digest(raw))
        attestation["proof_refs"] = [p for p in attestation["proof_refs"] if p["path"]!=row["source_ref"]["path"]]+[row["source_ref"]]
        raw["native_eval_attestation_ref"] = write(self.f.root, attestation_ref["path"], attestation)
        with self.assertRaises(C.Failure) as raised:
            self.gate(card, raw, "PASS", receipt_validator=validator)
        self.assertEqual(raised.exception.code, "VALUE_GATE_STRONG_ALTERNATIVE_BINDING_REQUIRED")

    def test_data_coverage_needs_an_existing_published_coverage_definition(self):
        card, _, _ = self.empirical_packet("data")
        card["value_gate"].pop("coverage_definition_ref", None)
        ref = write(self.f.root, "problems/no-coverage-definition.json", card)
        with self.assertRaises(C.Failure) as raised:
            self.f.transition("freeze_parent_problem", {"parent_problem_ref":ref})
        self.assertEqual(raised.exception.code, "PUBLISHED_NATIVE_COVERAGE_DEFINITION_REQUIRED")

    def test_formal_proof_cannot_satisfy_a_different_frozen_statement(self):
        card, raw, reviewer = self.formal_packet()
        row = raw["obligations"][0]
        statement = write(self.f.root, "evidence/unrelated-statement.json", {"statement":"unrelated engineering fixture"})
        row["statement_ref"] = statement
        review = C.load_file(C.verify_ref(self.f.root, row["review_ref"]))
        checker = C.load_file(C.verify_ref(self.f.root, review["checker_output_ref"]))
        checker["statement_sha256"] = statement["sha256"]
        review["statement_sha256"] = statement["sha256"]
        review["checker_output_ref"] = write(self.f.root, review["checker_output_ref"]["path"], checker)
        row["review_ref"] = write(self.f.root, row["review_ref"]["path"], review)
        comparison = C.load_file(C.verify_ref(self.f.root, row["comparison_ref"]))
        comparison["review_ref"] = row["review_ref"]
        row["comparison_ref"] = write(self.f.root, row["comparison_ref"]["path"], comparison)
        attestation_ref = raw.pop("formal_review_attestation_ref")
        attestation = C.load_file(C.verify_ref(self.f.root, attestation_ref))
        updated = {r["path"]:r for r in C.payload_refs(raw)+[review["checker_output_ref"]]}
        attestation["proof_refs"] = [updated.get(r["path"],r) for r in attestation["proof_refs"]]+[statement]
        attestation["observations_digest"] = digest(raw)
        raw["formal_review_attestation_ref"] = write(self.f.root, attestation_ref["path"], attestation)
        def reviewer(root, parent, observations, report):
            return {"status":"verified", "obligation_ids":["lemma-1"],
                    "proof_refs":attestation["proof_refs"], "attestation_ref":raw["formal_review_attestation_ref"]}
        result = self.gate(card, raw, "INCONCLUSIVE", formal_review_validator=reviewer)
        self.assertIn("FORMAL_STATEMENT_NOT_FROZEN", result["reason_codes"])


if __name__ == "__main__":
    unittest.main()
