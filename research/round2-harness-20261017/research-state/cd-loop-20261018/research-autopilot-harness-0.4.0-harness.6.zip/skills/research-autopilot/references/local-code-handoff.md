# Explicit Web-code handoff to the Local controller

The Local role is the user's control/supervision agent. Restore existing authorized
SSH targets before choosing workload placement, and fetch/pull or transfer pinned
code to the actual GPU execution machine under local-execution.md. The harness
details below apply when that full runtime is selected; they do not require a new
controller for direct SSH supervision or move GPU workloads onto the user's laptop.


Apply this contract whenever Web generates/updates experiment code, evaluation
adapters or a complete design for Local execution. This is part of the existing
code/G01/repository handoff, not a separate skill, scientific gate or execution
service. Read method-verification.md, repository-round-trips.md and the existing
E01–E05/harness contracts for their authoritative prerequisites.

Contents: [project entry](#web-must-deliver-an-explicit-local-entry),
[guide contents](#project-guide-contents), [downloads](#dataset-and-model-downloads),
[pre-run calibration](#pre-run-calibration-and-debug-entry),
[Local order](#local-follows-the-pinned-guide),
[debug routing](#debug-decision-table), [readback](#delivery-and-readback).

## Web must deliver an explicit Local entry

Deliver the following with the actual code/config/design to the selected project's
`main`. Use these default paths, or explicitly map the project's existing equivalent
paths. Preserve existing README/AGENTS instructions and unrelated work; do not
silently create a second competing entry. Honor the authorized write scope.

| Project file | Required direct pointer and purpose |
|---|---|
| `README.md` | A visible **Local Codex: start here** section links the Local guide and current round handoff; include generation/acceptance status. |
| `AGENTS.md` | The applicable agent instructions explicitly require reading the Local guide and round handoff at the delivered revision before setup, acceptance, execution or repair. Preserve existing instructions; add the scoped section when permitted. |
| `LOCAL_AGENT_RUNBOOK.md` | The project-specific guide, based on the bundled [authoring template](../assets/templates/local-agent-runbook.md), gives all required dataset/model download commands, ordered execution, outputs, failure diagnosis and return actions below. README/AGENTS also link its download section directly. |
| `rounds/ROUND/WEB_HANDOFF.md` | The immutable round entry links selected math/selection evidence, actual source/configs, full G01 coverage/design, native/harness plans, Local acceptance tasks, the guide and all known gaps. Retain prior rounds. |

The guide and entry must link **actual files and sections**, not just say “use the
skill”, “run tests” or “debug if needed”. Link every selected method/benchmark to
its adapter/config, comparison obligations and verification record. Do not require
a new round/discovery cycle to add a missing guide to an otherwise valid handoff.

These paths describe files Web must generate in the research project. The template
bundled with this skill is not already that project's guide or a tested run script.
If a required entry cannot be written within actual capability/scope, keep its
concrete content and name the missing pointer; do not claim the handoff complete.

## Project guide contents

Populate the guide from inspected code and the saved project brief, and keep it
consistent with the current round's records. Include:

1. **Identity and reading map.** Project/round/candidate IDs, the delivered revision
   resolved from the later receipt, Web's `generated_unexecuted` status, source and
   design refs, pending Local acceptance, and exact links to the plan, math-to-code
   mapping, benchmark coverage and current ledger. A file cannot contain its own
   future commit SHA; the receipt supplies it after publication.
2. **Host/path map.** The user's computer owns Local Codex, SSH control and the
   authenticated delivery checkout. The separate Linux GPU host owns runtime,
   Conda, tests, workloads and logs. Source the SSH alias, local delivery root,
   remote project/runtime/interpreter/Conda roots, data/model caches, GPU inventory
   and budgets. Bind code/config and placement to step 1's current single-device,
   multi-device or multi-host allocation, topology and CPU/RAM/I/O envelope; a
   cluster is not inferred from old access. Missing facts stay named pending Local restoration; do not invent
   paths or require remote Codex/GPT/GitHub credentials.
3. **Ordered command cards.** For source staging, native environment preparation,
   all required dataset/model acquisition and integrity checks,
   software/semantic acceptance, official native-interface qualification, design
   acceptance, scientific dispatch, monitoring/resume and result collection, give
   the host, exact working directory/interpreter, real command/argv or pinned plan,
   dependencies, expected output paths and acceptance/failure action. Derive CLI
   flags from actual entry points, never guessed `train.py`/`run_round` scripts.
   All executable project commands belong to admitted `run_harness.py` tasks on
   the GPU host; controller reading/SSH/file-transfer/Git operations remain distinct.
4. **Method/benchmark matrix.** For each agreed benchmark/split/native scorer and
   selected method, point to data and adapter entry, the adaptive development
   envelope or frozen confirmation parameters as applicable,
   strongest baseline/controls, resource/dependency envelope, output/denominator
   and required comparison. Separate software acceptance from the complete
   scientific queue; no smoke/quick test can replace its coverage.
5. **Expected evidence and stopping conditions.** Give precise harness/attempt
   stdout/stderr, status/context/receipt, prediction/checkpoint, native replay,
   E04 and review-packet locators. Runtime-generated attempt paths are resolved
   from actual receipts; do not fabricate UUIDs or assume logs exist before a run.
   State dev/confirmation and finite retry/tuning/total bounds. Apply the owner's
   soft-report/up-to-24-hour Local policy: inspect outer and inner timeouts, do not
   derive them from report cadence, preserve actual cumulative bounds/carryover.
6. **Project-specific debug routing.** Instantiate the decision table below with
   actual relevant source files/functions, config keys, logs and diagnostics.
   For each failure, explain what to read, which hypothesis distinguishes it,
   what repair is within scope and which checks must pass after the change.
   State Local's autonomous development envelope: permitted semantic repairs,
   tunable keys/bounds or bounded range-selection rules, dev-only selection,
   fair baseline tuning, calibration and pending-queue replanning, cumulative
   ceilings and changes requiring human review. Initial estimates/settings can
   evolve within that envelope; each actual attempt retains its effective
   parameters and version. Confirmation remains separately frozen.
   Include the pre-run entry below: actual calibration/diagnosis/recheck commands,
   per-task repair ceilings and independent next-task placement. Deliver bounded
   worker ownership and CPU/GPU queues before dispatch, not after a failure.
7. **Return instructions.** Explain collection over SSH, file identity checks,
   actual execution SHA/dirty patch, all trials and unfinished comparisons, the
   result-packet path, authorized GitHub/HF destinations, push/readback and the
   next Web locator. Do not silently choose a new repo or upload secrets/data.

Copy no unresolved authoring placeholders into purported ready commands. Unknown
host facts, hardware measurements or future passed tests do not block truthful
Web source delivery, but the guide must identify the exact Local resolution step
and keep the affected launch/acceptance pending. Distinguish source-inspected
commands from commands actually executed; Web never fabricates passed receipts.

## Dataset and model downloads

Include a **Download datasets and models** section in the project guide, linked
directly from README/AGENTS and the round handoff. Supply exact version-matched
commands for every input of the selected methods, strongest baselines, controls
and native evaluators. Bare URLs/repo names, “download the data/models” or an
implicit first-inference download are insufficient.

| Required card | Actual sourced contents |
|---|---|
| Complete inventory and consumers | Every benchmark/config/split and required method/baseline/scorer/reward/judge/embedding/perceptual model. Include loader-required weights, tokenizer/processor/config, adapters, shard index and all referenced shards. Shared assets may have one card listing all consumers. |
| Identity and acquisition | Official URL/repo ID/type, full immutable revision or release/checksum, required files/config/splits, host/cwd/Conda/tool version, exact download argv or inspected official script, destination/cache, extraction/native builder and consumed config/loader keys. Input sources are distinct from output GitHub/HF targets. |
| Capacity and recovery | Sourced size/disk requirements or explicitly unmeasured estimates, network/time allowance, dependencies and exclusive cache-write keys. Reuse matching complete caches; preserve partial downloads and use supported bounded resume/retry. Do not wipe a live cache or substitute another asset. |
| Local verification | Required file/shard/native-split identities, upstream checksum/manifest when available, actual verification command, logs and observed bytes/digests/revision. A local digest records identity, not an invented upstream checksum. HTML errors, LFS pointers and incomplete shards are not downloaded inputs. |
| Access-dependent action | Reuse existing access. For actual gated/private resources link the official access/license process and supported user-side authentication step. Keep credentials out of source and exported commands/logs; missing access leaves that asset and dependent work pending. |

Use the source's supported HF CLI/SDK, official archive/installer or native dataset
builder. A dataset repository download does not prove external builder inputs
were fetched or native eval data prepared: supply those steps too. File filters
must preserve the complete required set and released splits/labels/scoring.
Not uploading outputs to HF does not change the saved HF input-source mapping.

Inspect version-specific CLI/source documentation. HF skill metadata and docs
can differ on type flags; resolve against the actual pinned CLI/help instead of
guessing or upgrading. Official authoring shapes checked 2026-10-06:

```bash
hf download MODEL_REPO_ID --revision FULL_COMMIT_SHA --local-dir MODEL_DIR
hf download DATASET_REPO_ID --repo-type dataset --revision FULL_COMMIT_SHA --local-dir DATASET_DIR
```

Fill actual IDs, full revisions, paths and necessary filters before delivery.
When supported, `hf cache verify` checks a revision/cache or local directory;
use missing-file rules appropriate to a full snapshot or the required subset.
Sources: [official HF CLI](https://huggingface.co/docs/huggingface_hub/guides/cli)
and [download/revision guide](https://huggingface.co/docs/huggingface_hub/guides/download).
These shapes are not already runnable project commands or completed downloads.

Web source-reviews and supplies concrete cards with acquisition pending. Local
downloads/extracts/verifies through admitted remote harness preparation tasks,
normally requesting zero GPUs, under actual CPU/RAM/disk/cache and cumulative
bounds. Independent ready checks may overlap; asset-dependent tasks wait for
their required inputs. Download success is not code/design/scorer qualification
or a scientific PASS. Do not silently fetch an untracked latest revision later.

## Pre-run calibration and debug entry

Before the full comparison, deliver a populated **Calibrate, debug, then dispatch**
section in the project's runbook, linked from README/AGENTS and the round handoff.
Provide exact native config keys and actual implemented commands for inventory,
software/native qualification, bounded performance trials, diagnostics, repaired
rechecks and dispatch. Inspect source/help for each flag; no generic `--autobatch`,
`--retry-failed` or `--skip` service is supplied by this skill.

Use [dependency-resource-scheduling.md](dependency-resource-scheduling.md)'s
hardware-bound placement and calibration procedure. Separate inference batching
from training microbatch/effective optimizer batch; retain sampling/RNG, full native
coverage and fair baseline conditions. Let Local choose stable measured throughput
within the saved adaptive envelope, requalify changed properties and freeze fresh
confirmation. Calibration uses representative released native development inputs,
including relevant worst-shape cases; it is not a substitute scientific comparison.

The existing scheduler supports these command shapes **on each actual execution
host**, with that host's resolved paths/interpreter and existing authorized scope:

```bash
python3 "$SKILL_DIR/scripts/run_harness.py" --inspect-host > "$HOST_INVENTORY_FILE"
python3 "$SKILL_DIR/scripts/run_harness.py" "$CALIBRATION_DRAFT" \
  --root "$PROJECT_DIR" --freeze > "$CALIBRATION_PLAN"
python3 "$SKILL_DIR/scripts/run_harness.py" "$CALIBRATION_PLAN" --root "$PROJECT_DIR"
python3 "$SKILL_DIR/scripts/run_harness.py" "$CALIBRATION_PLAN" \
  --root "$PROJECT_DIR" --execute --approved-plan-digest "$CALIBRATION_DIGEST"
python3 "$SKILL_DIR/scripts/run_harness.py" "$CALIBRATION_PLAN" \
  --root "$PROJECT_DIR" --status
```

Web fills the inventory/plan paths and source-inspected native trial commands;
Local derives the canonical digest from the validated plan, checks remaining
authority/resources and binds actual qualification outputs before the main plan.
Freezing/validation is not approval or a passing receipt; `--status` is retained
state, not a fresh liveness probe. Future output hashes cannot be prefilled.
Parameter choices and semantic repairs require new pinned pending plans/configs,
not rewriting live jobs. Preserve all cumulative limits and actual attempt history.

Set finite per-task diagnosis/time/attempt bounds and supported escalation rules.
After exhausted supported repairs, retain the task and missing coverage as pending,
release only reconciled resources, and take the next independent ready task.
Do not make every idea depend on the first idea's acceptance; shared environment,
asset or scorer failures block their actual consumers, not unrelated work. If no
eligible task remains, report the real blocker and next action rather than invent
experiments, waive checks or keep blind retries running.

## Local follows the pinned guide

1. Fetch the delivered `main` commit into a compatible isolated checkout; retain
   local changes and active attempts. Read applicable `AGENTS.md`, the linked
   `LOCAL_AGENT_RUNBOOK.md` and `WEB_HANDOFF.md` at **that exact commit**. Restore
   ledger, selected evidence, existing authority, host paths and cumulative bounds.
   A README alone, stale guide or mutable latest-main URL is not the pinned plan.
2. Check the linked real sources/CLI interfaces and restore missing sourced host
   facts before interpreting a command card as launch-ready. Stage/check the exact
   project and runtime bytes on the GPU host; preserve the local/remote path map.
3. Start the guide's admitted setup and software/native acceptance tasks over SSH
   through the remote harness. Retain actual outputs and semantic review. These
   checks qualify their stated software/interface properties, not method benefit.
   First acquire/extract/verify the complete required input inventory for dependent
   checks and bind its actual model/data/scorer paths to the runtime config.
4. If acceptance fails, follow the corresponding guide/debug row. Repair only a
   supported cause within existing development scope and budget; retain failed
   attempts. Recheck affected code/native semantics and versioned design before
   `--before experiment-design` / `--before dispatch` and all scientific gates.
   Do not disable checks, weaken the scorer or reduce selected comparisons to pass.
   Apply its finite repair/park rule and keep independent qualified tasks moving;
   a parked task remains an incomplete obligation, not a scientific rejection.
5. Dispatch the approved complete scientific tasks with actual dependency/resource
   admission. Monitor real remote identities; reconcile after lost SSH acknowledgment
   before retrying. Continue independent ready tasks when another task is blocked.
6. Perform scoped E04 after results, collect a coherent window/final snapshot and
   return the verified GitHub result locator. Unfinished approved work keeps stable
   IDs and cumulative limits across windows. New scientific directions or material
   design changes follow the existing consolidated human decision.

## Debug decision table

Use the project's exact source/config/log/diagnostic pointers for every row. If a
needed diagnostic is not implemented or supported, retain that gap and prepare a
bounded design; do not invent a passing command or an automatic tuning service.

| Observation | Read and distinguish | Allowed next action and requalification |
|---|---|---|
| Import/path/Conda/CUDA error | Exact attempt stderr, interpreter/environment receipt, dependency pins and host/path map; distinguish wrong environment/path from unsupported dependency. | Fix the identified native setup/path within scope, isolate changes from active jobs, rerun affected acceptance. No Docker workaround or blind global upgrade. |
| Download/access/checksum or missing shard/split | Actual download stderr/receipt, official URL/repo/revision, access status, required file manifest and loader/cache/config paths. | Distinguish permission, wrong source/version/path, partial/corrupt download and incomplete components. Use supported bounded recovery, preserve cache users/evidence and recheck the same required inputs. No substitute dataset/model or guessed checksum. |
| OOM, foreign GPU use or resource block | Attempt stderr/context, live device/process identity, declared peaks/headroom and effective config; distinguish contention from workload requirement. | Reconcile reservations and requalify the relevant memory profile. Within the recorded development envelope Local may calibrate microbatch/inference batching and loader settings autonomously through new pinned trials; preserve effective optimizer batch or review its change, sampling/RNG and fair controls. Review/version result-affecting changes and independently confirm after freezing; never mutate live attempts, silently halve settings or reset budgets. |
| Shape/mask/gradient/NaN or wrong behavior | Actual failing input/output identity, traceback, math-to-code lines, preprocessing/state/numerical/config choices. | Form a supported causal hypothesis, change that cause and rerun meaningful affected semantics. For eval use supplied native cases/actual outputs, not invented evaluation fixtures. |
| Scorer, sample IDs, zero scores or denominator mismatch | Native adapter/scorer entry, released sample/split IDs, raw predictions, exclusions, frozen metric and actual replay receipt. | Repair/qualify the actual native path and rerun affected scoring through the harness. Preserve prior outputs; do not relabel missing units, create proxy metrics or infer method failure. |
| Some scenes/datasets improve and others worsen | E04 record, comparable baseline/controls, effective parameters, uncertainty, successful/failed native dev cases and assumption/optimization evidence. | Compare competing causes before fair bounded development-only tuning. Freeze the selected policy and independently confirm; do not tune on held-out outcomes, assume tuning is the sole cause or claim universal efficacy. |
| SSH timeout, lost launch receipt or stale status | Same remote host, saved batch/digest, PID/start-time/boot tuple, locks and actual attempt receipts. `--status` is retained state, not a fresh liveness probe. | Reconcile first; use same compatible IDs/bounds after real recovery. Never launch a duplicate queue, delete locks/state or equate a controller PID with a remote task. |
| Soft report boundary or unfinished comparison | Window report, live job/checkpoint identities, completed/remaining units and total deadlines. | Snapshot/report and carry eligible unchanged work forward. Continue eligible execution across reports within the remaining up-to-24-hour cycle. Do not copy report cadence into outer/inner timeouts or kill healthy tasks. No budget reset or verdict; actual hard bounds still apply. |
| GitHub write/readback failure | Actual repo/main parent, provider operation/history/content and selected delivery checkout. | Preserve concrete files/packet, reconcile before retry and use one integration writer. Do not rerun experiments, force-push or call another branch/PR completed Web delivery. |

Each actual repair retains an existing E04/debug note: observation and versions,
root-cause hypotheses/evidence, source/config diff, diagnostic/recheck refs,
all attempts/costs, invalidated evidence, child-protocol/confirmation obligations
and next action. Implementation-only repair must still preserve the reviewed
construction. A changed mechanism, scientific scope or tuning policy returns to
its existing review/decision contract, not an improvised Local new idea.

## Delivery and readback

Before claiming the Web handoff complete, inspect the actual delivered tree:
README and applicable AGENTS pointers resolve, guide/round links exist, commands
match inspected source interfaces, and the complete requested benchmark/comparison
matrix is present. This is source/navigation review, not Web software execution.
Reconcile every model/data/scorer input in the coverage/configs against its
download/access/cache/verification card; an omitted input leaves the guide incomplete.
Publish the scoped work to `main` through one writer and read back these entry
files plus code/config/design at the exact delivered commit.

Return a directly usable Local instruction with actual values:

```text
Use research-autopilot as Local Codex on my computer, controlling our GPU over SSH.
Repo: ACTUAL_PROJECT_REPO; branch: main; delivered commit: ACTUAL_READBACK_COMMIT.
At that commit read ACTUAL_APPLICABLE_AGENTS_PATH, then ACTUAL_LOCAL_GUIDE_PATH
and ACTUAL_ROUND_WEB_HANDOFF_PATH. Follow the guide's ordered acceptance commands,
debug rows and complete approved benchmark queue; retain actual logs and E04.
Web source/design is generated_unexecuted; qualify it before scientific dispatch.
Reuse our SSH/Conda, authorization and total limits. Return the exact verified
result repo/commit/packet locator at our reporting cadence; preserve live jobs.
```

Replace locator values only after actual push/readback. Do not call the skill's
own repo/runbook template the selected scientific project's handoff. A guide and
AGENTS instruction are explicit agent directions, not proof that a particular
client loaded them or a system-level bypass prevention service was installed.
