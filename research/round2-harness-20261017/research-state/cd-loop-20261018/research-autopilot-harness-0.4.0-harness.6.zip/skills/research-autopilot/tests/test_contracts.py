import copy
import itertools
import json
import pathlib
import subprocess
import sys
import types
import unittest
from fixtures import C, DATE, DIGEST, PACKAGE, ProjectFixture, canonical, digest, env, ref, sample_artifacts, state, write

class SchemaTests(unittest.TestCase):
    def test_valid_and_invalid_example_for_every_registered_schema(self):
        samples=sample_artifacts()
        extra = {}
        from test_native_eval import schema_contract_examples as native_examples
        from test_runner import schema_contract_examples as runner_examples
        from test_supervisor import schema_contract_examples as supervisor_examples
        from test_session_records import schema_contract_examples as session_examples
        from test_harness import schema_contract_examples as harness_examples
        from test_experiment_contract import schema_contract_examples as experiment_examples
        for examples in (native_examples(), runner_examples(), supervisor_examples(), session_examples(), harness_examples(), experiment_examples()):
            extra.update(examples)
        samples.update({name: item[0] for name, item in extra.items()})
        registered={p.name.removesuffix(".schema.json") for p in (PACKAGE/"schemas").glob("*.schema.json")}
        self.assertEqual(set(samples),registered)
        bad_fields={"research-intake":"entry_inference","research-state":"entry_origin","authority-request":"operation_id",
            "approval-event":"request_digest","authority-grant":"expires_at","ledger-event":"sequence","ledger-anchor":"head_digest",
            "search-run":"raw_capture_refs","work-record":"work_id","evidence-unit":"locators","evidence-snapshot":"artifact_refs",
            "idea-atom":"unique_prediction","collision-decision":"coverage","gate-a-protocol":"criteria",
            "full-validation-protocol":"criteria","run-manifest":"raw_output_refs","gate-a-decision":"outcome",
            "full-validation-decision":"outcome","redaction-event":"old_digest","handoff":"allowed_claims"}
        bad_fields.update({"commit-journal":"transaction_digest","backup-manifest":"source_head"})
        bad_fields.update({"parent-problem-card":"natural_failure","natural-gate-0":"observations_ref","importance-decision":"retained_problem"})
        bad_fields.update({name: item[1] for name, item in extra.items()})
        for name,value in samples.items():
            with self.subTest(schema=name):
                C.validate(value,name)
                broken=copy.deepcopy(value);broken.pop(bad_fields[name])
                with self.assertRaises(C.Failure):C.validate(broken,name)
                future=copy.deepcopy(value);future["schema_version"]="99.0.0"
                with self.assertRaises(C.Failure):C.validate(future,name)

    def test_duplicate_json_keys_do_not_silently_replace_evidence(self):
        with self.assertRaises(C.Failure):C.parse_json('{"a":1,"a":2}')

    def test_nan_and_infinity_rejected(self):
        for value in ('NaN','Infinity','-Infinity'):
            with self.subTest(value=value),self.assertRaises(C.Failure):C.parse_json('{"n":'+value+'}')

    def test_yaml_duplicate_keys_and_unsafe_tags_rejected(self):
        f=ProjectFixture();self.addCleanup(f.close)
        for text in ('a: 1\na: 2\n','!!python/object/apply:os.system ["true"]','a: .nan'):
            path=f.root/"unsafe.yaml";path.write_text(text)
            with self.subTest(text=text),self.assertRaises(C.Failure):C.load_file(path)

    def test_repair_state_requires_typed_suspension(self):
        s=state();s.update(current_route="repair_evidence",suspension="oops")
        with self.assertRaises(C.Failure):C.validate(s)

    def test_active_writing_requires_full_validation(self):
        s=state();s.update(current_route="prepare_writing",lifecycle_phase="writing",writing_state="drafting")
        with self.assertRaises(C.Failure):C.validate(s)

    def test_confirmed_unknown_origin_is_invalid(self):
        v=sample_artifacts()["research-intake"];v["entry_inference"]={"value":"unknown","status":"confirmed","basis":["maybe"]}
        with self.assertRaises(C.Failure):C.validate(v)

class GateTests(unittest.TestCase):
    def setUp(self):self.f=ProjectFixture();self.addCleanup(self.f.close)
    def decide(self,p=None,effects=(0.25,0.25),runs=None,refs=None,gate="gate-a"):
        p=p or self.f.protocol(gate)
        if runs is None:runs,refs=self.f.runs(p,effects)
        else:
            refs=[write(self.f.root,r["path"],m) for m,r in zip(runs,refs)]
        return C.evaluate(self.f.root,p,runs,refs,gate)
    def test_strong_paired_effect_passes(self):self.assertEqual(self.decide()["outcome"],"PASS")
    def test_clean_indispensable_effect_below_threshold_kills(self):self.assertEqual(self.decide(effects=(0,0))["outcome"],"KILL")
    def test_threshold_equality_uses_frozen_inclusivity(self):
        p=self.f.protocol();self.assertEqual(self.decide(p,effects=(.125,.125))["outcome"],"PASS")
        p["criteria"][0]["inclusive"]=False;p["protocol_digest"]=C.protocol_hash(p)
        self.assertEqual(self.decide(p,effects=(.125,.125))["outcome"],"KILL")
    def test_adjacent_values_straddle_threshold(self):
        self.assertEqual(self.decide(effects=(.124,.124))["outcome"],"KILL")
        self.assertEqual(self.decide(effects=(.126,.126))["outcome"],"PASS")
    def test_uncertainty_crossing_threshold_is_inconclusive(self):
        p=self.f.protocol();p["criteria"][0]["uncertainty"]="normal";p["protocol_digest"]=C.protocol_hash(p)
        self.assertEqual(self.decide(p,effects=(0,.5))["outcome"],"INCONCLUSIVE")
    def test_oom_failed_controls_and_pre_freeze_results_are_inconclusive(self):
        p=self.f.protocol()
        for field,value,code in (("status","oom","INCOMPLETE_RUN"),("baseline_qualified",False,"BASELINE_UNQUALIFIED"),
              ("positive_control_passed",False,"POSITIVE_CONTROL_FAILED"),("result_recorded_at",DATE,"RESULT_PRECEDES_FREEZE")):
            runs,refs=self.f.runs(p);runs[0][field]=value
            if field in {"baseline_qualified","positive_control_passed"}:
                raw=C.load_file(C.verify_ref(self.f.root,runs[0]["raw_output_refs"][0]));raw[field]=value
                runs[0]["raw_output_refs"]=[write(self.f.root,"raw/"+runs[0]["run_id"]+".json",raw)]
            result=self.decide(p,runs=runs,refs=refs)
            self.assertEqual(result["outcome"],"INCONCLUSIVE");self.assertIn(code,result["reason_codes"])
    def test_duplicate_run_and_seed_cannot_count_as_replications(self):
        p=self.f.protocol();runs,refs=self.f.runs(p)
        runs[1]=copy.deepcopy(runs[0]);runs[1]["run_id"]="different-id"
        raw=C.load_file(C.verify_ref(self.f.root,runs[1]["raw_output_refs"][0]));raw["run_id"]="different-id"
        runs[1]["raw_output_refs"]=[write(self.f.root,"raw/different-id.json",raw)]
        self.assertIn("DUPLICATE_RUN",self.decide(p,runs=runs,refs=refs)["reason_codes"])
    def test_run_order_does_not_change_decision_identity(self):
        p=self.f.protocol();runs,refs=self.f.runs(p)
        self.assertEqual(self.decide(p,runs=runs,refs=refs),self.decide(p,runs=runs[::-1],refs=refs[::-1]))
    def test_missing_seed_cannot_pass(self):
        p=self.f.protocol();runs,refs=self.f.runs(p,effects=(.25,))
        self.assertEqual(self.decide(p,runs=runs,refs=refs)["outcome"],"INCONCLUSIVE")
    def test_missing_raw_output_is_inconclusive(self):
        p=self.f.protocol();runs,refs=self.f.runs(p);C.verify_ref(self.f.root,runs[0]["raw_output_refs"][0]).unlink()
        self.assertEqual(self.decide(p,runs=runs,refs=refs)["outcome"],"INCONCLUSIVE")
    def test_raw_metrics_disagreement_is_inconclusive(self):
        p=self.f.protocol();runs,refs=self.f.runs(p);runs[0]["metrics"]["accuracy"]["treatment"]=1
        self.assertIn("RAW_MANIFEST_DISAGREEMENT",self.decide(p,runs=runs,refs=refs)["reason_codes"])
    def test_developmental_cannot_be_relabelled_confirmatory(self):
        p=self.f.protocol();runs,refs=self.f.runs(p);runs[0]["evidence_mode"]="developmental"
        self.assertIn("INELIGIBLE_EVIDENCE_MODE",self.decide(p,runs=runs,refs=refs)["reason_codes"])
    def test_fatal_resource_excess_kills(self):
        p=self.f.protocol();p["guardrails"]["seconds"]=1;p["protocol_digest"]=C.protocol_hash(p)
        self.assertEqual(self.decide(p)["outcome"],"KILL")
    def test_predeclared_severable_contrast_revises(self):
        p=self.f.protocol();r=copy.deepcopy(p["criteria"][0]);r.update(id="scope",metric="scope",indispensable=False)
        p["criteria"].append(r);p["prospective_child_hypothesis"]="Restrict to first regime";p["protocol_digest"]=C.protocol_hash(p)
        self.assertEqual(self.decide(p)["outcome"],"REVISE")
        p.pop("prospective_child_hypothesis");p["protocol_digest"]=C.protocol_hash(p)
        self.assertEqual(self.decide(p)["outcome"],"INCONCLUSIVE")
    def test_empty_criterion_group_cannot_vacuously_pass(self):
        p=self.f.protocol("full-validation");p["criteria"][0]["groups"]=[];p["protocol_digest"]=C.protocol_hash(p)
        self.assertEqual(self.decide(p,gate="full-validation")["outcome"],"INCONCLUSIVE")
    def test_undeclared_groups_cannot_bias_gate(self):
        p=self.f.protocol();runs,refs=self.f.runs(p);extra,extra_refs=self.f.runs(p,group="selected-lucky")
        self.assertEqual(self.decide(p,runs=runs+extra,refs=refs+extra_refs)["outcome"],"INCONCLUSIVE")
    def test_conflicting_valid_full_replication_kills(self):
        p=self.f.protocol("full-validation");p["required_groups"]=["main","heldout"];p["min_valid_runs"]=4
        p["inventory_run_ids"]=["p1-r1-heldout","p1-r1-main","p1-r2-heldout","p1-r2-main"]
        p["protocol_digest"]=C.protocol_hash(p);runs,refs=self.f.runs(p);extra,erefs=self.f.runs(p,effects=(0,0),group="heldout")
        self.assertEqual(self.decide(p,runs=runs+extra,refs=refs+erefs,gate="full-validation")["outcome"],"KILL")

class StateTests(unittest.TestCase):
    def setUp(self):self.f=ProjectFixture();self.addCleanup(self.f.close)
    def test_three_origins_keep_distinct_routes(self):
        for origin,route in (("I","explore_problem"),("M","audit_method"),("R","audit_rejection")):
            f=ProjectFixture(origin);self.addCleanup(f.close);self.assertEqual(C.project(f.root)[0]["current_route"],route)
    def test_transition_id_is_idempotent_and_cannot_be_reused(self):
        first=self.f.transition("evidence_repair",{"blocking_obligation_ids":["raw"]},tid="stable")
        self.assertEqual(self.f.transition("evidence_repair",{"blocking_obligation_ids":["raw"]},tid="stable",seq=1)["status"],"already_applied")
        with self.assertRaises(C.Failure):self.f.transition("explicit_stop",tid="stable",seq=1)
        self.assertEqual(C.project(self.f.root)[0]["sequence"],first["state"]["sequence"])
    def test_stale_concurrent_sequence_cannot_advance(self):
        self.f.transition("evidence_repair",{"blocking_obligation_ids":["raw"]})
        with self.assertRaises(C.Failure):self.f.transition("explicit_stop",seq=1)
    def test_project_lock_rejects_second_writer(self):
        with C.locked(self.f.root):
            with self.assertRaises(C.Failure):
                with C.locked(self.f.root):pass
    def test_whole_tail_deletion_detected_by_anchor(self):
        self.f.transition("evidence_repair",{"blocking_obligation_ids":["raw"]})
        ledger=self.f.root/"event-ledger.jsonl";ledger.write_text(ledger.read_text().splitlines()[0]+"\n")
        with self.assertRaises(C.Failure):C.project(self.f.root)
    def test_partial_final_event_is_not_recovered_silently(self):
        ledger=self.f.root/"event-ledger.jsonl";ledger.write_text(ledger.read_text()[:-4])
        with self.assertRaises(C.Failure):C.project(self.f.root)
    def test_projection_repair_does_not_change_canonical_state(self):
        expected=C.project(self.f.root)[0];(self.f.root/"research-state.json").write_text('{}')
        self.assertEqual(C.project(self.f.root,repair=True)[0],expected)
    def test_repair_requires_fresh_substantive_closure(self):
        self.f.transition("evidence_repair",{"blocking_obligation_ids":["raw"]})
        with self.assertRaises(C.Failure):self.f.transition("REPAIR_VERIFIED",{"closed_obligation_ids":["raw"],"evidence_snapshot_ref":self.f.snapshot_ref})
    def test_repair_cannot_be_bypassed_by_new_candidate(self):
        self.f.transition("evidence_repair",{"blocking_obligation_ids":["raw"]})
        idea=sample_artifacts()["idea-atom"];idea["source_evidence_refs"]=[self.f.source]
        candidate=write(self.f.root,"ideas/c1.json",idea)
        with self.assertRaises(C.Failure):self.f.transition("research_candidate",{"candidate_ref":candidate})
    def test_digest_consistent_illegal_history_still_rejected(self):
        ledger=self.f.root/"event-ledger.jsonl";event=C.parse_json(ledger.read_text())
        event["next_state"].update(current_route="stopped",lifecycle_phase="terminal",terminal_status="stopped")
        event["event_digest"]=digest({k:v for k,v in event.items() if k!="event_digest"})
        ledger.write_text(canonical(event)+"\n")
        write(self.f.root,"research-state.json",event["next_state"])
        anchor=C.load_file(self.f.root/"ledger-anchor.json");anchor["head_digest"]=event["event_digest"];write(self.f.root,"ledger-anchor.json",anchor)
        with self.assertRaises(C.Failure):C.project(self.f.root)
    def test_public_cli_errors_never_echo_secret(self):
        secret="ghp_"+"Q"*32;path=self.f.root/"secret.json";path.write_text(json.dumps({secret:secret}))
        result=subprocess.run([sys.executable,str(PACKAGE/"scripts/validate_artifact.py"),str(path)],capture_output=True,text=True)
        self.assertEqual(result.returncode,2);self.assertNotIn(secret,result.stdout+result.stderr)
    def test_traversal_and_symlink_refs_rejected(self):
        for path in ("../outside", "/etc/passwd"):
            with self.assertRaises(C.Failure):C.safe_path(self.f.root,path)
        (self.f.root/"link").symlink_to("/etc/passwd")
        with self.assertRaises(C.Failure):C.safe_path(self.f.root,"link")

if __name__=="__main__":unittest.main()
