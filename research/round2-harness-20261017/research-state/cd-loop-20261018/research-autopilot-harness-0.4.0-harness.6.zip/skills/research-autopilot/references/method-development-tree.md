# Idea routes and method design

Use after or alongside problem discovery; preserve Parent Problem/Natural Gate 0,
collision/IPCG and evidence constraints. The tree is an exploration index, not a
guarantee of novelty or improvement. Multiple routes can support one hypothesis.

Contents: [eight routes and navigation](#h01-eight-routes),
[composition](#h02-composition-and-competing-explanations),
[idea and decision card](#h03-idea-atom-from-observation),
[causal intervention](#m01-causal-intervention),
[mathematics](#m02-mathematical-and-computational-specification),
[algorithm](#m03-minimum-algorithm-and-interface),
[complexity](#m04-complexity-and-boundaries),
[evidence obligations](#m05-evidence-obligations-by-contribution).

## H01 Eight routes

Use [mathematical-empirical-inquiry.md](mathematical-empirical-inquiry.md) to
develop empirical and mathematical accounts together. Either can initiate
discovery; neither has universal priority. A baseline gap, a success pattern,
an equivalence, a scale dependence or an omitted gradient term can raise the
question. Reuse current evidence; a resume does not require another reproduction.
For M/R, preserve the requested asset/reviewer audit and its saved position.
Treat the eight routes as selectable, revisitable tools. They have no universal
originality ranking and do not form an eight-step sequence.
Every route requires the internal [mathematical procedure](math-analysis.md)
for every proposed candidate. The
mathematical-derivation row means mathematics initiates discovery; it does not
make mathematical analysis optional in the other seven rows. Select and perform
a relevant conditional derivation path, with no requirement to visit all tools.
For a new/reopened method-discovery batch, follow
[method-verification.md](method-verification.md): these mathematical operations
generate consequential constructions; each selected construction receives a
pinned derivation, semantic review and justified selection before code design.
One ready construction suffices for the next admissible step; no quota applies.
Counts never justify invented proofs or configuration variants as new ideas.

| Route | Starting material | Mechanism question | First discriminating check |
|---|---|---|---|
| Real-condition baseline gap | strong open baseline, reproducible natural failures | which implicit assumption fails under a real condition? | reproduce baseline, measure prevalence, intervene on that condition |
| Complementary composition | two mechanisms with distinct responsibilities | what information/function is missing, and why are mechanisms compatible? | A, B, A+B, budget-matched replacement and relevant interaction controls |
| Experiment-driven discovery | unexpected result/error clusters/negative finding | which competing explanations fit the observation? | predictive controlled contrast on fresh data |
| Cross-domain mechanism transfer | root cause translated into abstract variables | which external mechanism addresses the same constraint? | verify assumptions/interface and compare simple in-domain substitute |
| Mathematical derivation | identified objective/inconsistency/constraint | which derivation changes behavior and under which assumptions? | limiting cases, counterexample and computationally valid prediction |
| Efficiency or system constraint | latency/memory/communication/failure bottleneck | where is real end-to-end cost and what can be removed/shared? | matched quality-cost frontier and complete measured overhead |
| Existing data/evaluation audit | measurement blind spot/coverage/label problem | does the existing instrument measure the desired property? | audit native metrics and coverage; select a relevant existing benchmark if needed |
| Simplification or unification | redundant components/inconsistent explanations | can a simpler account preserve utility or reveal necessity? | removal/replacement and strongest simple model under matched conditions |

When selecting the gap route: recent strong open baseline → successful
reproduction → real condition omitted by its assumptions → publicly testable
condition → derived construction and decisive comparison. Distribution shift, occlusion, missing modality
or scarce labels are candidates, not automatically established important problems.
Do not infer that one or two added modules will probably succeed. Reproduction,
natural prevalence and mechanism tests decide whether to continue.

### Evidence-driven navigation

After a material new experiment, derivation, counterexample, failure audit,
evaluator check or primary-source finding, inspect validity and uncertainty
before interpreting the result. Select
continue, switch or combine thinking routes using the conditions below, and return
the H03 navigation decision card. These conditions suggest an investigation; they
do not establish a mechanism, novelty, statistical significance or gate PASS.

During a human-chosen batch, record E04's per-idea dispositions and continue the
agreed experiments. Select a new direction after the consolidated batch-end human
review under [state-and-routing.md](state-and-routing.md), not immediately after
one failure. Human-selected reassessment renews contextual primary-paper/code/
benchmark discovery before H01/H03 and G01; changed goals/resources return to P/I.
Supported success follows remaining validation/writing obligations. Preserve full
comparisons across soft reports and up-to-24-hour Local cycles, carrying unfinished approved work
under rolling-research-batches.md. Propose evidence-driven convergence at review,
not a fresh 20→15 discovery cycle each round. Diagnostic observations remain provisional navigation
notes during the batch, rather than authority to start a new research round.

| Current observation | Next investigation |
|---|---|
| A derivation exposes an equivalence, scale dependence, bound or missing term | Check assumptions and algebra, derive a distinguishing observation and seek evidence of its relevant regime; do not require a pre-existing failure census to reason. |
| Baseline reproduction, implementation or scoring is invalid | Repair the identified evidence/engineering fault and return to the caller; postpone scientific interpretation. |
| Qualified models share a consequential natural failure | Combine baseline-gap and experiment-driven discovery; compare common-cause explanations with controlled interventions. |
| A valid result contradicts the current explanation | Use experiment-driven discovery and revisit the affected mathematical analysis; predict a contrast that separates competing explanations. |
| The available observations or representation cannot distinguish outcomes that the task needs to distinguish | Investigate mathematical/identifiability boundaries and measurement validity; separate insufficient information from model failure. |
| Two qualified mechanisms leave complementary residual failures | Investigate composition after checking interfaces, information and matched total cost. |
| A documented root cause shares an abstract constraint with another field | Investigate mechanism transfer, checking assumptions and an in-domain simple substitute. |
| Measured end-to-end memory, latency or communication limits utility | Investigate efficiency/system constraints and the full quality-cost frontier. |
| Good scores coexist with poor real task outcomes, or the evaluator ignores the claimed capability | Audit existing data/evaluation validity; locate another established claim-relevant benchmark or retain the measurement gap as a blocker. |
| A qualified simple alternative resolves the meaningful failure | Select simplification or no new method; retain remaining scope/boundary evidence. |

Compare feasible next checks by consequential problem value, expected uncertainty
reduction, human time, compute/API cost and opportunity cost under the sourced
goal/resource brief. State the rationale rather than inventing a universal score.
Keep a route with useful unresolved predictions; switch or combine when evidence
changes what the next check can distinguish. When the evidence has not changed,
continue the pending check or report its blocker instead of cycling through routes.
Revisit retained alternatives on their recorded trigger; a negative result is
evidence to interpret, not an obligation to invent another module.

Use development observations to generate hypotheses and suitably fresh independent
data to confirm them. Viewed confirmation data becomes exploratory for the new
hypothesis. Version a result-affecting candidate/protocol change and repeat its
required collision/IPCG and confirmation checks. If the natural failure, population
or consequential endpoint changes, use the existing problem restart and a new
Parent Problem/Natural Gate 0. Record goal/resource changes through P/I and recheck
their affected obligations. Preserve prior decisions and negative evidence.

## H02 Composition and competing explanations

For any combination, write component responsibilities, representations, available
information, training/inference coupling and expected interaction. Test whether
gains come from extra parameters, budget, labels, retrieval or tuning. Ablation
does not alone prove causal mechanism. Include replacement and prediction tests
where claimed. Do not call packaging or renamed old computation a new mechanism.
Function-level collision review remains mandatory across all routes.

## H03 Idea atom from observation

Use the linked inquiry record in mathematical-empirical-inquiry.md. An observation
may suggest a derivation; a derivation may suggest what to observe. Record the
mathematical object, consequential steps, assumptions, empirical status and a
result that would revise the account. A formal insight is not automatically
an empirical method recommendation or a novelty verdict.
Every candidate's mathematical discovery card is mandatory. Record its selected
operations and justified transitions, what the construction changes, its relation
to the closest known method and an executable algorithm. An unresolved lead does
not count toward the candidate slate. Retain conditional and conjectural status
where appropriate; a completed general proof is not required for every idea.

Keep the idea and its experiment design together under the per-round contract in
[literature-evidence.md](literature-evidence.md). Link primary-paper passages, actual
GitHub implementation paths and native benchmark claim coverage to the proposed
comparison. Give outcome-dependent next actions and unresolved implementation/
measurement constraints each round. Do not infer causal independence merely from
different edited modules or expand all combinations to occupy a time window.

Return the observation or formal starting point, uncertainty, consequential
question, competing explanations when unresolved, smallest justified intervention
or next analysis, distinguishing prediction,
falsifier, strongest simple competitor, resource estimate and collision status.
New hypotheses generated from results are developmental until tested on fresh,
appropriately independent confirmation. A valid negative/null result can support
boundary or measurement contributions; don't discard candidates by result sign.

### Required navigation decision card

Return this concise card when selecting or materially changing an idea route.
Reuse existing evidence/candidate references; label unavailable facts unknown.
The card is an advisory research record, not a state transition or authorization.
For read-only conceptual inquiry, use the compact linked inquiry record instead;
include project/gate/resource slots only when a corresponding project exists.
Missing empirical prerequisites do not block a derivation or conditional prediction.

| Required slot | Contents |
|---|---|
| Identity and lineage | Decision ID/date, previous decision reference and existing project/caller identity. |
| Observation and validity | What changed, evidence snapshot/run/source references, baseline/evaluator validity, uncertainty and retained negative observations. |
| Route decision and explanations | Previous/selected H01 routes; continue/switch/combine/repair/wait/no-new-method rationale; competing explanations when unresolved and alternatives deferred with revisit triggers. |
| Mathematical discovery card | Per candidate: formal object, selected derivation path and connection conditions, consequential steps, assumptions/error, preserved/changed quantities, executable construction, distinguishing prediction, falsifier, closest-work relation and conclusion status. Reuse inspected shared algebra with candidate-specific implications. |
| Next discriminating check | Prediction, falsifier, smallest comparison, possible outcome interpretations and stop rule; cost estimate and sourced resource bound. |
| Priority and scope | Why this check matters and reduces uncertainty relative to alternatives; goal/resource brief and Parent Problem references; unchanged scope or explicitly proposed change. |
| Research quality and feasibility | Consequential problem evidence, substantive closest-work delta and coverage/crowding rationale; verified benchmark/data/evaluator readiness, unresolved obligations and the recommended level of investment from research-quality-bar.md. |
| Reading-to-design links | Current primary-paper versions/passages, GitHub commits/files/functions, considered benchmark contents/config/scorer and claim coverage, each linked to its hypothesis, experiment/control and outcome interpretations; reused vs newly inspected scope and unavailable sources. |
| Confirmation and progression | Developmental vs fresh confirmation status, consumed/available confirmation evidence, missing gate prerequisites and the next legal workflow action. |
| Next-window slate and carryover | Active/carried/repair/parked/stopped candidate IDs and reasons, unresolved causal groups and revisit triggers; at most 20 active ideas, typically fewer in later rounds; complete remaining comparisons, cumulative bounds, expected timing and unchanged authorization or human decision needed. |

Show the compact decision with the next useful step. Retain versioned cards in
the existing project research record under its disclosed durable artifact root;
reuse them on resume and do not overwrite earlier choices. When no durable root
exists yet, return a provisional card and follow the host persistence contract.
Suggest read-only inspection or repair when prerequisites are absent. A selected
thinking route cannot mint a candidate approval, bypass Natural Gate 0/IPCG/Gate A,
change immutable origin or launch an experiment. Final project abandonment remains
subject to the existing user-direction contract.

## M01 Causal intervention

Map the empirical phenomenon or derived structure → mechanism → available
signal/state → construction → predicted behavior → task consequence. For each component record its scientific duty,
information dependencies and evidence obligation. Remove components with no
defensible duty. Explain why the strongest simple alternative is insufficient.
Keep observation, mechanism hypothesis and experimentally supported inference
separate. Use multiple plausible interventions when uncertainty warrants it.

## M02 Mathematical and computational specification

Use the required internal [mathematical procedure](math-analysis.md) and
[empirical connection](mathematical-empirical-inquiry.md) for every candidate. Mathematical work can generate an idea, reveal
an equivalence or reject a mechanism. It is not only a notation check after
choosing an intervention. Select useful scaling, bounds, changes of variables,
decompositions, constrained optimization, expansions or geometric analysis;
perform the derivation and state what it predicts. Return to it when evidence
changes the explanation.
Use the operation graph's conditional connections rather than arbitrary tool
concatenation. An exact identity, a local approximation and an implemented
surrogate are different claims. Method construction may involve multiple coupled
stages; minimal confounding governs its decisive validation, not its size.

Define symbols, units, shapes, domains, objectives, conditioning, normalization,
optimization and train/test information. Check dimensions, sign, boundedness,
denominators, empty/degenerate cases, gradients and limiting cases. State all
assumptions and where they hold. A theorem requires proof or a clearly marked
conjecture; an equation is not proof of efficacy. Derive an algorithm that can
actually be computed with available information. Record approximation and error.

## M03 Minimum algorithm and interface

Specify inputs/outputs/state, initialization, update and termination, train vs
inference vs prompt route, pseudocode and a paper-to-code mapping. Preserve the
baseline interface and isolate the intervention. Name precision/batching/random
state effects, invalid input behavior and serialization needed for recovery.
For semantic/canary checks that qualify the eval path, use existing benchmark
cases/tests, native scoring and actual run outputs. Never handcraft an eval input,
test or reference label. Keep mathematical exposition and ordinary non-evaluation
engineering checks separate; they cannot establish benchmark performance.

## M04 Complexity and boundaries

Derive time/memory in relevant variables for complete training and inference;
measure wall time, peak memory, data movement, API/call cost and communication
when material. Parallel kernels and overhead may reverse Big-O rankings. Compare
complete quality-cost frontiers and state hardware/warmup/batch conditions. Predict
failure/success regimes and test boundaries rather than claiming universal gains.

## M05 Evidence obligations by contribution

Methods need fair baselines, mechanism/replacement controls and scope evidence;
theory needs assumptions, proofs, counterexamples and relevant numerical checks;
phenomena need prevalence, controls and independent confirmation; systems need
end-to-end cost/utility and failure recovery; studies of existing data/benchmarks
need validity, coverage and contamination audits. Never create eval cases or a
replacement benchmark to fill missing empirical evidence. Keep mathematical
exposition and ordinary non-evaluation engineering checks separate. Close each component's obligation
or narrow/remove its claim. Hand the obligations to G and V before paper framing.
