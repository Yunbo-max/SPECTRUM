# OPD examples: constructions and independent checks

The four user-supplied papers below were inspected in the indicated arXiv
versions on 2026-10-05. They are separate from the 20 conference examples in
math-paper-atlas.md. This note reads mathematical claims and method definitions; it
does not certify implementations or replicate performance.

## P1 — TOP-D, arXiv:2607.04751v1

[Original](https://arxiv.org/html/2607.04751v1), §§2–4.
The useful construction is an arithmetic proximal teacher and a nonlinear
log-ratio signal; math-worked-examples.md derives its lower bound. The paper's
token-estimator variance theorem assumes bounded scores. Keep that theorem
separate from sequence-return, normalization and clipped-update claims.
Its practical return also normalizes the future suffix; this is not the original
undiscounted sequence-KL gradient. At the final token, the displayed future-average
formula needs an explicit empty-suffix convention. The probability-space
contraction model leaves practical optimization error as an assumption/term.

**Independent normalization check:** a geometric teacher must be
`q_tilde=q^alpha p^(1-alpha)/Z`, so
`log(q_tilde/p)=alpha log(q/p)-log Z`. Omitting `Z` is not a normalized
distributional identity. A state-only offset may cancel in an appropriate local
score expectation; that needs a separate gradient argument.

## P2 — TRB, arXiv:2605.31159v1

[Original](https://arxiv.org/html/2605.31159v1), §4 and its referenced constrained
solution. The behavior distribution solves a teacher-directed KL problem within
a student-centered KL budget. Its normalized geometric family and monotonicity
calculation appear in math-worked-examples.md. This changes which prefixes are visited
while retaining the per-prefix loss form. Do not infer that retaining the local
loss preserves the overall student-on-policy objective. Support, local versus
trajectory budgets, budget endpoints and the annealing schedule remain distinct
questions. Operations D01–D03 connect to B03/H03 when studying the training law.

## P3 — ERPD, arXiv:2605.25582v2

[Original](https://arxiv.org/html/2605.25582v2), §§3.1–3.3, Eqs. 7–9.
The method separates aggressive fixed-data updates from constrained distillation
toward the resulting policy. This is a useful algorithm-reorganization entry:
separate two competing demands, formalize the second stage, then inspect the
implemented surrogate. The implementation uses a frozen old-policy denominator,
whitening and PPO-style clipping. These are approximations/choices, not an exact
solver of the displayed constrained problem. A meaningful test must distinguish
stage roles at matched total compute, rollout and teacher budgets. More stages
are legitimate when their mathematical duties and tradeoffs are explicit.

## P4 — TrOPD, arXiv:2606.01249v3

[Original](https://arxiv.org/html/2606.01249v3), §§4.2–4.3, Eqs. 5–7.
The method partitions student samples using teacher/student ratios, combines
different divergence signals and uses teacher-trajectory guidance. Analyze mask
dependence, truncated support and estimator bias separately; a region-selection
rule is not automatically a hard global KL constraint.

**Independent boundary check:** the text following Eq. 7 states that forward KL
vanishes when student mass on the fixed teacher top-k set tends to zero. For
`q=(0.9,0.1)`, `p=(delta,1-delta)` and top-k set `{1}`, its displayed positive
KL contribution is `0.9 log(0.9/delta)`, which tends to positive infinity.
The negative objective has the opposite sign, not a zero limit. This is a
counterexample to that stated explanation; it does not determine the full
algorithm's empirical performance. Check implementation before inferring what
training actually does.

## Two papers use the acronym OPRD

Do not resolve this acronym by silently choosing a title. Both relevant primary
papers were inspected here; ask which is intended only if that distinction blocks
the current task.

**On-Policy Representation Distillation**, [2606.06021v4](https://arxiv.org/html/2606.06021v4),
§3 and Appendix B.1–B.4. It changes supervision to hidden states. Conditional
determinism does not eliminate prompt/rollout variance, and a different objective
is not an unbiased estimator of the original KL gradient. Eq. 17 defines a bare
score, whereas Eq. 19 analyzes a score-weighted log-ratio; these must be separated.
The universal SNR-collapse conclusion needs an independent check:

For `Y~Bernoulli(p)`, `p=sigmoid(theta)`, fixed teacher probability `q!=1/2`
inside `(0,1)`, let `e=p-q` and
`g=log(P_p(Y)/P_q(Y))*(Y-p)`. Direct expansion gives
`E[g]=e+O(e^2)` and
`Var(g)=e^2*(1-2q)^2/[q(1-q)]+O(e^3)`.
Thus squared-mean SNR tends to `q(1-q)/(1-2q)^2>0`, while symmetric KL
tends to zero. This smooth finite-support example limits that stated general
claim; it does not establish how a particular neural run behaves.

**On-Policy Reverse Distillation**, [2609.08798v1](https://arxiv.org/html/2609.08798v1),
§2.2. It amplifies a verifier gradient along a teacher-shift direction using a
positive-definite logit-space map. Its logit-space stationary-point argument must
not be extended to shared neural parameters without a Jacobian analysis. The
counterexample in math-worked-examples.md shows why this transfer is not automatic.
Clipping, sampled gradients and asymmetric scheduling add further distinctions.

## What these papers contribute to the skill

An OPD analysis should keep separate: the sequence objective, prefix-visitation
law, token divergence, score/pathwise estimator, temporal return, target freezing,
mask/normalizer, and optimizer update. The local dense signal does not settle the
suffix-credit question. Useful research can begin by changing any one of these
objects or reorganizing their coupling, provided the connecting derivation and
distinguishing prediction are explicit. A source's theorem, intuition and
implemented approximation are different evidence categories.
