#!/usr/bin/env python3
"""Render retained aggregates; no scoring, statistics inference or source certification."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import math
from pathlib import Path
import shutil
import sys
import tempfile

import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
import numpy as np


COLORS = ["#0072B2", "#E69F00", "#009E73", "#CC79A7", "#56B4E9", "#D55E00", "#000000"]
MARKERS = ["o", "s", "^", "D", "v", "P", "X"]
HATCHES = ["", "//", "..", "\\\\", "xx", "--", "++"]
NO_INTERVAL = {"not reported", "not applicable"}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def number(value, label):
    try:
        value = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{label} must be a finite number") from None
    if not math.isfinite(value):
        raise ValueError(f"{label} must be finite")
    return value


def require_text(obj, key):
    if not isinstance(obj.get(key), str) or not obj[key].strip():
        raise ValueError(f"{key} must be explicitly documented")


def load_inputs(data_path, spec_path):
    data_bytes, spec_bytes = Path(data_path).read_bytes(), Path(spec_path).read_bytes()
    config = json.loads(spec_bytes.decode("utf-8"))
    if config.get("source_status") not in {"measured", "engineering_fixture"}:
        raise ValueError("source_status must be measured or engineering_fixture")
    refs = config.get("evidence_refs")
    if not isinstance(refs, list) or not refs or any(not isinstance(x, str) or not x.strip() for x in refs):
        raise ValueError("evidence_refs must identify retained sources")
    if config.get("source_sha256") != hashlib.sha256(data_bytes).hexdigest():
        raise ValueError("source digest does not match the retained CSV")
    panels = config.get("panels")
    if not isinstance(panels, list) or not 1 <= len(panels) <= 8:
        raise ValueError("spec must contain 1 to 8 panels")
    by_id = {}
    for panel in panels:
        for key in ["id", "kind", "title", "xlabel", "ylabel", "metric", "units", "better",
                    "aggregation", "sample_unit", "uncertainty", "selection_rule"]:
            require_text(panel, key)
        if panel["kind"] not in {"bar", "line", "scatter", "heatmap"}:
            raise ValueError("unsupported chart kind")
        if panel["better"] not in {"higher", "lower", "neither"}:
            raise ValueError("better must be higher, lower or neither")
        if type(panel.get("sample_count")) is not int or panel["sample_count"] < 1:
            raise ValueError("sample_count must be an explicit positive integer")
        if panel["id"] in by_id:
            raise ValueError("duplicate panel ID")
        by_id[panel["id"]] = panel
    with io.StringIO(data_bytes.decode("utf-8"), newline="") as f:
        reader = csv.DictReader(f)
        required = {"panel", "series", "x", "y", "value", "lower", "upper"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError("CSV needs panel, series, x, y, value, lower, upper columns")
        raw = list(reader)
    prepared, seen = {p["id"]: [] for p in panels}, set()
    for original in raw:
        row = dict(original)
        if row["panel"] not in by_id:
            raise ValueError("CSV contains an unknown panel")
        panel = by_id[row["panel"]]
        if not row["series"] or not row["x"]:
            raise ValueError("series and x cannot be empty")
        if panel["kind"] in {"line", "scatter"}:
            row["x"] = number(row["x"], "x")
        elif panel["kind"] == "heatmap" and not row["y"]:
            raise ValueError("heatmap rows require y category labels")
        if panel["kind"] != "heatmap" and row["y"]:
            raise ValueError("y category is supported only for a heatmap; numeric y uses value")
        row["value"] = number(row["value"], "value")
        intervals = bool(row["lower"]) or bool(row["upper"])
        if intervals:
            row["lower"] = number(row["lower"], "interval lower")
            row["upper"] = number(row["upper"], "interval upper")
            if not row["lower"] <= row["value"] <= row["upper"]:
                raise ValueError("interval must contain the supplied value")
            if panel["uncertainty"].lower() in NO_INTERVAL or panel["kind"] == "heatmap":
                raise ValueError("intervals conflict with the documented uncertainty or chart kind")
        else:
            row["lower"] = row["upper"] = None
            if panel["uncertainty"].lower() not in NO_INTERVAL:
                raise ValueError("documented uncertainty requires supplied intervals for every row")
        key = (row["panel"], row["series"], row["x"], row["y"])
        if key in seen:
            raise ValueError("duplicate observations need an explicit upstream aggregation")
        seen.add(key)
        prepared[row["panel"]].append(row)
    for panel in panels:
        rows = prepared[panel["id"]]
        if not rows:
            raise ValueError("every panel needs data")
        series = list(dict.fromkeys(r["series"] for r in rows))
        categories = list(dict.fromkeys(r["x"] for r in rows))
        if panel["kind"] == "bar" and len(rows) != len(series) * len(categories):
            raise ValueError("grouped bars need a complete comparison matrix")
        if panel["kind"] == "heatmap":
            ys = set(r["y"] for r in rows)
            if len(series) != 1 or len(rows) != len(categories) * len(ys):
                raise ValueError("heatmap needs one complete matrix")
        low = min(r["lower"] if r["lower"] is not None else r["value"] for r in rows)
        high = max(r["upper"] if r["upper"] is not None else r["value"] for r in rows)
        if "ylim" in panel:
            lim = panel["ylim"]
            if panel["kind"] == "heatmap" or not isinstance(lim, list) or len(lim) != 2:
                raise ValueError("ylim needs two numeric limits for a Cartesian chart")
            a, b = (number(x, "ylim") for x in lim)
            if a >= b:
                raise ValueError("ylim must increase")
            if panel["kind"] == "bar" and not a <= 0 <= b:
                raise ValueError("bar baseline must include zero; use a point plot for zooms")
            if a > low or b < high:
                raise ValueError("ylim would clip values or uncertainty")
    return config, prepared, data_bytes, spec_bytes


def draw_panel(ax, panel, rows, identity):
    kind = panel["kind"]
    series = list(dict.fromkeys(r["series"] for r in rows))
    xs = list(dict.fromkeys(r["x"] for r in rows))
    if kind == "heatmap":
        ys = list(dict.fromkeys(r["y"] for r in rows))
        lookup = {(r["x"], r["y"]): r["value"] for r in rows}
        matrix = [[lookup[(x, y)] for x in xs] for y in ys]
        image = ax.imshow(matrix, cmap="cividis", aspect="auto")
        ax.set_xticks(range(len(xs)), xs); ax.set_yticks(range(len(ys)), ys)
        ax.figure.colorbar(image, ax=ax, label=f"{panel['metric']} ({panel['units']})")
    else:
        for index, name in enumerate(series):
            selected = [r for r in rows if r["series"] == name]
            if kind == "bar":
                lookup = {r["x"]: r for r in selected}
                selected = [lookup[x] for x in xs]
            else:
                selected = sorted(selected, key=lambda r: r["x"])
            values = np.array([r["value"] for r in selected])
            err = None
            if selected[0]["lower"] is not None:
                err = np.array([[r["value"] - r["lower"] for r in selected],
                                [r["upper"] - r["value"] for r in selected]])
            style = identity[name]
            if kind == "bar":
                width = 0.8 / len(series)
                positions = np.arange(len(xs)) + (index - (len(series) - 1) / 2) * width
                ax.bar(positions, values, width=width, bottom=0, label=name, color=style["color"],
                       edgecolor="#333333", linewidth=0.6, hatch=style["hatch"], yerr=err,
                       capsize=3)
            else:
                ax.errorbar([r["x"] for r in selected], values, yerr=err, label=name,
                            color=style["color"], marker=style["marker"], markersize=4,
                            linestyle="-" if kind == "line" else "none", capsize=3)
        if kind == "bar":
            ax.set_xticks(range(len(xs)), xs)
            lo, hi = ax.get_ylim(); ax.set_ylim(min(0, lo), max(0, hi))
        if "ylim" in panel:
            ax.set_ylim(panel["ylim"])
        ax.legend(loc="best", frameon=False)
    ax.set_title(panel["title"])
    ax.set_xlabel(panel["xlabel"]); ax.set_ylabel(panel["ylabel"])


def render(data_path, spec_path, outdir):
    data_path, spec_path, outdir = Path(data_path), Path(spec_path), Path(outdir)
    if outdir.exists():
        raise ValueError("output already contains an artifact; choose a new version directory")
    config, prepared, data_bytes, spec_bytes = load_inputs(data_path, spec_path)
    observed = list(dict.fromkeys(r["series"] for p in config["panels"] if p["kind"] != "heatmap"
                                 for r in prepared[p["id"]]))
    names = config.get("series_order", observed)
    if (not isinstance(names, list) or any(not isinstance(n, str) or not n for n in names)
            or len(set(names)) != len(names) or not set(observed).issubset(names)):
        raise ValueError("series_order must uniquely include all plotted comparison series")
    identity = {name: {"color": COLORS[i % len(COLORS)], "marker": MARKERS[i % len(MARKERS)],
                       "hatch": HATCHES[i % len(HATCHES)]} for i, name in enumerate(names)}
    if len(names) > len(COLORS):
        raise ValueError("use a custom project style for more than seven registered series")
    ncols = 1 if len(config["panels"]) == 1 else 2
    nrows = math.ceil(len(config["panels"]) / ncols)
    width = number(config.get("width_inches", 6.8), "width_inches")
    height = number(config.get("height_inches", 3.2 * nrows), "height_inches")
    if not 2 <= width <= 30 or not 2 <= height <= 30:
        raise ValueError("figure dimensions must be between 2 and 30 inches")
    outdir.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".figure-", dir=outdir.parent) as temporary:
        stage = Path(temporary) / "artifact"; stage.mkdir()
        with matplotlib.rc_context({"font.family": "DejaVu Sans", "font.size": 9,
                                    "axes.spines.top": False, "axes.spines.right": False,
                                    "svg.fonttype": "none", "pdf.fonttype": 42,
                                    "text.usetex": False}):
            fig, axes = plt.subplots(nrows, ncols, figsize=(width, height), squeeze=False,
                                     layout="constrained")
            try:
                for ax, panel in zip(axes.flat, config["panels"]):
                    draw_panel(ax, panel, prepared[panel["id"]], identity)
                for ax in list(axes.flat)[len(config["panels"]):]:
                    ax.set_visible(False)
                for extension in ["svg", "pdf", "png"]:
                    fig.savefig(stage / ("figure." + extension), dpi=300, facecolor="white")
            finally:
                plt.close(fig)
        (stage / "source-data.csv").write_bytes(data_bytes)
        (stage / "figure-spec.json").write_bytes(spec_bytes)
        shutil.copyfile(Path(__file__).resolve(), stage / "publication_plot.py")
        caption = [f"Source status: {config['source_status']}."]
        for p in config["panels"]:
            direction = "no better direction" if p["better"] == "neither" else p["better"] + " is better"
            caption.append(f"{p['id']}: {p['metric']} ({p['units']}; {direction}). "
                           f"Aggregation: {p['aggregation']}. Unit: {p['sample_unit']}; "
                           f"reported count: {p['sample_count']}. Uncertainty: {p['uncertainty']}. "
                           f"Selection: {p['selection_rule']}.")
        (stage / "caption-disclosures.md").write_text("\n\n".join(caption) + "\n", encoding="utf-8")
        receipt = {
            "created_at": datetime.now(timezone.utc).isoformat(),
            "source_status": config["source_status"], "evidence_refs": config["evidence_refs"],
            "data_sha256": hashlib.sha256(data_bytes).hexdigest(),
            "spec_sha256": hashlib.sha256(spec_bytes).hexdigest(),
            "script_sha256": digest(__file__), "series_identity": identity,
            "runtime": {"python": sys.version.split()[0], "matplotlib": matplotlib.__version__,
                        "numpy": np.__version__},
            "panels": [dict(p, rows=prepared[p["id"]],
                            bar_baseline=0 if p["kind"] == "bar" else None) for p in config["panels"]],
            "outputs": {p.name: digest(p) for p in sorted(stage.iterdir())},
            "validation": {"input_contract": "passed", "export": "passed",
                           "visual_inspection": "not_performed", "scientific_verification": "not_performed"}
        }
        (stage / "figure-render.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n",
                                                  encoding="utf-8")
        if outdir.exists():
            raise ValueError("output already contains an artifact")
        stage.rename(outdir)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, type=Path)
    parser.add_argument("--spec", required=True, type=Path)
    parser.add_argument("--outdir", required=True, type=Path)
    args = parser.parse_args()
    try:
        result = render(args.data, args.spec, args.outdir)
    except (ValueError, OSError) as error:
        parser.exit(2, f"{error}\n")
    print(json.dumps({"artifact": str(args.outdir), "validation": result["validation"]}))


if __name__ == "__main__":
    main()
