# Operational recovery and bounded local persistence

This is an opt-in helper, not a daemon, cloud orchestrator, remote GitHub uploader,
or automatic migration of existing project scripts.

## Resources

`scripts/research_operations.py --cgroup ACTUAL_CGROUP` reads memory.current,
memory.max, memory.stat, memory.events and PSI memory.pressure, plus visible ancestor
headroom. Resolve the actual cgroup/mount from the host first; an arbitrary root may
not be the task's accounting domain. Missing data is unknown, not zero capacity.
Linux reference: https://docs.kernel.org/admin-guide/cgroup-v2.html
`file` contains cache including tmpfs/shared memory; do not add `shmem` again.

Use a representative measured peak plus an explicitly justified margin; distinguish
already-accounted own footprint from future incremental need. Do not demand an
arbitrary host total below 7 GiB for a 421 MiB workload. Admission is an estimate;
retained numerical/evidence thresholds do not change when a resource policy changes.
No cache is automatically credited as free, and the helper never clears global caches.
Read event deltas between comparable observations before attributing OOM to a task.

`reserve(directory, fresh_snapshot_fn, project_id, task_id, peak_bytes, margin_bytes)`
provides an atomic observation/reservation under fcntl.flock for cooperating jobs
sharing this exact local directory and host/cgroup domain. Call immediately before
launch; retain the token and release only after reconciling the owned job as terminal.
No automatic stale expiry: unknown launch/process identities retain their reservations.
It does not reserve the kernel's RAM, control nonparticipants or coordinate isolated
Chat/Work containers. Running memory and reserved peaks can be conservatively counted
twice; report this limitation rather than call the estimate globally optimal.
No tests authorize experiments outside the user's retained host/resource allocation.

## Skill discovery and adoption

On an actual wake use returned discovery identifiers, not guessed display-name URIs.
Record requested edition, available account version, actual loaded digest, project-adopted
digest, executor and wake separately. Verify source bytes, not only a version string.
If the selected skill cannot be read: do not claim it was loaded; preserve checkpoints,
report the observed access failure and use only an explicitly authorized pinned same-edition
fallback. Do not silently switch editions or disable a scheduler merely to avoid an error.
No helper can restore a missing host or guarantee notifications between real invocations.
`adoption_report` is read-only: preserve user pause; settle active/unknown attempts;
then perform the existing edition's versioned source-adoption handoff and verify it.
It does not migrate, start, stop or alter any scheduler.

## Incremental persistence

`save_delta(root, store, paths, project_id=..., parent=...)` hashes and copies only
explicitly supplied immutable changed files. It retains all prior file mappings,
adds only missing content-addressed objects and writes a complete small manifest.
It never rewrites a full history ZIP or interprets absent files as deletions.
Choose the exact dependency/output list; the helper cannot infer completeness.
Use a quiet writer boundary or immutable exports. Raw SQLite/WAL files are refused;
use the native journal backup/quiet checkpoint routine and preserve its consistency receipt.

`restore_subset(store, manifest_digest, empty_destination, paths)` validates the requested
objects and restores only them, preserving older versions and refusing existing work.
A subset cannot be called a full disaster-recovery verification. Perform full recovery
checks at meaningful migration/milestone boundaries, not automatically every small report.
This local CAS is not the existing project-specific GitHub coldstore. Integrate deliberately
at a quiet boundary and verify remote changed objects/manifests before any owned cleanup.
No delete or remote-cleanup operation is provided. An upload/verification failure preserves
local evidence; a matching local hash is not proof of remote delivery or process inactivity.

## Reporting

Separate scientific outcomes, execution/repair, waiting and archive receipts. Keep updates
brief but report material faults. Never convert file counts, completed shell commands,
a live idle supervisor or a signed archive into a scientific gain or continuous-compute claim.

For executable CPU/RAM/disk admission and automatic resource rechecks, read [resource-queue.md](resource-queue.md). Temporary contention keeps the goal active; preserve original deadlines and explicit pauses.
