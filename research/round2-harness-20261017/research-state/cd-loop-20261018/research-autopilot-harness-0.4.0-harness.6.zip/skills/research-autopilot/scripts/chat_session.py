#!/usr/bin/env python3
"""Observable Chat bootstrap and content-bound checkpoint handoff.

This module neither authenticates a provider/session nor saves to remote storage.
The host supplies real read/save/readback observations. When it exposes no turn
ID, a coordinator creates a fresh correlation nonce at invocation entry. It must
not reuse the saved nonce on a later turn; this module cannot authenticate a
provider or discover an unobservable turn boundary. Hash validation
establishes consistency of supplied bytes, not that an agent understood a skill.
New dispatch can be guarded; recording results/reconciling old work stays possible.
"""
from __future__ import annotations

import argparse
import contextvars
from contextlib import contextmanager
import copy
import hashlib
import json
import os
from pathlib import Path
import tempfile
import uuid

MAX_JSON_BYTES = 8 * 1024 * 1024
MAX_REFS = 4096
MAX_MANIFEST_DEPTH = 128
_INVOCATION = contextvars.ContextVar('chat_host_invocation', default=None)


def new_invocation():
    """Generate once on current invocation entry, not from a saved checkpoint."""
    return dict(id=str(uuid.uuid4()), origin='coordinator_nonce')


def _text(value, name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(name + ' required')
    return value


def _json_bytes(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def _read(path):
    with Path(path).open('rb') as stream:
        data = stream.read(MAX_JSON_BYTES + 1)
    if len(data) > MAX_JSON_BYTES:
        raise ValueError('bounded JSON size exceeded')
    result = json.loads(data)
    if not isinstance(result, dict):
        raise ValueError('JSON object required')
    return result


def _hash(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def _ref(root, reference, *, as_json=False):
    if not isinstance(reference, dict):
        raise ValueError('content reference required')
    path = Path(root) / _text(reference.get('path'), 'reference path')
    if _hash(path) != reference.get('sha256'):
        raise ValueError('reference hash mismatch: ' + str(path))
    return _read(path) if as_json else reference


def _refs(root, values, read_ref=_ref, *, nonempty=False):
    if not isinstance(values, list) or (nonempty and not values):
        raise ValueError('source reference list required')
    for value in values:
        read_ref(root, value)


@contextmanager
def host_invocation(invocation_id):
    """Bind a current observed host ID or fresh nonce, never a saved old turn ID."""
    token = _INVOCATION.set(None if invocation_id is None else _text(invocation_id, 'host invocation identity'))
    try:
        yield
    finally:
        _INVOCATION.reset(token)


def _contract(root, contract, read_ref=_ref, *, validate_sources=True):
    if not isinstance(contract, dict):
        raise ValueError('explicit session contract required')
    for key in ('package_id', 'release', 'source_revision', 'destination'):
        _text(contract.get(key), 'session ' + key)
    if validate_sources:
        _refs(root, contract.get('required_source_refs'), read_ref, nonempty=True)
    elif not isinstance(contract.get('required_source_refs'), list) or not contract['required_source_refs']:
        raise ValueError('source reference list required')
    limit = contract.get('max_unsaved_revisions', 32)
    if type(limit) is not int or not 4 <= limit <= 1000:
        raise ValueError('max_unsaved_revisions must be an integer from 4 to 1000')
    return copy.deepcopy(dict(contract, max_unsaved_revisions=limit))


def initialize(root, state):
    """Called after basic checkpoint initialization; legacy import is explicit."""
    if 'session_contract' in state:
        state['session_contract'] = _contract(root, state['session_contract'])
    state['session'] = dict(project_uuid=str(uuid.uuid4()), bootstrap=None,
                            acknowledged_head=None, pending_save=None,
                            observed_head=None, policy_history=[], initialized_revision=state['revision'])


def _semantic_digest(state):
    return hashlib.sha256(_json_bytes({k: v for k, v in state.items() if k != 'lineage'})).hexdigest()


def record_revision(state):
    """Stamp after a single CAS revision bump and before atomic save; no I/O."""
    revision = state.get('revision')
    if type(revision) is not int or revision < 0:
        raise ValueError('nonnegative state revision required')
    digest, old = _semantic_digest(state), state.get('lineage')
    if old and old['revision'] == revision:
        if old['digest'] != digest:
            raise ValueError('changed checkpoint requires a new revision')
        return old
    if old and revision != old['revision'] + 1:
        raise ValueError('lineage revision must advance by exactly one')
    ancestors = copy.deepcopy(old.get('ancestors', [])) if old else []
    if old:
        ancestors.append({'revision': old['revision'], 'digest': old['digest']})
    state['lineage'] = dict(revision=revision, digest=digest,
                            parent_digest=old['digest'] if old else None, ancestors=ancestors)
    return state['lineage']


def validate_lineage(state):
    """Legacy checkpoints have no anchor; they remain inspectable, not upgraded."""
    line = state.get('lineage')
    if not line:
        return None
    if line.get('revision') != state.get('revision') or line.get('digest') != _semantic_digest(state):
        raise ValueError('checkpoint lineage content mismatch')
    ancestors = line.get('ancestors')
    if not isinstance(ancestors, list):
        raise ValueError('checkpoint lineage ancestors required')
    previous = None
    for anchor in ancestors:
        if (not isinstance(anchor, dict) or type(anchor.get('revision')) is not int
                or not isinstance(anchor.get('digest'), str) or len(anchor['digest']) != 64
                or (previous is not None and anchor['revision'] != previous + 1)):
            raise ValueError('invalid checkpoint lineage sequence')
        previous = anchor['revision']
    if ancestors:
        if ancestors[-1]['revision'] + 1 != line['revision'] or line['parent_digest'] != ancestors[-1]['digest']:
            raise ValueError('checkpoint lineage parent mismatch')
    elif line.get('parent_digest') is not None:
        raise ValueError('unexpected checkpoint lineage parent')
    return line


def _session(state):
    session = state.get('session')
    if not isinstance(session, dict):
        raise ValueError('explicit session_policy migration required')
    try:
        uuid.UUID(session['project_uuid'])
    except (ValueError, KeyError, TypeError, AttributeError) as error:
        raise ValueError('stable project UUID required') from error
    return session


def _head(session):
    """Most recent observed authority, distinct from verified save/readback credit."""
    heads = [head for head in (session.get('acknowledged_head'), session.get('observed_head')) if head]
    return max(heads, key=lambda head: head['revision']) if heads else None


def _manifest_ancestor(state, manifest):
    session, line = _session(state), validate_lineage(state)
    if manifest.get('project_uuid') != session['project_uuid']:
        raise ValueError('authoritative head belongs to another project')
    anchor = {'revision': manifest['revision'], 'digest': manifest['checkpoint_digest']}
    if not line or anchor not in line['ancestors'] + [{'revision': line['revision'], 'digest': line['digest']}]:
        raise ValueError('divergent or newer authoritative checkpoint: restore/reconcile before dispatch')


def predispatch_guard(root, state, *, invocation_id=None, continuation=False):
    """Return a concrete blocker or None. Root decides which legacy scopes govern.

    Continuation needs the original pinned procedure; observation/result events
    never call this guard. A missing new release must not strand an old attempt.
    """
    try:
        session = _session(state)
        contract = _contract(root, state.get('session_contract'), validate_sources=not continuation)
        invocation = invocation_id or _INVOCATION.get()
        if not invocation:
            raise ValueError('current host invocation identity required')
        saved = session.get('bootstrap')
        if not saved:
            raise ValueError('session bootstrap required')
        receipt = _ref(root, saved['receipt_ref'], as_json=True)
        if receipt.get('kind') != 'chat-session-bootstrap' or receipt.get('project_uuid') != session['project_uuid']:
            raise ValueError('session bootstrap project/kind binding mismatch')
        if receipt.get('host_invocation_id') != invocation:
            raise ValueError('bootstrap belongs to another host invocation')
        if receipt.get('scope') == 'continuation':
            if not continuation:
                raise ValueError('continuation-only bootstrap cannot authorize a new attempt')
            if receipt.get('attempt_id') != (state.get('current_attempt') or {}).get('id'):
                raise ValueError('continuation bootstrap differs from current attempt')
        procedure = (state.get('current_attempt') or {}).get('procedure') if continuation else state['procedure']
        if not procedure or receipt.get('procedure') != procedure:
            raise ValueError('actual loaded procedure differs from pinned procedure; bootstrap again')
        _ref(root, procedure['ref'])
        if not continuation:
            for key in ('package_id', 'release', 'source_revision'):
                if receipt.get(key) != contract[key]:
                    raise ValueError('actual loaded ' + key + ' differs from expected session contract')
            if any(ref not in receipt['read_source_refs'] for ref in contract['required_source_refs']):
                raise ValueError('required current skill sources were not observed as read')
        _refs(root, receipt.get('read_source_refs'), nonempty=True)
        _ref(root, receipt.get('observation_ref'))
        head = session.get('acknowledged_head')
        saved_revision = head['revision'] if head else session['initialized_revision']
        if state['revision'] - saved_revision >= contract['max_unsaved_revisions']:
            raise ValueError('durable save/readback interval exhausted')
        return None
    except (KeyError, OSError, ValueError, TypeError) as error:
        detail = str(error)
        reason = 'session_bootstrap_required'
        action = 'Read the pinned sources, reconcile the authoritative checkpoint and record the current host observations'
        if 'save/readback interval exhausted' in detail:
            reason = 'checkpoint_readback_required'
            action = 'Export the current checkpoint, save to the authorized project destination and verify downloaded checkpoint/artifacts before new dispatch'
        elif 'migration required' in detail or 'explicit session contract required' in detail:
            reason = 'session_policy_required'
            action = 'Preserve attempts and usage; record explicit session_policy migration against the selected release before new dispatch'
        elif 'invocation identity required' in detail:
            action = 'Bind the current observed host ID or generate a fresh coordinator nonce for this invocation, then bootstrap its actual source reads'
        return dict(kind='blocked', reason=reason, detail=detail, next_action=action)


def apply(root, state, event, read_ref=_ref):
    """Apply session_* events to caller's CAS-owned in-memory state."""
    op = event.get('op')
    if op == 'session_policy':
        if state.get('current_attempt'):
            raise ValueError('settle current attempt before changing session policy')
        contract = _contract(root, event.get('contract'), read_ref)
        read_ref(root, event.get('source_ref'))
        _text(event.get('reason'), 'explicit migration/adoption reason')
        if not state.get('session'):
            initialize(root, state)
        session = _session(state)
        session['policy_history'].append(dict(revision=state['revision'],
            previous_contract=copy.deepcopy(state.get('session_contract')),
            source_ref=event['source_ref'], reason=event['reason']))
        state['session_contract'] = contract
        session['bootstrap'] = None
        return True
    session = _session(state)
    if op == 'session_bootstrap':
        receipt = read_ref(root, event.get('receipt_ref'), as_json=True)
        if receipt.get('kind') != 'chat-session-bootstrap' or receipt.get('project_uuid') != session['project_uuid']:
            raise ValueError('session bootstrap project/kind binding mismatch')
        scope = receipt.get('scope', 'new_work')
        if scope not in {'new_work', 'continuation'}:
            raise ValueError('bootstrap scope must be new_work or continuation')
        if scope == 'continuation':
            current = state.get('current_attempt')
            if (not current or receipt.get('attempt_id') != current['id']
                    or receipt.get('procedure') != current['procedure']):
                raise ValueError('continuation bootstrap requires the exact current attempt and original procedure')
        contract = _contract(root, state.get('session_contract'), read_ref,
                             validate_sources=scope != 'continuation')
        invocation = _text(receipt.get('host_invocation_id'), 'actual host invocation identity')
        origin = receipt.get('invocation_origin', 'host_observed')
        if origin not in {'host_observed', 'coordinator_nonce'}:
            raise ValueError('invocation origin must distinguish host observation from coordinator nonce')
        if origin == 'coordinator_nonce':
            try:
                uuid.UUID(invocation)
            except (ValueError, TypeError, AttributeError) as error:
                raise ValueError('fresh coordinator invocation UUID required') from error
        if _INVOCATION.get() and invocation != _INVOCATION.get():
            raise ValueError('receipt differs from current host invocation')
        for key in ('package_id', 'release', 'source_revision'):
            _text(receipt.get(key), 'actual loaded ' + key)
        procedure = receipt.get('procedure')
        if not isinstance(procedure, dict):
            raise ValueError('actual loaded procedure required')
        _text(procedure.get('id'), 'actual procedure id')
        read_ref(root, procedure.get('ref'))
        _refs(root, receipt.get('read_source_refs'), read_ref, nonempty=True)
        if procedure['ref'] not in receipt['read_source_refs']:
            raise ValueError('actual procedure must be in observed source reads')
        read_ref(root, receipt.get('observation_ref'))
        head_ref = receipt.get('authoritative_head_ref')
        if head_ref:
            manifest = verify_manifest(root, head_ref)
            if manifest['destination'] != contract['destination']:
                raise ValueError('authoritative destination mismatch')
            _manifest_ancestor(state, manifest)
            for known in (session.get('acknowledged_head'), session.get('observed_head')):
                if not known:
                    continue
                known_manifest = verify_manifest(root, known['manifest_ref'])
                if manifest['revision'] < known_manifest['revision']:
                    raise ValueError('observed authority is behind the newest known checkpoint')
                if (manifest['revision'] == known_manifest['revision']
                        and head_ref['sha256'] != known['manifest_ref']['sha256']):
                    raise ValueError('conflicting manifest identities at the same known revision')
                # A larger revision alone cannot supersede a known branch.
                incoming_checkpoint = _ref(root, manifest['checkpoint_ref'], as_json=True)
                _manifest_ancestor(incoming_checkpoint, known_manifest)
            session['observed_head'] = dict(manifest_ref=copy.deepcopy(head_ref), revision=manifest['revision'])
        elif _head(session):
            raise ValueError('resume requires an observed authoritative checkpoint head')
        session['bootstrap'] = dict(receipt_ref=copy.deepcopy(event['receipt_ref']),
                                    host_invocation_id=invocation, invocation_origin=origin)
    elif op == 'session_saved':
        if session.get('pending_save'):
            raise ValueError('reconcile the pending save readback before another publication')
        contract = _contract(root, state.get('session_contract'), read_ref)
        manifest_ref = event.get('manifest_ref')
        manifest = verify_manifest(root, manifest_ref)
        _manifest_ancestor(state, manifest)
        if manifest['destination'] != contract['destination']:
            raise ValueError('saved destination differs from project authority')
        head = _head(session)
        expected = head['manifest_ref'] if head else None
        if manifest.get('parent_manifest_ref') != expected:
            raise ValueError('save parent differs from acknowledged head; reconcile branch')
        if head and manifest['revision'] <= head['revision']:
            raise ValueError('save cannot replace newer or equal authority')
        receipt = read_ref(root, event.get('receipt_ref'), as_json=True)
        expected_fields = dict(kind='chat-checkpoint-save', project_uuid=session['project_uuid'],
            destination=contract['destination'], manifest_sha256=manifest_ref['sha256'],
            revision=manifest['revision'])
        if any(receipt.get(k) != v for k, v in expected_fields.items()):
            raise ValueError('save observation binding mismatch')
        _text(receipt.get('operation_id'), 'actual save operation identity')
        read_ref(root, receipt.get('execution_ref'))
        session['pending_save'] = dict(manifest_ref=copy.deepcopy(manifest_ref),
            receipt_ref=copy.deepcopy(event['receipt_ref']), revision=manifest['revision'])
    elif op == 'session_readback':
        pending = session.get('pending_save')
        if not pending:
            raise ValueError('record actual save before readback acknowledgement')
        receipt = read_ref(root, event.get('receipt_ref'), as_json=True)
        saved = read_ref(root, pending['receipt_ref'], as_json=True)
        manifest = verify_manifest(root, pending['manifest_ref'])
        _manifest_ancestor(state, manifest)
        readback_ref = receipt.get('readback_manifest_ref')
        read_ref(root, readback_ref)
        if readback_ref['sha256'] != pending['manifest_ref']['sha256']:
            raise ValueError('readback manifest differs from saved bytes')
        expected_fields = dict(kind='chat-checkpoint-readback', project_uuid=session['project_uuid'],
            destination=saved['destination'], save_operation_id=saved['operation_id'],
            revision=pending['revision'])
        if any(receipt.get(k) != v for k, v in expected_fields.items()):
            raise ValueError('readback observation binding mismatch')
        operation = _text(receipt.get('operation_id'), 'actual readback operation identity')
        if operation == saved['operation_id']:
            raise ValueError('readback must be a separate observed operation')
        read_ref(root, receipt.get('execution_ref'))
        restored = receipt.get('restored_artifact_refs')
        _refs(root, restored, read_ref, nonempty=True)
        hashes = {ref['sha256'] for ref in restored}
        if not {manifest['checkpoint_ref']['sha256'], *(r['sha256'] for r in manifest['artifacts'])} <= hashes:
            raise ValueError('readback must verify checkpoint and every manifest artifact, not just manifest text')
        session['acknowledged_head'] = dict(manifest_ref=copy.deepcopy(pending['manifest_ref']),
            revision=pending['revision'], readback_ref=copy.deepcopy(event['receipt_ref']))
        session['pending_save'] = None
    else:
        raise ValueError('unknown session operation')
    return True


def _inventory(root, state):
    """Transitive content graph, including raw evidence nested in JSON receipts."""
    pending, seen, result = [state], set(), []
    while pending:
        value = pending.pop()
        if isinstance(value, list):
            pending.extend(value)
        elif isinstance(value, dict):
            if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str):
                key = (value['path'], value['sha256'])
                if key in seen:
                    continue
                seen.add(key)
                if len(seen) > MAX_REFS:
                    raise ValueError('bounded checkpoint artifact inventory exceeded')
                reference = {'path': key[0], 'sha256': key[1]}
                _ref(root, reference)
                result.append(reference)
                try:
                    pending.append(_read(Path(root) / key[0]))
                except (UnicodeError, ValueError):
                    pass  # Non-JSON evidence remains hashed and included.
            else:
                pending.extend(value.values())
    return sorted(result, key=lambda ref: (ref['path'], ref['sha256']))


def _attempts(state):
    attempts = state.get('attempts', []) + ([state['current_attempt']] if state.get('current_attempt') else [])
    ids = [attempt['id'] for attempt in attempts]
    if len(ids) != len(set(ids)):
        raise ValueError('duplicate actual attempt identities')
    return [dict(attempt_id=a['id'], task_id=a['task_id'], status=a['status'],
                 outcome=a.get('outcome'), procedure=a['procedure'],
                 experiment_job_ids=a.get('experiment_job_ids', []),
                 evidence_ref=a.get('evidence_ref')) for a in attempts]


def _atomic_create(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(dir=path.parent, prefix=path.name + '.')
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        # Refuse overwrite, including a concurrent writer creating the same name.
        os.link(temporary, path)
    finally:
        os.unlink(temporary)


def export_manifest(state_path, output_path, *, parent_ref=None):
    """Create a local immutable snapshot+manifest; this is not a remote save."""
    state_path, output_path = Path(state_path).absolute(), Path(output_path).absolute()
    root, state = state_path.parent, _read(state_path)
    session, line = _session(state), validate_lineage(state)
    if session.get('pending_save'):
        raise ValueError('reconcile the pending save readback before another export')
    if not line:
        raise ValueError('explicit session migration and lineage stamp required before export')
    contract = _contract(root, state.get('session_contract'))
    expected = _head(session)
    if parent_ref is None and expected:
        parent_ref = expected['manifest_ref']
    if parent_ref != (expected['manifest_ref'] if expected else None):
        raise ValueError('export parent differs from acknowledged authority')
    if parent_ref:
        parent = verify_manifest(root, parent_ref)
        _manifest_ancestor(state, parent)
    snapshot = output_path.with_name(output_path.name + '.checkpoint.json')
    artifacts = _inventory(root, state)
    checkpoint_bytes = (json.dumps(state, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()
    snapshot_ref = dict(path=os.path.relpath(snapshot, root), sha256=hashlib.sha256(checkpoint_bytes).hexdigest())
    manifest = dict(kind='chat-checkpoint-manifest', schema_version=1,
        authority='observed_content_only', project_uuid=session['project_uuid'], goal_id=state['goal_id'],
        revision=state['revision'], checkpoint_digest=line['digest'], checkpoint_ref=snapshot_ref,
        destination=contract['destination'], parent_manifest_ref=copy.deepcopy(parent_ref),
        attempts=_attempts(state), artifacts=artifacts)
    if output_path.exists() or snapshot.exists():
        raise ValueError('immutable export already exists; choose a new filename')
    _atomic_create(snapshot, checkpoint_bytes)
    _atomic_create(output_path, _json_bytes(manifest) + b'\n')
    return dict(path=os.path.relpath(output_path, root), sha256=_hash(output_path))


def _verify_manifest_record(root, reference):
    manifest = _ref(root, reference, as_json=True)
    if manifest.get('kind') != 'chat-checkpoint-manifest' or manifest.get('schema_version') != 1:
        raise ValueError('checkpoint manifest kind/schema mismatch')
    checkpoint = _ref(root, manifest.get('checkpoint_ref'), as_json=True)
    line = validate_lineage(checkpoint)
    if not line or any(manifest.get(k) != expected for k, expected in {
            'project_uuid': _session(checkpoint)['project_uuid'], 'goal_id': checkpoint['goal_id'],
            'revision': checkpoint['revision'], 'checkpoint_digest': line['digest'],
            'attempts': _attempts(checkpoint)}.items()):
        raise ValueError('manifest differs from actual checkpoint lineage/attempts')
    contract = _contract(root, checkpoint.get('session_contract'), validate_sources=False)
    expected_head = _head(checkpoint['session'])
    expected_parent = expected_head['manifest_ref'] if expected_head else None
    if manifest.get('destination') != contract['destination']:
        raise ValueError('manifest destination differs from checkpoint session contract')
    if manifest.get('parent_manifest_ref') != expected_parent:
        raise ValueError('manifest parent differs from checkpoint publication authority')
    if manifest.get('artifacts') != _inventory(root, checkpoint):
        raise ValueError('manifest artifact closure differs from actual checkpoint')
    return manifest, checkpoint


def verify_manifest(root, reference):
    """Validate content and the complete bounded publication ancestry iteratively."""
    seen, current_ref, child_checkpoint, original = set(), reference, None, None
    while current_ref is not None:
        if not isinstance(current_ref, dict):
            raise ValueError('manifest parent reference required')
        key = (current_ref.get('path'), current_ref.get('sha256'))
        if key in seen:
            raise ValueError('cyclic manifest publication ancestry')
        seen.add(key)
        if len(seen) > MAX_MANIFEST_DEPTH:
            raise ValueError('bounded manifest publication ancestry exceeded; checkpoint archive migration required')
        manifest, checkpoint = _verify_manifest_record(root, current_ref)
        if original is None:
            original = manifest
        if child_checkpoint is not None:
            if manifest['revision'] >= child_checkpoint['revision']:
                raise ValueError('publication parent must be an earlier checkpoint')
            _manifest_ancestor(child_checkpoint, manifest)
        child_checkpoint = checkpoint
        current_ref = manifest.get('parent_manifest_ref')
    return original


def compare_heads(root, first_ref, second_ref):
    """Compare observed heads; never automatically select a divergent branch."""
    first, second = verify_manifest(root, first_ref), verify_manifest(root, second_ref)
    if first['project_uuid'] != second['project_uuid']:
        return {'relation': 'different_projects'}
    if first['checkpoint_digest'] == second['checkpoint_digest']:
        return {'relation': 'same_checkpoint'}
    a = _ref(root, first['checkpoint_ref'], as_json=True)['lineage']
    b = _ref(root, second['checkpoint_ref'], as_json=True)['lineage']
    if {'revision': a['revision'], 'digest': a['digest']} in b['ancestors']:
        return {'relation': 'second_descends_from_first'}
    if {'revision': b['revision'], 'digest': b['digest']} in a['ancestors']:
        return {'relation': 'first_descends_from_second'}
    return {'relation': 'divergent', 'action': 'reconcile_attempts_and_evidence_before_new_dispatch'}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('nonce', help='create a fresh current-invocation correlation ID when no host ID is exposed')
    export = sub.add_parser('export')
    export.add_argument('--state', required=True)
    export.add_argument('--output', required=True)
    check = sub.add_parser('verify')
    check.add_argument('--root', required=True)
    check.add_argument('--manifest', required=True, help='JSON {path,sha256} content reference')
    compare = sub.add_parser('compare')
    compare.add_argument('--root', required=True)
    compare.add_argument('--first', required=True)
    compare.add_argument('--second', required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == 'nonce':
            result = new_invocation()
        elif args.command == 'export':
            result = export_manifest(args.state, args.output)
        elif args.command == 'verify':
            result = verify_manifest(Path(args.root), json.loads(args.manifest))
        else:
            result = compare_heads(Path(args.root), json.loads(args.first), json.loads(args.second))
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        return 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(json.dumps({'error': str(error)}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
