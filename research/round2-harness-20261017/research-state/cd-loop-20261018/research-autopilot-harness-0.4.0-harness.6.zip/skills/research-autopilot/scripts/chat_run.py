#!/usr/bin/env python3
"""Durable bounded execution receipts for the current Chat host (Linux, stdlib).

This is an execution collector, not a scheduler or scientific validator. Commands
are reviewed argv, run without a shell, in a fresh copy of pinned files using the
existing native runner's staging. They must not daemonize or escape their process
group. Workspace isolation is not an OS sandbox and does not restrict absolute
path/network effects. Resource admission and permission remain with the caller.

API::
    plan = dict(attempt_id="a1", procedure_ref={"path": ..., "sha256": ...},
                input_refs=[], code_refs=[], command=["python3", "job.py"],
                cwd=".", output_paths=["result.json"], timeout_seconds=30,
                max_log_bytes=1048576, numeric_status_path=None)
    prepared = prepare(root, plan)  # new UUID; durable intent before dispatch
    receipt = execute(root, prepared["execution_id"], prepared["plan_digest"],
                      authorizer=lambda exact_scope: True)
    receipt = read_receipt(root, prepared["execution_id"])  # immutable readback
    observation = reconcile(root, prepared["execution_id"]) # never redispatches

prepare records rejected configuration without launching. execute also returns
that terminal rejection; another execute after dispatch is rejected. Logs are
bounded prefixes (byte counts and truncation retained), read as evidence only
with a committed receipt. Numeric status, if requested, is a fresh JSON output
{"status": "valid"|"invalid"|"partial"}; it is a workload report, not independent
validation. Exit zero alone is process success, never scientific acceptance.
All CPU values are observed user+system seconds for reaped command processes;
wall time is elapsed time, not CPU time or a reservation charge. Lost workers
leave unknown usage and require reconciliation, never an invented terminal run.
"""
import argparse
import copy
import ctypes
import fcntl
import math
import os
from pathlib import Path
import re
import selectors
import shutil
import signal
import subprocess
import sys
import time
import uuid

import _autoresearch as C
import chat_alerts as A
import run_experiments as R
import run_harness as H
import resource_queue as Q

BASE = "runs/chat-executions"
MAX_STATUS_BYTES = 65536

# The incident is separate from the immutable execution receipt. A notification
# adapter must later deliver it; recording it alone never means the user saw it.
_FAILURE_NOTICES = {
    "configuration_failed": ("configuration", "Command configuration was rejected before dispatch.",
                             "Read the committed receipt and correct the rejected configuration before a new attempt."),
    "failed": ("execution", "The command or its output checks failed.",
               "Read the committed receipt and bounded logs; classify the fault before repair or retry."),
    "numeric_invalid": ("numeric_invalid", "The workload reported numerically invalid output despite process exit.",
                        "Inspect numerical validity and affected outputs; do not treat this run as scientific evidence."),
    "timeout": ("timeout", "The command reached its declared execution deadline.",
                "Inspect cleanup and partial outputs, then decide a bounded continuation within the remaining budget."),
    "partial": ("partial", "The workload reported partial output; the requested execution is unfinished.",
                "Preserve the partial outputs and resume only the unfinished work under its pinned procedure."),
    "interrupted": ("interrupted", "The command was interrupted or its owner was lost.",
                    "Inspect the terminal receipt and cleanup evidence before deciding how to continue."),
}


def _reporting_warning(message):
    try: print(message, file=sys.stderr, flush=True)
    except Exception: pass  # notification failures must not replace the run result


def _report(root, execution_id, category, summary, next_action, *, evidence_paths=(), severity="error"):
    """Reporting must never replace a process result or make an unsafe retry safe."""
    try:
        refs = [C.reference(root, path) for path in evidence_paths]
    except Exception:
        refs = []
        _reporting_warning("CHAT_RUN_INCIDENT_EVIDENCE_UNREADABLE: reporting the observed fault without a saved evidence reference.")
    try:
        return A.safe_report(root, category=category, source="chat_run", scope=execution_id,
                             summary=summary, next_action=next_action,
                             evidence_refs=refs, severity=severity,
                             observation_id=C.hashed({"execution_id": execution_id, "category": category,
                                                      "evidence_refs": refs}) if refs else None)
    except Exception:
        # Even a broken reporter or unreadable evidence cannot mask the original
        # failure. Keep this message free of command arguments and raw log text.
        _reporting_warning("CHAT_RUN_INCIDENT_NOT_SAVED: report the execution fault through the live host channel.")


def _report_terminal(root, directory, receipt):
    notice = _FAILURE_NOTICES.get(receipt.get("status"))
    if notice is None: return
    if receipt.get("reason") in {"command_startup_failed", "watchdog_startup_failed"}:
        notice = ("startup", "The requested command or execution watchdog could not start.",
                  "Inspect the startup receipt and executable or host dependency; this does not establish that all CPU execution is unavailable.")
    _report(root, directory.name, *notice, evidence_paths=[directory / "receipt.json"],
            severity="warning" if receipt.get("status") == "partial" else "error")


def _report_uncertain(root, directory, observation):
    """Pin an observation, not mutable live logs and not an invented terminal run."""
    paths = []
    try:
        path = directory / "observations" / (C.hashed(observation) + ".json")
        if not path.exists():
            try: _save(path, observation, immutable=True)
            except FileExistsError: pass  # another observer pinned the same bytes
        if C.load_file(path) != observation: raise ValueError("CHAT_RUN_OBSERVATION_CHANGED")
        paths.append(path)
    except Exception:
        # The incident still matters when its checkpoint could not be persisted.
        _reporting_warning("CHAT_RUN_OBSERVATION_NOT_SAVED: execution remains uncertain.")
    _report(root, directory.name, "reconcile_required",
            "Execution has no confirmed terminal receipt; process state or complete usage remains uncertain.",
            "Reconcile the original execution identity before retrying; preserve unknown usage and report the interruption.",
            evidence_paths=paths)


def _save(path, value, *, immutable=False):
    if not immutable:
        H._atomic(path, value)
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        with temp.open("x", encoding="utf-8") as stream:
            stream.write(C.canonical(value) + "\n"); stream.flush(); os.fsync(stream.fileno())
        os.link(temp, path)  # fail, never overwrite an already committed record
        fd = os.open(str(path.parent), os.O_RDONLY)
        try: os.fsync(fd)
        finally: os.close(fd)
    finally:
        if temp.exists(): temp.unlink()


def _location(root, execution_id):
    if not isinstance(execution_id, str) or not re.fullmatch(r"[0-9a-f]{32}", execution_id):
        raise ValueError("CHAT_RUN_INVALID_EXECUTION_ID")
    root = C.root_path(root)
    return root, C.safe_path(root, BASE + "/" + execution_id)


def _relative(value):
    if not isinstance(value, str) or not value or Path(value).is_absolute() or ".." in Path(value).parts:
        raise ValueError("CHAT_RUN_INVALID_RELATIVE_PATH")
    if value == "." or Path(value).as_posix() != value: raise ValueError("CHAT_RUN_CANONICAL_FILE_PATH_REQUIRED")
    return value


def _validate(root, plan):
    if "resources" in plan:
        Q.validate(plan["resources"])
    if not Path("/proc/self/stat").is_file(): raise ValueError("CHAT_RUN_LINUX_IDENTITY_REQUIRED")
    if not isinstance(plan.get("attempt_id"), str) or not plan["attempt_id"].strip():
        raise ValueError("CHAT_RUN_ATTEMPT_REQUIRED")
    command = plan.get("command")
    if not isinstance(command, list) or not command or any(not isinstance(x, str) or not x or "\x00" in x for x in command):
        raise ValueError("CHAT_RUN_ARGV_REQUIRED")
    timeout = plan.get("timeout_seconds")
    if isinstance(timeout, bool) or not isinstance(timeout, (float, int)) or not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("CHAT_RUN_FINITE_TIMEOUT_REQUIRED")
    cap = plan.get("max_log_bytes", 1048576)
    if type(cap) is not int or not 1 <= cap <= 64 * 1048576:
        raise ValueError("CHAT_RUN_LOG_BOUND_REQUIRED")
    if type(plan.get("max_output_bytes", 268435456)) is not int or not 1 <= plan.get("max_output_bytes", 268435456) <= 68719476736:
        raise ValueError("CHAT_RUN_OUTPUT_BOUND_REQUIRED")
    C.verify_ref(root, plan["procedure_ref"])
    refs = plan.get("input_refs", []) + plan.get("code_refs", [])
    paths = []
    for ref in refs:
        _relative(ref["path"]); C.verify_ref(root, ref); paths.append(ref["path"])
    if len(paths) != len(set(paths)): raise ValueError("CHAT_RUN_INPUT_PATH_COLLISION")
    outputs = plan.get("output_paths", [])
    if not isinstance(outputs, list): raise ValueError("CHAT_RUN_OUTPUT_PATHS_REQUIRED")
    for value in outputs: _relative(value)
    if len(outputs) != len(set(outputs)): raise ValueError("CHAT_RUN_OUTPUT_COLLISION")
    for output in outputs:
        for other in paths + [x for x in outputs if x != output]:
            if Path(output) == Path(other) or Path(output) in Path(other).parents or Path(other) in Path(output).parents:
                raise ValueError("CHAT_RUN_OUTPUT_INPUT_COLLISION")
    numeric = plan.get("numeric_status_path")
    if numeric is not None and numeric not in outputs: raise ValueError("CHAT_RUN_NUMERIC_OUTPUT_REQUIRED")
    cwd = plan.get("cwd", ".")
    if cwd != ".": _relative(cwd)


def _logs(directory):
    return {name: {"retained_bytes": (directory / (name + ".log")).stat().st_size,
                   "observed_bytes": (directory / (name + ".log")).stat().st_size,
                   "truncated": False} for name in ("stdout", "stderr")}


def _error_log(directory, plan, error):
    cap = plan.get("max_log_bytes", 1048576)
    if type(cap) is not int or not 1 <= cap <= 64 * 1048576: cap = 4096
    raw = (str(error)[:4096] + "\n").encode()
    (directory / "stderr.log").write_bytes(raw[:cap])
    logs = _logs(directory)
    logs["stderr"].update(observed_bytes=len(raw), truncated=len(raw) > cap)
    return logs


def _finish(root, directory, plan, status, *, reason=None, exit_code=None,
            wall_seconds=0.0, cpu_seconds=0.0, cpu_scope="no_command_dispatched",
            logs=None, output_refs=None, cleanup=None):
    execution_id = directory.name
    receipt = {"schema_version": 1, "execution_id": execution_id,
        "attempt_id": plan.get("attempt_id"), "plan_digest": C.hashed(plan),
        "procedure_ref": plan.get("procedure_ref"), "input_refs": plan.get("input_refs", []),
        "code_refs": plan.get("code_refs", []), "status": status, "reason": reason,
        "exit_code": exit_code, "completed_at": C.now(), "wall_seconds": wall_seconds,
        "cpu_seconds": cpu_seconds, "cpu_scope": cpu_scope,
        "model_charge": 0 if cpu_scope == "no_command_dispatched" else None,
        "scientific_accepted": False, "gate_advanced": False,
        "output_refs": output_refs or [], "logs": logs or _logs(directory), "cleanup": cleanup,
        "procedure_snapshot_ref": C.reference(root, directory / "procedure.snapshot") if (directory / "procedure.snapshot").is_file() else None,
        "stdout_ref": C.reference(root, directory / "stdout.log"),
        "stderr_ref": C.reference(root, directory / "stderr.log")}
    _save(directory / "receipt.json", receipt, immutable=True)
    _save(directory / "commit.json", {"receipt_ref": C.reference(root, directory / "receipt.json")}, immutable=True)
    _report_terminal(root, directory, receipt)
    _release_resources(directory, plan)
    return receipt


def _release_resources(directory, plan):
    state = C.load_file(directory / "state.json")
    ticket = state.get("resource_wait")
    if ticket:
        Q.transition(plan["resources"], ticket["key"], "settled", "Committed terminal execution receipt")


def prepare(root, plan, *, execution_id=None):
    """Pin the complete finite command intent. Invalid configs get a receipt."""
    execution_id = execution_id or uuid.uuid4().hex
    root, directory = _location(root, execution_id)
    plan = copy.deepcopy(plan)
    digest = C.hashed(plan)  # rejects non-JSON / NaN before creating state
    directory.mkdir(parents=True, exist_ok=False)
    _save(directory / "plan.json", plan, immutable=True)
    for name in ("stdout", "stderr"): (directory / (name + ".log")).touch(exist_ok=False)
    state = {"execution_id": execution_id, "plan_digest": digest, "status": "prepared",
             "created_at": C.now(), "owner": H._self_identity()}
    _save(directory / "state.json", state)
    started = time.monotonic()
    try:
        _validate(root, plan)
        shutil.copy2(C.verify_ref(root, plan["procedure_ref"]), directory / "procedure.snapshot")
        if C.filehash(directory / "procedure.snapshot") != plan["procedure_ref"]["sha256"]:
            raise ValueError("CHAT_RUN_PROCEDURE_CHANGED_DURING_PREPARE")
    except (ValueError, KeyError, TypeError, OSError, C.Failure) as error:
        logs = _error_log(directory, plan, error)
        _finish(root, directory, plan, "configuration_failed", reason=str(error)[:4096],
                wall_seconds=time.monotonic() - started, logs=logs)
        state["status"] = "configuration_failed"
    return state


def read_receipt(root, execution_id):
    """Only return committed terminal logs/outputs; reject changed bytes."""
    root, directory = _location(root, execution_id)
    if not (directory / "commit.json").is_file():
        raise ValueError("CHAT_RUN_NOT_TERMINAL")
    commit = C.load_file(directory / "commit.json")
    receipt = C.load_file(C.verify_ref(root, commit["receipt_ref"]))
    plan = C.load_file(directory / "plan.json")
    if receipt["execution_id"] != execution_id or receipt["plan_digest"] != C.hashed(plan):
        raise ValueError("CHAT_RUN_RECEIPT_BINDING_CHANGED")
    references = [receipt["stdout_ref"], receipt["stderr_ref"]] + receipt["output_refs"]
    if receipt.get("procedure_snapshot_ref"): references.append(receipt["procedure_snapshot_ref"])
    for ref in references:
        C.verify_ref(root, ref)
    return receipt


def reconcile(root, execution_id):
    """Observe existing identities, never retry an uncertain launch."""
    root, directory = _location(root, execution_id)
    if (directory / "commit.json").is_file():
        receipt = read_receipt(root, execution_id)
        _report_terminal(root, directory, receipt)
        _release_resources(directory, C.load_file(directory / "plan.json"))
        return receipt
    state = C.load_file(directory / "state.json")
    result = {**state, "scientific_accepted": False, "gate_advanced": False,
              "cpu_seconds": None, "output_refs": [], "terminal": False}
    if state["status"] == "prepared":
        if state.get("resource_wait"):
            result["status"] = "waiting_resources" if state["resource_wait"]["status"] == "queued" else state["resource_wait"]["status"]
        return result
    if state["status"] == "reconcile_required":
        _report_uncertain(root, directory, result)
        return result
    if H._alive(state.get("worker")):
        result["status"] = "running"; return result
    result["status"] = "reconcile_required"
    result["reason"] = "Worker not observed alive; missing receipt does not establish command termination."
    _report_uncertain(root, directory, result)
    return result


def execute(root, execution_id, expected_digest, *, authorizer=None, resource_wait_seconds=30):
    """Dispatch once and wait for its independent finite watchdog's receipt."""
    if type(resource_wait_seconds) not in (int, float) or not math.isfinite(resource_wait_seconds) or resource_wait_seconds < 0:
        raise ValueError("finite nonnegative resource_wait_seconds required")
    root, directory = _location(root, execution_id)
    fd = os.open(directory / "dispatch.lock", os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        plan = C.load_file(directory / "plan.json")
        state = C.load_file(directory / "state.json")
        if expected_digest != C.hashed(plan) or state["plan_digest"] != expected_digest:
            raise ValueError("CHAT_RUN_PLAN_CHANGED")
        if (directory / "commit.json").exists():
            receipt = read_receipt(root, execution_id)
            if receipt["status"] == "configuration_failed": return receipt
            raise ValueError("CHAT_RUN_ALREADY_DISPATCHED")
        if state["status"] != "prepared": raise ValueError("CHAT_RUN_ALREADY_DISPATCHED")
        R._authorize(authorizer, {"operation": "chat_bounded_command", "execution_id": execution_id,
                                 "plan_digest": expected_digest, "plan": plan})
        if plan.get("resources") is not None:
            until = time.monotonic() + resource_wait_seconds
            while True:
                ticket = Q.poll(root, "chat:" + execution_id, plan["resources"], expected_digest,
                                deadline_epoch=plan.get("resource_deadline_epoch"))
                state["resource_wait"] = ticket
                _save(directory / "state.json", state)
                if ticket["status"] == "admitted":
                    break
                if ticket["status"] != "queued" or time.monotonic() >= until:
                    return {**reconcile(root, execution_id), "status": "waiting_resources" if ticket["status"] == "queued" else ticket["status"]}
                time.sleep(min(max(.01, ticket["next_check_at"] - time.time()), max(.01, until - time.monotonic())))
        # Revalidate bytes at dispatch; a rejected intent never consumes a command reservation.
        started = time.monotonic()
        try:
            _validate(root, plan)
            command, cwd, workspace = R._stage(root, {**plan, "input_refs": plan.get("input_refs", []),
                "code_refs": plan.get("code_refs", []), "cwd": plan.get("cwd", ".")}, directory)
            for output in plan.get("output_paths", []):
                if C.safe_path(workspace, output).exists(): raise ValueError("CHAT_RUN_STALE_OUTPUT")
        except (ValueError, KeyError, TypeError, OSError, C.Failure) as error:
            logs = _error_log(directory, plan, error)
            return _finish(root, directory, plan, "configuration_failed", reason=str(error)[:4096],
                           wall_seconds=time.monotonic() - started, logs=logs)
        state.update(status="launching", owner=H._self_identity(), command=command, cwd=str(cwd),
                     dispatched_at=C.now())
        _save(directory / "state.json", state)
        if state.get("resource_wait"):
            Q.transition(plan["resources"], state["resource_wait"]["key"], "dispatched", "Original Chat execution dispatch")
        # Worker has an independent timeout and observes owner death. Its stderr is
        # separate from command logs, preserving startup/collector failures too.
        try:
            with (directory / "worker.log").open("xb") as errors:
                worker = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), "_worker",
                    str(root), execution_id], stdin=subprocess.DEVNULL, stdout=errors, stderr=errors,
                    start_new_session=True, shell=False)
                worker.wait(timeout=float(plan["timeout_seconds"]) + 10)
        except OSError as error:
            logs = _error_log(directory, plan, repr(error))
            return _finish(root, directory, plan, "failed", reason="watchdog_startup_failed",
                           wall_seconds=time.monotonic() - started, logs=logs)
        except subprocess.TimeoutExpired:
            # Do not kill the watchdog blindly: it may be cleaning up the command.
            return reconcile(root, execution_id)
        except KeyboardInterrupt:
            worker.terminate()
            try: worker.wait(timeout=5)
            except subprocess.TimeoutExpired: return reconcile(root, execution_id)
        return read_receipt(root, execution_id) if (directory / "commit.json").exists() else reconcile(root, execution_id)
    finally:
        os.close(fd)


def _host_pid(local_pid):
    """procfs may show outer-namespace PIDs while wait4/Popen use inner PIDs."""
    owner = H._self_identity()["pid"]
    for path in Path("/proc").glob("[0-9]*/status"):
        try:
            fields = dict(line.split(":", 1) for line in path.read_text().splitlines() if ":" in line)
            ids = fields.get("NSpid", fields["Pid"]).split()
            if int(ids[-1]) == local_pid and int(fields["PPid"]) == owner:
                return int(fields["Pid"])
        except (OSError, ValueError, KeyError): continue
    return None


def _local_pid(identity):
    if not H._alive(identity): return None
    try:
        fields = dict(line.split(":", 1) for line in Path("/proc/%s/status" % identity["pid"]).read_text().splitlines() if ":" in line)
        return int(fields.get("NSpid", fields["Pid"]).split()[-1])
    except (OSError, ValueError, KeyError): return None


def _group_members(pgid):
    members = []
    for path in Path("/proc").glob("[0-9]*/stat"):
        try:
            fields = path.read_text().rsplit(")", 1)[1].split()
            if int(fields[2]) == pgid and fields[0] != "Z":
                identity = H._identity(int(path.parent.name))
                if identity: members.append(identity)
        except (OSError, ValueError, IndexError): continue
    return members


def _outputs(root, directory, plan):
    workspace = directory / "workspace"; refs = []; total_bytes = 0
    pinned = [C.safe_path(workspace, item["path"]) for item in plan.get("input_refs", []) + plan.get("code_refs", [])]
    for relative in plan.get("output_paths", []):
        path = C.safe_path(workspace, relative)
        if path.is_symlink() or any(parent.is_symlink() for parent in path.parents if parent != workspace.parent):
            raise ValueError("CHAT_RUN_OUTPUT_SYMLINK")
        if not path.is_file(): raise ValueError("CHAT_RUN_OUTPUT_MISSING:" + relative)
        if path.stat().st_nlink != 1 or any(path.samefile(item) for item in pinned):
            raise ValueError("CHAT_RUN_OUTPUT_NOT_OWNED:" + relative)
        total_bytes += path.stat().st_size
        if total_bytes > plan.get("max_output_bytes", 268435456): raise ValueError("CHAT_RUN_OUTPUT_BYTE_LIMIT")
        refs.append(C.reference(root, path))
    return refs


def _worker(root, execution_id):
    root, directory = _location(root, execution_id)
    plan = C.load_file(directory / "plan.json"); state = C.load_file(directory / "state.json")
    if state["status"] != "launching" or state["plan_digest"] != C.hashed(plan):
        raise ValueError("CHAT_RUN_WORKER_INTENT_MISMATCH")
    # Reaping orphaned foreground descendants produces their actual CPU receipts.
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0: raise RuntimeError("CHAT_RUN_SUBREAPER_UNAVAILABLE")
    stopped = False
    def stop(signum, frame):
        nonlocal stopped
        stopped = True
    signal.signal(signal.SIGTERM, stop); signal.signal(signal.SIGINT, stop)
    state.update(worker=H._self_identity()); _save(directory / "state.json", state)
    start = time.monotonic(); deadline = start + plan["timeout_seconds"]
    logs = {name: {"observed_bytes": 0, "retained_bytes": 0, "truncated": False} for name in ("stdout", "stderr")}
    selector = selectors.DefaultSelector(); process = None; status = "failed"; reason = None
    exit_code = None; cpu = 0.0; reaped = []; leader_done = False; cleanup = None; host_pid = None
    streams = {name: (directory / (name + ".log")).open("wb") for name in logs}
    def retain(name, data):
        record = logs[name]; record["observed_bytes"] += len(data)
        keep = data[:max(0, plan.get("max_log_bytes", 1048576) - record["retained_bytes"])]
        streams[name].write(keep); record["retained_bytes"] += len(keep)
        record["truncated"] = record["observed_bytes"] > record["retained_bytes"]
    try:
        if not H._alive(state["owner"]):
            status = "interrupted"; reason = "owner_lost_before_command"
        else:
            process = subprocess.Popen(state["command"], cwd=state["cwd"], shell=False,
                start_new_session=True, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            host_pid = _host_pid(process.pid)
            state.update(status="running", command_process=H._identity(host_pid) if host_pid else None,
                         command_group_host_pid=host_pid)
            _save(directory / "state.json", state)
            for name in logs:
                pipe = getattr(process, name); os.set_blocking(pipe.fileno(), False)
                selector.register(pipe, selectors.EVENT_READ, name)
            while True:
                for key, _ in selector.select(.025):
                    data = os.read(key.fileobj.fileno(), 65536)
                    if data: retain(key.data, data)
                    else: selector.unregister(key.fileobj); key.fileobj.close()
                while True:
                    try: pid, code, usage = os.wait4(-1, os.WNOHANG)
                    except ChildProcessError: break
                    if not pid: break
                    reaped.append(pid); cpu += usage.ru_utime + usage.ru_stime
                    if pid == process.pid:
                        leader_done = True; exit_code = os.waitstatus_to_exitcode(code); process.returncode = exit_code
                if stopped or not H._alive(state["owner"]):
                    status = "interrupted"; reason = "owner_interrupted_or_lost"; break
                if time.monotonic() >= deadline:
                    status = "timeout"; reason = "command_deadline"; break
                if leader_done:
                    survivors = _group_members(host_pid)
                    status = "completed" if exit_code == 0 else "failed"
                    if survivors:
                        status = "interrupted"; reason = "foreground_children_outlived_command"
                    if not selector.get_map() or survivors: break
            # Kill only this command's freshly created foreground group. Children
            # leaving it violate the contract; report surviving descendants below.
            for item in _group_members(host_pid):
                local_pid = _local_pid(item)
                if local_pid is not None:
                    try: os.kill(local_pid, signal.SIGKILL)
                    except ProcessLookupError: pass
            until = time.monotonic() + 2
            while time.monotonic() < until:
                while True:
                    try: pid, code, usage = os.wait4(-1, os.WNOHANG)
                    except ChildProcessError: pid = 0; break
                    if not pid: break
                    reaped.append(pid); cpu += usage.ru_utime + usage.ru_stime
                    if pid == process.pid:
                        leader_done = True; exit_code = os.waitstatus_to_exitcode(code); process.returncode = exit_code
                for key, _ in selector.select(.01):
                    data = os.read(key.fileobj.fileno(), 65536)
                    if data: retain(key.data, data)
                    else: selector.unregister(key.fileobj); key.fileobj.close()
                if leader_done and not _group_members(host_pid) and not selector.get_map(): break
            descendants = [H._identity(pid) for pid in H._descendants([H._self_identity()]) if pid != H._self_identity()["pid"]]
            descendants = [item for item in descendants if item]
            cleanup = {"foreground_group_alive": bool(_group_members(host_pid)),
                       "observed_surviving_descendants": descendants, "reaped_pids": reaped}
            if cleanup["foreground_group_alive"] or descendants or not leader_done or selector.get_map() or host_pid is None:
                status = "reconcile_required"; reason = "command_cleanup_not_confirmed"
    except Exception as error:
        # A collector/state-write failure after Popen is not a startup failure.
        # Preserve the diagnostic and attempt bounded cleanup, but never commit a
        # terminal receipt from this interrupted collection path. Even when the
        # foreground command is killed, complete usage/output collection is not
        # established, so reconciliation owns the remaining decision.
        diagnostic = (repr(error)[:4096] + "\n").encode()
        try: retain("stderr", diagnostic)
        except OSError: pass
        if process is None:
            status = "failed"; reason = "command_startup_failed"
        else:
            status = "reconcile_required"; reason = "collector_failed_after_dispatch"
            print(reason + ": " + repr(error)[:4096], file=sys.stderr, flush=True)
            try:
                if host_pid is None and not leader_done:
                    # This Popen child has not been reaped: its owned group cannot
                    # have been recycled. This handles failure during PID lookup.
                    try: os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError: pass
                else:
                    for item in _group_members(host_pid):
                        local_pid = _local_pid(item)
                        if local_pid is not None:
                            try: os.kill(local_pid, signal.SIGKILL)
                            except ProcessLookupError: pass
                until = time.monotonic() + 2
                while time.monotonic() < until:
                    try: pid, code, usage = os.wait4(-1, os.WNOHANG)
                    except ChildProcessError: break
                    if pid:
                        reaped.append(pid); cpu += usage.ru_utime + usage.ru_stime
                        if pid == process.pid:
                            leader_done = True
                            exit_code = os.waitstatus_to_exitcode(code); process.returncode = exit_code
                    elif leader_done: break
                    else: time.sleep(.01)
                descendants = [H._identity(pid) for pid in H._descendants([H._self_identity()])
                               if pid != H._self_identity()["pid"]]
                cleanup = {"foreground_group_alive": bool(_group_members(host_pid)) if host_pid else None,
                           "observed_surviving_descendants": [item for item in descendants if item],
                           "leader_reaped": leader_done, "reaped_pids": reaped}
            except Exception as cleanup_error:
                cleanup = {"confirmed": False, "error": repr(cleanup_error)[:4096]}
            # Pipes may not yet have been registered when state persistence failed.
            # Keep available bytes, without blocking on an escaped descendant.
            for name in logs:
                pipe = getattr(process, name)
                if pipe is None or pipe.closed: continue
                try:
                    os.set_blocking(pipe.fileno(), False)
                    drain_until = time.monotonic() + .1
                    while time.monotonic() < drain_until:
                        data = os.read(pipe.fileno(), 65536)
                        if not data: break
                        retain(name, data)
                except (BlockingIOError, OSError): pass
                finally: pipe.close()
    finally:
        for stream in streams.values(): stream.flush(); os.fsync(stream.fileno()); stream.close()
        selector.close()
    output_refs = []
    if status == "completed":
        try:
            for item in plan.get("input_refs", []) + plan.get("code_refs", []):
                C.verify_ref(directory / "workspace", item)
            output_refs = _outputs(root, directory, plan)
            numeric = plan.get("numeric_status_path")
            if numeric:
                path = C.safe_path(directory / "workspace", numeric)
                if path.stat().st_size > MAX_STATUS_BYTES: raise ValueError("CHAT_RUN_NUMERIC_STATUS_TOO_LARGE")
                value = C.load_file(path)
                if not isinstance(value, dict) or value.get("status") not in {"valid", "invalid", "partial"}:
                    raise ValueError("CHAT_RUN_NUMERIC_STATUS_INVALID")
                if value["status"] == "invalid": status = "numeric_invalid"
                elif value["status"] == "partial": status = "partial"
        except (ValueError, TypeError, OSError, C.Failure) as error:
            status = "failed"; reason = str(error)
    elif status != "reconcile_required":
        # Preserve freshly owned partial outputs without calling them completed.
        remaining = plan.get("max_output_bytes", 268435456)
        for path in plan.get("output_paths", []):
            try:
                partial = _outputs(root, directory, {**plan, "output_paths": [path], "max_output_bytes": remaining})
                output_refs.extend(partial)
                remaining -= sum((root / ref["path"]).stat().st_size for ref in partial)
            except (ValueError, OSError, C.Failure): pass
    if status == "reconcile_required":
        state.update(status=status, reason=reason, cleanup=cleanup, observed_cpu_lower_bound=cpu)
        _report_uncertain(root, directory, {**state, "scientific_accepted": False, "gate_advanced": False,
                                          "cpu_seconds": None, "output_refs": [], "terminal": False})
        _save(directory / "state.json", state)
        return
    _finish(root, directory, plan, status, reason=reason, exit_code=exit_code,
            wall_seconds=time.monotonic() - start, cpu_seconds=cpu,
            cpu_scope="reaped_command_processes_observed" if process else "no_command_dispatched",
            logs=logs, output_refs=output_refs, cleanup=cleanup)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=["prepare", "execute", "read", "reconcile", "_worker"])
    parser.add_argument("root"); parser.add_argument("value")
    parser.add_argument("--resource-wait-seconds", type=float, default=30)
    parser.add_argument("--expected-digest"); parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    try:
        if args.operation == "_worker": return _worker(args.root, args.value)
        if args.operation == "prepare": result = prepare(args.root, C.load_file(Path(args.value)))
        elif args.operation == "execute":
            if not args.execute: parser.error("--execute is required for dispatch")
            result = execute(args.root, args.value, args.expected_digest, authorizer=lambda scope: True, resource_wait_seconds=args.resource_wait_seconds)
        else: result = (read_receipt if args.operation == "read" else reconcile)(args.root, args.value)
    except Exception:
        # stdout remains the normal result protocol; the original traceback and
        # exit status stay available to the host even if the outbox is unwritable.
        scope = args.value if re.fullmatch(r"[0-9a-f]{32}", args.value) else "cli:" + args.operation
        _report(args.root, scope, "host_tool",
                "The execution helper could not complete its requested operation.",
                "Read the host error, report the capability or integrity fault, and reconcile any existing execution before retrying.")
        raise
    print(C.canonical(result))


if __name__ == "__main__": main()
