## 7. State model and routing

**Autonomous branch:** read [autonomous-rsi](autonomous-rsi.md) with this module. Its finite delegated machine supervisor replaces routine human step-7 selection and selects the startup-authorized delivery branch; scientific evidence, existing goals, budgets and same-attempt recovery remain binding. Older human-at-every-batch/main-only wording below describes the baseline and is superseded only within that explicit delegation.

Ordinary phase advances accepted by `advance_phase` are the following
machine-readable matrix. All other ordinary phase advances are illegal. Freeze,
gate decisions, repair completion, and writing advancement use their dedicated
outcomes in the normative table below; a generic phase change cannot replace them.

```json
{
  "schema_version": "1.0.0",
  "phase_advances": [
    {"route": "explore_problem", "from": "landscape", "to": "candidate_generation"},
    {"route": "audit_method", "from": "landscape", "to": "candidate_generation"},
    {"route": "audit_rejection", "from": "landscape", "to": "candidate_generation"},
    {"route": "develop_candidate", "from": "candidate_generation", "to": "collision_audit"},
    {"route": "repair_evidence", "from": "landscape", "to": "active_research"}
  ],
  "default": "illegal"
}
```

For an existing mature M/R project, `begin_retrospective_validation` enters
`full_experiments/active_research` only after A3/E3 audit evidence is verified.
It then freezes and evaluates a retrospective full-validation protocol before
writing. It never imports a prose statement of PASS as a verified decision.

`I`, `M`, and `R` describe immutable intake origin. They are never transition targets. Track the current route and lifecycle separately:

```yaml
entry_origin: I | M | R
current_route: explore_problem | audit_method | audit_rejection | repair_evidence | develop_candidate | replicate_or_transfer | execute_gate_a | full_experiments | prepare_writing | retarget | stopped
lifecycle_phase: intake | landscape | candidate_generation | collision_audit | gate_a_design | gate_a_execution | active_research | evidence_freeze | writing | submission_lock | terminal
asset_stage: A0_topic | A1_method | A2_pilot | A3_mature
evidence_trust: E0_narrative | E1_tables | E2_recomputable | E3_audited
claim_clarity: C0_topic | C1_question | C2_falsifiable
literature_state: L0_unsearched | L1_mapped | L2_primary_verified | L3_current_snapshot | stale
gate_state: not_ready | gate_a_frozen | pass | revise | kill | inconclusive
validation_state: not_ready | frozen | pass | revise | kill | inconclusive
writing_state: not_ready | evidence_frozen | planning | drafting | submission_lock
terminal_status: none | completed | stopped | abandoned | superseded
suspension: null | {return_route, return_phase, blocking_obligation_ids, suspended_snapshot_digest}
```

Routing behavior follows `current_route`, not `entry_origin`. Origin changes mandatory context only: an `R` project always retains and rechecks its reviewer-issue ledger; an `M` project always retains its authoritative asset/provenance audit; an `I` project always retains its problem-selection and landscape rationale. Rerouting never erases those obligations.

H01 thinking routes and the H03 navigation card are advisory choices inside this
workflow, specified in [method-development-tree.md](method-development-tree.md).
P/X supervisor/worker roles and route instances in
[multi-route-supervision.md](multi-route-supervision.md) are a coordination overlay,
not new scientific routes/phases/outcomes. Shared checkpoints cannot patch a
project's gate state. Changed results warn every same-project route until newer
canonical validation/closure verifies; unknown/stale/manual progress stays labeled.
Continue/switch/combine does not create a route, phase, outcome or gate PASS.
Record the next legal action under the existing transition table. A same-problem
candidate revision preserves the parent and triggers the existing child-candidate
review obligations; IPCG REROUTE uses the existing restart/new-parent process.
Keep origin immutable and do not reinterpret an invalid run as scientific failure.

### Batch-end machine review after E04

Use autonomous-rsi.md and chat-execution.md for machine selection. Classify
infrastructure faults, incomplete evidence and actual counterevidence separately.
Continue independent eligible work. Reports do not pause the goal or need
routine human direction. Within delegation, return to source investigation,
derivation, implementation or concrete evidence collection.
New candidates require substantive changes and preserved failure history.
Actual scope/access/spending expansion still requires its real authorization.

Candidate KILL closes that candidate, not the research goal. New Gate A or
full-validation KILL returns to explore_problem/landscape, terminal_status none,
retaining the failed decision/protocol. A successor research_candidate requires
the recovery payload in autonomous-rsi.md. Renaming is insufficient. Historical
terminal projects stay terminal; explicit project stop still ends work.
REVISE and INCONCLUSIVE retain their existing child/repair paths.

Completion needs requested outcomes and real delivery evidence. Positive/no-gap
alone is not completion. Pending empirical evidence does not block finishing
a labelled code-only/design-only requested artifact. Preserve cumulative limits
and exact next actions across active Chat turns.

### 7.1 Resume and recovery

Resume detection precedes new intake on every invocation. Locate state from an explicit path, the configured durable state root, or the current project. Validate schema versions, ledger continuity, asset hashes, permissions, pending operations, and frozen artifacts before continuing.

- If one valid state matches, show project, current route, last completed milestone, changed assets, unresolved blocker, and next safe action. Proceed without a question when that action is read-only and unambiguous.
- If multiple states match, ask one selection question.
- If state is corrupt or incompatible, preserve it unchanged and offer read-only recovery; never silently overwrite or merge it.
- “Start over” creates a new lineage and marks the earlier state `superseded` only with user approval.
- Persist accepted intake values after each answer and never re-ask confirmed, denied, or unchanged fields. Revisit a deferred field only when a later concrete action makes it blocking, explain the new dependency, and offer a skip or degraded route.
- Before resuming a side effect, reconcile its stable operation ID and provider job, commit, PR, or publication ID. An adapter is retry-safe only if the provider enforces the idempotency key or can query by an immutable request/effect fingerprint. If neither capability exists after a lost acknowledgment, enter `manual_reconciliation_required` and never retry automatically.
- Repository or Hub revision changes create a new asset version or evidence overlay rather than mutating a frozen snapshot.
