# Artifact contracts

Supported package/schema version: 1.0.0. Registry: `schemas/*.schema.json`.
Persist schema_id and schema_version on each object. JSON is valid YAML and is
the default encoding of emitted .yaml files; optional ordinary YAML input needs
the host's existing PyYAML.

Use absolute PROJECT and SKILL_DIR paths. Scripts return JSON and stable errors.
Validation/registry commands are local. The bounded runner and optional live
native scorer context execute only explicitly authorized reviewed commands;
they do not issue grants, provision GPUs/accounts or save to cloud storage.

| Command | Purpose |
| --- | --- |
| `init_project.py --root PROJECT --name NAME --goal GOAL --entry I|M|R --mode audit --intake FILE` | Preserve a prepared goal/resource intake when creating confirmed-origin state; resume an existing project without replacing its intake |
| `validate_artifact.py FILE` | Validate a registered artifact |
| `verify_methods.py --root PROJECT --batch RELATIVE --require selection_verified` | Derive per-method evidence status; require the verified declared mathematical cohort and justified selection before code design |
| `validate_artifact.py HANDOFF --evidence-root PROJECT` | Validate handoff against current full-validation closure |
| `validate_artifact.py --project PROJECT` | Verify ledger, anchor, projection, frozen artifacts |
| `replay_state.py --root PROJECT` | Display verified state; --repair-projection restores its cache |
| `transition_state.py --root PROJECT --request REQUEST` | Apply an outcome with an optimistic sequence and unique transition ID |
| `freeze_gate.py --root PROJECT --protocol INPUT --gate gate-a` | Retain immutable protocol and a freeze event |
| `evaluate_gate.py --protocol FROZEN --runs DIRECTORY --gate gate-a --evidence-root PROJECT` | Deterministic rules over verified native results; a live replay callback is required; --root PROJECT retains the decision |
| `run_experiments.py PLAN --root PROJECT` | Validate a bounded plan; explicit --execute with the reviewed plan digest enables scoped execution |
| `supervise_routes.py overview --root SUPERVISOR` | Replay the actual registry and display registered routes, freshness, conflicts and upstream obligations |
| `writing_assets.py --help` | Inspect claim/version bindings and enumerate actual downstream rewrite obligations |
| `redact_artifact.py --root PROJECT --path PATH --replacement FILE` | Replace a sidecar, append a tombstone, invalidate dependent decisions |
| `migrate_state.py --root PROJECT --to 1.0.0` | Content-addressed backup and supported-version recovery |

Each command is `python3 "$SKILL_DIR/scripts/<command>"`.
The [method-verification contract](method-verification.md) adds scoped evidence
packets, not new scientific state enums. Require current selected-candidate
`design_verified` before experiment dispatch and `verdict_verified` before a final
success/failure claim; native replay uses the existing trusted host context.
New/revised candidate protocols carry a pinned `method_discovery` code-stage batch
which native admission checks. Preserve old protocols without retroactive compliance.
Use `--gate full-validation` for the later evidence gate.
For authorized scorer execution, supply `--execute-native-scoring` and
`--native-timeout-seconds` on the gate/transition command with an explicit project
root. Never run an unreviewed or untrusted scorer through an ordinary subprocess;
use the host's required isolation. Read [native-evaluation.md](native-evaluation.md)
and [native-runner.md](native-runner.md) for commands, native inputs and actual limits.
Missing live execution capability produces INCONCLUSIVE, not a static-file PASS.

For new scientific projects, prepare `goal_alignment` and `resource_envelope` as
specified in [initial-intake.md](initial-intake.md) and validate the full intake
before initialization. `--intake` binds the name, one-line goal, mode and confirmed
origin to its arguments and retains every sourced goal/resource record. The older
command without `--intake` remains supported; its one-line goal is not proof of
human goal alignment. Older intake files without the extensions remain readable
and their missing startup values remain unknown when the next decision needs them.
Goal/resource fields retain value/status/source/updated_at. Validate nonnegative
time/spending limits, integer device counts, per-device VRAM, monetary currency
and status/value consistency. These checks do not verify availability or confer
authority; actual inventory, human statements and operation permissions remain
separate evidence.

IPCG adds `parent-problem-card`, `natural-gate-0` and `importance-decision` schemas.
Use the existing transition command to freeze the parent, record recomputed Gate 0
and apply an importance decision. Read [importance-preserving-gate.md](importance-preserving-gate.md)
for exact fields, natural observation format and legacy-project reassessment.
New Gate freezes bind the current parent/census/importance references into the
protocol digest. Record their nested raw/source refs in the canonical ledger.
The Parent Problem also binds the captured benchmark/task/metric/split/resource
contract and required simple alternatives. New candidates must declare a
`necessity_case` covering those alternatives and evidence of the remaining gap;
memory representation changes include `plain_text_memory`. Older Idea Atoms remain
readable, but require this contract before further candidate advancement.

New parents declare `contribution_type`; read
[contribution-value-gates.md](contribution-value-gates.md) for the appropriate
failure/frontier/phenomenon/data/formal value evidence. Pure theory uses a formal
contract, never an invented empirical benchmark. Formal Gate 0 review does not
make the numerical Gate A/full-validation evaluator a theorem verifier.

## Evidence identity and gate inputs

Local evidence references are `{"path":"evidence/raw.json","sha256":"<64 hex>"}`.
Paths are relative to PROJECT; traversal and symlinks are forbidden. Materialize
remote evidence through an authorized connector before using it in the helper.

Use `--evidence-root PROJECT` for pure evaluation, or `--root PROJECT` to retain
the decision. Use distinct run IDs and folders for each protocol; preserve earlier
manifests and raw outputs. Helpers retain protocols and decisions in immutable
`protocols/<id>.json` and `decisions/<id>.json` folders.

Protocols contain protocol_id, evidence_mode, evidence_snapshot_ref, seed_policy,
min_valid_runs, required_groups, guardrails, and criteria. A criterion contains id,
metric, direction (maximize|minimize), min_effect, inclusive, indispensable,
min_runs, uncertainty (none|normal|paired_t|bootstrap|external), confidence, and optional group selectors.
Normal intervals are an explicitly chosen approximation, not a universal method.
A prospective_child_hypothesis must exist before results to permit REVISE.
New freezes also require implementation/project versions, independent-unit and
eligibility policies, and an inline `native_eval_contract`. Optional
`native_eval_contracts` binds every required group to its own existing benchmark.
The primary benchmark/revision/endpoint matches the parent. Each run retains
per-arm native receipts, released predictions/sample IDs and native scorer output;
qualification flags alone are insufficient. Full validation freezes claim cards
for exactly its claim set. Read [statistics-and-claims.md](statistics-and-claims.md)
for multiplicity, external replay, frozen scope and complete run eligibility.

Run manifests contain run_id, protocol_id/digest, seed, group, status,
baseline_qualified, positive_control_passed, result_recorded_at, provenance,
resources, metrics, and raw_output_refs. Each raw JSON output contains the same
run_id, seed, group, flags, resources, and metrics:
`metrics[metric] = {"treatment": number, "control": number}`.
Manifest measurements must agree with retained raw content. Duplicate seed/group
pairs, missing evidence, non-finite metrics, and development runs are ineligible.
A protocol's confirmatory result timestamp must follow its anchored freeze;
independently verify reported timestamps against source provenance.

Transition requests contain transition_id, expected_sequence, outcome,
reason_code, evidence_refs, and payload. They cannot patch origin or authority.
Gate transitions require the referenced decision and its recomputation.
Full-validation additionally binds claim_set, indispensable_claim_ids,
inventory_run_ids, manuscript identity for retrospective audits, and the declared
multiple-comparison policy. Each indispensable contrast covers every required
replication group in this paired helper. After PASS, commit a new snapshot whose
closure maps claims to criterion IDs and retained result references, lists all
evaluated run IDs, contains no unresolved confounds, and binds the saved decision.
A closure boolean is insufficient. `advance_writing` cannot skip a writing stage.
Every claim marked closed, including non-indispensable claims, must belong to the
frozen claim set and snapshot, bind its own passed criteria and retain referenced
evidence. An optional or extra claim cannot enter a writing handoff merely by
adding a closed label or borrowing another claim's criterion.
Each claim's evidence must include its criterion's eligible run manifests and
native proof inventory. PASS binds the anchored decision, closure snapshot and
validated method/project versions. A new snapshot revokes old writing eligibility;
handoffs and writing advancement verify the current binding and frozen claim cards.

## Shared route artifacts

P/X coordination uses `supervisor-registry`, `supervisor-event`,
`route-checkpoint` and `resource-lease`; it does not add scientific states or gates.
The registry transactionally stores its hash-chained events/projection separately
from each scientific project's canonical ledger. Use
[multi-route-supervision.md](multi-route-supervision.md) for CAS revisions,
unique route IDs, writer isolation, lease fencing, usage and actual host receipts.
Use [project-chat-instructions.md](project-chat-instructions.md) for exact Project,
supervisor and worker messages. A local registry is not shared delivery or a live
chat feed. A manual report remains unverified until actual source import.

Hashes prove content identity, not timestamp truth, measurement validity, scientific
novelty, or host authority. Imported grants authorize nothing. The heuristic secret
scanner is a containment aid rather than a proof. Ledger/anchor contamination
requires a host-authorized replacement lineage; sidecar redaction cannot mint one.
Unsupported migration versions remain read-only. Do not claim tests were run
when the user directed skipping them.

The local anchor detects a deleted/truncated tail and mismatched projections.
It is not a signature against an attacker who can rewrite the ledger and anchor
together. Preserve the head in the host's trusted durable storage for that threat
model. Host approval and sandbox capabilities are detailed in
[host-adapters.md](host-adapters.md).

## 13. Project artifacts

Default project structure:

```text
autoresearch/
├── research-intake.yaml
├── research-state.json
├── event-ledger.jsonl
├── ledger-anchor.json
├── evidence/
│   ├── search-ledger.jsonl
│   ├── works.jsonl
│   ├── evidence-units.jsonl
│   └── snapshots/
├── ideas/
├── audits/
├── gate-a/
│   ├── protocols/
│   ├── runs/
│   └── decisions/
├── operations/
│   └── operation-ledger.jsonl
├── experiments/
│   └── full-validation/
├── claims/
├── writing/
├── figures/
└── communication/
    └── website-brief.md
```

The artifact root is disclosed before the first write, lives outside source repositories by default, uses restrictive permissions, and is isolated per project. It is protected from accidental commits. Safe export, retention, redaction, and deletion are explicit user actions.

Raw project code and large model artifacts normally remain in authoritative content-addressed storage. Every decision-bearing object must be durably available by immutable identifier and verified digest for the required retention period. A pointer and hash alone are insufficient when the object has disappeared; unavailable decision evidence invalidates recomputation and produces `INCONCLUSIVE`. Run manifests capture the Git tree and dirty patch, submodules/LFS, preprocessing, environment/container, structured command, RNG and seeds, hardware/software, metric code, checkpoint, and raw-output identities.

Every persisted artifact and JSONL event has a registered schema ID and version. Validators reject unknown versions, duplicate YAML keys, unsafe tags, non-finite numbers, truncated JSONL, invalid paths, orphaned IDs, and broken cross-file references with stable error codes and JSON paths.

For a requested website, use the optional `website` object on the existing
`handoff` schema and reference its brief/assets through retained source identities.
Read [research-websites.md](research-websites.md) for its fields, node connections
and acceptance contract. Website briefs and front-end/media sources are deliverable
assets, not new ledger events or legal research-state values. The generic handoff
validator does not check the contents of the `website` extension; review those
fields and scientific interactions against the reference and actual site.

External operations use `planned → submitted → running → completed | failed | cancelled | manual_reconciliation_required` states, stable idempotency keys, attempt IDs, provider IDs, cumulative budget reservations, bounded retries, and reconciliation before retry. Automatic retry after a lost acknowledgment is permitted only when the adapter records that the provider enforces idempotency or supports query-by-fingerprint. Otherwise the operation fails closed into manual reconciliation; interrupted acknowledgment never silently causes a duplicate job, push, PR, upload, or publication.
