"""Engineering contract fixtures only; no paper, GPU, or scientific result is asserted."""
import copy
from datetime import datetime, timedelta, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts/experiment_contract.py'
SPEC = importlib.util.spec_from_file_location('experiment_contract_tests', SCRIPT)
E = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(E)


class ExperimentContractFixture:
    """Shared minimal CPU fixture for Chat integration's meaningful gate tests."""
    def __init__(self, root):
        self.root = Path(root)
        self.counter = 0
        self.raw = self.write('Engineering fixture observation, not scientific evidence', 'raw.txt')
        self.hypothesis = self.write({'kind': 'research_hypothesis', 'candidate_id': 'candidate-a'}, 'hypothesis.json')
        self.protocol = self.write({'kind': 'test-protocol'}, 'protocol.json')
        self.code = self.write('print(1 + 1)', 'code.py')
        probe = self.write(dict(kind='resource-probe', host_id='cpu', observed_at=datetime.now(timezone.utc).isoformat(),
            valid_until=(datetime.now(timezone.utc) + timedelta(days=1)).isoformat(), capacity_basis='currently_allocated',
            cpu_count=8, ram_gib=8, gpus=[], raw_evidence=[self.raw]))
        calibration = self.write(dict(kind='resource-calibration', host_id='cpu', code_ref=self.code,
            protocol_ref=self.protocol, probe_ref=probe,
            observed_at='2026-10-10T00:00:00Z', command='python code.py', elapsed_seconds=.1,
            peak_ram_gib=.1, gpu_count=0, peak_gpu_memory_gib=0, raw_evidence=[self.raw]))
        self.contract = dict(kind='experiment-design-contract', version='1.0.0',
            schema_id='experiment-design-contract', schema_version='1.0.0', contract_id='design-a',
            candidate_id='candidate-a', stage='confirmation', proposal_task_id='proposal-a',
            hypothesis_ref=self.hypothesis, protocol_ref=self.protocol,
            paper_designs=[dict(id='source-a', title='Engineering source fixture', sources={
                'paper': dict(availability='available', url='https://example.org/fixture', ref=self.raw, locator='Section 4, Table 1'),
                'appendix': dict(availability='unavailable', reason='No appendix in engineering fixture'),
                'code': dict(availability='available', url='https://example.org/fixture/code.py', ref=self.code, locator='code.py:1')},
                practices=[dict(design_element='paired comparison', observation='Use paired native units', decision='adapt',
                    rationale='Same comparison on the actual declared finite population', obligation_ids=['main_comparison'])])],
            resources=dict(hosts=[dict(id='cpu', description='CPU fixture', owned=False, authorized=True,
                reachable=True, authorization_ref=self.raw, probe_ref=probe)],
                budgets=dict(source_ref=self.raw, usage_ref=self.raw, wall_seconds=100, gpu_seconds=0, cost=0,
                    consumed=dict(wall_seconds=2, gpu_seconds=0, cost=0))),
            claims=[dict(id='claim-a', statement='A declared finite comparison', prediction='The declared difference exceeds zero',
                falsifier='A non-positive difference', rival_explanation='Different measurement cost', scope='Finite fixture scope',
                required_dimensions=['main_comparison', 'reproducibility'],
                claim_types=['performance'],
                inference=dict(kind='deterministic_finite', rationale='All finite units measured exactly',
                    precision_rationale='Exact arithmetic for complete finite scope', independent_unit='finite object',
                    planned_units=1, uncertainty='none', selection_control='Fixed before observation; no held-out reuse'))],
            obligations=[], jobs=[])
        for dimension in E.DIMENSIONS:
            item = dict(id=dimension, dimension=dimension, claim_ids=['claim-a'],
                        applicability='required' if dimension in {'main_comparison', 'reproducibility'} else 'not_applicable',
                        rationale='Bounded exact fixture claim does not assert additional scientific scope')
            if item['applicability'] == 'required':
                item.update(paper_design_ids=['source-a'], job_ids=['compare'], fairness='Same inputs and finite execution budget',
                    evidence_kind='scientific_contrast',
                    native_scope=dict(benchmark='engineering fixture', revision='v1', split='complete finite scope',
                        metric='difference', denominator='1', scorer_ref=self.code, sample_manifest_ref=self.raw),
                    contrast=dict(estimand='treatment minus baseline', weights={'treatment': 1, 'baseline': -1},
                        decision_rule='fixed positive difference', canonical_criterion_id='effect', canonical_group_ids=['fixture']))
            self.contract['obligations'].append(item)
        self.contract['obligations'][-1].update(evidence_kind='reproducibility', checks=['raw_to_table', 'environment', 'commands'])
        del self.contract['obligations'][-1]['contrast']
        del self.contract['obligations'][-1]['native_scope']
        self.contract['jobs'] = [dict(id='compare', host_id='cpu', command='python code.py', code_ref=self.code,
            protocol_ref=self.protocol, obligation_ids=['main_comparison', 'reproducibility'],
            requires=dict(cpu_count=1, ram_gib=1, gpu_count=0, gpu_memory_gib=0),
            estimate=dict(wall_seconds=1, gpu_seconds=0, cost=0, extrapolation='Measured finite fixture with tenfold allowance'),
            calibration_ref=calibration)]

    def write(self, value, name=None):
        self.counter += 1
        name = name or ('artifact-' + str(self.counter) + '.json')
        data = value if isinstance(value, str) else json.dumps(value, sort_keys=True)
        (self.root / name).write_text(data)
        return dict(path=name, sha256=hashlib.sha256((self.root / name).read_bytes()).hexdigest())

    def freeze(self):
        reference = self.write(self.contract)
        review = self.write(dict(kind='experiment-design-review', contract_ref=reference,
            proposal_task_id='proposal-a', review_task_id='independent-review-a', reviewer='fixture separate reviewer',
            execution_ref=self.raw, checks={key: dict(status='verified', rationale='Engineering review fixture checks this field',
                evidence_refs=[self.raw]) for key in E.REVIEW_CHECKS}))
        return reference, review

    def completion(self, reference, outcome='supported'):
        return self.write(dict(kind='experiment-completion', contract_ref=reference, claim_outcomes={'claim-a': outcome},
            check_receipts={'reproducibility': {key: dict(job_id='compare', execution_id='execution-1',
                status='verified', finding='Executed fixture check', raw_evidence=[self.raw])
                for key in ('raw_to_table', 'environment', 'commands')}},
            receipts=[dict(job_id='compare', attempt_id='attempt-1', execution_id='execution-1', outcome='refuted' if outcome == 'refuted' else 'completed',
                protocol_ref=self.protocol, raw_evidence=[self.raw], verification_ref=self.raw,
                actual_usage=dict(wall_seconds=1, gpu_seconds=0, cost=0), usage_ref=self.raw)]))


def schema_contract_examples():
    """Register the real complete fixture with the repository-wide schema gate."""
    with tempfile.TemporaryDirectory() as directory:
        fixture = ExperimentContractFixture(directory)
        return {'experiment-design-contract': (copy.deepcopy(fixture.contract), 'claims')}


class ExperimentContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.f = ExperimentContractFixture(self.root)

    def inspect(self, phase='design', completion=False):
        ref, review = self.f.freeze()
        return E.inspect_contract(self.root, ref, phase=phase, review_ref=review,
            completion_ref=self.f.completion(ref) if completion else None)

    def test_exact_cpu_design_requires_no_gpu(self):
        report = self.inspect()
        self.assertTrue(report['ready'])
        self.assertEqual(report['eligible_job_ids'], ['compare'])
        self.assertFalse(report['scientific_truth_verified'])
        self.assertEqual(report['planned_usage']['wall_seconds'], 3)

    def test_registered_schema_checks_nested_refs_and_required_evidence_variants(self):
        from fixtures import C
        C.validate(self.f.contract, 'experiment-design-contract')
        nullable = copy.deepcopy(self.f.contract)
        nullable['resources']['budgets']['consumed']['wall_seconds'] = None
        C.validate(nullable, 'experiment-design-contract')
        broken = copy.deepcopy(self.f.contract)
        broken['hypothesis_ref']['sha256'] = 'not-a-digest'
        with self.assertRaises(C.Failure):
            C.validate(broken, 'experiment-design-contract')
        broken = copy.deepcopy(self.f.contract)
        del broken['obligations'][0]['native_scope']
        with self.assertRaises(C.Failure):
            C.validate(broken, 'experiment-design-contract')
        broken = copy.deepcopy(self.f.contract)
        broken['schema_version'] = '99.0.0'
        with self.assertRaisesRegex(E.ContractError, 'unsupported'):
            E.inspect_contract(self.root, self.f.write(broken))

    def test_completion_requires_receipts_then_accepts_valid_negative(self):
        self.assertFalse(self.inspect('completion')['coverage_complete'])
        ref, review = self.f.freeze()
        report = E.inspect_contract(self.root, ref, phase='completion', review_ref=review,
            completion_ref=self.f.completion(ref, 'refuted'))
        self.assertTrue(report['ready'])
        self.assertTrue(report['coverage_complete'])
        self.assertEqual(report['claim_outcomes']['claim-a'], 'refuted')

    def test_paper_appendix_unavailable_is_explicit_not_invented(self):
        self.assertTrue(self.inspect()['ready'])
        del self.f.contract['paper_designs'][0]['sources']['appendix']['reason']
        with self.assertRaisesRegex(E.ContractError, 'unavailable reason'):
            self.inspect()

    def test_paper_transfer_requires_source_locator_and_obligation(self):
        paper = self.f.contract['paper_designs'][0]
        paper['sources']['paper']['locator'] = ''
        with self.assertRaisesRegex(E.ContractError, 'locator'):
            self.inspect()
        paper['sources']['paper']['locator'] = 'Table 1'
        paper['practices'][0]['obligation_ids'] = []
        with self.assertRaisesRegex(E.ContractError, 'bind obligations'):
            self.inspect()

    def test_missing_dimension_cannot_be_hidden(self):
        self.f.contract['obligations'].pop()
        with self.assertRaisesRegex(E.ContractError, 'missing explicit coverage'):
            self.inspect()

    def test_indispensable_dimension_cannot_be_waived(self):
        self.f.contract['claims'][0]['required_dimensions'].append('mechanism')
        with self.assertRaisesRegex(E.ContractError, 'indispensable'):
            self.inspect()

    def test_stochastic_confirmation_cannot_use_point_estimate(self):
        inference = self.f.contract['claims'][0]['inference']
        inference['kind'] = 'stochastic'
        with self.assertRaisesRegex(E.ContractError, 'needs uncertainty'):
            self.inspect()
        inference.update(uncertainty='paired_t', planned_units=5)
        with self.assertRaisesRegex(E.ContractError, 'cannot be waived'):
            self.inspect()

    def test_diagnostic_point_screen_cannot_become_confirmation(self):
        self.f.contract['stage'] = 'diagnostic'
        self.f.contract['claims'][0]['inference']['kind'] = 'point_screen'
        self.assertTrue(self.inspect()['ready'])
        self.f.contract['stage'] = 'confirmation'
        with self.assertRaisesRegex(E.ContractError, 'point screen'):
            self.inspect()

    def test_no_independent_review_leaves_research_pending(self):
        ref, review = self.f.freeze()
        report = E.inspect_contract(self.root, ref)
        self.assertFalse(report['ready'])
        self.assertEqual(report['eligible_job_ids'], [])
        bad = E.read_reference(self.root, review, as_json=True)
        bad['review_task_id'] = 'proposal-a'
        with self.assertRaisesRegex(E.ContractError, 'independent'):
            E.inspect_contract(self.root, ref, review_ref=self.f.write(bad))

    def test_missing_calibration_is_pending_not_malformed_design(self):
        del self.f.contract['jobs'][0]['calibration_ref']
        report = self.inspect()
        self.assertTrue(report['valid'])
        self.assertFalse(report['ready'])
        self.assertIn('calibration_missing', [p['reason'] for p in report['pending']])

    def test_owned_gpu_is_not_reachable_gpu(self):
        self.f.contract['resources']['hosts'].append(dict(id='gpu', description='Owner reported GPU', owned=True,
            authorized=False, reachable=False))
        other = copy.deepcopy(self.f.contract['jobs'][0])
        other.update(id='gpu-compare', host_id='gpu', calibration_ref=None,
            requires=dict(cpu_count=1, ram_gib=1, gpu_count=1, gpu_memory_gib=24, gpu_model='RTX 4090'),
            estimate=dict(wall_seconds=1, gpu_seconds=1, cost=0, extrapolation='Uncalibrated estimate awaiting probe'))
        self.f.contract['resources']['budgets']['gpu_seconds'] = 100
        self.f.contract['jobs'].append(other)
        for item in self.f.contract['obligations']:
            if item['applicability'] == 'required':
                item['job_ids'].append('gpu-compare')
        report = self.inspect()
        self.assertFalse(report['ready'])
        self.assertEqual(report['eligible_job_ids'], ['compare'])

    def test_measured_capacity_and_cost_cannot_be_ignored(self):
        self.f.contract['jobs'][0]['requires']['ram_gib'] = 16
        self.assertFalse(self.inspect()['ready'])
        self.f.contract['jobs'][0]['requires']['ram_gib'] = 1
        self.f.contract['resources']['budgets']['consumed']['wall_seconds'] = 100
        report = self.inspect()
        self.assertEqual(report['eligible_job_ids'], [])
        self.assertIn('planned_wall_seconds_exceeds_budget', [p['reason'] for p in report['pending']])

    def test_explicit_mechanism_contrast_is_retained(self):
        contrast = self.f.contract['obligations'][0]['contrast']
        contrast['weights'] = {'treatment': 1, 'ablation': -1}
        self.assertTrue(self.inspect()['ready'])
        contrast['weights'] = {'treatment': 1, 'ablation': 0}
        with self.assertRaisesRegex(E.ContractError, 'positive and negative'):
            self.inspect()

    def test_source_tampering_and_stale_review_are_rejected(self):
        ref, review = self.f.freeze()
        changed = copy.deepcopy(self.f.contract)
        changed['contract_id'] = 'design-b'
        with self.assertRaisesRegex(E.ContractError, 'review contract binding'):
            E.inspect_contract(self.root, self.f.write(changed), review_ref=review)
        (self.root / self.f.code['path']).write_text('changed')
        with self.assertRaisesRegex(E.ContractError, 'hash mismatch'):
            E.inspect_contract(self.root, ref, review_ref=review)

    def test_receipt_protocol_mismatch_and_unknown_job_rejected(self):
        ref, review = self.f.freeze()
        packet = E.read_reference(self.root, self.f.completion(ref), as_json=True)
        packet['receipts'][0]['job_id'] = 'invented'
        with self.assertRaisesRegex(E.ContractError, 'unknown or duplicate'):
            E.inspect_contract(self.root, ref, phase='completion', review_ref=review, completion_ref=self.f.write(packet))
        packet['receipts'][0]['job_id'] = 'compare'
        packet['receipts'][0]['protocol_ref'] = self.f.raw
        with self.assertRaisesRegex(E.ContractError, 'protocol binding'):
            E.inspect_contract(self.root, ref, phase='completion', review_ref=review, completion_ref=self.f.write(packet))

    def test_multiple_main_comparisons_are_required_not_duplicate_dimensions(self):
        second = copy.deepcopy(self.f.contract['obligations'][0])
        second['id'] = 'strong-baseline'
        second['contrast']['canonical_criterion_id'] = 'strong-baseline-effect'
        second['contrast']['weights'] = {'treatment': 1, 'strong-baseline': -1}
        self.f.contract['obligations'].append(second)
        self.f.contract['jobs'][0]['obligation_ids'].append(second['id'])
        report = self.inspect()
        self.assertTrue(report['ready'])
        self.assertEqual(report['criterion_ids'], ['effect', 'strong-baseline-effect'])

    def test_reproducibility_needs_actual_checks_not_fake_contrast(self):
        repro = self.f.contract['obligations'][-1]
        self.assertNotIn('contrast', repro)
        repro['checks'] = ['commands']
        with self.assertRaisesRegex(E.ContractError, 'checks incomplete'):
            self.inspect()

    def test_expired_allocation_blocks_dispatch_not_completed_evidence(self):
        host = self.f.contract['resources']['hosts'][0]
        probe = E.read_reference(self.root, host['probe_ref'], as_json=True)
        probe.update(observed_at='2020-01-01T00:00:00Z', valid_until='2020-01-02T00:00:00Z')
        host['probe_ref'] = self.f.write(probe)
        job = self.f.contract['jobs'][0]
        calibration = E.read_reference(self.root, job['calibration_ref'], as_json=True)
        calibration['probe_ref'] = host['probe_ref']
        job['calibration_ref'] = self.f.write(calibration)
        self.assertFalse(self.inspect()['ready'])
        report = self.inspect('completion', completion=True)
        self.assertTrue(report['ready'])

    def test_completion_actual_usage_does_not_recharge_planned_job(self):
        self.f.contract['resources']['budgets']['wall_seconds'] = 3
        ref, review = self.f.freeze()
        completion = self.f.completion(ref)
        report = E.inspect_contract(self.root, ref, phase='completion', review_ref=review, completion_ref=completion)
        self.assertTrue(report['ready'])
        self.assertEqual(report['budget_overrun']['wall_seconds'], 0)
        packet = E.read_reference(self.root, completion, as_json=True)
        packet['receipts'][0]['actual_usage']['wall_seconds'] = 4
        report = E.inspect_contract(self.root, ref, phase='completion', review_ref=review, completion_ref=self.f.write(packet))
        self.assertTrue(report['ready'])
        self.assertEqual(report['budget_overrun']['wall_seconds'], 3)

    def test_unknown_usage_and_zero_time_cannot_admit_execution(self):
        self.f.contract['resources']['budgets']['consumed']['wall_seconds'] = None
        report = self.inspect()
        self.assertTrue(report['valid'])
        self.assertEqual(report['eligible_job_ids'], [])
        self.assertIsNone(report['planned_usage']['wall_seconds'])
        self.f.contract['jobs'][0]['estimate']['wall_seconds'] = 0
        with self.assertRaisesRegex(E.ContractError, 'positive'):
            self.inspect()

    def test_infeasible_wishlist_does_not_block_feasible_cpu_subset(self):
        second = copy.deepcopy(self.f.contract['jobs'][0])
        second.update(id='expensive')
        second['estimate']['wall_seconds'] = 200
        self.f.contract['jobs'].append(second)
        for item in self.f.contract['obligations']:
            if item['applicability'] == 'required':
                item['job_ids'].append('expensive')
        report = self.inspect()
        self.assertFalse(report['ready'])
        self.assertFalse(report['plan_within_budget'])
        self.assertEqual(report['eligible_job_ids'], ['compare'])

    def test_calibration_must_match_protocol_and_allocation(self):
        job = self.f.contract['jobs'][0]
        calibration = E.read_reference(self.root, job['calibration_ref'], as_json=True)
        calibration['protocol_ref'] = self.f.raw
        job['calibration_ref'] = self.f.write(calibration)
        with self.assertRaisesRegex(E.ContractError, 'protocol_ref binding'):
            self.inspect()

    def test_batch_attempt_needs_distinct_execution_evidence(self):
        second = copy.deepcopy(self.f.contract['jobs'][0])
        second['id'] = 'second-job'
        self.f.contract['jobs'].append(second)
        for item in self.f.contract['obligations']:
            if item['applicability'] == 'required':
                item['job_ids'].append('second-job')
        ref, review = self.f.freeze()
        packet = E.read_reference(self.root, self.f.completion(ref), as_json=True)
        second_receipt = copy.deepcopy(packet['receipts'][0])
        second_receipt.update(job_id='second-job', execution_id='execution-2')
        packet['receipts'].append(second_receipt)
        with self.assertRaisesRegex(E.ContractError, 'distinct execution evidence'):
            E.inspect_contract(self.root, ref, phase='completion', review_ref=review, completion_ref=self.f.write(packet))
        second_receipt['raw_evidence'] = [self.f.write('Second actual fixture execution', 'second.txt')]
        report = E.inspect_contract(self.root, ref, phase='completion', review_ref=review, completion_ref=self.f.write(packet))
        self.assertTrue(report['coverage_complete'])

    def test_completed_comparison_does_not_imply_reproducibility_checks_ran(self):
        ref, review = self.f.freeze()
        packet = E.read_reference(self.root, self.f.completion(ref), as_json=True)
        del packet['check_receipts']
        report = E.inspect_contract(self.root, ref, phase='completion', review_ref=review, completion_ref=self.f.write(packet))
        self.assertFalse(report['coverage_complete'])
        self.assertEqual(len([p for p in report['pending'] if p['reason'].startswith('operational_check_missing')]), 3)

    def test_operational_check_must_bind_its_executed_job_evidence(self):
        ref, review = self.f.freeze()
        packet = E.read_reference(self.root, self.f.completion(ref), as_json=True)
        packet['check_receipts']['reproducibility']['environment']['raw_evidence'] = [self.f.write('Unrelated environment capture')]
        with self.assertRaisesRegex(E.ContractError, 'belong to its actual job'):
            E.inspect_contract(self.root, ref, phase='completion', review_ref=review, completion_ref=self.f.write(packet))


if __name__ == '__main__':
    unittest.main()
