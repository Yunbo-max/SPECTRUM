#!/usr/bin/env python3
"""Check frozen experiment coverage and observed resource/receipt bindings.

This stdlib module does not launch work, authenticate people, or certify science.
The host must obtain actual sources, resource probes and independent reviews.
Scientific conclusions additionally require the canonical native evaluator.
Missing calibration, access, review or results produces actionable pending work;
malformed or mismatched evidence raises ContractError (a ValueError).
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re

DIMENSIONS = ('main_comparison', 'mechanism', 'generalization', 'uncertainty', 'cost', 'reproducibility')
REVIEW_CHECKS = ('paper_transfer', 'claim_coverage', 'contrasts_and_fairness',
                 'precision_and_selection', 'resources_and_reproducibility')
MAX_BYTES = 8 * 1024 * 1024


class ContractError(ValueError):
    """Invalid frozen design or mismatched evidence."""


def _require(condition, message):
    if not condition:
        raise ContractError(message)


def _text(value, label):
    _require(isinstance(value, str) and bool(value.strip()), label + ' requires nonempty text')
    return value


def _obj(value, label):
    _require(isinstance(value, dict), label + ' requires an object')
    return value


def _array(value, label, nonempty=True):
    _require(isinstance(value, list) and (bool(value) or not nonempty), label + ' requires a list')
    return value


def _number(value, label, positive=False):
    _require(not isinstance(value, bool) and isinstance(value, (int, float))
             and math.isfinite(value) and (value > 0 if positive else value >= 0),
             label + ' requires a finite ' + ('positive' if positive else 'nonnegative') + ' number')
    return value


def _integer(value, label, positive=False):
    _number(value, label, positive)
    _require(isinstance(value, int), label + ' requires an integer')
    return value


def _time(value, label):
    try:
        parsed = datetime.fromisoformat(_text(value, label).replace('Z', '+00:00'))
    except ValueError as exc:
        raise ContractError(label + ' requires an ISO timestamp') from exc
    _require(parsed.tzinfo is not None, label + ' requires a timezone')
    return parsed


def _ids(values, label, nonempty=True):
    values = _array(values, label, nonempty)
    for value in values:
        _text(value, label)
    _require(len(values) == len(set(values)), label + ' contains duplicates')
    return values


def _records(values, label):
    result = {}
    for value in _array(values, label):
        value = _obj(value, label)
        identifier = _text(value.get('id'), label + ' id')
        _require(identifier not in result, label + ' contains duplicate id')
        result[identifier] = value
    return result


def read_reference(root, reference, *, as_json=False):
    reference = _obj(reference, 'reference')
    _require(set(reference) == {'path', 'sha256'}, 'reference needs path and sha256 only')
    _require(bool(re.fullmatch('[0-9a-f]{64}', str(reference['sha256']))), 'invalid reference sha256')
    path = Path(root) / _text(reference['path'], 'reference path')
    try:
        with path.open('rb') as stream:
            raw = stream.read(MAX_BYTES + 1)
    except OSError as exc:
        raise ContractError('reference unavailable: ' + str(path)) from exc
    _require(len(raw) <= MAX_BYTES, 'reference exceeds bounded size')
    _require(hashlib.sha256(raw).hexdigest() == reference['sha256'], 'reference hash mismatch: ' + str(path))
    if not as_json:
        return reference
    try:
        value = json.loads(raw)
    except (ValueError, UnicodeError) as exc:
        raise ContractError('invalid referenced JSON') from exc
    return _obj(value, 'referenced JSON')


def _refs(root, values):
    for value in _array(values, 'evidence refs'):
        read_reference(root, value)


def _pending(report, reason, action, *, job_id=None, obligation_id=None):
    entry = {'reason': reason, 'next_action': action}
    if job_id is not None:
        entry['job_id'] = job_id
    if obligation_id is not None:
        entry['obligation_id'] = obligation_id
    report['pending'].append(entry)


def _papers(root, contract, obligations):
    papers = _records(contract.get('paper_designs'), 'paper designs')
    for paper_id, paper in papers.items():
        _text(paper.get('title'), 'paper title')
        sources = _obj(paper.get('sources'), 'paper sources')
        for role in ('paper', 'appendix', 'code'):
            source = _obj(sources.get(role), role + ' source')
            if source.get('availability') == 'unavailable':
                _require(role != 'paper', 'a primary paper must actually be read')
                _text(source.get('reason'), role + ' unavailable reason')
                continue
            _require(source.get('availability') == 'available', role + ' availability required')
            _require(_text(source.get('url'), role + ' URL').startswith(('https://', 'http://')), 'primary source URL required')
            _text(source.get('locator'), role + ' exact section/table/file locator')
            read_reference(root, source.get('ref'))
        for practice in _array(paper.get('practices'), 'extracted experimental practices'):
            _obj(practice, 'practice')
            for field in ('design_element', 'observation', 'rationale'):
                _text(practice.get(field), 'practice ' + field)
            _require(practice.get('decision') in {'adopt', 'adapt', 'reject'}, 'paper transfer decision required')
            linked = _ids(practice.get('obligation_ids'), 'practice obligation ids', nonempty=False)
            _require(set(linked) <= set(obligations), 'paper practice refers to unknown obligation')
            _require(practice['decision'] == 'reject' or bool(linked), 'adopted/adapted practices must bind obligations')
    return papers


def _claims(contract):
    claims = _records(contract.get('claims'), 'claims')
    for claim in claims.values():
        for key in ('statement', 'prediction', 'falsifier', 'rival_explanation', 'scope'):
            _text(claim.get(key), 'claim ' + key)
        inference = _obj(claim.get('inference'), 'claim inference')
        kind = inference.get('kind')
        _require(kind in {'point_screen', 'deterministic_finite', 'stochastic', 'generalization'}, 'claim inference kind required')
        for key in ('rationale', 'precision_rationale', 'independent_unit'):
            _text(inference.get(key), 'inference ' + key)
        _integer(inference.get('planned_units'), 'planned independent units', True)
        uncertainty = _text(inference.get('uncertainty'), 'uncertainty method')
        if contract['stage'] == 'confirmation':
            _require(kind != 'point_screen', 'point screen cannot support confirmation')
            if kind in {'stochastic', 'generalization'}:
                _require(uncertainty != 'none', 'stochastic/generalization confirmation needs uncertainty')
                _require(inference['planned_units'] >= 2, 'stochastic confirmation needs independent replication')
        _text(inference.get('selection_control'), 'selection and holdout reuse control')
        indispensable = _ids(claim.get('required_dimensions'), 'claim indispensable dimensions')
        _require(set(indispensable) <= set(DIMENSIONS), 'unknown indispensable dimension')
        _require({'main_comparison', 'reproducibility'} <= set(indispensable), 'claim requires comparison and reproducibility')
        if kind == 'generalization':
            _require('generalization' in indispensable, 'generalization claim requires generalization coverage')
        types = _ids(claim.get('claim_types'), 'claim types')
        _require(set(types) <= {'performance', 'mechanism', 'generalization', 'efficiency'}, 'unknown claim type')
        for typ, dimension in (('mechanism', 'mechanism'), ('generalization', 'generalization'), ('efficiency', 'cost')):
            _require(typ not in types or dimension in indispensable, typ + ' claim needs its corresponding indispensable dimension')
    return claims


def _obligations(root, contract, claims, obligations, papers):
    covered = {key: set() for key in claims}
    for identifier, item in obligations.items():
        claim_ids = _ids(item.get('claim_ids'), 'obligation claim ids')
        _require(set(claim_ids) <= set(claims), 'obligation refers to unknown claim')
        dimension = item.get('dimension')
        _require(dimension in DIMENSIONS, 'unknown coverage dimension')
        for claim_id in claim_ids:
            covered[claim_id].add(dimension)
        _text(item.get('rationale'), 'coverage rationale')
        applicable = item.get('applicability')
        _require(applicable in {'required', 'not_applicable'}, 'explicit applicability required')
        if applicable == 'not_applicable':
            _require(dimension not in {'main_comparison', 'reproducibility'}, 'main comparison and reproducibility cannot be waived')
            _require(all(dimension not in claims[c]['required_dimensions'] for c in claim_ids), 'indispensable claim dimension cannot be waived')
            if dimension == 'uncertainty' and contract['stage'] == 'confirmation':
                _require(all(claims[c]['inference']['kind'] == 'deterministic_finite' for c in claim_ids),
                         'stochastic uncertainty obligation cannot be waived')
            _require(not item.get('job_ids'), 'not-applicable obligation cannot claim completed jobs')
            continue
        linked = _ids(item.get('paper_design_ids'), 'obligation paper design ids')
        _require(set(linked) <= set(papers), 'unknown paper design id')
        _ids(item.get('job_ids'), 'obligation job ids')
        evidence_kind = item.get('evidence_kind')
        _require(evidence_kind in {'scientific_contrast', 'reproducibility', 'resource_accounting'}, 'explicit obligation evidence kind required')
        if evidence_kind != 'scientific_contrast':
            _require((dimension, evidence_kind) in {('reproducibility', 'reproducibility'), ('cost', 'resource_accounting')},
                     'scientific comparison cannot be replaced by an operational check')
            checks = set(_ids(item.get('checks'), 'operational evidence checks'))
            required_checks = {'raw_to_table', 'environment', 'commands'} if evidence_kind == 'reproducibility' else {'all_attempts', 'allocated_device_time', 'measurement_conditions'}
            _require(required_checks <= checks, 'operational evidence checks incomplete')
            continue
        scope = _obj(item.get('native_scope'), 'native evaluation scope')
        for key in ('benchmark', 'revision', 'split', 'metric', 'denominator'):
            _text(scope.get(key), 'native scope ' + key)
        read_reference(root, scope.get('scorer_ref'))
        read_reference(root, scope.get('sample_manifest_ref'))
        contrast = _obj(item.get('contrast'), 'explicit contrast')
        for key in ('estimand', 'decision_rule', 'canonical_criterion_id'):
            _text(contrast.get(key), 'contrast ' + key)
        _ids(contrast.get('canonical_group_ids'), 'contrast canonical groups')
        weights = _obj(contrast.get('weights'), 'contrast arm weights')
        _require(len(weights) >= 2, 'contrast requires at least two named arms')
        for arm, weight in weights.items():
            _text(arm, 'contrast arm')
            _require(not isinstance(weight, bool) and isinstance(weight, (int, float)) and math.isfinite(weight), 'finite contrast weight required')
        _require(any(w > 0 for w in weights.values()) and any(w < 0 for w in weights.values()), 'contrast must compare positive and negative arms')
        _require(abs(sum(weights.values())) < 1e-9, 'comparison contrast weights must sum to zero')
        _text(item.get('fairness'), 'information/tuning/compute fairness')
    for identifier, dimensions in covered.items():
        _require(dimensions == set(DIMENSIONS), 'claim ' + identifier + ' is missing explicit coverage dimensions')


def _resources(root, contract, jobs, report, phase):
    resources = _obj(contract.get('resources'), 'resources')
    hosts = _records(resources.get('hosts'), 'resource hosts')
    for host in hosts.values():
        for key in ('owned', 'authorized', 'reachable'):
            _require(isinstance(host.get(key), bool), 'resource ' + key + ' must be explicit boolean')
        _text(host.get('description'), 'resource description')
        if host['authorized']:
            read_reference(root, host.get('authorization_ref'))
        if host['reachable']:
            probe = read_reference(root, host.get('probe_ref'), as_json=True)
            _require(probe.get('kind') == 'resource-probe' and probe.get('host_id') == host['id'], 'resource probe host binding mismatch')
            observed = _time(probe.get('observed_at'), 'resource observation time')
            expires = _time(probe.get('valid_until'), 'resource allocation expiry')
            _require(expires > observed, 'resource allocation expiry must follow observation')
            _require(probe.get('capacity_basis') == 'currently_allocated', 'probe must describe allocated capacity, not owned hardware')
            _integer(probe.get('cpu_count'), 'observed CPU count', True)
            _number(probe.get('ram_gib'), 'observed RAM', True)
            gpus = _array(probe.get('gpus'), 'observed GPUs', nonempty=False)
            for gpu in gpus:
                _text(gpu.get('model'), 'observed GPU model')
                _number(gpu.get('memory_gib'), 'observed GPU memory', True)
                _integer(gpu.get('count'), 'observed GPU count', True)
            _refs(root, probe.get('raw_evidence'))
    budgets = _obj(resources.get('budgets'), 'resource budgets')
    read_reference(root, budgets.get('source_ref'))
    caps = {key: _number(budgets.get(key), key) for key in ('wall_seconds', 'gpu_seconds', 'cost')}
    consumed = _obj(budgets.get('consumed'), 'cumulative consumed usage including tuning and failures')
    read_reference(root, budgets.get('usage_ref'))
    unknown_usage = {key for key in caps if consumed.get(key) is None}
    totals = {key: 0 if key in unknown_usage else _number(consumed.get(key), 'consumed ' + key) for key in caps}
    for job_id, job in jobs.items():
        host_id = _text(job.get('host_id'), 'job host id')
        _require(host_id in hosts, 'job resource host not inventoried')
        host = hosts[host_id]
        if phase == 'design' and (not host['authorized'] or not host['reachable']):
            _pending(report, 'resource_not_authorized_or_reachable', 'Obtain authorized access or version this job onto an observed feasible host', job_id=job_id)
        request = _obj(job.get('requires'), 'job resource requirements')
        cpu = _integer(request.get('cpu_count'), 'required CPUs', True)
        ram = _number(request.get('ram_gib'), 'required RAM', True)
        gpu_count = _integer(request.get('gpu_count'), 'required GPU count')
        gpu_mem = _number(request.get('gpu_memory_gib'), 'required per-device GPU memory')
        if gpu_count:
            _text(request.get('gpu_model'), 'required GPU model')
        else:
            _require(gpu_mem == 0, 'CPU-only job cannot reserve GPU memory')
        if host['reachable']:
            probe = read_reference(root, host['probe_ref'], as_json=True)
            if phase == 'design' and _time(probe['valid_until'], 'resource expiry') <= datetime.now(timezone.utc):
                _pending(report, 'resource_probe_expired', 'Refresh the actual allocation probe and version the affected resource binding', job_id=job_id)
            available = sum(g['count'] for g in probe['gpus'] if g['memory_gib'] >= gpu_mem and g['model'] == request.get('gpu_model'))
            if phase == 'design' and (cpu > probe['cpu_count'] or ram > probe['ram_gib'] or gpu_count > available):
                _pending(report, 'resource_capacity_insufficient', 'Reduce measured resource demand or version onto a verified suitable host', job_id=job_id)
        estimate = _obj(job.get('estimate'), 'job measured estimate')
        for key in totals:
            totals[key] += _number(estimate.get(key), 'estimated ' + key, positive=(key == 'wall_seconds'))
        _require(estimate['gpu_seconds'] >= estimate['wall_seconds'] * gpu_count,
                 'GPU device-seconds must include every allocated device')
        if not gpu_count:
            _require(estimate['gpu_seconds'] == 0, 'CPU job cannot invent GPU usage')
        _text(estimate.get('extrapolation'), 'calibration extrapolation and safety margin')
        if not job.get('calibration_ref'):
            _pending(report, 'calibration_missing', 'Run a bounded resource calibration on the authorized host before this job', job_id=job_id)
            continue
        calibration = read_reference(root, job['calibration_ref'], as_json=True)
        for key, expected in (('kind', 'resource-calibration'), ('host_id', host_id), ('code_ref', job['code_ref']),
                              ('protocol_ref', job['protocol_ref']), ('probe_ref', host.get('probe_ref'))):
            _require(calibration.get(key) == expected, 'calibration ' + key + ' binding mismatch')
        _text(calibration.get('observed_at'), 'calibration observation time')
        _text(calibration.get('command'), 'actual calibration command')
        _number(calibration.get('elapsed_seconds'), 'measured calibration time', True)
        _number(calibration.get('peak_ram_gib'), 'measured RAM', True)
        measured_gpu = _integer(calibration.get('gpu_count'), 'measured GPU count')
        _number(calibration.get('peak_gpu_memory_gib'), 'measured GPU memory')
        _require(measured_gpu == gpu_count, 'calibration GPU count mismatch')
        _require(calibration['peak_ram_gib'] <= ram and calibration['peak_gpu_memory_gib'] <= gpu_mem,
                 'job resources below measured calibration demand')
        _refs(root, calibration.get('raw_evidence'))
    report['planned_usage'] = {key: None if key in unknown_usage else total for key, total in totals.items()}
    report['plan_within_budget'] = not unknown_usage and all(totals[key] <= caps[key] for key in caps)
    if phase == 'design':
        blocked = {item['job_id'] for item in report['pending'] if 'job_id' in item}
        reserved = {key: consumed.get(key) or 0 for key in caps}
        for job_id, job in jobs.items():
            if unknown_usage:
                _pending(report, 'cumulative_usage_unknown', 'Reconcile actual cumulative usage before reserving further execution', job_id=job_id)
                continue
            if job_id in blocked:
                continue
            exceeds = [key for key in caps if reserved[key] + job['estimate'][key] > caps[key]]
            if exceeds:
                _pending(report, 'planned_' + exceeds[0] + '_exceeds_budget', 'Keep this obligation pending; version a feasible allocation or obtain a sourced budget change without dropping controls', job_id=job_id)
            else:
                for key in caps:
                    reserved[key] += job['estimate'][key]


def _review(root, reference, contract_ref, contract, report):
    if reference is None:
        _pending(report, 'independent_design_review_missing', 'Dispatch an independent review of the frozen sources, design and resource evidence')
        return
    review = read_reference(root, reference, as_json=True)
    _require(review.get('kind') == 'experiment-design-review' and review.get('contract_ref') == contract_ref,
             'design review contract binding mismatch')
    _require(review.get('proposal_task_id') == contract['proposal_task_id'], 'review proposal binding mismatch')
    _require(_text(review.get('review_task_id'), 'review task') != contract['proposal_task_id'], 'independent review task required')
    _text(review.get('reviewer'), 'independent reviewer')
    read_reference(root, review.get('execution_ref'))
    checks = _obj(review.get('checks'), 'design review checks')
    for key in REVIEW_CHECKS:
        check = _obj(checks.get(key), 'review check ' + key)
        _text(check.get('rationale'), 'review reasoning')
        _refs(root, check.get('evidence_refs'))
        _require(check.get('status') in {'verified', 'pending', 'rejected'}, 'review check status required')
        if check['status'] != 'verified':
            _pending(report, 'design_review_' + key + '_' + check['status'], _text(check.get('next_action'), 'review recovery action'))


def _completion(root, reference, contract_ref, contract, jobs, obligations, claims, report):
    if reference is None:
        for identifier, item in obligations.items():
            if item['applicability'] == 'required':
                _pending(report, 'completion_receipt_missing', 'Execute and verify the pending frozen comparison', obligation_id=identifier)
        return
    packet = read_reference(root, reference, as_json=True)
    _require(packet.get('kind') == 'experiment-completion' and packet.get('contract_ref') == contract_ref,
             'completion contract binding mismatch')
    completed = set()
    execution_ids = set()
    evidence_by_attempt = {}
    actual_usage = {key: 0 for key in ('wall_seconds', 'gpu_seconds', 'cost')}
    receipts_by_job = {}
    for receipt in _array(packet.get('receipts'), 'completion receipts', nonempty=False):
        job_id = _text(receipt.get('job_id'), 'receipt job')
        _require(job_id in jobs and job_id not in completed, 'unknown or duplicate completion job')
        _require(receipt.get('protocol_ref') == contract['protocol_ref'], 'completion protocol binding mismatch')
        attempt = _text(receipt.get('attempt_id'), 'completion attempt id')
        execution = _text(receipt.get('execution_id'), 'job execution id')
        _require(execution not in execution_ids, 'duplicate job execution id')
        execution_ids.add(execution)
        _require(receipt.get('outcome') in {'completed', 'refuted'}, 'only completed or validly refuted jobs close obligations')
        _refs(root, receipt.get('raw_evidence'))
        raw_identity = frozenset((ref['path'], ref['sha256']) for ref in receipt['raw_evidence'])
        _require(raw_identity not in evidence_by_attempt.setdefault(attempt, set()), 'batch jobs require distinct execution evidence')
        evidence_by_attempt[attempt].add(raw_identity)
        # This is the method-result packet reference, checked by the caller against
        # canonical verify_methods results; a hash alone is not a scientific PASS.
        read_reference(root, receipt.get('verification_ref'))
        usage = _obj(receipt.get('actual_usage'), 'completion actual usage')
        for key in actual_usage:
            actual_usage[key] += _number(usage.get(key), 'actual ' + key)
        read_reference(root, receipt.get('usage_ref'))
        completed.add(job_id)
        receipts_by_job[job_id] = receipt
    outcomes = _obj(packet.get('claim_outcomes'), 'claim outcomes')
    _require(set(outcomes) == set(claims), 'completion must retain every claim outcome')
    _require(all(value in {'supported', 'refuted', 'inconclusive'} for value in outcomes.values()), 'invalid claim outcome')
    operation_checks = _obj(packet.get('check_receipts', {}), 'operational check receipts')
    _require(set(operation_checks) <= set(obligations), 'unknown operational obligation receipt')
    operational_complete = True
    for identifier, item in obligations.items():
        if item['applicability'] == 'required' and not set(item['job_ids']) <= completed:
            _pending(report, 'required_jobs_incomplete', 'Execute or validly refute the remaining frozen jobs; retain their actual evidence', obligation_id=identifier)
        if item['applicability'] != 'required' or item['evidence_kind'] == 'scientific_contrast':
            continue
        checks = _obj(operation_checks.get(identifier, {}), 'operational obligation checks')
        _require(set(checks) <= set(item['checks']), 'unknown operational check receipt')
        for check_id in item['checks']:
            check = checks.get(check_id)
            if check is None:
                operational_complete = False
                _pending(report, 'operational_check_missing:' + check_id, 'Execute and record the actual ' + check_id + ' check', obligation_id=identifier)
                continue
            _obj(check, 'operational check receipt')
            job_id = _text(check.get('job_id'), 'operational check job')
            _require(job_id in item['job_ids'] and job_id in receipts_by_job, 'operational check requires its actual completed job')
            _require(check.get('execution_id') == receipts_by_job[job_id]['execution_id'], 'operational check execution binding mismatch')
            _refs(root, check.get('raw_evidence'))
            _require(all(ref in receipts_by_job[job_id]['raw_evidence'] for ref in check['raw_evidence']), 'operational check evidence must belong to its actual job')
            _require(check.get('status') in {'verified', 'pending', 'failed'}, 'operational check status required')
            _text(check.get('finding'), 'operational check finding')
            if check['status'] != 'verified':
                operational_complete = False
                _pending(report, 'operational_check_unverified:' + check_id, _text(check.get('next_action'), 'operational check recovery'), obligation_id=identifier)
    report['coverage_complete'] = operational_complete and all(item['applicability'] == 'not_applicable' or set(item['job_ids']) <= completed for item in obligations.values())
    report['completed_job_ids'] = sorted(completed)
    report['claim_outcomes'] = outcomes
    report['actual_job_usage'] = actual_usage
    # Over-budget completed evidence remains evidence. Report the overrun; do not
    # charge completed jobs again as future reservations or relaunch them.
    budgets = contract['resources']['budgets']
    report['budget_overrun'] = {key: None if budgets['consumed'].get(key) is None else max(0, actual_usage[key] + budgets['consumed'][key] - budgets[key]) for key in actual_usage}


def inspect_contract(root, reference, *, phase='design', review_ref=None, completion_ref=None):
    """Validate design identity and return coverage/eligibility, never science PASS.

    ``ready`` includes every obligation; callers dispatching a subset should use
    ``eligible_job_ids`` so one unavailable GPU does not block an eligible CPU job.
    Missing independent review blocks research dispatch, not source/probe work.
    Completion requires a separate canonical scientific validation by the caller.
    """
    _require(phase in {'design', 'completion'}, 'unknown inspection phase')
    root = Path(root)
    contract = read_reference(root, reference, as_json=True)
    _require(contract.get('kind') == 'experiment-design-contract' and contract.get('version') == '1.0.0'
             and contract.get('schema_id') == 'experiment-design-contract'
             and contract.get('schema_version') == '1.0.0', 'unsupported experiment contract')
    _require(contract.get('stage') in {'diagnostic', 'confirmation'}, 'diagnostic or confirmation stage required')
    for key in ('contract_id', 'candidate_id', 'proposal_task_id'):
        _text(contract.get(key), key)
    read_reference(root, contract.get('hypothesis_ref'))
    read_reference(root, contract.get('protocol_ref'))
    claims = _claims(contract)
    obligations = _records(contract.get('obligations'), 'obligations')
    papers = _papers(root, contract, obligations)
    _obligations(root, contract, claims, obligations, papers)
    jobs = _records(contract.get('jobs'), 'jobs')
    for job_id, job in jobs.items():
        _text(job.get('command'), 'reproducible job command')
        read_reference(root, job.get('code_ref'))
        _require(job.get('protocol_ref') == contract['protocol_ref'], 'job protocol binding mismatch')
        linked = _ids(job.get('obligation_ids'), 'job obligation ids')
        _require(set(linked) <= set(obligations), 'job refers to unknown obligation')
        for item in linked:
            _require(job_id in obligations[item].get('job_ids', []), 'job/obligation mapping must be reciprocal')
    for identifier, item in obligations.items():
        for job_id in item.get('job_ids', []):
            _require(job_id in jobs and identifier in jobs[job_id]['obligation_ids'], 'obligation/job mapping must be reciprocal')
    report = dict(valid=True, ready=False, coverage_complete=False, scientific_truth_verified=False,
                  contract_id=contract['contract_id'], candidate_id=contract['candidate_id'], stage=contract['stage'],
                  protocol_ref=contract['protocol_ref'], claim_ids=sorted(claims), pending=[], eligible_job_ids=[],
                  criterion_ids=sorted({o['contrast']['canonical_criterion_id'] for o in obligations.values() if o['applicability'] == 'required' and o.get('evidence_kind') == 'scientific_contrast'}))
    _resources(root, contract, jobs, report, phase)
    _review(root, review_ref, reference, contract, report)
    global_block = any('job_id' not in item for item in report['pending'])
    blocked = {item['job_id'] for item in report['pending'] if 'job_id' in item}
    report['eligible_job_ids'] = [] if global_block else sorted(set(jobs) - blocked)
    if phase == 'completion':
        _completion(root, completion_ref, reference, contract, jobs, obligations, claims, report)
    report['ready'] = not report['pending']
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path('.'))
    parser.add_argument('--contract', required=True, help='JSON {path,sha256} reference')
    parser.add_argument('--phase', choices=('design', 'completion'), default='design')
    parser.add_argument('--review', help='JSON {path,sha256} independent design review reference')
    parser.add_argument('--completion', help='JSON {path,sha256} completion packet reference')
    args = parser.parse_args()
    result = inspect_contract(args.root, json.loads(args.contract), phase=args.phase,
                              review_ref=json.loads(args.review) if args.review else None,
                              completion_ref=json.loads(args.completion) if args.completion else None)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result['ready'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
