#!/usr/bin/env python3
"""Create an empty-project inquiry fixture. Does not start a host or researcher."""
import argparse
import hashlib
import json
from pathlib import Path


def build(root):
    root = Path(root)
    if root.is_symlink():
        raise ValueError('Use an ordinary empty directory, not a symlink.')
    root.mkdir(parents=True, exist_ok=True)
    if any(root.iterdir()):
        raise ValueError('Refusing to overwrite an existing project; use an empty directory.')
    def put(name, value):
        p = root / name
        text = value if isinstance(value, str) else json.dumps(value, indent=2, ensure_ascii=False) + '\n'
        p.write_text(text, encoding='utf-8')
        return dict(path=name, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    goal = put('goal.txt', 'Known arithmetic fixture: distinguish averaging losses from loss of an average.\nNot a new-method or benchmark result.\n')
    code = '''from fractions import Fraction as F
import json
from pathlib import Path
p = [F(1, 2), F(1, 2)]
r = F(1)
rows = []
for mus in ([F(1), F(1)], [F(-1), F(3)]):
    mean = sum(w*m for w,m in zip(p,mus))
    average_loss = sum(w*(r-m)**2 for w,m in zip(p,mus))
    loss_of_average = (r-mean)**2
    disagreement = sum(w*(m-mean)**2 for w,m in zip(p,mus))
    assert average_loss == loss_of_average + disagreement
    rows.append(dict(average_loss=str(average_loss),loss_of_average=str(loss_of_average),disagreement=str(disagreement)))
Path('probe.json').write_text(json.dumps(dict(scope='exact arithmetic fixture only',rows=rows),indent=2))
'''
    code_ref = put('probe.py', code)
    inquiry = dict(problem_id='loss-aggregation',frame_id='initial',entry='mathematics',stage='hypothesis',
        goal_ref=goal,goal_preservation='Both expressions concern the same specified residual and weights.',
        question='Do these two objectives differ when component predictions disagree?',
        objects=dict(target='Exact equality or difference in the two expressions.',information='Fixed public rational inputs.',
                     objective='Compare average squared loss and squared loss of average.'),
        defaults=[dict(id='default',statement='The objectives are interchangeable.',status='open',evidence_refs=[])],
        explanations=[dict(id='same',mechanism='Averaging commutes with squaring.',conditions='Weights sum to one.',
                           prediction='Difference remains zero.',status='open',evidence_refs=[]),
                      dict(id='disagreement',mechanism='The nonlinear loss retains a disagreement term.',conditions='Nonzero component disagreement.',
                           prediction='Difference changes while the average prediction is fixed.',status='open',evidence_refs=[])],
        contrasts=[dict(id='vary-disagreement',explanation_ids=['same','disagreement'],intervention='Vary component disagreement.',
                        held_fixed='Weights, observed target and mean prediction.',
                        predictions=dict(same='Difference is zero in both cases.',disagreement='Difference becomes nonzero.'))],
        selected_explanation_ids=['disagreement'],selected_contrast_id='vary-disagreement',
        selection_reason='One exact-arithmetic probe separates the accounts without training a model.',
        priority=dict(basis='Algebraic question stated by the fixture.',uncertainty='Unknown until evaluated in this record.',
                      decision_value='Decide whether a changed objective must be versioned.',cost='Two rational-input evaluations.'),
        next_check=dict(action='probe',question='Hold the mean fixed and vary disagreement.',task_ids=['probe'],
                        input_refs=[goal,code_ref],outcome_actions=dict(supports='Derive the discrepancy term.',
                        refutes='Check the proposed explanation.',inconclusive='Choose a discriminating input.',invalid='Repair the evaluator.')),
        observations=[],based_on_observation_ids=[])
    d = dict(kind='research_decision',schema_version=4,decision_id='inquiry-1',goal_id='fixture-goal',candidate_id='fixture',
             family_id='objective-aggregation',mechanism='Nonlinear aggregation versus prediction.',previous_ref=None,
             review_after_rounds=3,evidence_change='none',evidence_refs=[goal],objective_change='No experiment yet.',
             if_repairs_free='Clarify objective semantics before attributing a gain to a new estimator.',
             options=[dict(id='probe',action='explore',value_if_success='Distinguish two accounts.',cost='two exact cases'),
                      dict(id='derive',action='explore',value_if_success='Derive the relation symbolically.',cost='short algebra')],
             selected_option='probe',selected_task_ids=['probe'],why_selected='Use an independently executable sanity check.',
             stop_or_pivot='Do not expand this classical identity into a new-method claim.',facts=[],inquiry=inquiry,
             math_trace_ref=None,trajectory_ref=None,quality_ref=None)
    decision_ref = put('decision.json', d)
    put('task.json', dict(task_id='probe',research_scope='diagnostic',phase='diagnostic',reasoning_ref=decision_ref,
                         input_refs=[decision_ref],argv=['python3','probe.py'],purpose='Known arithmetic control fixture.',
                         timeout_seconds=10,outputs=['probe.json']))
    return decision_ref

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory')
    args=parser.parse_args();print(json.dumps(build(args.directory)))
