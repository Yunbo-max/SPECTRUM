"""Engineering checks of claim scope and downstream asset invalidation."""
import copy
import unittest
from fixtures import C, ProjectFixture, sample_artifacts, write
try:
    import _writing as W
except ImportError:
    W = None


class ClaimAssetsTests(unittest.TestCase):
    def setUp(self):
        self.f = ProjectFixture()
        self.addCleanup(self.f.close)

    def cards(self):
        return [{"claim_id": "claim-1", "supported_wording": "Bounded statement for the engineering contract",
                 "forbidden_wording": ["Unrestricted generalization"], "limitations": ["Defined scope only"],
                 "scope": {"benchmark_id": "fixture-task-suite", "version": "fixture-v1", "split": "discovery",
                    "sample_manifest_ref": self.f.source, "metrics": ["accuracy"], "groups": ["main"], "budget": {"seconds": 120}},
                 "method_version": "method-1", "project_version": "project-1"}]

    def test_closed_claim_cards_must_match_frozen_native_scope(self):
        self.assertIsNotNone(W, "Claim scope verifier is required")
        p = self.f.protocol("full-validation")
        p.update(claim_cards=self.cards(), method_version="method-1", project_version="project-1")
        p["native_eval_contract"] = {"benchmark": {"benchmark_id": "another-benchmark", "version": "fixture-v1", "split": "discovery"},
                                     "sample_manifest_ref": self.f.source, "primary_metric": "accuracy", "metrics": {"accuracy": {}},
                                     "budget": {"seconds": 120}}
        with self.assertRaises(C.Failure):
            W.validate_claim_cards(p)

    def test_changed_claim_marks_all_dependent_assets_stale(self):
        self.assertIsNotNone(W, "Claim dependency tracker is required")
        old = self.cards()
        digest = C.hashed(old[0])
        assets = []
        for kind in ("motivation", "method", "main_result", "appendix", "figure", "website", "social_post"):
            artifact = write(self.f.root, "writing/" + kind + ".json", {"kind": kind, "engineering_fixture": True})
            assets.append({"asset_id": kind, "kind": kind, "asset_ref": artifact, "claim_ids": ["claim-1"],
                           "rendered_from": {"claim-1": digest}, "method_version": "method-1", "project_version": "project-1"})
        changed = copy.deepcopy(old)
        changed[0]["supported_wording"] = "Changed bounded statement"
        result = W.refresh_assets(self.f.root, {"assets": assets}, changed,
                                  method_version="method-1", project_version="project-1")
        self.assertEqual({a["asset_id"] for a in result["assets"] if a["status"] == "stale"}, {a["asset_id"] for a in assets})
        self.assertEqual(len(result["rewrite_actions"]), 7)

    def test_unknown_claim_cannot_be_reported_as_a_current_asset(self):
        self.assertIsNotNone(W, "Claim dependency tracker is required")
        a = {"asset_id": "figure", "kind": "figure", "asset_ref": self.f.source,
             "claim_ids": ["unknown"], "rendered_from": {}, "method_version": "method-1", "project_version": "project-1"}
        result = W.refresh_assets(self.f.root, {"assets": [a]}, self.cards(), method_version="method-1", project_version="project-1")
        self.assertEqual(result["assets"][0]["status"], "blocked")

    def test_manual_asset_edit_requires_new_scope_review(self):
        self.assertIsNotNone(W, "Claim dependency tracker is required")
        cards = self.cards()
        a = {"asset_id": "website", "kind": "website", "asset_ref": self.f.source,
             "claim_ids": ["claim-1"], "rendered_from": {"claim-1": C.hashed(cards[0])},
             "method_version": "method-1", "project_version": "project-1"}
        write(self.f.root, self.f.source["path"], {"engineering_fixture": "edited"})
        result = W.refresh_assets(self.f.root, {"assets": [a]}, cards, method_version="method-1", project_version="project-1")
        self.assertEqual(result["assets"][0]["status"], "stale")


if __name__ == "__main__":
    unittest.main()
