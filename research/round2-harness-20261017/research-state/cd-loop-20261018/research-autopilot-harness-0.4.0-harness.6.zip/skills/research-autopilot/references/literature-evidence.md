## 8. Continuous literature evidence

The evidence layer is active throughout the project. It stores:

- reproducible search runs;
- canonical papers and versions;
- read depth (`D0` metadata, `D1` triage, `D2` scientific read, `D3` forensic verification);
- atomic evidence units with exact locators;
- gaps, contradictions, failures, claims, experiments, review issues, and typed relations;
- versioned snapshots at Gate A, evidence freeze, draft lock, and submission.

### Each round joins reading, implementation, benchmarks and experiment design

Apply this contract at the first discussion and every scientific iteration: idea
generation, method revision, run planning, every returned result and every feedback
item, including execution faults, positive/null/adverse findings, human comments,
reviewer objections and worker/model critiques. Feedback without new runs still
requires a sourced assessment; it is a report or proposition, not a proved cause.
Apply the contract on continuation and writing/review as well. Literature,
implementation and measurement remain
active together. Before an actionable recommendation, inspect the relevant primary
papers, their author/baseline GitHub files and every benchmark under consideration,
then connect each supported hypothesis to its next discriminating experiment.
Load [idea-generation.md](idea-generation.md),
[evaluation-and-assets.md](evaluation-and-assets.md) and the design contract in
[full-validation-and-review.md](full-validation-and-review.md). Keep this work tied
to the current goal, evidence gap and resource limits rather than a fixed experiment
count. Reuse valid saved readings at the same version; refresh changed, stale or
newly relevant dependencies. Do not restart completed reproductions each round.

At each intake of results/feedback, verify actual code/config/evaluator/data versions
against retained paper and benchmark readings, assess validity and assumptions,
compare competing explanations and update the paired H03 decision/G01 experiment
card. Record reused versus newly read scope and what the feedback changes (or why
it changes nothing). No changed obligation means no forced rerun. Apply E04's
post-run verification to every completed run/coherent batch before a scientific
verdict; scenario-dependent performance uses its diagnosis/fair tuning contract in
[development-and-execution.md](development-and-execution.md). Retain pending
parameter/bug/measurement questions rather than calling execution completion proof.

For a human-chosen experiment batch, this per-result review verifies evidence and
supports only the agreed diagnostic/repair scope. Retain its source links and
per-idea observations during the batch. Renewing the scientific direction or a
new idea/design round waits for consolidated batch-end human review under
[state-and-routing.md](state-and-routing.md); explicit human steering may arrive
earlier. Reuse qualified pinned reading while executing the agreed batch. One
failed idea does not autonomously trigger a full direction-search loop.

The nominal eight-hour point is a soft progress/evidence checkpoint, not an
execution stop. Local cycles may run up to 24 elapsed hours; unfinished
approved work may carry unchanged within existing scope and cumulative bounds.
Reuse qualified paper/code/benchmark reads and update changed obligations rather
than force a new search or rerun each window. At human review, pair proposed
convergence/expansion with H03/G01: confirm/deepen useful positives, stop/park validly
refuted candidates and distinguish competing causes behind mixed results. A new
idea slate follows named evidence or changed requirements, not a count target.

Retain one compact linked round record in the existing project artifacts:

| Part | What to actually read, connect and retain |
|---|---|
| Primary literature | Exact paper version and full scientific sections supporting the decision: task, assumptions, objective/algorithm, evidence, ablations and limitations, with page/section/table locators and bounded closest-work coverage. |
| GitHub implementation | Actual repository and commit, inspected file/function/config paths, paper-to-code mapping, inference/training entry points, information/state interfaces, constraints, dependencies, released weights and evaluation commands. Inspect the implementation and scorer beyond a README when they affect the claim; record paper/code differences. |
| Benchmark contents | For every shortlisted benchmark, read primary docs plus actual task/data configs and native evaluator files: task/population, input/output, released sample content, labels, versions/splits, allowed information, preprocessing, metric/extraction/aggregation, denominators/exclusions, access and cost. Inspect accessible native examples and held-out access rules without consuming confirmation to design a favorable method. Record which central and auxiliary claims it can and cannot test and why alternatives were included/excluded. |
| Hypothesis and design | Link observed residual failure, competing explanations, minimal intervention and closest-work difference to a strong/simple comparison, required replacement/interaction controls, matched information/total budget, native metric, eligible unit/sampling, uncertainty, outcome interpretations, falsifier and stop/next action. |
| Readiness and delivery | Distinguish sources located, full text/files read, statically inspected, executed, reproduced, novelty adjudicated and scientifically confirmed. Retain unknowns, protocol/confirmation status, per-task cost and dependency order; save through the project's startup-selected GitHub/HF mapping within the existing update scope and retain actual receipts. |

Reading a skill is a workflow input; reading a paper is a source observation;
neither is a completed code run, originality decision or experimental result.
Repository URLs, names, search snippets and benchmark summaries do not prove their
contents were inspected. Report exact read scope and unavailable portions. If a
paper has no released code or a repo cannot be read, retain that fact and separate
the paper's specification from any independent reimplementation. Do not invent
files, commands or model capabilities. A purely formal contribution can record
code/empirical benchmark as not applicable with a reason and retain its actual
proof/assumption obligations; do not force an unrelated empirical task.

Scope the reading to the project's relevant work and benchmark inventory, and
record exclusions and coverage limits; never claim all GitHub repos or all field
benchmarks have been read. A benchmark measuring only appearance, motion or a
proxy cannot validate a joint dynamic-editing or other broader claim. If no
existing evaluation measures the core claim, return bounded source/access or
measurement-validity investigations and the blocked method decision. Do not
manufacture evaluation data, labels or scoring rules to close it.

For each current hypothesis, explain what each comparison could distinguish and
how positive, null, adverse or invalid outcomes affect it. Keep diagnosis, method
necessity, confirmation and generalization experiments distinct, and count unique
scientific hypotheses separately from experiment arms and seed/configuration runs.
Separate module changes need not isolate causes; check interacting constraints
before interpreting a single-factor result and add only decision-relevant interaction
controls. Exclude extra compute, calls, feedback, information or tuning as rivals
when claimed. Prioritize the cheapest valid uncertainty-reducing check, preserve
independent confirmation, and carry unfinished obligations into later rounds.

Missing source/evaluation/baseline evidence yields an investigation or conditional
design with explicit blockers, not an approved method slate. Preparing the linked
record does not bypass Parent/Natural Gate 0, collision/IPCG, qualification or
frozen confirmation. On new results, check validity, update the literature/code/
benchmark links and revise the paired idea/design under the existing H03 and
protocol lineage; preserve earlier plans and negative evidence. This is an
instruction and evidence record, not a new schema, background search service or
installed experiment scheduler.

Each `search-run` freezes the exact query strings, provider and API/index version, search date and cutoff, filters, sort order, page size, pagination cursors or page range, language/type restrictions, seed works, citation-expansion policy, requested and returned counts, raw-response snapshot or immutable digest, parser version, canonicalization rules, deduplication version, and normalized output digest. Replaying captured connector responses must reproduce the same normalized works, evidence units, coverage result, and snapshot digest. Missing raw captures, protocol metadata, or versioned normalization prevents the run from satisfying collision coverage and therefore prevents `ADVANCE` or `KILL`.

Search families vary by entry:

- `I`: landscape, contradiction, failure regime, benchmark, mechanism, theory, replication, adjacent domain;
- `M`: genealogy, historical aliases, functional equivalence, component combination, simple alternative, failure, resource profile, concurrent work;
- `R`: reviewer-literal terms, reviewer-cited sources, novelty objection, soundness, missing baseline, generalization, post-submission work, venue rules.

Search snippets and model memory are discovery aids only. Core novelty, mechanism, benchmark, and contradiction claims require verified primary sources. New material after a freeze enters a monitored overlay and can reopen affected claims; it never silently mutates a frozen snapshot.

Refresh is event-driven at minimum: new candidate, changed method digest, unexpected Gate A result, new headline claim, evidence freeze, venue change, reviewer feedback, and submission delta audit. Optional scheduled monitoring is separately authorized. A search iteration reaches risk-based saturation only after all applicable query families run, critical seeds receive backward/forward expansion, and two successive batches add no new high-impact method family, contradiction, or evidence obligation. This is recorded as coverage, never as exhaustive completion.

Every newly verified item receives an impact class:

- `S0 context`: ledger update only;
- `S1 positioning`: rerun citation and related-work projection;
- `S2 evidence obligation`: invalidate affected experiment, claim, writing, and figure projections;
- `S3 thesis or novelty`: mark the evidence snapshot stale and reopen collision audit or Gate A.

Downstream artifacts carry the exact evidence-snapshot digest. A stale dependency cannot remain `current` or authorize writing/submission progression.
