"""Adaptive DAG control-flow tests; fixtures are not scientific run evidence."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

S=Path(__file__).resolve().parents[1]/'scripts'
class AdaptiveTrajectoryTests(unittest.TestCase):
    def setUp(self):
        spec=importlib.util.spec_from_file_location('trajectory_test_reasoning',S/'research_reasoning.py')
        self.m=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.m)
        self.assertTrue(hasattr(self.m,'check_trajectory'),'adaptive experimental trajectory checker missing')
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name);self.n=0
        self.raw=self.ref('fixture: scoped mathematical note, not a live experiment')
    def ref(self,value):
        self.n+=1;p=self.root/f'{self.n}.json';p.write_text(value if isinstance(value,str) else json.dumps(value,sort_keys=True))
        return dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    def trace(self, candidate='a'):
        return dict(kind='mathematical_trace',schema_version=1,trace_id=candidate+'-trace',candidate_id=candidate,revision=1,
            objects=[dict(id='x',definition='x is a positive scalar')],assumptions=[],obligations=[],
            steps=[dict(id='s',operation='A02',inputs=['x'],assumptions=[],obligations=[],
                transition='Multiply by a fixed positive scalar',derivation='d(cx)/dx=c',output='derivative c',validity='exact')],
            branches=[],frontier=[],method=dict(rule='Scale the update reciprocally',from_steps=['s']),
            prediction=dict(ours='Compensated update agrees',rival='Uncompensated update differs',distinguishing_test='Exact common-start comparison',falsifier='An admissible discrepancy'))
    def route(self,identity):
        return dict(id=identity,candidate_id=identity,trace_ref=self.ref(self.trace(identity)),
            prior=dict(priority='medium',basis='A sourced mathematical analogy, not a measured discovery probability',evidence_refs=[self.raw],uncertainty='Transfer to this setting is unknown'),
            decision_value='high',cost='one bounded CPU comparison',availability='ready',
            experiments=[dict(id='test',question='Does the predicted invariance hold?',target_step_ids=['s'],
                contrast='Compensated versus uncompensated from same input',analysis_plan='Compare exact outputs; record invalid runs separately',
                scope='development',independent_unit='problem',sampling_plan='Preserve problem identity across paired arms',
                budget='One bounded batch',outcome_actions=dict(supports='confirm',refutes='backtrack',inconclusive='repeat',invalid='repair'))])
    def trajectory(self):
        return dict(kind='adaptive_trajectory',schema_version=1,trajectory_id='traj',goal_id='goal',revision=1,previous_ref=None,
            routes=[self.route('a'),self.route('b')],observations=[],
            selection=dict(route_id='a',action='experiment',experiment_id='test',task_ids=['task'],
                reason='Resolve the first uncertainty cheaply',alternative='b can test a different explanation',
                based_on_observation_ids=[]))
    def codes(self,r):return {g['code'] for g in r['gaps']}
    def observe(self,t,outcome='inconclusive',route='a',attempt='run-1',unit='problem-1'):
        rr=next(r for r in t['routes'] if r['id']==route)
        experiment=next(e for e in rr['experiments'] if e['id']=='test')
        contract_ref=self.ref(experiment)
        result=dict(kind='trajectory_outcome',attempt_id=attempt,route_id=route,experiment_id='test',trace_ref=rr['trace_ref'],
            experiment_ref=contract_ref,outcome=outcome,terminal=True,raw_refs=[self.raw],
            interpretation='A scoped outcome from the specified protocol, not a universal truth',independent_unit_ids=[unit])
        obs=dict(id='obs-'+attempt,route_id=route,experiment_id='test',attempt_id=attempt,trace_ref=rr['trace_ref'],
            experiment_ref=contract_ref,outcome=outcome,result_ref=self.ref(result))
        t['observations'].append(obs);t['selection']['based_on_observation_ids'].append(obs['id'])
        return t
    def check(self,t,**kw):return self.m.check_trajectory(self.root,t,**kw)
    def test_prior_choice_is_not_a_posterior_or_science_pass(self):
        r=self.check(self.trajectory());self.assertEqual(r['status'],'record_complete');self.assertFalse(r['scientific_certification']);self.assertFalse(r['posterior_probability_computed'])
    def test_prior_requires_source_and_uncertainty(self):
        t=self.trajectory();t['routes'][0]['prior']['evidence_refs']=[];self.assertIn('missing_evidence',self.codes(self.check(t)))
        t=self.trajectory();t['routes'][0]['prior']['uncertainty']='';self.assertIn('prior_uncertainty_missing',self.codes(self.check(t)))
    def test_no_fabricated_numeric_prior(self):
        t=self.trajectory();t['routes'][0]['prior']['probability']=0.9;self.assertIn('unsupported_probability',self.codes(self.check(t)))
    def test_selected_route_must_exist(self):
        t=self.trajectory();t['selection']['route_id']='missing';self.assertIn('route_not_found',self.codes(self.check(t)))
    def test_bound_candidate_and_goal(self):
        self.assertIn('candidate_mismatch',self.codes(self.check(self.trajectory(),candidate_id='b')))
        self.assertIn('goal_mismatch',self.codes(self.check(self.trajectory(),goal_id='different')))
    def test_experiment_targets_actual_dag_step(self):
        t=self.trajectory();t['routes'][0]['experiments'][0]['target_step_ids']=['absent'];self.assertIn('unknown_experiment_step',self.codes(self.check(t)))
    def test_outcomes_have_predeclared_routes(self):
        t=self.trajectory();t['routes'][0]['experiments'][0]['outcome_actions'].pop('refutes');self.assertIn('missing_outcome_action',self.codes(self.check(t)))
    def test_run_to_experiment_binding(self):
        t=self.observe(self.trajectory());t['observations'][0]['attempt_id']='different';self.assertIn('result_binding_mismatch',self.codes(self.check(t)))
    def test_unread_observation_cannot_be_ignored(self):
        t=self.observe(self.trajectory());t['selection']['based_on_observation_ids']=[];self.assertIn('feedback_not_consumed',self.codes(self.check(t)))
    def test_repeated_same_run_is_not_new_evidence(self):
        t=self.observe(self.trajectory());o=copy.deepcopy(t['observations'][0]);o['id']='alias';t['observations'].append(o);t['selection']['based_on_observation_ids'].append('alias')
        self.assertIn('duplicate_attempt',self.codes(self.check(t)))
    def test_multiple_independent_attempts_one_question(self):
        t=self.observe(self.trajectory());self.observe(t,attempt='run-2');t['selection']['action']='repeat'
        r=self.check(t);self.assertEqual(r['status'],'record_complete');self.assertEqual(r['attempt_count'],2);self.assertEqual(r['question_count'],1);self.assertEqual(r['observed_unit_count'],1)
    def test_refutation_changes_admissible_method_path(self):
        t=self.observe(self.trajectory(),'refutes');self.assertIn('refuted_route_selected',self.codes(self.check(t)))
        t['selection'].update(route_id='b',reason='Counterevidence rules out route a');self.assertEqual(self.check(t)['status'],'record_complete')
    def test_backtrack_retains_old_failed_branch(self):
        t=self.observe(self.trajectory(),'refutes');t['selection']['action']='backtrack';self.assertEqual(self.check(t)['status'],'record_complete')
    def test_invalid_run_routes_to_repair_not_refutation(self):
        t=self.observe(self.trajectory(),'invalid');self.assertIn('invalid_result_needs_repair',self.codes(self.check(t)))
        t['selection']['action']='repair';r=self.check(t);self.assertEqual(r['status'],'record_complete');self.assertEqual(r['route_states']['a'],'needs_repair')
    def test_inconclusive_can_repeat_without_changing_hypothesis(self):
        t=self.observe(self.trajectory());t['selection']['action']='repeat';self.assertEqual(self.check(t)['status'],'record_complete')
    def test_confirmation_needs_an_unexposed_contract(self):
        t=self.observe(self.trajectory(),'supports');t['selection']['action']='confirm';self.assertIn('confirmation_scope_required',self.codes(self.check(t)))
    def test_revision_retains_observation_prefix(self):
        old=self.observe(self.trajectory());t=copy.deepcopy(old);t.update(revision=2,previous_ref=self.ref(old));t['observations']=[];t['selection']['based_on_observation_ids']=[]
        self.assertIn('lost_observation_history',self.codes(self.check(t)))
    def test_revision_cannot_rewrite_old_prior(self):
        old=self.trajectory();t=copy.deepcopy(old);t.update(revision=2,previous_ref=self.ref(old));t['routes'][0]['prior']['priority']='high'
        self.assertIn('prior_rewritten',self.codes(self.check(t)))
    def test_old_test_contract_not_tuned_after_outcome(self):
        t=self.observe(self.trajectory());t['routes'][0]['experiments'][0]['contrast']='An easier comparison'
        self.assertIn('experiment_contract_changed',self.codes(self.check(t)))
    def test_selected_tasks_flow_into_method_decision(self):
        t=self.trajectory();r=self.check(t);self.assertEqual(r['selected_task_ids'],['task']);self.assertEqual(r['selected_trace_ref'],t['routes'][0]['trace_ref'])
    def test_all_branches_are_retained_on_revision(self):
        old=self.trajectory();t=copy.deepcopy(old);t.update(revision=2,previous_ref=self.ref(old));t['routes']=t['routes'][:1]
        self.assertIn('lost_route_history',self.codes(self.check(t)))
    def test_control_flow_prioritizes_information_before_prior_preference(self):
        t=self.trajectory();t['routes'][0]['decision_value']='low';t['routes'][1]['prior']['priority']='low';t['selection']['route_id']='b'
        r=self.check(t);self.assertEqual(r['recommended_route_order'][0],'b')
    def test_nonleading_route_requires_reasoned_override(self):
        t=self.trajectory();t['routes'][0]['decision_value']='low';self.assertIn('selection_override_required',self.codes(self.check(t)))
        t['selection']['override_reason']='Route b is scientifically stronger but the source calibration for a is immediately needed';self.assertEqual(self.check(t)['status'],'record_complete')
    def test_broken_math_branch_cannot_be_selected(self):
        t=self.trajectory();x=self.trace();x['steps'][0]['inputs']=['s'];t['routes'][0]['trace_ref']=self.ref(x)
        self.assertIn('unknown_input',self.codes(self.check(t)))
    def test_unresolved_alternative_does_not_globally_block(self):
        t=self.trajectory();t['routes'][1].update(availability='blocked',blocker='Evidence acquisition pending');t['routes'][1]['trace_ref']=None
        self.assertEqual(self.check(t)['status'],'record_complete')

if __name__=='__main__':unittest.main()
