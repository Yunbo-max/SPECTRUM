# Autonomous foreground Chat research goal

Use the pinned autonomous-rsi-chat edition in this active conversation.
Read chat-execution.md and autonomous-rsi.md, then only the current action's
relevant modules. Use actual current-host tools without requiring Local, SSH,
Work or a paid API. This prompt creates no daemon or automatic wakeup.

Project/goal: REPLACE_ACTUAL_PROJECT_AND_REQUESTED_OUTCOMES.
Acceptance/delivery: REPLACE_REQUIRED_EVIDENCE_AND_CONFIRMED_DESTINATION.
Existing scope/limits: REUSE_ACTUAL_AUTHORIZATION_AND_CUMULATIVE_BUDGET.
Restore from: REPLACE_SAVED_SOURCE_REVISION_CHECKPOINT_AND_RAW_EVIDENCE.
Current procedure: REPLACE_ACTUAL_LOADED_PROCEDURE_VERSION.

Inspect actual tools/resources and choose a feasible next action. Default to one
consequential candidate with real derivation, independent mathematical/selection
review and source/implementation/native-protocol reading. Record the edition
pool_target=1, selection_target=1 and explicit target_override in canonical method
records. Reuse existing qualified pools; do not reset them or pad candidate counts.

Implement complete requested code/design, run feasible authorized checks on this
host, inspect actual evidence and route each failure to repair, evidence
collection or a substantive successor. Keep native scoring, E04, frozen
confirmation and supported claim scope. No Docker, invented GPU, fake outputs,
retrospective acceptance or substituted toy benchmark.

Continue after each stage/report while useful authorized work remains. Record
real attempts and partial output; reconcile uncertain effects before retry.
Failed candidates do not end the whole goal. Fixing a prerequisite explicitly
rebinds pending consumers to the new evidence, without altering live inputs.

Save artifacts, failed predicates, versions, usage, outstanding obligations and
exact next action; read back actual delivery. Complete only requested outcomes
with evidence/receipts. At a genuine host/context/turn boundary save a coherent
checkpoint for the next active turn and report that boundary accurately.
Do not require Local handoff documents for this host-contained project.
