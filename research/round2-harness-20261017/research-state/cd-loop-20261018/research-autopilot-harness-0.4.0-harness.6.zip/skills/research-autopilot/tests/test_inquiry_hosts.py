"""Real short CPU commands with fixture projects; not agent or benchmark evaluations."""
import copy
import importlib
import json
from pathlib import Path
import sys
import time
import unittest
import test_inquiry_discovery as fixtures
S=Path(__file__).resolve().parents[1]/'scripts';sys.path.insert(0,str(S))
import research_reasoning as rr

class InquiryHosts(unittest.TestCase):
    def setUp(self):
        self.f=fixtures.InquiryTests();self.f.setUp();self.addCleanup(self.f.doCleanups)
        self.root=self.f.root
    def simple(self):
        if not (S/'simple_runner.py').exists():self.skipTest('Chat edition: Simple executor not included')
        import simple_runner
        r=simple_runner.SimpleRunner(self.root)
        r.initialize(dict(idea='candidate',goal='goal',goal_contract=dict(mode='bounded_task',completion_criteria=[dict(id='x',description='inquiry CPU fixture')]),
                          limits=dict(max_attempts=8,max_command_seconds=40,deadline_seconds=40,max_concurrency=1)))
        self.addCleanup(lambda:r.stop('fixture cleanup'));return r
    def task(self,name,ref,depends=()):
        return dict(task_id=name,argv=[sys.executable,'-c',f"from pathlib import Path;Path('{name}.txt').write_text(str(sum(i*i for i in range(10))))"],
                    phase='diagnostic',purpose='bounded empirical lead fixture, not a claimed new method',timeout_seconds=8,
                    outputs=[name+'.txt'],research_scope='diagnostic',reasoning_ref=ref,input_refs=[ref],depends_on=list(depends))
    def review(self,r,d,event_id):
        ref=self.f.ref(d);r.loop.record(dict(event_id=event_id,kind='research_review',reason='Adopt bounded inquiry selection',
            decision_ref=ref,evidence=[ref]),r.loop.status()['version']);return ref
    def wait(self,r,pred):
        end=time.monotonic()+18
        while time.monotonic()<end:
            r.tick();st=r.status()
            if pred(st):return st
            time.sleep(.03)
        self.fail('real CPU inquiry did not reach expected terminal state')
    def test_simple_probe_then_feedback_then_second_probe(self):
        r=self.simple();d=self.f.decision();d['selected_task_ids']=['task','stale'];d['inquiry']['next_check']['task_ids']=['task','stale']
        ref=self.review(r,d,'first');r.submit(dict(submission_id='first',idea='candidate',revision=1,
            tasks=[self.task('task',ref),self.task('stale',ref,('task',))]))
        st=self.wait(r,lambda s:any(t['task_id']=='stale' and t['state']=='blocked' for t in s['tasks']))
        self.assertEqual((self.root/'task.txt').read_text(),'285');self.assertFalse((self.root/'stale.txt').exists())
        with r.loop._connection(readonly=True) as cx:
            receipt=r._load(cx)['reasoning_experiment_receipts'][0]
        self.assertEqual(receipt['feedback_kind'],'inquiry')
        d2=copy.deepcopy(d);d2.update(decision_id='second',previous_ref=ref,selected_task_ids=['next'])
        i=d2['inquiry'];i['next_check']['task_ids']=['next'];i['observations']=[dict(id='o',attempt_id=receipt['attempt_id'],task_id='task',
            receipt_ref=receipt['receipt_ref'],outcome='inconclusive',affected_layer='evaluation',affected_explanation_ids=['h1'],
            interpretation='Execution fixture completed; no mathematical truth inferred.')];i['based_on_observation_ids']=['o']
        new=self.review(r,d2,'second');r.submit(dict(submission_id='second',idea='candidate',revision=1,tasks=[self.task('next',new)]))
        st=self.wait(r,lambda s:any(t['task_id']=='next' and t['state']=='succeeded' for t in s['tasks']))
        self.assertEqual((self.root/'next.txt').read_text(),'285')
        with r.loop._connection(readonly=True) as cx:
            self.assertEqual(len(r._load(cx)['reasoning_experiment_receipts']),2)
        self.assertFalse(st['journal']['scientific_certification'])
    def test_simple_changed_goal_pin_blocks_probe(self):
        r=self.simple();d=self.f.decision();ref=self.review(r,d,'first')
        r.submit(dict(submission_id='first',idea='candidate',revision=1,tasks=[self.task('task',ref)]))
        (self.root/self.f.goal['path']).write_text('tampered goal')
        self.wait(r,lambda s:s['tasks'][0]['state']=='blocked');self.assertFalse((self.root/'task.txt').exists())
    def chat(self):
        if not (S/'chat_cycle.py').exists():self.skipTest('Simple edition: Chat adapter not included')
        import test_chat_strategy as sf
        x=sf.StrategyTests();x.setUp();self.addCleanup(x.doCleanups)
        self.root=x.root;self.f.root=x.root;self.f.f.root=x.root;self.f.q.root=x.root;self.f.goal=x.source;self.f.f.raw=x.source
        x.scope=x.write(dict(kind='chat_research_scope',candidate_id='candidate',claim_kind='investigation',
             implementation_ref=x.source,protocol_ref=x.source,default_parameters_ref=x.source,baselines=[]))
        return x,sf.S
    def chat_task(self,x,s,d,name):
        ref=self.f.ref(d)
        task=x.task(name,purpose='diagnostic',kind='action',research_scope='diagnostic',reasoning_ref=ref,action='bounded inquiry CPU fixture')
        import chat_cycle
        task['input_refs']=[ref]
        normalized=chat_cycle._task(self.root,task);task.update(normalized)
        s.apply(self.root,x.state,dict(op='strategy_reasoning',decision_ref=ref),x.read)
        return task,ref
    def test_chat_early_probe_admitted_without_a_claimed_novelty_qualification(self):
        x,s=self.chat();d=self.f.decision();task,ref=self.chat_task(x,s,d,'task')
        s.admit_task(self.root,task,x.state,x.read)
        task['research_scope']='method'
        with self.assertRaises(ValueError):rr.require_task(self.root,task,expand=True)
    def test_chat_real_probe_receipt_controls_successor(self):
        x,s=self.chat();d=self.f.decision();d['selected_task_ids']=['task','stale'];d['inquiry']['next_check']['task_ids']=['task','stale']
        # Register both pending tasks before accepting the selection.
        ref=self.f.ref(d)
        tasks=[x.task(n,purpose='diagnostic',kind='action',research_scope='diagnostic',reasoning_ref=ref,action='CPU inquiry fixture') for n in ('task','stale')]
        import chat_cycle, chat_run
        for t in tasks:
            t['input_refs']=[ref];t.update(chat_cycle._task(self.root,t))
        s.apply(self.root,x.state,dict(op='strategy_reasoning',decision_ref=ref),x.read)
        attempt=x.start(tasks[0]);procedure=x.source
        prepared=chat_run.prepare(self.root,dict(attempt_id=attempt['id'],procedure_ref=procedure,input_refs=tasks[0]['input_refs'],
            code_refs=[],command=[sys.executable,'-c',"from pathlib import Path;Path('result.txt').write_text('285')"],cwd='.',
            output_paths=['result.txt'],timeout_seconds=8,max_log_bytes=4096,numeric_status_path=None))
        result=chat_run.execute(self.root,prepared['execution_id'],prepared['plan_digest'],authorizer=lambda scope:True)
        self.assertEqual(result['status'],'completed');self.assertFalse(result['scientific_accepted'])
        raw=self.f.ref(result);attempt['evidence_ref']=raw;attempt['outcome']='completed'
        usage=x.write(dict(kind='chat_strategy_usage',attempt_id=attempt['id'],terminal=True,
            totals=dict(wall_seconds=result['wall_seconds'],gpu_seconds=0,cost=0),raw_evidence=[raw]))
        s.after_result(self.root,x.state,attempt,dict(outcome='completed',strategy_usage=dict(receipt_ref=usage,
            totals=dict(wall_seconds=result['wall_seconds'],gpu_seconds=0,cost=0))),x.read)
        x.state['attempts'].append(attempt);x.state['current_attempt']=None;tasks[0]['status']='completed'
        self.assertEqual(x.state['strategy']['reasoning_experiment_receipts'][0]['feedback_kind'],'inquiry')
        with self.assertRaisesRegex(ValueError,'consume'):s.before_begin(self.root,x.state,tasks[1],dict(id='a2',task_id='stale'),x.read)
        d2=copy.deepcopy(d);d2.update(previous_ref=ref,decision_id='after-probe',selected_task_ids=['next'])
        d2['inquiry']['next_check']['task_ids']=['next'];d2['inquiry'].update(observations=[dict(id='o',attempt_id=attempt['id'],task_id='task',
           receipt_ref=raw,outcome='inconclusive',affected_explanation_ids=['h1'],affected_layer='evaluation',interpretation='Fixture only.')],based_on_observation_ids=['o'])
        task2,newref=self.chat_task(x,s,d2,'next');s.before_begin(self.root,x.state,task2,dict(id='a2',task_id='next'),x.read)
        self.assertEqual(len(x.state['strategy']['entries']),2)

if __name__=='__main__':unittest.main()
