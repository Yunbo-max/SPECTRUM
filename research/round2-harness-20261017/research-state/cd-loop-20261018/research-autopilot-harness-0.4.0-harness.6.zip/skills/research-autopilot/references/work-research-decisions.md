# Work Auto: choose the next experiment from evidence

Current edition and continuation: read [edition-policy.md](edition-policy.md) and
[round-continuation.md](round-continuation.md) first. They supersede older host,
human/machine selection and manual-resume defaults in examples below.

Read at project start/resume, before the first empirical investment and at every
step-7 decision. This is the `autonomous-rsi` policy from 0.2.0-autonomous.4.
It changes research selection, not the authorized host, resources or scientific
acceptance criteria. Keep one verified Work goal, the real Local/SSH execution
path (or the owner's existing scoped override), cumulative budgets and pauses.

## Decide what could change the conclusion

Each round closes one consequential uncertainty or builds evidence needed to
close it. Before implementation, record the current claim, strongest competing
explanation, changed premise, cheapest credible decisive test and prospective
stop condition. Compare continuation, diagnosis, a different approved mechanism
and parking. Explain the expected information and plausible end-to-end benefit;
do not invent probabilities or rank directions by list position, number of cards,
reports, agents, experiments or time already invested.

Valid counterevidence retires the scoped hypothesis. Invalid measurement first
requires bounded evidence repair; it does not prove the method failed. Audit and
baseline work are valuable but are not additional original methods. Repeated
repair needs a new causal delta and a reason that it can change the decision.
Enforce both per-direction repair allowances and unchanged cumulative limits.
If one route is exhausted, review the remaining approved alternatives; do not
silently close the whole project while another justified route remains. If none
is justified, preserve the question, negative evidence and reopening condition.
An instruction to continue indefinitely means continue eligible work within
actual renewable resources; it cannot create an immortal process or reset limits.

## Qualify comparisons and measurements early

Before the first empirical comparison or performance claim, collect four linked
records. Reuse current, independently checked evidence; missing qualification
blocks only the work that depends on it.

| Record | Required content |
| --- | --- |
| Strong baseline | Author/native implementation and strongest simple credible implementation; matched information, quality targets, initialization, preprocessing, caching, precision, threads and tuning opportunity. Record exclusions and why. |
| Measurement | Metric definition and numerical implementation; invariant/identity checks, near-zero cancellation, ties/degeneracy, missing/nonfinite outcomes and denominator accounting; independent calculation or reference scorer checks. Engineering stress cases qualify the instrument only and never replace native scientific benchmarks. |
| Comparison contract | Freeze `equivalence`, `new_algorithm` or `diagnostic`, the intended claims, native data/scorer versions, development versus fresh confirmation, acceptable quality/stability/cost and uncertainty/stop rules. |
| Cost and value | Paired full-policy CPU and wall time, peak memory and decomposition into maintenance, certificate/query, endpoint construction, update, scoring and I/O as applicable. State which term changes and the optimistic total-benefit bound; include added overhead and calibration uncertainty. |

For example, removing a component occupying fraction f can at best reduce that
same fixed workload's time by f (ideal speedup 1/(1-f)); it cannot explain away
an unchanged dominant endpoint cost. This is an optimistic screening bound, not
an empirical speedup claim. Fewer queries, smaller projector movement and faster
root solving are different quantities; establish their causal link to total cost.
Use scoped component improvements honestly when they are independently useful.

With `equivalence`, test the required endpoints/trajectory and tolerances as well
as cost. With `new_algorithm`, freeze the quality–stability–cost comparison
prospectively; exact old-trajectory parity is not a universal acceptance rule.
Do not relabel a failed equivalence experiment as a successful new algorithm after
seeing results. Create a child protocol and retain the old failure. A diagnostic
can correct a metric or explain a confound without qualifying a scientific claim.

## Select ready mechanisms without a quantity quota

New Work Auto discovery has no default 20-candidate or top-15 requirement. Start
with one consequential, distinct construction when its derivation, falsifier,
closest-work review and applicable Parent/Gate 0/IPCG prerequisites are ready.
The 48 operations are tools for reasoning, not a list to fill. Deduplicate by
actual update operator, state, information access and assumptions. Solver changes,
certificates, parameter choices and packaging are not automatically new methods.

Use `method-verification-batch` version `1.1.0` for a new readiness cohort, with
`pool_target=1`, `selection_target=1` by default, a substantive `scope_rationale`
and an actual pinned `history_ref` retaining rejected/unready alternatives.
Every declared cohort member still needs mathematical review and comparison;
larger cohorts require a complete ranking and the explicitly selected subset.
Keep separate unresolved families in the search ledger instead of making a ready
method wait for arbitrary numbers. Do not remove candidates from an already
frozen comparison to improve its result. A genuinely empty or unsound cohort
cannot pass. Schema success does not authenticate a reviewer or establish novelty.

Existing version `1.0.0` packets retain their original 20/15 defaults or explicit
`target_override`; source updates do not rewrite frozen evidence. To adopt the
new selection policy, create a prospectively scoped child batch with real history
and source bindings, preserving prior results. No new user confirmation is needed
for this routine choice when existing scope already authorizes it.

## Use independent agents before expensive commitment

When the current host actually exposes subagents and the work has separable
uncertainties, dispatch bounded independent reviews before empirical investment:

| Assignment | Question to challenge |
| --- | --- |
| Baseline and cost reviewer | Could a simple cached/incremental implementation erase the proposed advantage? Which dominant cost can this mechanism remove? |
| Mathematics and novelty reviewer | Does the derivation hold, what counterexample breaks it, and how does the operation differ from primary prior work? |
| Measurement and experiment reviewer | Can the metric produce a false difference or hide a real one? Does the design separate mechanisms and support its stated claim? |

Choose only the roles relevant to the current uncertainty. Give the reviewer the
raw pinned artifacts and question, not a desired positive answer. Retain actual
assignment/task/agent identity, input hashes, commands/findings, dissent and scope.
The integrator resolves disagreements and owns writes/publication. Reviewers have
disjoint outputs or are read-only; do not share a mutable result file. A different
role label or model name is not evidence of an independent task. Independent review
also does not make the original development experiment an independent confirmation.

Observe available slots and provider limits; reserve the same finite project
budget. Agent parallelism is separate from CPU/native concurrency and the single
harness owner. Do not launch three expensive experiments on one 8-GB host because
three agents exist. If host delegation is unavailable, use a clearly labelled
sequential challenge review, preserve unmet independent-verification obligations
and continue admissible work. Never claim that a subagent ran when none did; do
not install or charge an API backend merely to fill the roles.

## Runtime integration and old delegations

For background exceptions, including absent CPU tools and lost workers, also apply
[background-exception-reporting.md](background-exception-reporting.md). A direct
host report must not depend on the broken executor or successful checkpoint write.
An independently configured watch observes actual task/checkpoint evidence and
never changes project state or restarts execution.

New Python `Delegation(...)` objects default to `decision_policy="evidence_v2"`.
Serialize that field explicitly in new delegation JSON. The trusted live
`verify_review` hook must return `VerifiedReview(strategy=VerifiedStrategy(...))`:

- `intent`: continue, repair, pivot or park; chosen `direction`, `step`, `action`;
- `assessment_ref`, `hypothesis_delta`, `decisive_test`, `falsifier`,
  `expected_information`, `alternatives` and `claim_mode`;
- for native execution, current `baseline_ref`, `measurement_ref`,
  `comparison_ref` and `cost_ref`.

Qualification runs that produce these preflight records are not required to
already possess them. Use explicit `native_purpose="qualification"`,
`claim_mode="diagnostic"` and `native_plan_ref` for the exact pinned baseline-only
or measurement qualification harness. Materialized parameters must retain
`native_purpose` and the same `harness_plan_ref`; admission rejects treatment arms
in qualification plans. Native comparisons default to `native_purpose="comparison"`
and require all four preflight references. A diagnostic label alone is no exception.
Candidate math/code/design gaps do not block these non-treatment qualifications;
their own source/resource and complete native-protocol requirements still apply.
Both paths retain actual scientific host, protocol, resources and budget admission.

Every strategy reference is also included in `review.evidence_refs`. The supervisor
rechecks actual bytes and the live hook authenticates assignments and scientific
content. Nonempty prose and pins alone do not establish a good decision. The
controller intersects the choice with earlier prerequisites, approved directions,
finite repair/failure limits and live eligible actions. A pivot returns to source
or resource review; a missing record never becomes a made-up eligible action.
The child blueprint retains the decision, falsifier, comparison mode and evidence.
Native admission and G01/E04/Gate A remain independently required.
The existing `result_verify` action is the canonical final-verdict boundary.
Preliminary result/measurement inspection uses `source_read`; actual recalculation
uses an appropriately admitted native qualification or comparison. A step-6 label
does not grant a scorer launch or turn pending evidence into a verified verdict.

Serialized delegations without `decision_policy` remain `legacy_v1`, preserving
their exact immutable bytes and historical routing. No in-place policy migration
or counter reset is provided. Existing live runs keep their pinned skill/hooks;
source delivery alone does not upgrade them. A future adoption must reconcile
old attempts and retain old history and total usage through the existing scoped
project transition. Report the actually effective policy, not the newest file's
version. The runtime still reserves at most one child per round; independent
host-agent reviews are explicit bounded tasks, not an automatically deployed
multi-agent supervisor or daemon.

## One recovery entry, with policy and executor separated

Use `research-state/CURRENT.json` as the sole human/Work resume locator. It points
to an immutable hashed checkpoint; README, handoff and scheduled prompts link
to this locator instead of embedding changing batch instructions. Existing
controller DB/attempt receipts remain authoritative for dispatch and budgets:
the integration writer must reconcile them before publishing the checkpoint.
If old README says B03 and the checkpoint says B15, inspect the actual ledger,
report and pending work; do not run the old embedded instruction.

The bundled `scripts/work_checkpoint.py` publishes and inspects this contract:
project/sequence/previous hash, latest batch, active/paused/parked/completed state,
effective policy edition/version/source revision/skill digest, separate executor
identity/version/revision, pinned project contract/ledger/report, original pending
attempt references, remaining obligations, cumulative counters and fixed limits.
It checks actual bytes, rejects stale writers, regressions, overwritten contracts,
loaded-policy conflicts and completed states with open work. Source adoption is
recorded separately and requires quiescent attempts; resuming a paused/parked
project requires a fresh retained scoped instruction, checked against the complete
immutable checkpoint history so clearing a field cannot reuse old authority.
Those records describe
existing authorization; a JSON field cannot grant it.

Removing an attempt or obligation requires a pinned `transition_ref` (otherwise
null). Its version-1 packet binds `previous_ref`, `review_ref`, exact
`closed_attempts` entries (`attempt_ref`, terminal `outcome`, `receipt_ref`) and
`closed_obligations` entries (`obligation`, nonempty `evidence_refs`). The writer
must independently reconcile actual controller/native terminal receipts and
review the closure; schema/hash checks alone do not authenticate their contents.
Cancellation can close requested work without supporting a scientific success.
Each transition binds its exact predecessor. On a later checkpoint with no
closures, set `transition_ref` to null; do not carry forward the old transition.

On inspection every current dependency must match. Publishing a successor checks
old immutable checkpoint identity/history and all new dependency bytes, allowing
an append-only ledger to advance without accepting its obsolete hash as current.
Archive versioned evidence before overwriting mutable working files; the checker
does not recreate lost original evidence or make stale historical claims valid.

```bash
python3 scripts/work_checkpoint.py --root /actual/project inspect
python3 scripts/work_checkpoint.py --root /actual/project inspect --expected-batch B15
python3 scripts/work_checkpoint.py --root /actual/project inspect --expected-policy loaded-policy.json
python3 scripts/work_checkpoint.py --root /actual/project publish next-checkpoint.json --expected-ref previous-checkpoint-ref.json
```

Run these via the actual installed/pinned script path. `--expected-ref` contains
the previously inspected `checkpoint_ref` object; omit only on first publication.
Construct the manifest from real records, not example hashes. Unix publication
uses one writer lock, immutable snapshots, atomic pointer update and exact readback.
`may_continue` means only the recorded state is active: verify current authority,
live attempts, controller budget and scientific admission before any dispatch.
Inspection does not activate a Work task, scheduler, research process or service.
