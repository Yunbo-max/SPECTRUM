"""Optional bounded child-work bookkeeping for the actual active Chat host.

No agent SDK, scheduler, execution, authority authentication, or scientific credit.
The parent is the sole writer. Host receipts must come from real tool calls.
"""
from __future__ import annotations

import copy
from datetime import datetime, timezone, timedelta
import hashlib
import math
from pathlib import Path
import uuid

LIVE = {'dispatching', 'running', 'partial', 'unknown'}
TERMINAL = {'completed', 'failed', 'cancelled'}
ROLES = {'source', 'implement', 'experiment', 'review'}
PACKET_FIELDS = {'id', 'role', 'action', 'acceptance', 'input_refs', 'output_paths',
                 'reserve', 'deadline_seconds', 'max_continuations', 'resource_ids',
                 'job_ids', 'review_of'}


def _now():
    return datetime.now(timezone.utc)


def _time(value):
    try:
        moment = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if moment.tzinfo is None:
            raise ValueError('timezone required')
        return moment
    except (TypeError, AttributeError, ValueError) as error:
        raise ValueError('timezone-qualified observation time required') from error


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + ' required')
    return value


def _number(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
        raise ValueError('finite nonnegative ' + label + ' required')
    return value


def _ids(value, label, *, nonempty=False):
    if not isinstance(value, list) or (nonempty and not value):
        raise ValueError(label + ' list required')
    for item in value:
        _text(item, label)
    if len(set(value)) != len(value):
        raise ValueError('duplicate ' + label)
    return value


def _path(root, name):
    path = Path(_text(name, 'relative output path'))
    if path.is_absolute() or '..' in path.parts or path == Path('.'):
        raise ValueError('output paths must be nonempty project-relative paths')
    candidate = root / path
    if any(part.is_symlink() for part in [candidate, *candidate.parents] if part != root.parent):
        raise ValueError('symlink output aliases are not allowed')
    if not candidate.resolve().is_relative_to(root.resolve()):
        raise ValueError('output path escapes project')
    if candidate.exists() and not candidate.is_file():
        raise ValueError('declare exact output files, not directories')
    return candidate.resolve()


def _overlap(a, b):
    return a == b or a in b.parents or b in a.parents


def _refs(root, refs, read_ref, *, nonempty=False):
    if not isinstance(refs, list) or (nonempty and not refs):
        raise ValueError('evidence refs required')
    for ref in refs:
        read_ref(root, ref)


def _amounts(value, units, label):
    if not isinstance(value, dict) or set(value) != set(units):
        raise ValueError(label + ' must cover exactly the declared budget units')
    for unit, amount in value.items():
        _number(amount, label + ':' + unit)
    return value


def _pins(root, current, read_ref):
    read_ref(root, current['procedure']['ref'])
    _refs(root, current['input_refs'], read_ref)
    _refs(root, current.get('dependency_evidence_refs', []), read_ref)


def _invalid_pins(root, current, read_ref):
    invalid = []
    for ref in [current['procedure']['ref']] + current['input_refs'] + current.get('dependency_evidence_refs', []):
        try:
            read_ref(root, ref)
        except (OSError, ValueError) as error:
            invalid.append(dict(ref=copy.deepcopy(ref), reason=str(error)))
    return invalid


def _protected_evidence(root, state, read_ref):
    """Protect both saved refs and their bounded, already-existing receipt graph."""
    paths, seen, pending = set(), set(), [state]
    while pending:
        item = pending.pop()
        if isinstance(item, list):
            pending.extend(item)
        elif isinstance(item, dict):
            if isinstance(item.get('path'), str) and isinstance(item.get('sha256'), str):
                key = (item['path'], item['sha256'])
                paths.add((root / item['path']).resolve())
                if key not in seen:
                    seen.add(key)
                    if len(seen) > 2048:
                        raise ValueError('bounded team evidence graph exceeded; split the parent task')
                    try:
                        pending.append(read_ref(root, item, as_json=True))
                    except (OSError, ValueError):
                        pass  # Text refs/invalid history still own their exact paths.
            else:
                pending.extend(item.values())
    return paths


def capability(root, state, read_ref):
    reference = state.get('team_capability_ref')
    if not reference:
        return None
    observed = read_ref(root, reference, as_json=True)
    if observed.get('kind') != 'chat-team-capability':
        raise ValueError('host capability receipt kind mismatch')
    _text(observed.get('session_id'), 'host session identity')
    _text(observed.get('parent_agent_id'), 'parent agent identity')
    read_ref(root, observed.get('source_ref'))
    start, expiry, now = _time(observed.get('observed_at')), _time(observed.get('expires_at')), _now()
    if not start <= now < expiry or (expiry - start).total_seconds() > 3600:
        raise ValueError('stale or invalid host capability observation')
    flags = observed.get('capabilities')
    if not isinstance(flags, dict) or any(type(flags.get(k)) is not bool for k in ('spawn', 'observe', 'continue')):
        raise ValueError('actual spawn/observe/continue capability observations required')
    if not (flags['spawn'] and flags['observe']):
        return observed
    capacity = observed.get('max_active_agents')
    active = _ids(observed.get('active_agent_ids'), 'active agent identities', nonempty=True)
    if type(capacity) is not int or capacity < 1 or len(active) > capacity or observed['parent_agent_id'] not in active:
        raise ValueError('invalid host capacity/inventory')
    return observed


def _available(observation, team):
    if not observation or not all(observation['capabilities'][key] for key in ('spawn', 'observe')):
        return 0
    known = set(observation['active_agent_ids'])
    unlisted = sum(1 for child in team.get('children', []) if child['status'] in LIVE
                   and child.get('agent_id') not in known)
    return max(0, observation['max_active_agents'] - len(known) - unlisted)


def _child(team, child_id):
    found = next((c for c in team['children'] if c['id'] == child_id), None)
    if found is None:
        raise ValueError('unknown child identity')
    return found


def _current(state, event):
    current = state.get('current_attempt')
    if not current or event.get('attempt_id') != current['id']:
        raise ValueError('current parent attempt binding required')
    return current


def _host_receipt(root, current, team, child, reference, read_ref, *, terminal=False):
    receipt = read_ref(root, reference, as_json=True)
    expected = dict(kind='chat-team-operation', attempt_id=current['id'], child_id=child['id'],
                    dispatch_token=child['dispatch_token'], session_id=team['session_id'])
    if any(receipt.get(k) != v for k, v in expected.items()):
        raise ValueError('host operation receipt binding mismatch')
    read_ref(root, receipt.get('source_ref'))
    observed = _time(receipt.get('observed_at'))
    if observed < _time(child['prepared_at']) or observed > _now() + timedelta(seconds=1):
        raise ValueError('stale host operation observation')
    if child.get('last_observed_at') and observed < _time(child['last_observed_at']):
        raise ValueError('host observation moved backwards')
    if child.get('agent_id') and receipt.get('agent_id') != child['agent_id']:
        raise ValueError('host agent identity mismatch')
    if terminal and receipt.get('state') not in {'completed', 'failed', 'cancelled', 'not_started'}:
        raise ValueError('actual terminal host observation required before settlement')
    return receipt


def _held(state, team):
    units = state['budget'].get('limits', {})
    held = dict(team['parent_reserve'])
    for child in team['children']:
        if child['id'] in team['accounted_child_ids']:
            continue
        amounts = child['actual_usage'] if child['status'] in TERMINAL else child['reserve']
        for unit in units:
            if unit == 'wall_seconds':
                held[unit] = max(held[unit], amounts[unit])
            else:
                held[unit] += amounts[unit]
    return held


def _wall_floor(state, team, observed_at=None):
    if 'wall_seconds' not in team['parent_reserve']:
        return 0
    elapsed = max(0, ((observed_at or _now()) - _time(team['started_at'])).total_seconds())
    return max([state['usage']['totals']['wall_seconds'], team['baseline_usage']['wall_seconds'] + elapsed]
               + [c['wall_usage_baseline'] + c['actual_usage']['wall_seconds']
                  for c in team['children'] if c['status'] in TERMINAL])


def _admit_budget(state, team, reserve):
    limits = state['budget'].get('limits', {})
    _amounts(reserve, limits, 'reservation')
    held = _held(state, team)
    for unit, limit in limits.items():
        total = state['usage']['totals'].get(unit)
        if total is None:
            raise ValueError('actual cumulative usage observation required')
        if unit == 'wall_seconds':
            total = _wall_floor(state, team)
            parent_remaining = max(0, team['baseline_usage'][unit] + team['parent_reserve'][unit] - total)
            child_remaining = [max(0, c['wall_usage_baseline'] + c['reserve'][unit] - total)
                               for c in team['children'] if c['status'] not in TERMINAL]
            demand = max([reserve[unit], parent_remaining] + child_remaining)
        else:
            demand = held[unit] + reserve[unit]
        if total + demand > limit:
            raise ValueError('shared remaining budget cannot cover child and parent reservations')


def _review_targets(root, team, packet, read_ref):
    targets = packet.get('review_of', [])
    _ids(targets, 'review targets', nonempty=packet['role'] == 'review')
    if packet['role'] != 'review' and targets:
        raise ValueError('only review packets name review targets')
    agents = []
    for target in targets:
        producer = _child(team, target)
        if producer['status'] != 'completed' or not producer.get('agent_id'):
            raise ValueError('review requires completed pinned producer outputs')
        result = read_ref(root, producer['result_ref'], as_json=True)
        _refs(root, result['output_refs'], read_ref, nonempty=True)
        if any(ref not in packet['input_refs'] for ref in result['output_refs']):
            raise ValueError('review inputs must pin every reviewed producer output')
        agents.append(producer['agent_id'])
    return agents


def _result(root, current, team, child, reference, read_ref):
    result = read_ref(root, reference, as_json=True)
    expected = dict(kind='chat-child-result', attempt_id=current['id'], child_id=child['id'],
        candidate_id=current['candidate_id'], procedure=current['procedure'],
        input_refs=child['input_refs'], dispatch_token=child['dispatch_token'])
    if any(result.get(k) != v for k, v in expected.items()):
        raise ValueError('child result differs from immutable parent/packet pins')
    outcome = result.get('outcome')
    if outcome not in TERMINAL:
        raise ValueError('child outcome must be completed, failed or cancelled')
    receipt = _host_receipt(root, current, team, child, result.get('operation_ref'), read_ref, terminal=True)
    if not child.get('agent_id'):
        if receipt['state'] != 'not_started' or receipt.get('agent_id') is not None or outcome != 'cancelled':
            raise ValueError('unbound dispatch needs observed not_started cancellation')
    elif result.get('agent_id') != child['agent_id']:
        raise ValueError('child result agent identity mismatch')
    if outcome == 'completed' and receipt['state'] != 'completed':
        raise ValueError('completed child requires completed host receipt')
    if child['role'] == 'review' and child.get('agent_id') in child['producer_agent_ids']:
        raise ValueError('producer cannot independently review its own output')
    if outcome == 'completed':
        _pins(root, current, read_ref)
        _refs(root, child['input_refs'], read_ref)
    _refs(root, result.get('raw_evidence'), read_ref, nonempty=True)
    outputs = result.get('output_refs')
    _refs(root, outputs, read_ref, nonempty=outcome == 'completed')
    for ref in outputs:
        if ref not in result['raw_evidence'] or ref['path'] not in child['output_paths']:
            raise ValueError('child outputs must be owned files attached to raw evidence')
        _path(root, ref['path'])
        if child['output_before'].get(ref['path']) == ref['sha256']:
            raise ValueError('old unchanged file cannot be a fresh child output')
    _amounts(result.get('actual_usage'), team['parent_reserve'], 'actual child usage')
    read_ref(root, result.get('usage_ref'))
    if child['role'] == 'experiment':
        job_refs = result.get('job_receipts')
        _refs(root, job_refs, read_ref, nonempty=True)
        jobs = {}
        for job_ref in job_refs:
            job = read_ref(root, job_ref, as_json=True)
            expected_job = dict(kind='chat-team-job-receipt', attempt_id=current['id'], child_id=child['id'],
                contract_ref=current['experiment_contract_ref'], dispatch_token=child['dispatch_token'],
                host_id=child['experiment_host_id'])
            if any(job.get(k) != v for k, v in expected_job.items()):
                raise ValueError('actual experiment operation binding mismatch')
            job_id = job.get('job_id')
            if job_id not in child['job_ids'] or job_id in jobs:
                raise ValueError('unknown or duplicate experiment operation receipt')
            if job.get('state') not in TERMINAL | {'not_started'}:
                raise ValueError('actual experiment jobs must be terminal before resources release')
            if job['state'] != 'not_started':
                _text(job.get('execution_id'), 'actual experiment execution identity')
            job_observed = _time(job.get('observed_at'))
            if not _time(child['prepared_at']) <= job_observed <= _now():
                raise ValueError('stale or future experiment terminal observation')
            read_ref(root, job.get('source_ref'))
            jobs[job_id] = job
        if set(jobs) != set(child['job_ids']):
            raise ValueError('retain terminal observations for every delegated experiment job')
    return result, receipt


def assert_joined(root, current, read_ref, *, tolerate_invalid=False):
    team = current.get('team')
    if not team:
        return []
    if any(child['status'] not in TERMINAL for child in team['children']):
        raise ValueError('unresolved child work requires observation/reconciliation before parent settlement or replay')
    if team['parent_reserve'] and set(team['accounted_child_ids']) != {c['id'] for c in team['children']}:
        raise ValueError('settled child usage must be included in cumulative usage before parent settlement')
    refs = []
    invalid = []
    for child in team['children']:
        try:
            _result(root, current, team, child, child['result_ref'], read_ref)
        except (OSError, ValueError) as error:
            if not tolerate_invalid:
                raise
            invalid.append(dict(child_id=child['id'], result_ref=child['result_ref'], reason=str(error)))
        refs.append(child['result_ref'])
    if tolerate_invalid:
        team['invalidated_child_evidence'] = invalid
    return refs


def summary(root, state, read_ref):
    current = state.get('current_attempt') or {}
    team = current.get('team')
    if not team:
        return None
    try:
        observed = capability(root, state, read_ref)
        slots = _available(observed, team)
        capability_reason = None
    except (OSError, ValueError) as error:
        slots, capability_reason = 0, str(error)
    pending = [dict(child_id=c['id'], status=c['status'], agent_id=c.get('agent_id'),
                    dispatch_token=c['dispatch_token'], next_action=c.get('next_action'))
               for c in team['children'] if c['status'] not in TERMINAL]
    return dict(kind='parallel', attempt_id=current['id'], available_slots=slots,
        capability_reason=capability_reason, children=pending,
        unaccounted_child_ids=[c['id'] for c in team['children'] if team['parent_reserve'] and c['status'] in TERMINAL
                              and c['id'] not in team['accounted_child_ids']],
        action='Observe/reconcile existing child identities; integrate verified results with the parent')


def apply(root, state, event, read_ref, *, protected_paths=(), experiment_admission=None):
    """Mutate only the parent's in-memory CAS state; never invoke host tools."""
    op = event['op']
    if op == 'team_capability':
        reference = event.get('observation_ref')
        state['team_capability_ref'] = reference
        observation = capability(root, state, read_ref)
        current = state.get('current_attempt') or {}
        team = current.get('team')
        if team and (observation['session_id'] != team['session_id']
                     or observation['parent_agent_id'] != team['parent_agent_id']):
            raise ValueError('reconcile original host session; do not switch a live team to another host')
        return
    current = _current(state, event)
    if op in {'team_start', 'team_prepare', 'team_continue'}:
        _pins(root, current, read_ref)
    if op == 'team_start':
        if current.get('team'):
            raise ValueError('team already configured; bounds cannot reset')
        observation = capability(root, state, read_ref)
        if not observation or not all(observation['capabilities'][k] for k in ('spawn', 'observe')):
            raise ValueError('host subagents unavailable; continue serially')
        config = event.get('config')
        if not isinstance(config, dict):
            raise ValueError('team config required')
        read_ref(root, config.get('source_ref'))
        count = config.get('max_children')
        if type(count) is not int or count < 1:
            raise ValueError('finite positive max_children required')
        seconds = _number(config.get('deadline_seconds'), 'team deadline')
        if seconds <= 0:
            raise ValueError('positive team deadline required')
        reserve = copy.deepcopy(config.get('parent_reserve'))
        _amounts(reserve, state['budget'].get('limits', {}), 'parent reservation')
        if 'wall_seconds' in reserve and reserve['wall_seconds'] <= 0:
            raise ValueError('positive parent walltime reservation required')
        paths = _ids(config.get('parent_output_paths', []), 'parent output paths')
        for name in paths:
            _path(root, name)
        team = dict(session_id=observation['session_id'], parent_agent_id=observation['parent_agent_id'],
            source_ref=config['source_ref'], max_children=count, parent_reserve=reserve,
            parent_output_paths=paths, parent_resource_ids=_ids(config.get('parent_resource_ids', []), 'parent resource IDs'),
            started_at=_now().isoformat(), deadline_at=(_now() + timedelta(seconds=seconds)).isoformat(),
            baseline_usage=copy.deepcopy(state['usage']['totals']), accounted_child_ids=[], children=[])
        _admit_budget(state, team, {k: 0 for k in reserve})
        current['team'] = team
        return
    team = current.get('team')
    if not team:
        raise ValueError('configure a bounded team first')
    if op == 'team_prepare':
        observation = capability(root, state, read_ref)
        if _available(observation, team) <= 0:
            raise ValueError('no observed free host slot; wait or continue parent work')
        if _now() >= _time(team['deadline_at']) or len(team['children']) >= team['max_children']:
            raise ValueError('finite team dispatch allowance exhausted')
        packet = copy.deepcopy(event.get('packet'))
        if not isinstance(packet, dict):
            raise ValueError('child packet required')
        if set(packet) - PACKET_FIELDS:
            raise ValueError('unknown/internal child packet fields are forbidden')
        child_id = _text(packet.get('id'), 'child identity')
        if any(c['id'] == child_id for c in team['children']):
            raise ValueError('duplicate child dispatch; reconcile the saved operation')
        if packet.get('role') not in ROLES:
            raise ValueError('unsupported child role')
        _text(packet.get('action'), 'child action')
        _text(packet.get('acceptance'), 'child acceptance condition')
        refs = packet.get('input_refs')
        _refs(root, refs, read_ref)
        allowed = current['input_refs'] + current.get('dependency_evidence_refs', [])
        for c in team['children']:
            if c['status'] == 'completed':
                result = read_ref(root, c['result_ref'], as_json=True)
                allowed += result['output_refs'] + [c['result_ref']]
        if any(ref not in allowed for ref in refs):
            raise ValueError('child inputs must be pinned parent inputs or settled child outputs')
        output_paths = _ids(packet.get('output_paths'), 'exclusive output paths', nonempty=True)
        claimed = [_path(root, name) for name in team['parent_output_paths']]
        claimed += [_path(root, name) for c in team['children'] for name in c['output_paths']]
        protected = [Path(p).resolve() for p in protected_paths]
        protected += list(_protected_evidence(root, state, read_ref))
        protected += [(root / r['path']).resolve() for r in allowed + [current['procedure']['ref']]]
        before = {}
        for name in output_paths:
            path = _path(root, name)
            if any(path.parent == Path(p).parent and path.name.startswith(Path(p).name + '.') for p in protected_paths):
                raise ValueError('checkpoint lock/temporary namespace is parent-owned')
            if any(_overlap(path, other) for other in claimed + protected):
                raise ValueError('child output ownership overlaps another writer or pinned input')
            claimed.append(path)
            before[name] = hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
        resources = _ids(packet.get('resource_ids', []), 'resource IDs')
        jobs = _ids(packet.get('job_ids', []), 'experiment job IDs')
        experiment_host_id = None
        if packet['role'] == 'experiment':
            if (current.get('kind') != 'research_experiment' or current.get('experiment_phase') != 'confirmation'
                    or len(jobs) != 1 or not set(jobs) <= set(current.get('experiment_job_ids', []))):
                raise ValueError('experiment children need one pinned confirmation job; diagnostics stay with the parent')
            if experiment_admission is None:
                raise ValueError('real current-host experiment admission is unavailable')
            experiment_admission(dict(current, experiment_job_ids=jobs))
            contract = read_ref(root, current['experiment_contract_ref'], as_json=True)
            job = next(j for j in contract['jobs'] if j['id'] == jobs[0])
            experiment_host_id = _text(job.get('host_id'), 'contracted experiment host')
            resources = list(dict.fromkeys(resources + ['experiment-host:' + experiment_host_id]))
            for unit in ('wall_seconds', 'gpu_seconds', 'cost'):
                if packet.get('reserve', {}).get(unit, -1) < job['estimate'][unit]:
                    raise ValueError('child reservation cannot understate the admitted experiment estimate')
        occupied = set(team['parent_resource_ids'])
        used_jobs = set()
        for c in team['children']:
            if c['status'] not in TERMINAL:
                occupied.update(c['resource_ids'])
            used_jobs.update(c['job_ids'])
        if occupied.intersection(resources) or used_jobs.intersection(jobs):
            raise ValueError('resource/device or experiment job already owned')
        if packet['role'] != 'experiment' and jobs:
            raise ValueError('only experiment children own experiment jobs')
        _admit_budget(state, team, packet.get('reserve'))
        deadline = _number(packet.get('deadline_seconds'), 'child deadline')
        if deadline <= 0 or _now() + timedelta(seconds=deadline) > _time(team['deadline_at']):
            raise ValueError('child deadline exceeds remaining team walltime')
        if 'wall_seconds' in packet['reserve'] and deadline > packet['reserve']['wall_seconds']:
            raise ValueError('child deadline exceeds its walltime reservation')
        continuations = packet.get('max_continuations', 0)
        if type(continuations) is not int or continuations < 0:
            raise ValueError('finite nonnegative child continuation allowance required')
        producer_ids = _review_targets(root, team, packet, read_ref)
        now = _now().isoformat()
        packet.update(status='dispatching', dispatch_token=uuid.uuid4().hex, agent_id=None,
            prepared_at=now, deadline_at=(_now() + timedelta(seconds=deadline)).isoformat(),
            candidate_id=current['candidate_id'], parent_attempt_id=current['id'],
            procedure=copy.deepcopy(current['procedure']), output_before=before,
            producer_agent_ids=producer_ids, resource_ids=resources, job_ids=jobs,
            experiment_host_id=experiment_host_id,
            wall_usage_baseline=_wall_floor(state, team),
            max_continuations=continuations, continuations=0, dispatch_history=[])
        team['children'].append(packet)
        return
    if op == 'team_usage':
        totals = event.get('totals')
        _amounts(totals, team['parent_reserve'], 'cumulative usage')
        ids = _ids(event.get('accounted_child_ids'), 'accounted child IDs')
        if not set(team['accounted_child_ids']) <= set(ids):
            raise ValueError('accounted usage cannot reset')
        children = [_child(team, ident) for ident in ids]
        if any(c['status'] not in TERMINAL for c in children):
            raise ValueError('unknown or live child usage cannot release its reservation')
        receipt = read_ref(root, event.get('receipt_ref'), as_json=True)
        expected = dict(kind='chat-team-usage', attempt_id=current['id'], totals=totals, accounted_child_ids=ids)
        if any(receipt.get(k) != v for k, v in expected.items()):
            raise ValueError('cumulative usage receipt binding mismatch')
        read_ref(root, receipt.get('source_ref'))
        observed_at = _time(receipt.get('observed_at'))
        previous_time = _time(team.get('usage_observed_at', team['started_at']))
        if not previous_time <= observed_at <= _now():
            raise ValueError('cumulative usage observation is stale or future-dated')
        if any(observed_at < _time(c['last_observed_at']) for c in children):
            raise ValueError('cumulative usage observation predates accounted child completion')
        for unit, amount in totals.items():
            actual = [c['actual_usage'][unit] for c in children]
            if unit == 'wall_seconds':
                floor = _wall_floor(state, team, observed_at)
            else:
                floor = max(state['usage']['totals'][unit], team['baseline_usage'][unit] + sum(actual))
            if amount < floor:
                raise ValueError('cumulative usage omits settled child work or decreases')
        team['accounted_child_ids'] = ids
        team['usage_ref'] = event['receipt_ref']
        team['usage_observed_at'] = receipt['observed_at']
        state['usage'] = dict(totals=totals, receipt_ref=event['receipt_ref'],
                              observed_attempt_ids=[a['id'] for a in state['attempts']])
        return
    child = _child(team, event.get('child_id'))
    if child['status'] in TERMINAL:
        raise ValueError('terminal child cannot dispatch, replay or settle again')
    if op == 'team_bind':
        if child['status'] != 'dispatching' or event.get('dispatch_token') != child['dispatch_token']:
            raise ValueError('bind only the saved dispatch intent/token')
        receipt = _host_receipt(root, current, team, child, event.get('receipt_ref'), read_ref)
        if receipt.get('state') not in {'running', 'queued'}:
            raise ValueError('actual acknowledged spawn/continuation receipt required')
        agent_id = _text(receipt.get('agent_id'), 'actual child agent identity')
        if agent_id == team['parent_agent_id'] or agent_id in child['producer_agent_ids']:
            raise ValueError('child/reviewer must be a distinct actual host agent')
        if any(c['id'] != child['id'] and c.get('agent_id') == agent_id and c['status'] in LIVE for c in team['children']):
            raise ValueError('host agent already owns live child work')
        child.update(agent_id=agent_id, status='running', operation_ref=event['receipt_ref'],
                     last_observed_at=receipt['observed_at'])
    elif op == 'team_observe':
        receipt = _host_receipt(root, current, team, child, event.get('receipt_ref'), read_ref)
        status = receipt.get('state')
        if status not in {'running', 'queued', 'partial', 'unknown', 'completed', 'failed', 'cancelled', 'not_started'}:
            raise ValueError('unsupported actual child observation')
        if status not in {'unknown', 'not_started'} and not receipt.get('agent_id'):
            raise ValueError('anonymous operation remains unknown; actual agent identity required')
        if (status in {'running', 'queued', 'partial', 'completed', 'failed', 'cancelled'}
                and not child.get('agent_id') and receipt.get('agent_id')):
            agent_id = _text(receipt.get('agent_id'), 'reconciled agent identity')
            if agent_id == team['parent_agent_id'] or agent_id in child['producer_agent_ids']:
                raise ValueError('reconciled child must have independent host identity')
            if any(c['id'] != child['id'] and c.get('agent_id') == agent_id and c['status'] in LIVE for c in team['children']):
                raise ValueError('reconciled agent already owns live child work')
            child['agent_id'] = agent_id
        next_status = 'running' if status == 'queued' else ('stopped' if status in TERMINAL | {'not_started'} else status)
        if next_status == 'partial':
            _refs(root, receipt.get('partial_refs'), read_ref, nonempty=True)
            if any(ref['path'] not in child['output_paths'] for ref in receipt['partial_refs']):
                raise ValueError('partial artifacts must stay within declared child output ownership')
            child['partial_refs'] = receipt['partial_refs']
            child['next_action'] = _text(receipt.get('next_action'), 'partial continuation action')
        child.update(status=next_status, operation_ref=event['receipt_ref'], last_observed_at=receipt['observed_at'])
    elif op == 'team_continue':
        observation = capability(root, state, read_ref)
        if child['status'] != 'partial' or not observation['capabilities']['continue']:
            raise ValueError('only acknowledged partial work with actual continuation capability can continue')
        _text(child.get('agent_id'), 'acknowledged original child identity')
        siblings = dict(team, children=[c for c in team['children'] if c['id'] != child['id']])
        if child['agent_id'] not in observation['active_agent_ids'] and _available(observation, siblings) <= 0:
            raise ValueError('no observed slot to continue the acknowledged partial child')
        if child['continuations'] >= child['max_continuations'] or _now() >= _time(child['deadline_at']):
            raise ValueError('finite continuation allowance exhausted')
        _refs(root, child['input_refs'], read_ref)
        _refs(root, child.get('partial_refs', []), read_ref, nonempty=True)
        _admit_budget(state, team, {k: 0 for k in team['parent_reserve']})
        child['dispatch_history'].append(dict(dispatch_token=child['dispatch_token'], operation_ref=child.get('operation_ref')))
        child.update(status='dispatching', dispatch_token=uuid.uuid4().hex, prepared_at=_now().isoformat(),
                     continuations=child['continuations'] + 1)
    elif op == 'team_result':
        result, receipt = _result(root, current, team, child, event.get('result_ref'), read_ref)
        child.update(status=result['outcome'], result_ref=event['result_ref'], actual_usage=result['actual_usage'],
                     operation_ref=result['operation_ref'], last_observed_at=receipt['observed_at'],
                     invalidated_parent_pins=_invalid_pins(root, current, read_ref))
    else:
        raise ValueError('unknown team event')
