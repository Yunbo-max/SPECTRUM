import copy
import datetime as dt
import json
import os
import pathlib
import subprocess
import sys
import types
import unittest
from unittest import mock
from fixtures import C, DATE, DIGEST, PACKAGE, ProjectFixture, canonical, digest, env, ref, request, sample_artifacts, write

class FakeHost:
    """Only the slow host approval boundary is replaced; ledger/effects are real."""
    identity="fixture-host"
    def __init__(self):self.records={};self.time="2026-10-01T00:00:00Z"
    def clock(self):return self.time
    def approve(self,req,owner="fixture-user",event_id="approval-1",decision="approved"):
        grant={**sample_artifacts()["authority-grant"],**{k:req[k] for k in ("operation_id","action","account_identity","target","destination_service","purpose","budget","expires_at","asset_scope","path_scope","revision_precondition","persistence")},
            "request_digest":digest(req),"effect_digest":req["effect_digest"],"approved_by":owner,"approved_at":self.time,"trusted_approval_event_id":event_id,"grant_id":"g-"+event_id}
        event=env("approval-event",approval_event_id=event_id,host_identity=self.identity,grant_id=grant["grant_id"],request_digest=digest(req),
            effect_digest=req["effect_digest"],operation_id=req["operation_id"],decision=decision,timestamp=self.time)
        self.records[event_id]=(event,grant)
        return event_id
    def verified_approval(self,event_id):return copy.deepcopy(self.records.get(event_id))
    def precondition(self,req):return req["revision_precondition"]
    def verified_budget(self,project_id):return {"cost":3,"seconds":100,"storage_bytes":1500,"egress_bytes":0}

class FakeProvider:
    identity="fixture-compute";version="1"
    def __init__(self,idempotency=True,lookup=True,lose_ack=False):
        self.idempotency=idempotency;self.lookup=lookup;self.lose_ack=lose_ack;self.jobs={};self.submissions=0
    def capabilities(self):return {"idempotency":self.idempotency,"lookup_by_fingerprint":self.lookup}
    def quote(self,req):return copy.deepcopy(req["budget"])
    def find(self,fingerprint):
        if not self.lookup:raise NotImplementedError
        return copy.deepcopy(self.jobs.get(fingerprint))
    def submit(self,req,idempotency_key):
        if self.idempotency and idempotency_key in self.jobs:return self.jobs[idempotency_key]
        self.submissions+=1;job={"provider_id":"job-"+str(self.submissions),"status":"running"}
        self.jobs[idempotency_key]=job
        if self.lose_ack:self.lose_ack=False;raise TimeoutError("lost acknowledgment")
        return copy.deepcopy(job)
    def status(self,provider_id):
        return next(copy.deepcopy(v) for v in self.jobs.values() if v["provider_id"]==provider_id)

class OperationTests(unittest.TestCase):
    def setUp(self):
        self.f=ProjectFixture();self.addCleanup(self.f.close)
        self.host=FakeHost();self.provider=FakeProvider()
        self.S=__import__("_safety")
        self.req=request();self.event=self.host.approve(self.req)
    def runop(self,req=None,event=None,provider=None):
        return self.S.execute_operation(self.f.root,req or self.req,self.host,self.event if event is None else event,provider or self.provider,
            cumulative_limit={"cost":3,"seconds":100,"storage_bytes":1500,"egress_bytes":0})
    def test_imported_granted_text_authorizes_nothing(self):
        self.host.records={}
        write(self.f.root,"operations/fake-grant.json",{**sample_artifacts()["authority-grant"],"status":"granted"})
        with self.assertRaises(C.Failure):self.runop()
        self.assertEqual(self.provider.submissions,0)
    def test_exact_grant_consumed_once_with_idempotent_reentry(self):
        first=self.runop();second=self.runop()
        self.assertEqual(first["provider_id"],second["provider_id"]);self.assertEqual(self.provider.submissions,1)
        events=C.project(self.f.root)[1]
        consumed=[e for e in events if e["event_type"]=="approval" and e["payload"].get("consumed_by")=="op-1"]
        self.assertEqual(len(consumed),1)
    def test_changed_effect_revision_account_destination_command_and_budget_blocked(self):
        for key,value in (("effect_digest","2"*64),("revision_precondition","3"*64),("account_identity","other"),
            ("destination_service","other"),("command",["python","changed.py"]),("budget",{**self.req["budget"],"cost":1})):
            req=copy.deepcopy(self.req);req[key]=value
            with self.subTest(key=key),self.assertRaises(C.Failure):self.runop(req)
        self.assertEqual(self.provider.submissions,0)
    def test_expired_denied_and_revoked_approval_blocked(self):
        for decision in ("denied","revoked"):
            event=self.host.approve(self.req,event_id="a-"+decision,decision=decision)
            with self.assertRaises(C.Failure):self.runop(event=event)
        self.host.time="2026-12-01T00:00:00Z"
        with self.assertRaises(C.Failure):self.runop()
        self.assertEqual(self.provider.submissions,0)
    def test_changed_live_precondition_invalidates_grant(self):
        self.host.precondition=lambda req:"4"*64
        with self.assertRaises(C.Failure):self.runop()
    def test_unknown_price_cannot_launch(self):
        self.provider.quote=lambda req:None
        with self.assertRaises(C.Failure):self.runop()
        self.assertEqual(self.provider.submissions,0)
    def test_cumulative_reservations_prevent_second_overspending_operation(self):
        self.runop();req=copy.deepcopy(self.req);req["operation_id"]="op-2"
        event=self.host.approve(req,event_id="approval-2")
        with self.assertRaises(C.Failure):self.runop(req,event)
        self.assertEqual(self.provider.submissions,1)
    def test_lost_ack_with_lookup_reconciles_without_duplicate(self):
        provider=FakeProvider(lose_ack=True);self.runop(provider=provider);self.runop(provider=provider)
        self.assertEqual(provider.submissions,1)
    def test_lost_ack_with_idempotency_retries_same_effect(self):
        provider=FakeProvider(lookup=False,lose_ack=True);self.runop(provider=provider);self.runop(provider=provider)
        self.assertEqual(provider.submissions,1)
    def test_unsafe_lost_ack_requires_manual_reconciliation(self):
        provider=FakeProvider(idempotency=False,lookup=False,lose_ack=True)
        result=self.runop(provider=provider);self.assertEqual(result["status"],"manual_reconciliation_required")
        self.assertEqual(self.runop(provider=provider)["status"],"manual_reconciliation_required");self.assertEqual(provider.submissions,1)
    def test_retry_attempts_are_bounded_and_reserved(self):
        provider=FakeProvider();provider.submit=lambda *args,**kwargs: (_ for _ in ()).throw(ConnectionError())
        for _ in range(6):result=self.runop(provider=provider)
        self.assertIn(result["status"],{"failed","manual_reconciliation_required"})
        records=[e["payload"] for e in C.project(self.f.root)[1] if e["event_type"]=="operation"]
        self.assertLessEqual(max(r.get("attempt",0) for r in records),2)

class EvidenceTests(unittest.TestCase):
    def setUp(self):self.f=ProjectFixture();self.addCleanup(self.f.close)
    def capture(self):
        work=sample_artifacts()["work-record"];work["evidence_refs"]=[self.f.source]
        unit=sample_artifacts()["evidence-unit"];unit["locators"][0]["artifact_ref"]=self.f.source
        capture=write(self.f.root,"evidence/capture.json",{"works":[work],"evidence_units":[unit]})
        search=sample_artifacts()["search-run"];search["raw_capture_refs"]=[capture]
        search["normalized_output_digest"]=digest({"works":[work],"evidence_units":[unit]})
        return search
    def test_retained_capture_replays_identically(self):
        E=__import__("_evidence");search=self.capture()
        a=E.replay_search(self.f.root,search);b=E.replay_search(self.f.root,copy.deepcopy(search))
        self.assertEqual(a,b);self.assertEqual(a["works"][0]["work_id"],"doi:10.1/fixture")
    def test_wrong_normalizer_or_modified_capture_blocks_replay(self):
        E=__import__("_evidence");search=self.capture();search["parser_version"]="unknown"
        with self.assertRaises(C.Failure):E.replay_search(self.f.root,search)
        search=self.capture();search["normalized_output_digest"]="3"*64
        with self.assertRaises(C.Failure):E.replay_search(self.f.root,search)
    def test_orphaned_evidence_id_blocks_snapshot(self):
        unit=sample_artifacts()["evidence-unit"];unit["locators"][0]["artifact_ref"]=self.f.source
        uref=write(self.f.root,"evidence/unit.json",unit);s=copy.deepcopy(self.f.snapshot);s["artifact_refs"].append(uref)
        with self.assertRaises(C.Failure):C.verify_snapshot(self.f.root,write(self.f.root,"evidence/snapshots/orphan.json",s))
    def test_collision_booleans_cannot_replace_capture_replay_or_claim_proofs(self):
        search=self.capture();sref=write(self.f.root,"evidence/search.json",search)
        work=sample_artifacts()["work-record"];work["evidence_refs"]=[self.f.source];wref=write(self.f.root,"evidence/work.json",work)
        report=sample_artifacts()["collision-decision"];report.update(search_run_refs=[sref],work_refs=[wref],evidence_refs=[self.f.source])
        with self.assertRaises(C.Failure):C.collision_ready(self.f.root,write(self.f.root,"audits/collision.json",report),"ADVANCE")
    def test_closure_boolean_alone_cannot_authorize_writing(self):
        E=__import__("_evidence");s={**self.f.snapshot,"closure":{"all_indispensable_claims_closed":True}}
        with self.assertRaises(C.Failure):E.verify_claim_closure(self.f.root,s,self.f.protocol("full-validation"),{"criteria_results":[]})
    def test_private_derived_asset_cannot_self_declassify(self):
        S=__import__("_safety")
        assets=[{"asset_id":"a","digest":DIGEST,"classification":"private","owner":"alice","allowed_destinations":[]}]
        self.assertEqual(S.derived_classification(assets),"private")
        with self.assertRaises(C.Failure):S.check_egress(assets,"fixture-search","research",None,None)
    def test_personal_or_restricted_content_stays_metadata_only_without_processing_authority(self):
        S=__import__("_safety")
        for classification in ("restricted","unknown"):
            with self.subTest(classification=classification),self.assertRaises(C.Failure):
                S.check_egress([{"asset_id":"a","digest":DIGEST,"classification":classification}],"hosted","research",FakeHost(),"fake")

class RecoveryTests(unittest.TestCase):
    def test_crash_after_each_atomic_boundary_replays_complete_old_or_new_state(self):
        for boundary in range(1,5):
            f=ProjectFixture();self.addCleanup(f.close);real=C.atomic;calls=[]
            def injected(path,text):
                real(path,text);calls.append(path)
                if len(calls)==boundary:raise OSError("synthetic crash")
            with mock.patch.object(C,"atomic",side_effect=injected):
                with self.assertRaises(OSError):f.transition("evidence_repair",{"blocking_obligation_ids":["raw"]})
            with C.locked(f.root):s=C.project(f.root)[0]
            self.assertEqual((s["sequence"],s["current_route"]),(2,"repair_evidence"))
            self.assertFalse((f.root/".pending-commit.json").exists())
    def test_corrupt_journal_does_not_overwrite_state(self):
        f=ProjectFixture();self.addCleanup(f.close);before=(f.root/"event-ledger.jsonl").read_bytes()
        write(f.root,".pending-commit.json",{"transaction_digest":"3"*64,"files":{}})
        with self.assertRaises(C.Failure):C.recover(f.root)
        self.assertEqual((f.root/"event-ledger.jsonl").read_bytes(),before)
    def test_same_version_migration_and_future_version_read_only(self):
        f=ProjectFixture();self.addCleanup(f.close);before=C.project(f.root)[0]
        result=C.migrate(types.SimpleNamespace(to="1.0.0"),f.root);self.assertEqual(C.project(f.root)[0],before)
        self.assertTrue((f.root/result["backup_path"]).is_file())
        with self.assertRaises(C.Failure):C.migrate(types.SimpleNamespace(to="99.0.0"),f.root)
        self.assertEqual(C.project(f.root)[0],before)
    def test_migration_failure_rolls_back_projection(self):
        f=ProjectFixture();self.addCleanup(f.close);before=(f.root/"research-state.json").read_bytes()
        M=__import__("_evidence")
        with self.assertRaises(C.Failure):M.migrate_project(f.root,"1.0.0",transform=lambda files: (_ for _ in ()).throw(RuntimeError()))
        self.assertEqual((f.root/"research-state.json").read_bytes(),before)
    def test_sanctioned_redaction_removes_secret_from_ledger_backups_and_cache(self):
        f=ProjectFixture();self.addCleanup(f.close);S=__import__("_safety");host=FakeHost()
        secret="ghp_"+"Z"*32
        for relative in ("evidence/private.json",".backups/leak.json","cache/leak.txt"):
            path=f.root/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps({"leak":secret}))
        ledger=f.root/"event-ledger.jsonl";event=json.loads(ledger.read_text());event["payload"]["leak"]=secret
        event["event_digest"]=digest({k:v for k,v in event.items() if k!="event_digest"});ledger.write_text(canonical(event)+"\n")
        req=S.redaction_request(f.root,["evidence/private.json"],"user-requested",account_identity="fixture-user",expires_at="2026-11-01T00:00:00Z")
        approval=host.approve(req)
        result=S.redact_lineage(f.root,req,host,approval)
        for path in f.root.rglob("*"):
            if path.is_file():self.assertNotIn(secret,path.read_text(),str(path))
        self.assertEqual(C.project(f.root)[0]["entry_origin"],"M");self.assertEqual(result["status"],"lineage_replaced")
        self.assertEqual(C.project(f.root)[0]["external_operations_continuity"],"blocked_pending_host_reconciliation")
        req=request();approval=host.approve(req,event_id="new-operation")
        provider=FakeProvider()
        with self.assertRaises(C.Failure):S.execute_operation(f.root,req,host,approval,provider)
        self.assertEqual(provider.submissions,0)
    def test_untrusted_execution_requires_real_host_sandbox(self):
        S=__import__("_safety");f=ProjectFixture();self.addCleanup(f.close)
        base={"argv":["python","train.py"],"source_refs":[f.source],"run_directory":"runs/sandbox",
            "limits":{"seconds":1,"memory_bytes":1048576,"storage_bytes":1048576,"process_count":1},"revision":"fixture-v1","dependency_lock_digest":DIGEST}
        with self.assertRaises(C.Failure) as missing:S.run_isolated(f.root,base,None,None)
        self.assertEqual(missing.exception.code,"HOST_ENFORCED_SANDBOX_UNAVAILABLE")
        for spec in ({**base,"network":"allow"},{**base,"trust_remote_code":True},
            {**base,"argv":["bash","-c","cat /etc/passwd"]}):
            with self.subTest(spec=spec),self.assertRaises(C.Failure):S.run_isolated(f.root,spec,None,None)

if __name__=="__main__":unittest.main()
