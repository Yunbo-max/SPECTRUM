# Object-first entry: runnable control example

This is a known algebra/control-flow fixture, NOT a new benchmark or a research result.
It creates a v4 inquiry with two competing predictions and no invented completed proof.
No model, paid service, scheduler or background job is started.

From the skill root:

```sh
python3 assets/examples/object-first/setup.py /tmp/object-first-empty
python3 scripts/research_reasoning.py --root /tmp/object-first-empty --decision decision.json
python3 scripts/research_reasoning.py --root /tmp/object-first-empty --task task.json
```

The generated `probe.py` uses `fractions.Fraction`; it can be run directly to inspect the
arithmetic. Such a direct run is not a host-bound research receipt. For the actual workflow,
adopt `decision.json` through Simple's `research_review` or Chat's `strategy_reasoning`,
submit the corresponding diagnostic task, and retain the host's terminal receipt. Chat
uses its existing `kind=action`/diagnostic intent with `claim_kind=investigation`, not the
Simple task envelope. Do not fabricate either host's state or receipt.

After execution, append a scoped observation (with that exact attempt/task/receipt) and a
successor decision. Only then dispatch the next tagged action. Before promoting any new
method, add a genuine mathematical_trace, adaptive_trajectory and research_quality record;
this arithmetic identity itself is not novel. The setup script refuses nonempty directories.
