# Downloadable ZIP when GitHub is unavailable

Use this fallback in all four editions when an authorized GitHub read or write
cannot complete: missing connector, network/service failure, rate limit, denied
access, or an upload/readback with an uncertain outcome. Apply it to research
projects and source maintenance. Keep GitHub as the selected destination; this
handoff does not authorize another cloud service, credential, host or repository.
Respect any restriction on the data itself; never export prohibited data to evade
a denied operation. Ordinary user-authorized local work can still be returned.

## Preserve and deliver now

1. Record the operation, observed error, UTC time when available, repository,
   branch, last verified commit, project/attempt identities and affected files.
   Mark remote synchronization `pending` when no write was sent or rejection is
   confirmed; mark it `unknown` when a write may have succeeded but its response
   or readback was lost. Use `verified` only after actual remote readback. Do not
   fabricate a current remote head or retry an uncertain write blindly.
2. Preserve the actual current files and checkpoint before ephemeral state can
   disappear. Use the last verified local snapshot when a fresh pull fails, with
   its age/provenance explicit. List unavailable inputs; never substitute guessed
   source or results. Continue only safe read-only or already admitted disjoint
   work with sufficient local inputs. Missing shared claims/fencing still leaves
   cooperation pending; a local ZIP does not confer coordination ownership.
3. Build a real ZIP on the authorized host without waiting indefinitely for
   GitHub or asking whether the user wants the fallback. Use a unique filename,
   such as `<project>-<edition>-<UTC>-checkpoint.zip`. Include:
   - `HANDOFF.md`: what completed, failed or remains unknown, the GitHub error,
     exact next action and restoration/reconciliation instructions;
   - a checkpoint preserving goal, adopted source/procedure, task/attempt IDs,
     human decisions, pauses/stops, cumulative budgets and unfinished work;
   - changed code/configuration plus available source and dependencies needed
     for the next action; include a patch and its exact base when appropriate;
   - actual results, ordinary `.log` files, commands, observed exit statuses and
     positive/negative/partial evidence, retaining their original scope;
   - `MANIFEST.json`: project/edition/source provenance, repository/branch,
     `github_sync` state, intended paths/patch base, pending files, and each
     payload file's relative path, byte size and SHA-256. Do not hash the manifest
     into itself; provide the final archive's SHA-256 separately.
   Keep relevant dot-directories containing project state, such as `.autopilot`,
   after reviewing their contents. Exclude credentials, private environment values,
   credential-bearing remotes, caches and unrelated files. Snapshot a live database
   only through a consistent export; do not copy an actively changing database or
   log and call it final. List every necessary excluded, missing or remote-only
   artifact with its known locator/hash and the resulting restoration limitation.
4. Open/test the ZIP, verify its members and payload hashes, and check that the
   next-step instructions match its contents. For a large handoff, use separately
   valid ZIPs with a shared index and explicit coverage instead of silently
   omitting evidence. Retain source data until a verified durable copy exists.
5. Make the verified ZIP available through the host's supported user download
   channel, persist it in that channel when available, and return a clickable file
   link, filename, size and SHA-256. Say clearly: "ZIP ready for download; GitHub
   synchronization pending/unknown." A local path or a promise to package later
   is insufficient. Do not claim that the user has downloaded it, that GitHub is
   updated, or that unattended continuation is active without the corresponding
   observation. Record archive creation, download availability, confirmed user
   download (if observed), and remote synchronization as separate states.

If the host cannot create or expose downloadable files, say exactly which
capability is missing and provide the most complete visible recovery checkpoint
possible. Do not invent a ZIP or link. Keep the unavailable delivery explicit.
If file delivery fails, preserve the real local archive and report that failure.

## Restore and reconcile

On a later authorized continuation, accept the uploaded ZIP or retained verified
copy, validate hashes and restore the same project/attempt identities, budgets,
pauses and source pins. If GitHub works again, pull its current state, reconcile
any unknown write by intended paths/hashes and parent identity, and preserve
concurrent changes. Do not replay completed experiments, force-push, duplicate a
commit already present, or treat a stale offline patch as current remote state.
Push only the reconciled outstanding changes with the expected current parent,
then read back bytes/hashes before marking remote synchronization `verified`.
If access remains unavailable, retain/update the downloadable checkpoint; avoid
repeated retries without new evidence. A download link does not itself supply a
cross-turn runner with durable readable input. Keep unattended continuation
blocked when its required checkpoint or coordination state cannot be restored,
while preserving safe work and the parent's unfinished goal. Never resume a
paused goal merely because storage recovered. Do not use GitHub Actions,
workflow runs or workflow_dispatch for any part of this fallback.
