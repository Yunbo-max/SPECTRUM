import copy
import datetime as dt
import json
import os
import pathlib
import subprocess
import sys
import types
import unittest
from unittest import mock
from fixtures import C, DATE, DIGEST, PACKAGE, ProjectFixture, canonical, digest, env, ref, sample_artifacts, write
from test_boundaries import FakeHost, FakeProvider
from ipcg_fixtures import ready_problem,importance

def primary_snapshot(f):
    work=copy.deepcopy(sample_artifacts()["work-record"]);work["evidence_refs"]=[f.source]
    unit=copy.deepcopy(sample_artifacts()["evidence-unit"]);unit["locators"][0]["artifact_ref"]=f.source
    wref=write(f.root,"evidence/work.json",work);uref=write(f.root,"evidence/unit.json",unit)
    snapshot=copy.deepcopy(f.snapshot);snapshot["artifact_refs"]=[f.source,wref,uref]
    return write(f.root,"evidence/snapshots/primary.json",snapshot)

def to_gate(f):
    ready_problem(f)
    sref=primary_snapshot(f)
    f.transition("update_evidence",{"claim_clarity":"C2_falsifiable","literature_state":"L2_primary_verified","evidence_snapshot_ref":sref},refs=[sref])
    f.transition("importance_decision",{"importance_decision_ref":importance(f)})
    f.transition("no_new_idea_needed")
    p=f.protocol(frozen=False);p["evidence_snapshot_ref"]=sref
    source=write(f.root,"protocol-input.json",p)
    with C.locked(f.root):result=C.freeze_gate(types.SimpleNamespace(protocol=str(f.root/source["path"]),gate="gate-a"),f.root)
    return C.verify_ref(f.root,result["protocol_ref"],"gate-a-protocol"),result["protocol_ref"]

def evaluate_persisted(f,p,pref,gate):
    runs,refs=f.runs(p)
    args=types.SimpleNamespace(protocol=str(f.root/pref["path"]),runs=str(f.root/"runs"/p["protocol_id"]),gate=gate,root=str(f.root))
    with C.locked(f.root):result=C.evaluate_command(args,f.root)
    return result,runs,refs

class WorkflowTests(unittest.TestCase):
    def setUp(self):self.f=ProjectFixture();self.addCleanup(self.f.close)
    def test_full_path_freezes_evidence_then_allows_sequential_writing(self):
        p,pref=to_gate(self.f);result,runs,refs=evaluate_persisted(self.f,p,pref,"gate-a")
        self.assertEqual(result["decision"]["outcome"],"PASS")
        self.f.transition("gate_a_PASS",{"decision_ref":result["decision_ref"]},refs=[result["decision_ref"]])
        full=self.f.protocol("full-validation",frozen=False)
        full["evidence_snapshot_ref"]=p["evidence_snapshot_ref"]
        full["protocol_id"]="full-p1";full["inventory_run_ids"]=["full-p1-r1-main","full-p1-r2-main"]
        source=write(self.f.root,"full-input.json",full)
        with C.locked(self.f.root):frozen=C.freeze_gate(types.SimpleNamespace(protocol=str(self.f.root/source["path"]),gate="full-validation"),self.f.root)
        full=C.verify_ref(self.f.root,frozen["protocol_ref"],"full-validation-protocol")
        result,runs,refs=evaluate_persisted(self.f,full,frozen["protocol_ref"],"full-validation")
        self.assertEqual(result["decision"]["outcome"],"PASS")
        # A fresh post-evaluation snapshot binds every bounded claim to retained runs.
        s=copy.deepcopy(self.f.snapshot);s["snapshot_id"]="writing-1";s["created_at"]=C.now()
        s["artifact_refs"]+=refs+[result["decision_ref"]]
        s["closure"]={"claims":[{"claim_id":"claim-1","status":"closed","unresolved_confounds":[],"criterion_ids":["effect"],"evidence_refs":refs}],
            "result_inventory_run_ids":sorted(r["run_id"] for r in runs),"decision_ref":result["decision_ref"]}
        sref=write(self.f.root,"evidence/snapshots/writing-1.json",s)
        self.f.transition("full_validation_PASS",{"decision_ref":result["decision_ref"],"evidence_snapshot_ref":sref},refs=[result["decision_ref"],sref])
        self.assertEqual(C.project(self.f.root)[0]["writing_state"],"evidence_frozen")
        for stage in ("planning","drafting","submission_lock"):
            self.f.transition("advance_writing",{"writing_state":stage},refs=[sref])
        final=C.project(self.f.root)[0]
        self.assertEqual((final["entry_origin"],final["lifecycle_phase"]),("M","submission_lock"))
        import _evidence as E
        handoff=copy.deepcopy(sample_artifacts()["handoff"]);handoff.update(evidence_snapshot_ref=sref,source_refs=refs)
        handoff["provenance"]["evidence_mode"]="prospective_confirmatory"
        handoff["stage"] = final["writing_state"]
        handoff["claim_cards"] = copy.deepcopy(full["claim_cards"])
        E.verify_handoff(self.f.root,handoff)
        hpath=write(self.f.root,"writing/handoff.json",handoff)
        command=[sys.executable,str(PACKAGE/"scripts/validate_artifact.py"),str(self.f.root/hpath["path"]),"--evidence-root",str(self.f.root)]
        checked=subprocess.run(command,capture_output=True,text=True)
        self.assertEqual(checked.returncode,0,checked.stdout)
        handoff["allowed_claims"].append("unsupported-scaling")
        with self.assertRaises(C.Failure):E.verify_handoff(self.f.root,handoff)
    def test_self_declared_evidence_upgrade_does_not_satisfy_audit(self):
        with self.assertRaises(C.Failure):self.f.transition("update_evidence",{"evidence_trust":"E3_audited","literature_state":"L3_current_snapshot"})
    def test_claim_closure_boolean_does_not_pass_full_transition(self):
        # Direct closure check exercises the same production check used by transition.
        import _evidence as E
        s=copy.deepcopy(self.f.snapshot);s["closure"]={"all_indispensable_claims_closed":True}
        with self.assertRaises(C.Failure):E.verify_claim_closure(self.f.root,s,self.f.protocol("full-validation"),{"criteria_results":[],"eligible_run_ids":[]})

    def closure_packet(self, optional=False):
        # Software-contract metadata only; this does not qualify a benchmark eval.
        protocol=self.f.protocol("full-validation")
        snapshot=copy.deepcopy(self.f.snapshot)
        runs, refs = self.f.runs(protocol)
        claim={"claim_id":"claim-1","status":"closed","unresolved_confounds":[],
            "criterion_ids":["effect"],"evidence_refs":refs}
        snapshot["artifact_refs"] += refs
        run_ids = sorted(r["run_id"] for r in runs)
        proof_refs = [r for run in runs for r in run["native_eval_receipts"].values()]
        snapshot["closure"]={"claims":[claim],"result_inventory_run_ids":run_ids}
        decision={"criteria_results":[{"criterion_id":"effect","passed":True,"run_ids":run_ids,"proof_refs":proof_refs}],
            "eligible_run_ids":run_ids,"run_manifest_refs":refs}
        if optional:
            protocol["claim_set"].append("claim-2")
            rule=copy.deepcopy(protocol["criteria"][0])
            rule.update(id="scope",claim_id="claim-2",indispensable=False)
            protocol["criteria"].append(rule)
            snapshot["claim_ids"].append("claim-2")
            snapshot["closure"]["claims"].append({**copy.deepcopy(claim),"claim_id":"claim-2","criterion_ids":["scope"]})
            decision["criteria_results"].append({"criterion_id":"scope","passed":True,"run_ids":run_ids,"proof_refs":proof_refs})
        return snapshot,protocol,decision

    def test_extra_closed_claim_cannot_enter_writing_closure(self):
        import _evidence as E
        snapshot,protocol,decision=self.closure_packet()
        snapshot["claim_ids"].append("claim-2")
        snapshot["closure"]["claims"].append({"claim_id":"claim-2","status":"closed"})
        with self.assertRaises(C.Failure) as caught:
            E.verify_claim_closure(self.f.root,snapshot,protocol,decision)
        self.assertEqual(caught.exception.code,"CLAIM_OUTSIDE_FROZEN_SCOPE")

    def test_optional_closed_claim_cannot_borrow_another_claim_criterion(self):
        import _evidence as E
        snapshot,protocol,decision=self.closure_packet(optional=True)
        snapshot["closure"]["claims"][1]["criterion_ids"]=["effect"]
        with self.assertRaises(C.Failure) as caught:
            E.verify_claim_closure(self.f.root,snapshot,protocol,decision)
        self.assertEqual(caught.exception.code,"CLAIM_CRITERION_CLOSURE_REQUIRED")

    def test_optional_closed_claim_requires_retained_evidence(self):
        import _evidence as E
        snapshot,protocol,decision=self.closure_packet(optional=True)
        snapshot["closure"]["claims"][1]["evidence_refs"]=[]
        with self.assertRaises(C.Failure) as caught:
            E.verify_claim_closure(self.f.root,snapshot,protocol,decision)
        self.assertEqual(caught.exception.code,"CLAIM_RAW_EVIDENCE_REQUIRED")

    def test_optional_closed_claim_with_failed_criterion_cannot_be_written(self):
        import _evidence as E
        snapshot,protocol,decision=self.closure_packet(optional=True)
        decision["criteria_results"][1]["passed"]=False
        with self.assertRaises(C.Failure) as caught:
            E.verify_claim_closure(self.f.root,snapshot,protocol,decision)
        self.assertEqual(caught.exception.code,"CLAIM_CRITERION_NOT_PASSED")

    def test_evidenced_optional_claim_can_enter_writing_closure(self):
        import _evidence as E
        snapshot,protocol,decision=self.closure_packet(optional=True)
        self.assertTrue(E.verify_claim_closure(self.f.root,snapshot,protocol,decision))
    def test_repair_restores_exact_route_and_phase(self):
        to_gate(self.f);before=C.project(self.f.root)[0]
        self.f.transition("evidence_repair",{"blocking_obligation_ids":["raw"]})
        proof=write(self.f.root,"evidence/repaired.json",{"fixture":"recomputed raw evidence"})
        s=copy.deepcopy(self.f.snapshot);s.update(snapshot_id="repair-1",created_at=C.now());s["artifact_refs"].append(proof)
        s["closure"]={"obligations":[{"obligation_id":"raw","status":"closed","evidence_refs":[proof]}]}
        sref=write(self.f.root,"evidence/snapshots/repair-1.json",s)
        self.f.transition("REPAIR_VERIFIED",{"closed_obligation_ids":["raw"],"evidence_snapshot_ref":sref},refs=[proof,sref])
        after=C.project(self.f.root)[0]
        self.assertEqual((after["current_route"],after["lifecycle_phase"]),(before["current_route"],before["lifecycle_phase"]))
    def test_frozen_protocol_cannot_be_modified_in_place(self):
        p,pref=to_gate(self.f);p["criteria"][0]["min_effect"]=.5
        inputref=write(self.f.root,"changed.json",p)
        with C.locked(self.f.root),self.assertRaises(C.Failure):C.freeze_gate(types.SimpleNamespace(protocol=str(self.f.root/inputref["path"]),gate="gate-a"),self.f.root)
    def test_semantic_child_requires_parent_and_excludes_old_runs(self):
        p,pref=to_gate(self.f);runs,refs=self.f.runs(p);child=copy.deepcopy(p);child.update(protocol_id="p2",parent_protocol_digest=p["protocol_digest"])
        child["criteria"][0]["min_effect"]=.2
        inputref=write(self.f.root,"child.json",child)
        with C.locked(self.f.root):result=C.freeze_gate(types.SimpleNamespace(protocol=str(self.f.root/inputref["path"]),gate="gate-a"),self.f.root)
        child=C.verify_ref(self.f.root,result["protocol_ref"],"gate-a-protocol")
        self.assertIn("STALE_RUN_PROTOCOL",C.evaluate(self.f.root,child,runs,refs,"gate-a")["reason_codes"])
    def test_protocol_key_order_does_not_change_semantic_identity(self):
        p=self.f.protocol();reordered=dict(reversed(list(p.items())))
        self.assertEqual(C.protocol_hash(p),C.protocol_hash(reordered))
    def test_manifest_ref_mismatch_is_inconclusive(self):
        p=self.f.protocol();runs,refs=self.f.runs(p)
        runs[0]["provenance"]["git_revision"]="changed"
        result=C.evaluate(self.f.root,p,runs,refs,"gate-a")
        self.assertEqual(result["outcome"],"INCONCLUSIVE")
    def test_retrospective_inventory_cannot_omit_negative_run(self):
        p=self.f.protocol("full-validation");p["evidence_mode"]="retrospective_audit";p["inventory_run_ids"].append("missing-negative")
        p["protocol_digest"]=C.protocol_hash(p);runs,refs=self.f.runs(p)
        self.assertEqual(C.evaluate(self.f.root,p,runs,refs,"full-validation")["outcome"],"INCONCLUSIVE")
    def test_machine_errors_redact_secret_keys_and_signed_urls(self):
        for secret in ("ghp_"+"Q"*32,"https://example.org/object?X-Amz-Signature="+"Q"*32):
            value=sample_artifacts()["idea-atom"];value[secret]="secret in key"
            path=self.f.root/"secret.json";path.write_text(json.dumps(value))
            result=subprocess.run([sys.executable,str(PACKAGE/"scripts/validate_artifact.py"),str(path)],capture_output=True,text=True)
            self.assertEqual(result.returncode,2);self.assertNotIn(secret,result.stdout+result.stderr)
    def test_all_eight_entrypoints_and_projection_repair_work_from_clean_install(self):
        scripts=("init_project","validate_artifact","replay_state","transition_state","freeze_gate","evaluate_gate","redact_artifact","migrate_state")
        for name in scripts:
            with self.subTest(command=name):
                result=subprocess.run([sys.executable,str(PACKAGE/"scripts"/(name+".py")),"--help"],capture_output=True,text=True)
                self.assertEqual(result.returncode,0)
        result=subprocess.run([sys.executable,str(PACKAGE/"scripts/validate_artifact.py"),"--project",str(self.f.root)],capture_output=True,text=True)
        self.assertEqual(result.returncode,0);self.assertTrue(json.loads(result.stdout)["valid"])
    def test_tiny_trusted_fixture_reproduces_from_pinned_manifest(self):
        source=self.f.root/"tiny-fixture.py"
        source.write_text('import json\nprint(json.dumps({"accuracy":{"treatment":0.75,"control":0.5}},sort_keys=True))\n')
        manifest={"source_ref":ref(self.f.root,"tiny-fixture.py"),"command":[sys.executable,"-I",str(source)],"seed":1,
            "environment":{"python":sys.version.split()[0]}}
        # This is known test code, not the skill's route for untrusted repositories.
        result=subprocess.run(manifest["command"],env={"PATH":os.defpath,"PYTHONHASHSEED":"1"},capture_output=True,text=True)
        self.assertEqual(result.returncode,0)
        self.assertEqual(json.loads(result.stdout),{"accuracy":{"treatment":.75,"control":.5}})
        C.verify_ref(self.f.root,manifest["source_ref"])
        source.write_text('print("changed")')
        with self.assertRaises(C.Failure):C.verify_ref(self.f.root,manifest["source_ref"])
    def test_sidecar_redaction_invalidates_gate_and_writing(self):
        path=self.f.root/"replacement.json";path.write_text('{"fixture":"redacted"}')
        with C.locked(self.f.root):C.redact(types.SimpleNamespace(path="evidence/source.json",replacement=str(path)),self.f.root)
        state=C.project(self.f.root)[0]
        self.assertEqual((state["current_route"],state["gate_state"],state["writing_state"]),("repair_evidence","not_ready","not_ready"))
    def test_retarget_without_validation_enters_repair_with_exact_blockers(self):
        result=self.f.transition("retarget_writing",{"blocking_obligation_ids":["matched_compute"]})
        self.assertEqual(result["state"]["current_route"],"repair_evidence")
        self.assertEqual(result["state"]["suspension"]["blocking_obligation_ids"],["matched_compute"])
    def test_complete_independent_collision_proof_can_advance(self):
        ready_problem(self.f)
        import _evidence as E
        from test_boundaries import EvidenceTests
        work=copy.deepcopy(sample_artifacts()["work-record"]);work["evidence_refs"]=[self.f.source]
        unit=copy.deepcopy(sample_artifacts()["evidence-unit"]);unit["locators"][0]["artifact_ref"]=self.f.source
        wref=write(self.f.root,"evidence/work.json",work);uref=write(self.f.root,"evidence/unit.json",unit)
        capture=write(self.f.root,"evidence/capture.json",{"works":[work],"evidence_units":[unit]})
        searches=[]
        for i in (1,2):
            search=copy.deepcopy(sample_artifacts()["search-run"]);search.update(search_id="search-"+str(i),raw_capture_refs=[capture],
                query_families=sorted(E.FAMILIES),normalized_output_digest=digest({"works":[work],"evidence_units":[unit]}))
            searches.append(write(self.f.root,"evidence/search-"+str(i)+".json",search))
        candidate=copy.deepcopy(sample_artifacts()["idea-atom"]);candidate["source_evidence_refs"]=[uref]
        candidate["necessity_case"]["baseline_evidence_refs"]=[uref]
        candidate["parent_problem_ref"]=C.project(self.f.root)[0]["parent_problem_ref"]
        cref=write(self.f.root,"ideas/c1.json",candidate);self.f.transition("research_candidate",{"candidate_ref":cref})
        roles={}
        for role in ("retriever","prosecutor","defender","equivalence_verifier","provenance_auditor","adjudicator"):
            roles[role]=write(self.f.root,"audits/"+role+".json",{"role":role,"context_id":"synthetic-"+role,"evidence_refs":[uref],"fixture":True})
        report=copy.deepcopy(sample_artifacts()["collision-decision"])
        report.update(candidate_ref=cref,evidence_refs=[uref],search_run_refs=searches,work_refs=[wref],
            coverage_batches=[{"new_high_risk_families":[],"search_run_refs":[r]} for r in searches],
            claim_audits=[{"claim_id":"claim-1","work_ids":[work["work_id"]],"evidence_refs":[uref],"role_refs":roles}])
        report["coverage"].update(required_families=sorted(E.FAMILIES),completed_families=sorted(E.FAMILIES))
        rref=write(self.f.root,"audits/complete.json",report)
        self.f.transition("importance_decision",{"importance_decision_ref":importance(self.f,collision_ref=rref)})
        result=self.f.transition("collision_ADVANCE",{"collision_ref":rref})
        self.assertEqual(result["state"]["current_route"],"execute_gate_a")
        report["coverage_batches"][1]["search_run_refs"]=[searches[0]]
        with self.assertRaises(C.Failure):C.collision_ready(self.f.root,write(self.f.root,"audits/reused-round.json",report),"ADVANCE")

if __name__=="__main__":unittest.main()
