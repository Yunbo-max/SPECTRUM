# B01 upstream configuration and startup

B01 establishes the task/metric contract and configures existing benchmark assets.
For a theory-only claim, retain the supported formal contract alternative; do not
require a dataset, executable evaluator or GPU startup for formal-only work.
Prefer the benchmark authors' implementation and documented settings. Pin the
published repository/package revision, dataset configuration/split, dependency
versions, data/model paths, selected interpreter and actual invocation. Reuse
already supplied SSH authority and confirmed resources. Define the GPU and execution
environment at intake and reuse that target throughout the run; machine migration
is not part of the normal B01 flow. Revisit the target only on an explicit user
change or an observed loss of access.

Perform one real import/configuration/entrypoint startup check on the authorized
execution server. Read its exit code and retained output. Fix an actual dependency
or invocation error if observed. Once these checks pass, submit B01 setup evidence
for independent acceptance and continue the prescribed sequence. Do not request
repeated literature searches, custom correctness proofs or fabricated incorrect
samples just to configure a published tool. Recheck only changed components or
an actual new failure.

Preserve the original task population, setup code, prompts, metric and denominator.
An upstream package being installed does not authorize replacing MBPP full/test
with MBPP+ or a sanitized subset. Record such differences. If authors provide
data and evaluation instructions but no executable scorer, state that fact and
name the actual community/project executor honestly; never relabel it official.
Lack of an author-provided executable is an outstanding scoring integration fact,
not a reason to repeat B01 indefinitely after its configuration work is complete.

Startup success proves only configuration/startup. Baseline runs, scorer behavior,
adaptation/parity checks and generated-program isolation belong to B03/the actual
scoring stage. Retain those obligations and unscored outputs. No automatic
scientific PASS, threshold changes, test removal or native-admission exemption
follows from B01 acceptance.

For an existing pinned Work Harness, the owner can adopt a scoped B01 setup policy
with `ResearchProgram.adopt_b01_setup(project_id, policy_ref,
expected_revision=...)` at a quiet B01 decision boundary. The policy pins the user
instruction, exact execution target and observed setup report. Runtime supplies
the same effective criteria to both worker and reviewer and records the policy
with acceptance; historical catalog and accepted-step pins stay intact.

For setup-only acceptance (`tasks=[]`), retain the exact accepted scientific
decision reference instead of inventing a new inquiry/frame merely to acknowledge
an import. Fresh native scientific receipts or new child work retain their normal
decision and review requirements. Existing coverage and future scoring obligations
cannot be erased. The setup report identifies pending scoring explicitly.
