# GPU intake and experiment feasibility

## Ask once, inspect before committing to a plan

Before GPU-dependent design or implementation, restore the user's current target,
allocation and intended task. If no execution target is supplied, ask first:
“这次用哪台 GPU 机器？请提供已有的 SSH 连接或机器信息；还没选的话可先给 GPU 型号与显存。”
This is one execution-target choice, not a request for credentials in a public
artifact. Never save passwords, private keys or tokens in research files.

If an authorized SSH target already exists, inspect it directly and report the
observed GPU name, visible/allocated device count, VRAM, native precision support
and selected interpreter. Ask only for missing allocation or access facts that
cannot be observed. Do not ask again on every round. A user estimate such as
“应该支持 BF16” remains user-stated until verified. After target replacement,
reinspect the new host; never copy the previous host's readiness flags.

Read-only research may proceed while execution facts are unknown. Hardware-bound
model, batch, precision and training promises must remain provisional until the
checks below. Optional source/delivery preferences must not delay discovering an
unknown execution target when the immediate request is GPU work.

## Real host preflight

The Work Harness source runtime provides a bounded helper:

Use the reviewed runtime source accompanying this edition (or its separately
installed runtime). A skills-only archive does not supply the Python module.
For a source checkout, run from that root with `PYTHONPATH=src`; do not upgrade a
running project's pinned runtime merely to invoke this standalone observer.

```sh
python -m research_autopilot.gpu_preflight \
  --target gpu-target.json --requirements gpu-requirements.json \
  --output gpu-preflight.json
```

Use the explicit project interpreter in the target (not whatever system Python
happens to import torch). Target format is the existing trusted NativeTarget:

```json
{"host":"authorized-ssh-alias","root":"/absolute/project","skill_root":"/absolute/skill","python":"/absolute/project-venv/bin/python"}
```

A requirements example (numbers are an example, not a universal safe budget):

```json
{"stage":"prediction","gpu_count":1,"precision":"bf16","min_free_vram_mib":8192}
```

Use null for precision or required free VRAM when not yet determined. GPU count
means the job's required count; do not infer permission to use every host GPU.
Use allocated_gpu_uuids with canonical `GPU-...` or `MIG-...` identities when the
allocation is restricted; bare UUIDs are not allocation declarations. All hosts and paths
must come from existing user authority. Missing SSH/framework/device observations
remain unknown; do not quietly switch hosts or interpreters.
Without an explicit UUID list, the helper probes the first `gpu_count` visible
devices. Use explicit UUIDs for a different selection. Device inventory is separate
from device operations; only the selected scope receives memory/precision probes
and optional smoke. CUDA inspection may initialize a context on selected devices.

The helper reports process-visible devices separately from host inventory,
selected Python/PyTorch, UUID/capability, memory and native BF16 versus emulation.
Do not interpret default `torch.cuda.is_bf16_supported()` as proof of native BF16.
Optional `--smoke` performs tiny precision operations on the selected GPU scope;
use only when such execution is authorized, after reconciling current jobs. It
never downloads a model, runs generated benchmark code or qualifies training.

## Decide what can actually run

Return a short feasibility card before investing in the chosen implementation:

| Question | Required evidence |
| --- | --- |
| What hardware may this job use? | Actual host/device identity, allocation and live free VRAM; CPU/RAM/disk observations where relevant. |
| Which precision works? | Native dtype support, actual small operation if authorized, and compatibility of the project's implementation. |
| Does this stage fit? | Selected model/config, sequence length, batch, optimizer/LoRA and memory estimate followed by a measured pilot with headroom. |
| Is the environment usable? | Correct project interpreter, dependency versions and actual imports; a successful check in system Python does not qualify a different venv. |
| What remains blocked? | Exact stage dependency, failure/unknown and next test or scoped code repair. |

Use three outcomes: `blocked` for a measured hard prerequisite mismatch;
`needs_measurement` for unresolved facts; `ready_for_pilot` for satisfied measured
GPU prerequisites. None means the complete experiment is proven feasible.
The weight size alone excludes activations, gradients, optimizer state, cache,
workspace and fragmentation. Snapshot free VRAM is not a reservation. Calibrate
one workload at a time using supported batches, preserving effective batch and
scientific protocol. An FP16 matmul passing does not supply a missing training
GradScaler or prove gradients are stable. Do not silently substitute BF16/FP16/
FP32: record the effective dtype and the implementation change, then test it.

Separate training, generation and scoring. SSH success does not prove namespace
permissions; failed unshare does not mean SSH or CUDA is unavailable. Only the
stage executing generated programs acquires its required execution-isolation
checks. Reuse actual deferred-scoring support; retain unscored outputs honestly.

## Keep the result current and attributable

Pin the report and requirement/config identities in the current stage's evidence.
Re-run on host, device allocation, interpreter, precision or material config
change, and check volatile resources immediately before dispatch. Preserve failed
observations; avoid repeated identical read-only loops after an execution gap is
known. Use the authorized qualification route to resolve that gap, with existing
review and actual receipts. The helper is an observation tool, not a scheduler,
allocation, sandbox, scientific acceptance or permission grant.

Run portable/code verification on the user's designated GPU server when requested;
Mac-specific process/service checks must still use their actual host. Keep source
changes, remotely tested bytes, plugin installation and live project adoption
separate. Updating a plugin does not rewrite immutable running Skill pins.
