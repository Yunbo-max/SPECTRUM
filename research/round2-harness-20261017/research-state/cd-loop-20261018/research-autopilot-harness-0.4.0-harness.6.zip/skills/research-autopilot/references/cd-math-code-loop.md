# Work Harness C/D mathematical diagnosis and executable idea development

## Select the adopted profile first

This guide applies **only** to `sequence.flow_profile: work-harness-cd-v1` in
Work Harness. Its catalog is `assets/skill-sequence-cd-v1.json`; its C/D node guides
are `references/nodes/cd-v1/`. The original 84 node IDs/order remain represented.
The historical registry/node sources remain provenance and may supply compatible
scientific detail. For this profile, the new catalog and this guide take precedence
for C/D responsibilities, diagnostic/development admission, local revisits and
D-to-E acceptance, including conflicting inherited Gate 0/IPCG, natural-census-only
or baseline-only qualification wording. Evidence integrity, native scoring,
mathematical review and fair comparisons remain required.

Omitted `flow_profile` retains the legacy catalog and transition semantics.
Neither installing a plugin nor reading this file adopts the profile into a live
program. Restore the actual profile/catalog hash from the handoff. An explicit
adoption must use the runtime's supported quiet-boundary procedure, backup and
revision check; preserve old acceptance meanings, jobs, raw results, source pins,
usage and pause state. This guide does not alter another plugin/edition.

## The research loop

```text
B: papers, code, observations and verified discussion leads
                 ↓
C: condition/dependency diagnosis ⇄ D: mechanism construction + local experiments
          ↖ targeted B visits, then return to the origin ↗
                 ↓
independent VERIFIED_FOR_SCALEUP review + program checks
                 ↓
E: full settings, fair comparisons, freeze, scale and confirmation
```

Program code owns every transition. The worker proposes current-step work and
schema-supported revisits; a separate reviewer evaluates evidence and requests.
An accepted diagnostic child job is not node acceptance. An accepted node is not
scientific success. The program advances after the appropriate evidence checks.

## C: condition, failure mode and computational dependency diagnosis

C includes B01, S01, E01, B02, B03, B04 and B05. Start from a specific existing
method/architecture with pinned code and a meaningful condition, not a desired
new module. Two legitimate patterns may coexist:

- **Assumption mismatch:** a sourced data/information/noise/resource condition
  changes and an existing assumption becomes inadequate, causing measurable loss.
- **Overly strict dependency:** an always-compute/wait/update/solve rule creates
  avoidable cost, interference or quality limitations. The original method can
  remain correct and accurate; task failure is not a prerequisite.

Conditions need practical or scientific provenance. Preserve native benchmark
semantics and transparent population/group definitions. Do not choose only the
conditions or samples where a favored comparator loses, alter reference answers,
or replace existing benchmark evidence with generated examples.

Trace assumptions and dependencies into code, derive observable predictions,
measure actual behavior, and perform discriminating simple interventions. Check
implementation, tuning, information, resource and randomness explanations. Retain
population/denominator, frequency or coverage, task/cost effects, uncertainty and
raw results. Correlation, a small state delta, or a failed smoke run is insufficient.

C may design and execute substantive diagnostic code: freezing, skipping, random
or fixed selection, replacement and budget matching as appropriate. B01 remains
configuration/setup under its existing explicit qualification controls. Other C
nodes permit reviewed design/code/native child work serving their current question.
This capability is required to obtain evidence before accepting the problem.

B04 creates the versioned **problem contract**: existing method; condition and
provenance; limitation/dependency; original assumption; observables; task/cost
consequences; rivals; actual interventions/results; denominators/uncertainty;
control scope; unresolved items; predecessor lineage. B05 independently reviews
it. `PROBLEM_SUPPORTED` means evidence supports a scoped problem worth developing;
it does not imply universal impossibility, a verified solution or an obligation
to make the hypothesis succeed. Unsupported findings lead to targeted B/C work.

## D: construct, implement, compare and revise the mechanism

D includes H01–H05 and M01–M05. Consume the current problem contract and iterate:

1. Formalize state, available information, objective and constraints.
2. Compare mechanisms and simpler alternatives that could address the limitation.
3. Derive computable operators, state/information flows, approximation error and
   meaningful applicability predictions; mark proof versus conjecture.
4. Map each consequential mathematical object to actual code, tensors/configs and
   observables. Implement complete methods and required comparison paths.
5. Run real local comparisons on existing benchmark/model/data/evaluation, with
   qualified strong/simple controls and necessary mechanism interventions.
6. Inspect raw outputs, costs and uncertainty; revise mathematics, code or the
   problem contract according to the evidence, preserving failures.

H05 is scoped candidate/development selection, not a requirement to pass the old
Gate 0/IPCG chain. D nodes permit reviewed design/code/native work needed to answer
their current question. Use the actual profile-specific admission schema: never
label a new treatment as baseline qualification to obtain permission.

A mechanism may remove, reorder, approximate, share or select computation. Formula
novelty is not established by notation; inspect closest primary work and real code.
A single model/dataset can suffice for local scope, with substantive experiments
and adequate controls. A startup check or toy example cannot replace that evidence.

## One mathematical-to-code evidence chain

For each consequential claim, link these fields in a reviewable evidence record;
use the supplied runtime schemas rather than inventing response keys:

| Element | Required connection |
| --- | --- |
| Question/claim | The scientific statement and rival explanations being distinguished. |
| Assumptions | Conditions, permitted information, approximations and valid scope. |
| Mathematical object | State/operator/dependency/objective and derivation status. |
| Code binding | Exact source identity, function/tensor/config and implementation departures. |
| Observable | Actual measurement and its relationship to the claim. |
| Intervention/control | Executed change and strong/simple counterfactuals. |
| Prediction/falsifier | Predicted result and rejection condition recorded before outcomes. |
| Evidence | Protocol, run, raw output, scoring, cost and uncertainty references. |
| Revision | What changed and which dependent claims/evidence are no longer valid. |

For selective recurrent updates, a small omitted state change can amplify later.
Use actual skip/freeze/perturbation controls and downstream task measurements;
state norms alone do not show dispensability. Frozen-model interventions and
training a new architecture test different hypotheses. Computing all updates and
then masking them can diagnose a mechanism but cannot demonstrate saved compute.
An efficiency claim needs the actual omitted computation and full selection cost.

Independent review checks reasoning and interpretation. Runtime checks establish
identity, completeness and lawful state; JSON validity or exit zero proves neither
mathematical correctness nor scientific effectiveness.

## Statistical scope, costs and boundary evidence

Retain fair legal information and training/tuning/search/call/compute budgets.
Record inherited versus adapted settings. A quality-preservation claim requires
an explicit noninferiority margin and sufficient precision; nonsignificance is
not equivalence. Task bootstrap is not independent training replication. Choose
sample sizes/repetitions for actual variance/effect/resource needs, without a
universal seed quota. Retain every tried condition/method and development exposure.

Test inside/near/outside predicted ranges when meaningful; do not invent a
threshold for every question. Failure of a sufficient condition does not imply
reversal of its conclusion. Experiments test applicability/predictions under
measured conditions; they do not prove unrestricted theorems.

Measure end-to-end costs including setup, decisions, updates/fallbacks, transfer,
scoring and tuning as appropriate. Capability claims require evidence about
information represented, retained or updated; acceleration alone does not establish
such capability. Label C/D results as development evidence and preserve independent
confirmation obligations for E rather than recycling exposed data as unseen tests.

## Reviewed local revisits

Target B nodes by the actual gap: L01 retrieval, L02 maps/citations, L03 close
reading, X02 figures/appendices, L04 code/reproduction, X03 logs/web, L05 new leads.
A B visit addresses that gap and returns to its origin; it does not rerun all B.
Enabled Xiaohongshu posts/comments are read serially and only as leads; verify
tricks against primary sources, code or experiments. Unavailable access does not
block independent research or authorize fabricated discussion evidence.

A typed revisit records origin, legal target, evidence gap/rival explanation,
expected output, return point and affected versions. Use the exact worker/reviewer
schemas in the handoff. The worker proposes, independent reviewer checks, and
controller applies the transition after job reconciliation. No raw jump/skip,
unrestricted 84-node scheduler or implicit whole-cycle restart is permitted.

When D evidence invalidates C, rewind to the affected C node. Retain earlier
unaffected accepted evidence; invalidate the affected acceptance suffix for renewed
review while preserving immutable historical receipts, derivations, failed runs,
raw outputs, exposure, external job identities and cumulative use. C/D revisions
can revisit the relevant earlier C/D work rather than deferring all repair until
another full 84-node cycle. Reconcile active/unknown jobs before changing context.
Do not add unsourced cumulative round/time caps or silently enlarge existing ones.

## M05: VERIFIED_FOR_SCALEUP and automatic E

The independent reviewer must establish all of the following:

- Current C problem contract is supported under meaningful, explicit conditions.
- Mathematical assumptions/mechanism correspond to executed code; gaps are visible.
- Complete actual local runs use existing benchmark/model/data and valid evaluation.
- Main effect and key mechanism predictions have adequate scoped support, strong
  and simple controls, practical effect size, uncertainty and relevant costs.
- Major implementation/scoring/tuning/information/budget/randomness alternatives
  have been checked; unresolved explanations are not hidden.
- Closest-work review supports continued investment; renaming is not innovation.
- Candidate/code/protocol/evidence versions are pinned; full exploration history
  and E obligations for scale, coverage, replication and confirmation remain.

`VERIFIED_FOR_SCALEUP` plus program validation automatically enters E under the
user's continuation authority. No extra per-transition human approval is needed.
The status means readiness to expand, not a completed paper or final scientific
success. A negative/inconclusive method stays unverified and triggers targeted
work or honest archival; do not launch its superiority study on a fabricated PASS.
Engineering failures receive diagnosis/debugging and are not scientific refutations.

E preserves S02/S03/S04 and the existing formal design, freeze, implementation,
execution, scoring, archive and confirmation requirements. Reuse qualified assets
and valid evidence without repeating installation. E counterevidence may reopen
C/D through the supported explicit reviewed transition; it does not silently reset
results, expenditure, frozen obligations or the user's original objective.
