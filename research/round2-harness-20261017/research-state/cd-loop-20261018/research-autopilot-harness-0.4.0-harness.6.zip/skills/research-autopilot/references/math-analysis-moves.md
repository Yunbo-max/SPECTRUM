# Mathematical moves for research

Contents: scaling; bounds; equivalence; decomposition; constraints and duality;
expansions; geometry; dynamics; limits and counterexamples.

Choose a move because of a specific uncertainty. A useful move changes a
conclusion or produces a discriminating prediction. The menu is not a fixed
sequence and need not be exhausted.

## Scaling and nondimensionalization — 缩放

Identify units, typical magnitudes and independent dimensionless ratios. Rescale
variables, losses, temperature, time, horizon or dimension; transform the whole
objective and update, including the measure and Jacobian when appropriate.

Ask what is actually invariant: minimizers, probabilities, gradient direction,
conditioning, discrete updates or only an ideal continuous trajectory.

- A positive constant multiplying an unconstrained objective preserves its
  minimizers. It need not preserve a finite-step optimizer.
- A sample-, token- or timestep-dependent multiplier changes relative weighting.
  It generally changes the objective, even if each term has the same minimizer.
- Summing versus averaging variable-length sequences changes example weighting,
  not merely a global learning-rate factor.
- Scaling a matrix uniformly differs from scaling its directions differently.
  Compare eigenvalue ratios and condition numbers, not just gradient norms.
- Temperature changes a distribution; “divide logits by a constant” is not
  automatically a harmless coordinate change.

Deliver the transformed expression, invariant and non-invariant quantities,
and a controlled scale intervention. Explain which optimizer assumptions are
required for any learning-rate equivalence.

## Inequality bounds and relaxations — 放缩

Start with the quantity that matters. Decide whether an upper bound, lower bound,
two-sided bound or asymptotic equivalent can answer the question. Consider
Jensen, Cauchy–Schwarz, Young, convexity, log-sum or problem-specific inequalities;
derive the relevant instance rather than name-dropping them.

Track the direction at each step and record equality conditions. Evaluate the
gap or relative tightness in the regime of interest. Separate pointwise,
expected, high-probability, local and uniform statements.

A bound on a reward does not bound its parameter gradient without assumptions
on the score/Jacobian. A small absolute bound need not imply a small relative
error when the signal also vanishes. A bound that grows with horizon or dimension
may become vacuous at the target scale.

If optimizing a bound as a surrogate, ask whether it shares minimizers with the
original objective or only touches it at the current iterate. An upper bound
alone does not guarantee that reducing it reduces the original objective;
majorization arguments need the appropriate tightness and update conditions.

Deliver a bound, its gap/tightness regime and the strongest conclusion it
actually supports. If it is too loose, improve the decomposition or reject it.

## Reparameterization, change of measure and equivalence

Translate into useful coordinates: logits/probabilities, residuals, log-ratios,
whitened variables or primal/dual variables. For stochastic objectives, derive
the change of measure and importance weights explicitly.

Check invertibility, support, normalization, Jacobians and the space in which
an equivalence holds. Distinguish equality of functions, gradients, stationary
points, minimizers, estimators and optimization trajectories.

Ask whether the “new method” is an old method in different coordinates, or
whether an implementation detail breaks the equivalence. State exactly where.

## Decomposition and conditioning

Split a hard quantity into interpretable terms: immediate/future credit,
bias/variance, approximation/optimization error, within/between-group variation,
predictable/residual components or orthogonal subspaces.

Use conditioning, telescoping, integration by parts or total expectation/variance
where appropriate. Include covariance and cross terms unless they demonstrably
vanish. Inspect signs and units before interpreting an individual term.

For gradients, compare score-function and pathwise routes when both exist.
Account for derivatives of the sampling distribution and parameter-dependent
rewards. Specify the random variables held fixed by each conditional statement.

Deliver a term whose size, direction or covariance can be measured or controlled,
and an alternative explanation if that term is negligible.

## Constraints, variational reasoning and duality

Write the desired behavior as an objective and explicit constraint. Derive a
Lagrangian, stationarity/KKT conditions or functional variation; normalize the
solution. Verify feasibility, constraint activity and conditions for duality.

Keep the direction of a divergence explicit. Arithmetic and geometric mixtures
usually solve different problems; changing a target distribution differs from
changing the behavior distribution.

Explain how the dual variable relates to a measurable constraint. A formula
containing a divergence does not by itself establish a trust-region guarantee.
Do not claim global optimality from a stationarity condition in a nonconvex problem.

## Taylor expansion, perturbation and asymptotics

Choose a small/large parameter, an expansion point and a regime where the
remainder is controlled. Compare the leading nonzero orders of both the proposed
mechanism and the competing signal. Include constants that scale with dimension,
horizon or conditioning.

Check whether limits commute and whether the expansion is uniform on the
states actually visited. A local expansion cannot establish a global trend.
Zero first derivative can signal a second-order effect rather than no effect.

Deliver a directional or scaling prediction and a boundary where the
approximation should fail. Test the boundary as well as the easy regime.

## Geometry, spectrum, invariance and identifiability

Identify the relevant space and metric: parameters, logits, distributions or
representations. Examine Hessian/Fisher spectra, Jacobian rank, nullspaces,
symmetries and the induced metric under a map.

Positive definiteness in one space does not automatically preserve stationary
points after pullback through a rank-deficient map. A larger output dimension
does not by itself imply a nontrivial input nullspace.

Separate ill-conditioning, non-identifiability and insufficient capacity.
Derive what a projection or preconditioner preserves before attributing
improvements to “more information” or “better alignment.”

## Dynamics and fixed points

Write the actual update operator, including target lag, sampling, clipping and
optimizer state. Find candidate fixed points and analyze local stability or
contraction where justified. Distinguish convergence to the desired point from
convergence to any fixed point.

Check finite step sizes and stochastic noise. Monotonic improvement of an ideal
operator does not prove monotonic training of a parameterized approximation.

## Limits, counterexamples and transfers

Probe equality, zero noise, identical models, zero/infinite temperature, one-step
horizon, large dimension, disjoint support and singular curvature when relevant.
Construct the smallest mathematical example capable of refuting a universal
claim. It is a logical test, not an invented performance benchmark.

Transfer a method from another field only after matching the abstract objects,
assumptions and information access. Shared vocabulary is not a derivation.

An informative negative result can delimit a claim or redirect research. Do not
force every mathematical move to produce a new algorithm.
