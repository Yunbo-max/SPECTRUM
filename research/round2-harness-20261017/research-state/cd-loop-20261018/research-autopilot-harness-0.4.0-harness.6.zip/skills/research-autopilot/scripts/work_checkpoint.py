#!/usr/bin/env python3
"""One versioned Work resume locator; no scheduler, dispatch or authority grant.

The trusted integration writer assembles observations from the actual ledger and
controller. Hashes protect identity, not truth. Runtime DB/receipts still own live
attempts and budgets; this checkpoint must agree with them before continuation.
Uses a POSIX file lock and atomic pointer replacement on the project filesystem.
"""
import argparse
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
import re
import tempfile
import _autoresearch as C

POINTER = 'research-state/CURRENT.json'
FIELDS = {'version', 'project_id', 'sequence', 'previous_ref', 'state', 'latest_batch',
          'policy', 'executor', 'contract_ref', 'ledger_ref', 'report_ref',
          'pending_attempt_refs', 'obligations', 'counters', 'limits', 'next_action',
          'adoption_ref', 'resume_authority_ref', 'transition_ref'}


def _text(value):
    if not isinstance(value, str) or not value.strip() or '\x00' in value:
        C.fail('CHECKPOINT_TEXT_REQUIRED')


def _keys(value, expected):
    if not isinstance(value, dict) or set(value) != expected:
        C.fail('CHECKPOINT_FIELDS_INVALID')


def _pin(root, value, *, verify=True):
    _keys(value, {'path', 'sha256'})
    if not isinstance(value['sha256'], str) or not re.fullmatch('[0-9a-f]{64}', value['sha256']):
        C.fail('CHECKPOINT_DIGEST_INVALID')
    return C.verify_ref(root, value) if verify else C.safe_path(root, value['path'])


def validate(root, value, *, verify_dependencies=True):
    _keys(value, FIELDS)
    C.finite(value)
    if type(value['version']) is not int or value['version'] != 1:
        C.fail('CHECKPOINT_VERSION_UNSUPPORTED')
    if type(value['sequence']) is not int or value['sequence'] < 1:
        C.fail('CHECKPOINT_SEQUENCE_INVALID')
    for name in ('project_id', 'latest_batch', 'next_action'):
        _text(value[name])
    if value['state'] not in ('active', 'paused', 'parked', 'completed'):
        C.fail('CHECKPOINT_STATE_INVALID')
    _keys(value['policy'], {'edition', 'version', 'source_revision', 'skill_digest'})
    _keys(value['executor'], {'name', 'version', 'source_revision'})
    if value['policy']['edition'] not in ('autonomous-rsi', 'autonomous-rsi-harness'):
        C.fail('CHECKPOINT_EDITION_MISMATCH')
    for obj in (value['policy'], value['executor']):
        for item in obj.values():
            _text(item)
        if not re.fullmatch('[0-9a-f]{40}', obj['source_revision']):
            C.fail('CHECKPOINT_SOURCE_REVISION_INVALID')
    if not re.fullmatch('[0-9a-f]{64}', value['policy']['skill_digest']):
        C.fail('CHECKPOINT_SKILL_DIGEST_INVALID')
    for name in ('contract_ref', 'ledger_ref', 'report_ref'):
        _pin(root, value[name], verify=verify_dependencies)
    for name in ('previous_ref', 'adoption_ref', 'resume_authority_ref', 'transition_ref'):
        if value[name] is not None:
            _pin(root, value[name], verify=verify_dependencies)
    for name in ('obligations', 'pending_attempt_refs'):
        if not isinstance(value[name], list):
            C.fail('CHECKPOINT_LIST_REQUIRED')
    for item in value['obligations']:
        _text(item)
    for item in value['pending_attempt_refs']:
        _pin(root, item, verify=verify_dependencies)
    if len({p['path'] for p in value['pending_attempt_refs']}) != len(value['pending_attempt_refs']):
        C.fail('CHECKPOINT_DUPLICATE_ATTEMPT')
    for name in ('counters', 'limits'):
        if not isinstance(value[name], dict) or not value[name]:
            C.fail('CHECKPOINT_BUDGET_REQUIRED')
        for key, amount in value[name].items():
            _text(key)
            if type(amount) not in (int, float) or amount < 0:
                C.fail('CHECKPOINT_BUDGET_INVALID')
    if set(value['counters']) != set(value['limits']):
        C.fail('CHECKPOINT_BUDGET_UNITS_MISMATCH')
    if any(value['counters'][key] > limit for key, limit in value['limits'].items()):
        C.fail('CHECKPOINT_BUDGET_EXCEEDED')
    if value['state'] == 'completed' and (value['obligations'] or value['pending_attempt_refs']):
        C.fail('CHECKPOINT_COMPLETION_HAS_OPEN_OBLIGATIONS')
    if verify_dependencies and value['transition_ref'] is not None:
        if value['previous_ref'] is None:
            C.fail('CHECKPOINT_CLOSURE_BINDING_MISMATCH')
        previous = validate(root, json.loads(_pin(root, value['previous_ref']).read_text()), verify_dependencies=False)
        _check_closure(root, previous, value, value['previous_ref'])
    return value


def _current(root, *, verify_dependencies=True):
    root = C.root_path(root)
    pointer = json.loads(C.safe_path(root, POINTER).read_text())
    _keys(pointer, {'version', 'project_id', 'checkpoint_ref'})
    if type(pointer['version']) is not int or pointer['version'] != 1:
        C.fail('CHECKPOINT_VERSION_UNSUPPORTED')
    value = validate(root, json.loads(_pin(root, pointer['checkpoint_ref']).read_text()),
                     verify_dependencies=verify_dependencies)
    if pointer['project_id'] != value['project_id']:
        C.fail('CHECKPOINT_PROJECT_MISMATCH')
    return {'checkpoint_ref': pointer['checkpoint_ref'], 'checkpoint': value,
            'may_continue': verify_dependencies and value['state'] == 'active',
            'qualification': 'observed checkpoint only; reconcile live authority, attempts and admission'}


def inspect(root, *, expected_batch=None, expected_policy=None):
    result = _current(root)
    value = result['checkpoint']
    if expected_batch is not None and expected_batch != value['latest_batch']:
        C.fail('STALE_EMBEDDED_HANDOFF')
    if expected_policy is not None and expected_policy != value['policy']:
        C.fail('LOADED_POLICY_MISMATCH')
    return result


def _used_resume_refs(root, value):
    """Read immutable history, never requalify superseded mutable dependencies."""
    used, seen = set(), set()
    project = value['project_id']
    while True:
        if value['resume_authority_ref'] is not None:
            used.add(value['resume_authority_ref']['sha256'])
        previous = value['previous_ref']
        if previous is None:
            if value['sequence'] != 1:
                C.fail('CHECKPOINT_HISTORY_INCOMPLETE')
            return used
        if previous['sha256'] in seen:
            C.fail('CHECKPOINT_HISTORY_CYCLE')
        seen.add(previous['sha256'])
        older = validate(root, json.loads(_pin(root, previous).read_text()), verify_dependencies=False)
        if older['sequence'] != value['sequence'] - 1 or older['project_id'] != project:
            C.fail('CHECKPOINT_HISTORY_MISMATCH')
        value = older


def _check_closure(root, old, value, previous_ref):
    removed = [pin for pin in old['pending_attempt_refs'] if pin not in value['pending_attempt_refs']]
    obligations = set(old['obligations']) - set(value['obligations'])
    if not removed and not obligations and value['transition_ref'] is None:
        return
    if value['transition_ref'] is None:
        C.fail('CHECKPOINT_CLOSURE_EVIDENCE_REQUIRED')
    closure = json.loads(_pin(root, value['transition_ref']).read_text())
    _keys(closure, {'version', 'previous_ref', 'review_ref', 'closed_attempts', 'closed_obligations'})
    if type(closure['version']) is not int or closure['version'] != 1 or closure['previous_ref'] != previous_ref:
        C.fail('CHECKPOINT_CLOSURE_BINDING_MISMATCH')
    _pin(root, closure['review_ref'])
    if not isinstance(closure['closed_attempts'], list) or not isinstance(closure['closed_obligations'], list):
        C.fail('CHECKPOINT_CLOSURE_INVALID')
    attempts = []
    for entry in closure['closed_attempts']:
        _keys(entry, {'attempt_ref', 'outcome', 'receipt_ref'})
        _pin(root, entry['attempt_ref'], verify=False)  # original identity stays in the immutable history
        _pin(root, entry['receipt_ref'])
        if entry['outcome'] not in ('completed', 'failed', 'cancelled'):
            C.fail('CHECKPOINT_ATTEMPT_NOT_TERMINAL')
        attempts.append(entry['attempt_ref'])
    if sorted(attempts, key=lambda p: (p['path'], p['sha256'])) != sorted(removed, key=lambda p: (p['path'], p['sha256'])):
        C.fail('CHECKPOINT_ATTEMPT_CLOSURE_MISMATCH')
    closed = []
    for entry in closure['closed_obligations']:
        _keys(entry, {'obligation', 'evidence_refs'})
        _text(entry['obligation'])
        if not isinstance(entry['evidence_refs'], list) or not entry['evidence_refs']:
            C.fail('CHECKPOINT_OBLIGATION_EVIDENCE_REQUIRED')
        for pin in entry['evidence_refs']:
            _pin(root, pin)
        closed.append(entry['obligation'])
    if len(set(closed)) != len(closed) or set(closed) != obligations:
        C.fail('CHECKPOINT_OBLIGATION_CLOSURE_MISMATCH')


@contextmanager
def _locked(root):
    directory = C.safe_path(root, 'research-state')
    directory.mkdir(parents=True, exist_ok=True)
    path = C.safe_path(root, 'research-state/writer.lock')
    fd = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        os.close(fd)


def _write_atomic(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.checkpoint-', delete=False) as stream:
            temporary = stream.name
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    finally:
        if temporary is not None and os.path.exists(temporary):
            os.unlink(temporary)


def publish(root, manifest, *, expected_ref=None):
    root = C.root_path(root)
    # Detach caller-owned objects before checks and publication.
    value = json.loads(json.dumps(manifest, allow_nan=False))
    with _locked(root):
        validate(root, value)
        pointer = C.safe_path(root, POINTER)
        # A new ledger/report may legitimately have new bytes at its old path.
        # Historical snapshot integrity is required, not stale live dependencies;
        # every dependency of the proposed new checkpoint was verified above.
        current = _current(root, verify_dependencies=False) if pointer.exists() else None
        actual = current['checkpoint_ref'] if current else None
        if actual != expected_ref or value['previous_ref'] != actual:
            C.fail('STALE_CHECKPOINT_WRITER')
        if current:
            old = current['checkpoint']
            consumed_resume_refs = _used_resume_refs(root, old)
            if value['sequence'] != old['sequence'] + 1:
                C.fail('CHECKPOINT_SEQUENCE_MISMATCH')
            for key in ('project_id', 'contract_ref', 'limits'):
                if value[key] != old[key]:
                    C.fail('CHECKPOINT_IMMUTABLE_CONTRACT_CHANGED')
            if any(value['counters'][k] < count for k, count in old['counters'].items()):
                C.fail('CHECKPOINT_CUMULATIVE_COUNTER_RESET')
            _check_closure(root, old, value, actual)
            if value['policy'] != old['policy'] or value['executor'] != old['executor']:
                if value['adoption_ref'] is None or old['pending_attempt_refs'] or value['pending_attempt_refs']:
                    C.fail('CHECKPOINT_QUIESCENT_ADOPTION_REQUIRED')
            if old['state'] != 'active' and value['state'] == 'active':
                if value['resume_authority_ref'] is None or value['resume_authority_ref']['sha256'] in consumed_resume_refs:
                    C.fail('CHECKPOINT_RESUME_AUTHORITY_REQUIRED')
        elif value['sequence'] != 1:
            C.fail('CHECKPOINT_INITIAL_SEQUENCE_INVALID')
        body = (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
        sha = hashlib.sha256(body).hexdigest()
        pin = {'path': f'research-state/checkpoints/{value["sequence"]:06d}-{sha}.json', 'sha256': sha}
        path = C.safe_path(root, pin['path'])
        if path.exists():
            if path.read_bytes() != body:
                C.fail('CHECKPOINT_IMMUTABLE_SNAPSHOT_CHANGED')
        else:
            _write_atomic(path, body)
        # Re-read all current dependencies before publishing the pointer.
        validate(root, value)
        index = {'version': 1, 'project_id': value['project_id'], 'checkpoint_ref': pin}
        _write_atomic(pointer, (json.dumps(index, sort_keys=True, indent=2) + '\n').encode())
        if inspect(root)['checkpoint_ref'] != pin:
            C.fail('CHECKPOINT_READBACK_MISMATCH')
        return pin


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    sub = parser.add_subparsers(dest='command', required=True)
    show = sub.add_parser('inspect')
    show.add_argument('--expected-batch')
    show.add_argument('--expected-policy', help='JSON file with the actually loaded policy identity')
    write = sub.add_parser('publish')
    write.add_argument('manifest', help='project-relative manifest with actual pinned evidence')
    write.add_argument('--expected-ref', help='JSON file containing the previously inspected checkpoint_ref')
    args = parser.parse_args(argv)
    try:
        root = C.root_path(args.root)
        def load(name):
            return json.loads(C.safe_path(root, name).read_text()) if name else None
        if args.command == 'inspect':
            result = inspect(root, expected_batch=args.expected_batch, expected_policy=load(args.expected_policy))
        else:
            result = publish(root, load(args.manifest), expected_ref=load(args.expected_ref))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (C.Failure, OSError, ValueError, TypeError) as error:
        print(json.dumps({'status': 'blocked', 'reason': str(error)}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
