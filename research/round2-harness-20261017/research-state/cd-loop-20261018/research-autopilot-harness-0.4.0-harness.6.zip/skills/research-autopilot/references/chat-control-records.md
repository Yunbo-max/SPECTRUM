# Research decisions, invocation reads and durable execution

Read when using `chat_cycle.py` for new research dispatch or migrating a saved
project. These helpers require no Local service. The host performs actual work;
records constrain declared actions and preserve their evidence. They cannot
authenticate a provider, decide novelty, or manufacture missing observations.

Contents: [migration](#start-or-migrate), [strategy](#research-strategy),
[decisions](#record-decisions-and-usage), [invocation](#actual-invocation),
[persistence](#durable-checkpoint-handoff), [runner](#bounded-command-execution),
[incidents](#operational-incidents-and-delivery).

## Start or migrate

Keep the original checkpoint and all failed attempts. `status`, observations,
usage reconciliation and settlement remain available for old checkpoints. Before
new `research` dispatch, adopt a sourced strategy, bind missing pending task
intents, set a session contract, read the actual procedure and bootstrap this
invocation. Do not change the goal to `bounded_task` to bypass these requirements.
An existing partial attempt retains its original procedure and inputs.

The coordinator uses `record --expected-revision N --event FILE`. Invalid events
leave the saved checkpoint unchanged. Strategies and session contracts are not
automatic installation, an external scheduler or permission to resume a pause.
`pause` records the real stop request (`request_ref`, `reason`). `resume_goal`
requires a new sourced user request; maintenance/adoption never clears a pause.
Observe and settle previously running operations while paused; do not dispatch.

## Research strategy

`strategy_ref` pins a JSON document with:

- `kind=chat_research_strategy`, `goal_id`, the exact original `request_ref`,
  and `source_ref` for the working plan and its finite limits.
- `obligations`: objects with `id`, `description`, `priority` (`critical`,
  `required`, `optional`), `criterion_ids`, `delivery_ids`. Preserve all original
  acceptance and delivery obligations; extra work does not replace missing ones.
- `families`: objects with stable `id`, `mechanism`, `mechanism_ref` and
  `diagnostic_limits={max_attempts,wall_seconds,gpu_seconds,cost}`.
- `limits`: `max_no_progress_attempts`, `max_diagnostic_attempts`,
  `diagnostic_wall_seconds`, `diagnostic_gpu_seconds`, `diagnostic_cost`.

Use actual prospective working bounds within the user's cumulative budget, not
fabricated consumption. In initialize, supply the ref. For migration use
`strategy_adopt` with `strategy_ref`. If history exists, add `review_ref` to a
`chat_strategy_adoption` binding `goal_id`, old `previous_strategy_ref`, new
`strategy_ref`, every historical `attempt_id`, `reason`, and separate review
evidence. Each `historical_attempts` entry retains `attempt_id`, `family_id`,
`diagnostic`, sourced `reservation`, `reservation_source_ref`, and actual `usage`
when known. Unknown usage remains reserved, not zero. Adoption preserves counts,
obligations and cumulative limits. See `chat_strategy.py` for exact validation.

Every research task pins `intent_ref` to `kind=chat_task_intent`, `goal_id`,
`candidate_id`, `family_id`, `obligation_ids`, `purpose`, `decision`, `falsifier`,
`estimate={wall_seconds,gpu_seconds,cost}`, and `scope_ref`. Wall estimate is
positive and finite. Purposes are `acquire`, `qualify`, `unblock`,
`independent_review`, `main_evidence`, `analysis`, `diagnostic`.
State what would change after each plausible result, rather than merely naming
another experiment. Keep artifact/version pins in the task's actual inputs.

Missing pending legacy intent uses `strategy_bind_task` with `task_id`,
`intent_ref`, and a reviewed `chat_strategy_task_binding` tying these to the goal.
Use `revise_task` for a changed pending task instead of changing running pins.
Repair successors inherit the original family and obligations. A classified
engineering repair receives recovery priority; the old failure remains failed.

Selection orders eligible work by obligation importance, dependency recovery,
purpose and bounded cost. Missing qualification blocks its candidate investment,
not unrelated source acquisition, baseline qualification or review. Diagnostic
experiments cannot escape accounting by being renamed as analysis. Prerequisite
experimental qualification must be diagnostic, declare `prerequisite_only=true`
and identify `qualification_targets` from `baseline_fidelity`,
`resource_calibration`, `metric_validity`; it still consumes diagnostic allowance.

Before candidate investment, `strategy_qualify` records `qualification_ref` to
`chat_research_qualification` binding goal, candidate, family and exact `scope_ref`.
The scope is `chat_research_scope` with candidate, `implementation_ref`,
`protocol_ref`, `default_parameters_ref`, matching baseline pins, their
`implementation_kind=official|qualified_port`, and
`claim_kind=new_method|comparison|replication`. Its separate review covers
`checks.source`, `checks.baseline`, `checks.nearest_work`, each with evidence,
finding and verdict. Source/baseline verdict is `verified`; a new-method claim
needs `distinct_testable_gap`, while a comparison may use `known_comparison`.
These are reviewed judgments with provenance, not a novelty detector.

## Record decisions and usage

Result events may include `strategy_usage={totals,receipt_ref}`. Totals cover
wall seconds, GPU seconds and cost; the receipt is `chat_strategy_usage`, binds
the actual `attempt_id`, identical `totals`, `terminal=true`, and `raw_evidence`.
An absent measurement does not prevent failed/blocked settlement. It retains the
reservation and requires reconciliation before further diagnostic investment.
Later use `strategy_usage` with `attempt_id` and `usage`. Keep whole-project
`usage` observations current too; family accounting is not a replacement ledger.

After meaningful evidence, use `strategy_progress` with `progress_ref` to
`chat_strategy_progress`: goal, settled `attempt_ids`, separate reviewer execution
and `changes`. Each change binds `obligation_ids`, concrete `before`/`after`, and
actual attempt `evidence_refs`. Types are `obligation_evidence`,
`dependency_resolved`, `hypothesis_retired`, `qualification`. Run counts and
renamed old evidence do not reset stagnation. Valid negative evidence can count.

At stagnation, `strategy_review` supplies `review_ref` to `chat_strategy_review`
binding current strategy, every settled attempt, `retained_obligation_ids`,
`diagnosis`, `alternative_considered`, `why_changed_plan`, `exit_condition`, and
`next_intent_refs` of concrete pending changed work. The review does not zero
budgets or erase no-progress history. More of the same decision/falsifier under
a new task name is rejected. Every independent strategy review binds distinct
`proposal_task_id`/`review_task_id`, actual `execution_ref` and `raw_evidence`;
the coordinator must genuinely obtain that review with available host tools.

## Actual invocation

Supply `session_contract={package_id,release,source_revision,required_source_refs,
destination,max_unsaved_revisions}` at init or use `session_policy` with `contract`,
real `source_ref` and `reason`. The revision interval is finite, from 4 to 1000.
Changing policy or adopting another procedure requires reading and bootstrapping
the new version at a settled boundary. Record the actual loaded package/source;
an explicitly read pinned repository bundle is not an installed-plugin update.

Save a `chat-session-bootstrap` receipt with `project_uuid`,
`host_invocation_id`, actual package/release/source fields, pinned `procedure`,
`read_source_refs` (including that procedure), `observation_ref`, and on resume
the observed `authoritative_head_ref`. Record it with `session_bootstrap` and
`receipt_ref`. Use the live Python `chat_session.host_invocation(identity)`
context, or CLI `--host-invocation-id ID`, for this actual invocation. If the host
does not expose an invocation ID, generate a fresh local correlation nonce,
record that origin, and never report it as a provider-authenticated identifier.
Do not replay the previous invocation's token to avoid reading its checkpoint.
Observations, migration and status inspection work without dispatch capability.
For a new invocation resuming an existing partial attempt, bootstrap with
`scope=continuation` and its exact `attempt_id`, original procedure and source
reads. Missing future-release sources do not block this scoped recovery; the
continuation receipt cannot authorize a new task. Use `chat_session.py nonce`
when no host ID is exposed. Keep source copies immutable and project-local for
portable recovery; an absolute installed-cache path is not durable storage.

## Durable checkpoint handoff

Each atomic state write records revision ancestry and a content digest. Branches
retain a stable project UUID, actual attempt IDs and experiment job IDs; stage
labels such as R014 are display labels only. Same-revision changed state fails
validation. The snapshot is locally coherent; it is not automatically durable.

Use `chat_session.py export --state STATE --output MANIFEST`, then actually save
the manifest, immutable checkpoint snapshot and every referenced artifact to the
authorized destination. Record `session_saved` with `manifest_ref`, `receipt_ref`.
The receipt is `chat-checkpoint-save` with `project_uuid`, `destination`,
`manifest_sha256`, exported `revision`, actual `operation_id`, `execution_ref`.
Reconcile an unacknowledged save before starting another publication.

Read back the real destination. Record `session_readback` with a receipt of kind
`chat-checkpoint-readback` binding project, destination, exported revision,
`save_operation_id`, a distinct read `operation_id`, `readback_manifest_ref`,
`restored_artifact_refs` for the checkpoint and all artifacts, and `execution_ref`.
The unsaved interval uses the exported revision; recording the acknowledgement
does not cause an infinite save/acknowledge loop. A manifest hash alone is
insufficient. Missing historical bytes remain an explicit recovery gap.
Use `verify`/`compare` to inspect saved manifests and conflicting heads; do not
choose a branch from its largest R number or silently discard another head.

## Bounded command execution

Use the existing native harness when it already fits the workload. For a current
Linux Chat command, `chat_run.py` provides a reusable bounded collector. Read its
module API, then `prepare(root, plan)` to persist a unique execution ID and pinned
intent. The plan binds `attempt_id`, `procedure_ref`, input/code refs, argv
`command`, `cwd`, fresh `output_paths`, finite `timeout_seconds`, log bounds and
optional `numeric_status_path`. It stages pinned files in a new workspace.

Call `execute(root, execution_id, plan_digest, authorizer=...)` after actual
resource/permission admission. The live authorizer checks that exact scope;
it is not another human approval prompt for already authorized work. Commands
must stay in their foreground process group. This collector does not provide
an OS security sandbox, GPU scheduler or provider billing meter.

Retain the committed terminal receipt, bounded stdout/stderr and output hashes.
Exit zero is execution success, not numerical validity or scientific acceptance.
Numeric invalid/partial, timeout, configuration/startup failures and unknown
operations remain distinct. Use `read_receipt` or `reconcile` on the original ID;
never duplicate a launch because its caller disappeared. Actual observed CPU and
wall time differ; unknown consumption is not zero. Process escape/uncertain
termination requires reconciliation before treating resources as released.

## Operational incidents and delivery

Follow [incident reporting](chat-incident-reporting.md) for every operational
anomaly. The coordinator reports the observed error through the live host even
when `chat_cycle.py`, `chat_run.py`, CPU/Python or the filesystem cannot run.
Host output and authorized connector writes/readback are independent fallback
paths. A rejected action or reporting failure must not be hidden by a retry.

The optional `chat_alerts.py` stores deduplicated incident versions and pending
delivery, separate from scientific acceptance and the coherent checkpoint.
`report`/`safe_report` record the fault; `pending`/`read` expose it. Real delivery
is performed by the host, followed by `delivery` with the actual observed outcome
and receipt. `resolve` records verified recovery with a new pending version.
See the incident module for exact arguments and receipt fields. A save, hash,
helper return, notification attempt or terminal command receipt cannot substitute
for actual report delivery evidence.

Persist and read back incident evidence alongside the project checkpoint when
possible. Preserve unsaved and pending/unknown/failed/unavailable delivery states
when storage or notification is unavailable, and show them in the task result.
Reconcile uncertain execution before another launch, independently of whether its
incident notification arrived. Preserve the original exception if outbox writing
also fails, and report both through the still-live host. No helper supplies a
background wakeup or changes a project's explicit pause.
