"""Engineering coordination tests; these are not scientific evaluation evidence."""
import copy
import datetime as dt
import importlib
import importlib.util
import json
import os
from pathlib import Path
from unittest import mock
import subprocess
import sys
import tempfile
import unittest

from fixtures import C, PACKAGE, ProjectFixture, canonical


START = "2026-10-03T00:00:00Z"
LATER = "2026-10-03T00:02:00Z"


def schema_contract_examples():
    """Return real engineering coordination records for the global schema contract."""
    S = importlib.import_module("_supervisor")
    f = ProjectFixture()
    try:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "registry"
            S.initialize(root, "schema-engineering", resources={"gpu-0": {"kind": "gpu", "capacity": 1}},
                         budget={"cost": 1}, at=START)
            S.register_route(root, "schema-register", 0, {
                "route_id": "engineering-route", "project_root": str(f.root),
                "owner": {"agent_id": "engineering-agent", "chat_id": "engineering-chat", "model": "unspecified"},
                "repository": "engineering-repository", "branch": "routes/schema", "workspace": str(Path(directory) / "work"),
                "goal": "Engineering schema validation", "scope": ["engineering"], "budget": {"cost": 1},
                "writer": True, "status": "active", "overlay": {"path": ["P01", "P02"], "current_node": "P02",
                "next_node": "I01", "last_evidence": copy.deepcopy(f.source)}}, at=START)
            S.reserve(root, "schema-reserve", 1, {"lease_id": "engineering-lease", "route_id": "engineering-route",
                "resources": {"gpu-0": 1}, "budget": {"cost": 1}, "expires_at": "2026-10-03T00:01:00Z"}, at=START)
            registry = S.replay(root)
            return copy.deepcopy({
                "supervisor-registry": (registry, "head_digest"),
                "supervisor-event": (registry["events"][0], "request_digest"),
                "route-checkpoint": (registry["state"]["routes"]["engineering-route"]["checkpoint"], "observed_at"),
                "resource-lease": (registry["state"]["leases"]["engineering-lease"], "fencing_token")})
    finally:
        f.close()


class SupervisorTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(importlib.util.find_spec("_supervisor"),
                             "Executable shared route supervisor is missing")
        self.S = importlib.import_module("_supervisor")
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "supervisor"
        self.f = ProjectFixture()
        self.S.initialize(self.root, "engineering-supervisor", resources={
            "gpu-0": {"kind": "gpu", "capacity": 1},
            "worker-pool": {"kind": "other", "capacity": 2}},
            budget={"cost": 10, "seconds": 1000}, stale_after_seconds=60, at=START)

    def tearDown(self):
        if hasattr(self, "f"):
            self.f.close()
            self.tmp.cleanup()

    def revision(self):
        return self.S.replay(self.root)["revision"]

    def route(self, route_id="route-a", project=None, **changes):
        value = {"route_id": route_id, "project_root": str((project or self.f).root),
                 "owner": {"agent_id": "agent-" + route_id, "chat_id": "chat-" + route_id,
                           "model": "unspecified"},
                 "repository": "engineering-repository", "branch": "routes/" + route_id,
                 "workspace": str(Path(self.tmp.name) / ("work-" + route_id)),
                 "goal": "Verify existing project ledger coordination",
                 "scope": ["engineering coordination"], "budget": {"cost": 8, "seconds": 800},
                 "writer": True, "status": "active",
                 "overlay": {"path": ["P01", "P02"], "current_node": "P02", "next_node": "I01",
                             "last_evidence": copy.deepcopy((project or self.f).source)}}
        value.update(changes)
        return value

    def register(self, route_id="route-a", project=None, **changes):
        value = self.route(route_id, project, **changes)
        return self.S.register_route(self.root, "register-" + route_id,
                                     self.revision(), value, at=START)

    def checkpoint(self, route_id="route-a", **changes):
        route = self.S.replay(self.root)["state"]["routes"][route_id]
        value = {"route_id": route_id, "expected_route_revision": route["revision"],
                 "kind": "verified", "observed_at": START, "summary": "Engineering milestone",
                 "status": "active", "blockers": [], "changed_results": False,
                 "overlay": copy.deepcopy(route["overlay"]), "lease_tokens": []}
        value.update(changes)
        return value

    def reserve(self, lease_id="lease-a", route_id="route-a", amount=1, budget=None, at=START):
        return self.S.reserve(self.root, "reserve-" + lease_id, self.revision(), {
            "lease_id": lease_id, "route_id": route_id, "resources": {"gpu-0": amount},
            "budget": budget or {}, "expires_at": "2026-10-03T00:01:00Z"}, at=at)

    def assertCode(self, code, call):
        with self.assertRaises(C.Failure) as caught:
            call()
        self.assertEqual(caught.exception.code, code)

    def test_empty_registry_has_no_invented_routes_and_names_missing_destination(self):
        overview = self.S.overview(self.root, at=START)
        self.assertEqual(overview["routes"], [])
        self.assertIn("DURABLE_DESTINATION_MISSING", overview["coordination_blockers"])
        self.assertEqual(overview["durability"]["status"], "local_only")
        self.assertEqual(os.stat(self.root / "registry.json").st_mode & 0o777, 0o600)
        self.assertEqual(os.stat(self.root).st_mode & 0o777, 0o700)

    def test_registration_imports_real_canonical_ledger_and_map_overlay(self):
        result = self.register()
        route = self.S.replay(self.root)["state"]["routes"]["route-a"]
        state, _, anchor = C.project(self.f.root)
        self.assertEqual(result["revision"], 1)
        self.assertEqual(route["project_id"], state["project_id"])
        self.assertEqual(route["imported_state"]["head_digest"], anchor["head_digest"])
        self.assertEqual(route["imported_state"]["state"], state)
        self.assertEqual(route["checkpoint"]["verification"], "verified_project_ledger")
        self.assertEqual(route["overlay"]["next_node"], "I01")
        self.assertEqual(self.S.overview(self.root, at=START)["routes"][0]["classification"], "fresh")

    def test_multiple_routes_share_a_project_and_other_projects_remain_independent(self):
        self.register()
        self.register("route-b")
        other = ProjectFixture("I")
        try:
            self.register("route-c", other, repository="other-repository")
            state = self.S.replay(self.root)["state"]
            self.assertEqual(len(state["projects"]), 2)
            self.assertEqual(len(state["routes"]), 3)
            self.assertEqual(state["routes"]["route-a"]["project_id"], state["routes"]["route-b"]["project_id"])
            self.assertNotEqual(state["routes"]["route-a"]["project_id"], state["routes"]["route-c"]["project_id"])
        finally:
            other.close()

    def test_active_writers_cannot_share_branch_or_overlapping_workspace(self):
        self.register()
        a = self.S.replay(self.root)["state"]["routes"]["route-a"]
        self.assertCode("WRITER_BRANCH_CONFLICT", lambda: self.register("route-b", branch=a["branch"]))
        self.assertCode("WRITER_WORKSPACE_CONFLICT", lambda: self.register("route-b", workspace=a["workspace"] + "/child"))
        self.assertEqual(self.revision(), 1)

    def test_read_only_route_can_share_workspace_and_branch(self):
        self.register()
        a = self.S.replay(self.root)["state"]["routes"]["route-a"]
        self.register("reader", writer=False, workspace=a["workspace"], branch=a["branch"])
        self.assertEqual(len(self.S.overview(self.root, at=START)["routes"]), 2)

    def test_registry_cas_and_request_idempotency_prevent_old_update_overwrite(self):
        request = self.route()
        first = self.S.register_route(self.root, "same-request", 0, request, at=START)
        duplicate = self.S.register_route(self.root, "same-request", 0, request, at=LATER)
        self.assertEqual(first, duplicate)
        self.assertEqual(self.revision(), 1)
        self.assertCode("REGISTRY_REVISION_CONFLICT", lambda: self.S.register_route(
            self.root, "old-request", 0, self.route("route-b"), at=START))
        changed = copy.deepcopy(request)
        changed["goal"] = "A different goal"
        self.assertCode("REQUEST_ID_REUSED", lambda: self.S.register_route(
            self.root, "same-request", 0, changed, at=START))

    def test_checkpoint_cas_and_observation_time_reject_old_reports(self):
        self.register()
        old = self.checkpoint()
        current = self.checkpoint(observed_at="2026-10-03T00:00:30Z")
        self.S.checkpoint_route(self.root, "checkpoint-1", 1, current, at="2026-10-03T00:00:30Z")
        self.assertCode("ROUTE_REVISION_CONFLICT", lambda: self.S.checkpoint_route(
            self.root, "checkpoint-old", 2, old, at="2026-10-03T00:00:40Z"))
        old = self.checkpoint(observed_at=START)
        self.assertCode("OLD_CHECKPOINT", lambda: self.S.checkpoint_route(
            self.root, "checkpoint-old-time", 2, old, at="2026-10-03T00:00:40Z"))

    def test_manual_checkpoint_is_explicitly_unverified_and_cannot_patch_scientific_state(self):
        self.register()
        prior_state = (self.f.root / "research-state.json").read_bytes()
        report = self.checkpoint(kind="manual", source="user-reported chat milestone")
        report["reported_state"] = {"gate_state": "pass", "validation_state": "pass"}
        self.S.checkpoint_route(self.root, "manual-1", 1, report, at=START)
        route = self.S.replay(self.root)["state"]["routes"]["route-a"]
        self.assertEqual(route["checkpoint"]["verification"], "unverified_manual_report")
        self.assertEqual(route["imported_state"]["state"]["gate_state"], "not_ready")
        self.assertEqual((self.f.root / "research-state.json").read_bytes(), prior_state)
        self.assertIn("MANUAL_CHECKPOINT_UNVERIFIED", self.S.overview(self.root, at=START)["routes"][0]["reason_codes"])

    def test_verified_checkpoint_reads_latest_project_state_without_advancing_it(self):
        self.register()
        self.f.transition("update_evidence")
        before = (self.f.root / "event-ledger.jsonl").read_bytes()
        self.S.checkpoint_route(self.root, "verified-1", 1, self.checkpoint(), at=START)
        route = self.S.replay(self.root)["state"]["routes"]["route-a"]
        self.assertEqual(route["imported_state"]["sequence"], 2)
        self.assertEqual((self.f.root / "event-ledger.jsonl").read_bytes(), before)

    def test_canonical_rollback_cannot_replace_a_newer_import(self):
        files = {name: (self.f.root / name).read_bytes() for name in
                 ("event-ledger.jsonl", "ledger-anchor.json", "research-state.json")}
        self.register()
        self.f.transition("update_evidence")
        self.S.checkpoint_route(self.root, "import-new", 1, self.checkpoint(), at=START)
        for name, data in files.items():
            (self.f.root / name).write_bytes(data)
        self.assertCode("CANONICAL_STATE_ROLLBACK", lambda: self.S.checkpoint_route(
            self.root, "import-old", 2, self.checkpoint(), at=START))
        self.assertEqual(self.S.overview(self.root, at=START)["routes"][0]["classification"], "conflicts")

    def test_higher_sequence_fork_cannot_replace_a_verified_ancestor(self):
        baseline = {name: (self.f.root / name).read_bytes() for name in
                    ("event-ledger.jsonl", "ledger-anchor.json", "research-state.json")}
        self.register()
        self.f.transition("update_evidence")
        self.S.checkpoint_route(self.root, "import-ancestor", 1, self.checkpoint(), at=START)
        for name, data in baseline.items():
            (self.f.root / name).write_bytes(data)
        self.f.transition("update_evidence")
        self.f.transition("update_evidence")
        self.assertCode("CANONICAL_HISTORY_CONFLICT", lambda: self.S.checkpoint_route(
            self.root, "import-fork", 2, self.checkpoint(), at=START))
        self.assertEqual(self.S.overview(self.root, at=START)["routes"][0]["classification"], "conflicts")

    def test_stale_and_unavailable_sources_are_reported_from_real_records(self):
        self.register()
        self.assertEqual(self.S.overview(self.root, at=LATER)["routes"][0]["classification"], "stale")
        (self.f.root / "ledger-anchor.json").unlink()
        view = self.S.overview(self.root, at=START)["routes"][0]
        self.assertEqual(view["classification"], "blocked")
        self.assertIn("CANONICAL_STATE_UNAVAILABLE", view["reason_codes"])

    def test_capacity_denial_is_recorded_as_blocked_without_double_reserving_gpu(self):
        self.register()
        self.register("route-b")
        first = self.reserve()
        denied = self.reserve("lease-b", "route-b")
        self.assertEqual(first["status"], "reserved")
        self.assertEqual(denied["status"], "blocked")
        self.assertIn("RESOURCE_CAPACITY_CONFLICT", denied["reason_codes"])
        views = {r["route_id"]: r for r in self.S.overview(self.root, at=START)["routes"]}
        self.assertEqual(views["route-b"]["classification"], "blocked")
        self.assertEqual(len(self.S.query_leases(self.root, at=START)["active"]), 1)

    def test_expired_lease_releases_capacity_and_increments_fencing_token(self):
        self.register()
        first = self.reserve()
        self.register("route-b")
        second = self.S.reserve(self.root, "reserve-after-expiry", self.revision(), {
            "lease_id": "lease-b", "route_id": "route-b", "resources": {"gpu-0": 1}, "budget": {},
            "expires_at": "2026-10-03T00:04:00Z"}, at=LATER)
        self.assertGreater(second["fencing_token"], first["fencing_token"])
        self.assertCode("LEASE_EXPIRED", lambda: self.S.assert_lease(
            self.root, "lease-a", "route-a", first["fencing_token"], at=LATER))
        self.assertTrue(self.S.assert_lease(self.root, "lease-b", "route-b", second["fencing_token"], at=LATER))
        self.assertCode("FENCING_TOKEN_MISMATCH", lambda: self.S.assert_lease(
            self.root, "lease-b", "route-b", first["fencing_token"], at=LATER))

    def test_expired_worker_cannot_submit_a_fenced_checkpoint(self):
        self.register()
        first = self.reserve()
        report = self.checkpoint(observed_at=LATER, lease_tokens=[{
            "lease_id": "lease-a", "fencing_token": first["fencing_token"]}])
        self.assertCode("LEASE_EXPIRED", lambda: self.S.checkpoint_route(
            self.root, "late-worker", self.revision(), report, at=LATER))

    def test_expired_and_released_leases_keep_unsettled_budget_reserved(self):
        self.register()
        first = self.reserve(budget={"cost": 7})
        self.register("route-b")
        denied = self.S.reserve(self.root, "over-budget", self.revision(), {
            "lease_id": "lease-b", "route_id": "route-b", "resources": {"gpu-0": 1}, "budget": {"cost": 4},
            "expires_at": "2026-10-03T00:04:00Z"}, at=LATER)
        self.assertIn("GLOBAL_BUDGET_EXCEEDED", denied["reason_codes"])
        self.S.release(self.root, "release-a", self.revision(), {
            "lease_id": "lease-a", "route_id": "route-a", "fencing_token": first["fencing_token"]}, at=LATER)
        accounting = self.S.overview(self.root, at=LATER)["budget_accounting"]
        self.assertEqual(accounting["held"]["cost"], 7)
        self.S.record_usage(self.root, "settlement-a", self.revision(), {
            "lease_id": "lease-a", "route_id": "route-a", "fencing_token": first["fencing_token"],
            "usage": {"cost": 3}, "final": True, "receipt": "engineering-fixture/no-external-operation"}, at=LATER)
        accounting = self.S.overview(self.root, at=LATER)["budget_accounting"]
        self.assertEqual(accounting["spent"]["cost"], 3)
        self.assertEqual(accounting["held"].get("cost", 0), 0)

    def test_route_budget_and_unknown_budget_limits_fail_closed(self):
        self.register(budget={"cost": 2})
        denied = self.reserve(budget={"cost": 3})
        self.assertIn("ROUTE_BUDGET_EXCEEDED", denied["reason_codes"])
        unknown = self.reserve("unknown-budget", budget={"api_tokens": 1})
        self.assertIn("BUDGET_LIMIT_UNKNOWN", unknown["reason_codes"])

    def test_gpu_count_cannot_be_fractionally_shared(self):
        self.register()
        self.assertCode("INTEGER_GPU_RESOURCE_REQUIRED", lambda: self.reserve(amount=0.5))

    def test_gpu_inventory_requires_whole_device_counts(self):
        self.assertCode("INTEGER_GPU_CAPACITY_REQUIRED", lambda: self.S.initialize(
            Path(self.tmp.name) / "fractional-inventory", "fractional-supervisor",
            resources={"gpu-0": {"kind": "gpu", "capacity": 0.5}}, at=START))

    def test_workspace_lease_cannot_be_fractionally_shared(self):
        other = Path(self.tmp.name) / "workspace-registry"
        self.S.initialize(other, "workspace-supervisor", resources={
            "workspace-0": {"kind": "workspace", "capacity": 1}}, at=START)
        self.S.register_route(other, "workspace-register", 0, self.route(), at=START)
        self.assertCode("WORKSPACE_RESOURCE_EXCLUSIVE", lambda: self.S.reserve(other, "half-workspace", 1, {
            "lease_id": "workspace-lease", "route_id": "route-a", "resources": {"workspace-0": 0.5},
            "budget": {}, "expires_at": "2026-10-03T00:01:00Z"}, at=START))

    def test_conflicting_workspace_leases_are_blocked_until_release(self):
        other = Path(self.tmp.name) / "workspace-registry"
        self.S.initialize(other, "workspace-supervisor", resources={
            "workspace-0": {"kind": "workspace", "capacity": 1}}, at=START)
        self.S.register_route(other, "workspace-register-a", 0, self.route(), at=START)
        self.S.register_route(other, "workspace-register-b", 1, self.route("route-b"), at=START)
        request = {"lease_id": "workspace-a", "route_id": "route-a", "resources": {"workspace-0": 1},
                   "budget": {}, "expires_at": "2026-10-03T00:01:00Z"}
        first = self.S.reserve(other, "workspace-reserve-a", 2, request, at=START)
        denied = self.S.reserve(other, "workspace-reserve-b", 3,
                              {**request, "lease_id": "workspace-b", "route_id": "route-b"}, at=START)
        self.assertEqual(denied["status"], "blocked")
        self.S.release(other, "workspace-release", 4, {"lease_id": "workspace-a", "route_id": "route-a",
                       "fencing_token": first["fencing_token"]}, at=START)
        allowed = self.S.reserve(other, "workspace-reserve-c", 5,
                                {**request, "lease_id": "workspace-c", "route_id": "route-b"}, at=START)
        self.assertEqual(allowed["status"], "reserved")
        self.assertGreater(allowed["fencing_token"], first["fencing_token"])

    def test_lease_release_and_usage_are_idempotent_and_bound_to_owner(self):
        self.register()
        first = self.reserve(budget={"cost": 4})
        request = {"lease_id": "lease-a", "route_id": "route-a", "fencing_token": first["fencing_token"]}
        released = self.S.release(self.root, "release-a", self.revision(), request, at=START)
        self.assertEqual(released, self.S.release(self.root, "release-a", 2, request, at=LATER))
        self.assertCode("LEASE_OWNER_MISMATCH", lambda: self.S.release(self.root, "wrong-owner", self.revision(),
            {**request, "route_id": "other-route"}, at=START))
        self.assertEqual(self.S.query_leases(self.root, at=START)["active"], [])

    def test_registry_replay_detects_tampered_event_and_projection(self):
        self.register()
        path = self.root / "registry.json"
        original = path.read_text()
        tampered = json.loads(original)
        tampered["events"][0]["payload"]["route"]["goal"] = "tampered"
        path.write_text(canonical(tampered) + "\n")
        self.assertCode("REGISTRY_EVENT_DIGEST_MISMATCH", lambda: self.S.replay(self.root))
        tampered = json.loads(original)
        tampered["state"]["routes"]["route-a"]["goal"] = "projection-only tamper"
        path.write_text(canonical(tampered) + "\n")
        self.assertCode("REGISTRY_PROJECTION_MISMATCH", lambda: self.S.replay(self.root))

    def test_invalid_nodes_edges_and_evidence_cannot_enter_runtime_overlay(self):
        invalid = self.route()
        invalid["overlay"]["current_node"] = "invented-gate"
        self.assertCode("UNKNOWN_MAP_NODE", lambda: self.S.register_route(self.root, "bad-node", 0, invalid, at=START))
        invalid = self.route()
        invalid["overlay"]["next_node"] = "W01"
        self.assertCode("MAP_EDGE_MISSING", lambda: self.S.register_route(self.root, "bad-edge", 0, invalid, at=START))
        invalid = self.route()
        invalid["overlay"]["last_evidence"]["sha256"] = "0" * 64
        self.assertCode("EVIDENCE_DIGEST_MISMATCH", lambda: self.S.register_route(self.root, "bad-evidence", 0, invalid, at=START))
        self.assertEqual(self.revision(), 0)

    def test_changed_results_keep_upstream_validation_obligation(self):
        self.register()
        report = self.checkpoint(changed_results=True)
        self.S.checkpoint_route(self.root, "changed-results", 1, report, at=START)
        self.S.checkpoint_route(self.root, "routine-after-change", 2, self.checkpoint(), at=START)
        view = self.S.overview(self.root, at=START)["routes"][0]
        self.assertIn("UPSTREAM_VALIDATION_REQUIRED", view["reason_codes"])
        self.assertEqual(view["classification"], "blocked")
        self.assertCode("UPSTREAM_VALIDATION_NOT_ESTABLISHED", lambda: self.S.checkpoint_route(
            self.root, "fake-clear", 3, self.checkpoint(resolve_upstream_validation=True), at=START))

    def test_changed_results_in_one_route_warn_all_routes_of_the_same_project(self):
        self.register()
        self.register("writing-route")
        self.S.checkpoint_route(self.root, "result-change", 2, self.checkpoint(changed_results=True), at=START)
        views = {r["route_id"]: r for r in self.S.overview(self.root, at=START)["routes"]}
        self.assertIn("UPSTREAM_VALIDATION_REQUIRED", views["writing-route"]["reason_codes"])
        self.assertEqual(views["writing-route"]["classification"], "blocked")

    def test_upstream_clear_reads_anchored_validation_without_running_a_scorer(self):
        self.register()
        self.S.checkpoint_route(self.root, "change", 1, self.checkpoint(changed_results=True), at=START)
        from test_evidence_lifecycle import validated_project
        with mock.patch.object(C, "now", return_value="2026-10-03T00:00:30Z"):
            validated_project(self.f)
        with C.evaluation_runtime(native_replay_context=None):
            self.S.checkpoint_route(self.root, "validated", 2,
                self.checkpoint(resolve_upstream_validation=True, observed_at=LATER), at=LATER)
        self.assertNotIn("UPSTREAM_VALIDATION_REQUIRED", self.S.overview(self.root, at=LATER)["routes"][0]["reason_codes"])

    def test_saved_local_registry_can_attach_a_real_destination_and_preserve_routes(self):
        self.register()
        self.assertTrue(hasattr(self.S, "set_destination"))
        destination = {"kind": "repository", "uri": "private://existing-engineering-store", "private": True}
        self.S.set_destination(self.root, "attach", 1, {"destination": destination}, at=START)
        view = self.S.overview(self.root, at=START)
        self.assertEqual(view["durability"]["destination"], destination)
        self.assertEqual(view["durability"]["status"], "not_synced")
        self.assertEqual([r["route_id"] for r in view["routes"]], ["route-a"])
        self.assertEqual(self.S.replay(self.root)["revision"], 2)

    def test_paused_writer_must_release_live_lease_before_workspace_reuse(self):
        self.register()
        reserved = self.reserve()
        self.S.checkpoint_route(self.root, "pause", 2, self.checkpoint(status="paused"), at=START)
        a = self.S.replay(self.root)["state"]["routes"]["route-a"]
        self.assertCode("WRITER_BRANCH_CONFLICT", lambda: self.register("route-b", branch=a["branch"], workspace=a["workspace"]))
        self.assertCode("LEASE_OWNER_NOT_ACTIVE", lambda: self.S.assert_lease(self.root, "lease-a", "route-a", reserved["fencing_token"], at=START))
        self.S.release(self.root, "released", 3, {"lease_id": "lease-a", "route_id": "route-a", "fencing_token": reserved["fencing_token"]}, at=START)
        self.register("route-b", branch=a["branch"], workspace=a["workspace"])

    def test_html_and_mermaid_draw_recorded_paths_and_show_source_details(self):
        self.register()
        html_path = Path(self.tmp.name) / "map.html"
        self.S.export_overview(self.root, html_path, format="html", at=START)
        content = html_path.read_text()
        self.assertIn('<svg', content)
        self.assertEqual(content.count('data-map-region='), 16)
        self.assertEqual(content.count('data-map-node='), 84)
        self.assertEqual(content.count('data-map-edge='), 221)
        self.assertIn('data-route-step="0-0"', content)
        self.assertIn('chat-route-a', content)
        self.assertIn('Last evidence', content)
        self.assertIn('Budget', content)
        self.assertIn('Recorded path', content)
        mermaid = Path(self.tmp.name) / "paths.mmd"
        self.S.export_overview(self.root, mermaid, format="mermaid", at=START)
        self.assertIn('route_0_0 --> route_0_1', mermaid.read_text())
        self.assertIn('route_0_1 -.-> route_0_next', mermaid.read_text())

    def test_checkpoint_cannot_supply_a_fabricated_validation_resolution(self):
        self.register()
        report = self.checkpoint(validation_resolution={"resolved_by": "unseen scientific verdict"})
        self.assertCode("CHECKPOINT_VERIFICATION_IS_DERIVED", lambda: self.S.checkpoint_route(
            self.root, "fabricated-resolution", 1, report, at=START))

    def test_host_destination_and_receipts_do_not_fabricate_cloud_sync(self):
        destination = {"kind": "repository", "uri": "https://example.org/private/engineering-registry", "private": True}
        hosted = Path(self.tmp.name) / "hosted"
        self.S.initialize(hosted, "hosted-supervisor", destination=destination, at=START)
        view = self.S.overview(hosted, at=START)
        self.assertEqual(view["durability"]["status"], "not_synced")
        self.assertIn("HOST_WRITE_RECEIPT_MISSING", view["coordination_blockers"])
        receipt = {"destination": destination, "source_revision": 0, "source_head_digest": "1" * 64,
                   "source_sha256": C.filehash(hosted / "registry.json"),
                   "remote_revision_before": "previous", "remote_revision_after": "new",
                   "operation_id": "actual-host-write-needed", "readback_sha256": "0" * 64}
        self.assertCode("SYNC_SOURCE_MISMATCH", lambda: self.S.record_sync_receipt(
            hosted, "bad-receipt", 0, receipt, at=START))
        replay = self.S.replay(hosted)
        receipt["source_head_digest"] = replay["head_digest"]
        receipt["readback_sha256"] = receipt["source_sha256"]
        self.S.record_sync_receipt(hosted, "record-only", 0, receipt, at=START)
        self.assertEqual(self.S.overview(hosted, at=START)["durability"]["status"], "host_receipt_recorded")
        self.assertFalse(self.S.overview(hosted, at=START)["durability"]["independently_verified_by_helper"])

    def test_host_receipt_becomes_stale_after_a_route_checkpoint_and_old_head_is_rejected(self):
        hosted = Path(self.tmp.name) / "hosted"
        destination = {"kind": "drive", "uri": "https://example.org/private/registry", "private": True}
        self.S.initialize(hosted, "hosted-supervisor", destination=destination, at=START)
        self.S.register_route(hosted, "hosted-register", 0, self.route(), at=START)
        registry = self.S.replay(hosted)
        receipt = {"destination": destination, "source_revision": 1, "source_head_digest": registry["head_digest"],
                   "source_sha256": C.filehash(hosted / "registry.json"), "remote_revision_before": "remote-0",
                   "remote_revision_after": "remote-1", "operation_id": "record-only-engineering-fixture"}
        receipt["readback_sha256"] = receipt["source_sha256"]
        self.S.record_sync_receipt(hosted, "hosted-receipt", 1, receipt, at=START)
        route = self.S.replay(hosted)["state"]["routes"]["route-a"]
        report = {"route_id": "route-a", "expected_route_revision": 1, "kind": "verified", "observed_at": START,
                  "summary": "New engineering checkpoint", "status": "active", "blockers": [],
                  "changed_results": False, "overlay": route["overlay"], "lease_tokens": []}
        self.S.checkpoint_route(hosted, "new-checkpoint", 2, report, at=START)
        self.assertEqual(self.S.overview(hosted, at=START)["durability"]["status"], "unsynced_changes")
        self.assertCode("SYNC_SOURCE_MISMATCH", lambda: self.S.record_sync_receipt(
            hosted, "old-receipt-after-new-checkpoint", 3, receipt, at=START))

    def test_schema_examples_cover_valid_invalid_and_unsupported_coordination_records(self):
        for name, (value, remove_field) in schema_contract_examples().items():
            with self.subTest(schema=name):
                C.validate(value, name)
                broken = copy.deepcopy(value)
                broken.pop(remove_field)
                with self.assertRaises(C.Failure):
                    C.validate(broken, name)
                unsupported = copy.deepcopy(value)
                unsupported["schema_version"] = "99.0.0"
                with self.assertRaises(C.Failure):
                    C.validate(unsupported, name)

    def test_private_export_escapes_real_route_content_and_does_not_publish(self):
        self.register(goal="<script>alert('x')</script> engineering record")
        path = Path(self.tmp.name) / "overview.html"
        self.S.export_overview(self.root, path, format="html", at=START)
        content = path.read_text()
        self.assertIn("route-a", content)
        self.assertIn("&lt;script&gt;", content)
        self.assertNotIn("<script>alert", content)
        self.assertNotIn("http-equiv=\"refresh\"", content)
        self.assertEqual(os.stat(path).st_mode & 0o777, 0o600)
        mermaid = Path(self.tmp.name) / "overview.mmd"
        self.S.export_overview(self.root, mermaid, format="mermaid", at=START)
        self.assertIn("flowchart TD", mermaid.read_text())

    def test_cli_two_writers_have_exactly_one_winner_and_stable_json_errors(self):
        request_paths = []
        for name in ("one", "two"):
            path = Path(self.tmp.name) / (name + ".json")
            path.write_text(canonical(self.route(name)) + "\n")
            request_paths.append(path)
        processes = [subprocess.Popen([sys.executable, str(PACKAGE / "scripts/supervise_routes.py"),
            "register", "--root", str(self.root), "--request-id", "concurrent-" + path.stem,
            "--expected-revision", "0", "--request", str(path)], stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True) for path in request_paths]
        results = [(process.returncode, stdout, stderr) for process in processes
                   for stdout, stderr in [process.communicate(timeout=20)]]
        self.assertEqual(sum(code == 0 for code, _, _ in results), 1)
        failure = next(json.loads(stdout)["error"]["code"] for code, stdout, _ in results if code != 0)
        self.assertIn(failure, {"REGISTRY_REVISION_CONFLICT", "REGISTRY_BUSY"})
        self.assertEqual(self.revision(), 1)
        command = [sys.executable, str(PACKAGE / "scripts/supervise_routes.py"), "overview", "--root", str(self.root)]
        result = subprocess.run(command, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(len(json.loads(result.stdout)["routes"]), 1)


if __name__ == "__main__":
    unittest.main()
