# Work Harness C/D runtime contracts

Apply only to `work-harness-cd-v1`. Every `*_ref` is a real project-relative
`{path, sha256}` pin. Use unique immutable paths per revision; never invent a hash.
The controller supplies `sequence` including profile, epoch, problem and verified
handoff pins. Copy the entire binding unchanged. The exact runtime schema wins.

## Decisions and task inputs

`research-cd-decision`, `schema_version: 1` fields:
`goal_id`, `previous_ref` (accepted predecessor or null at intake), `stage`
(`diagnosis`, `development`, `scaleup`), `rationale`, `selected_task_ids` (exact
proposal task IDs, [] for acceptance), `evidence_refs`, `observed_receipt_refs`
(all previously observed and all fresh native receipts), `problem_ref`,
`mechanism_ref`, `verified_ref` (explicit null when not applicable).
The first C/D decision may extend the exact accepted legacy v4 decision. Never
rewrite a v4 artifact as though it had always had the new meaning.

Scientific child tasks bind `reasoning_ref`, `goal_id`, `candidate_id`,
`research_scope` diagnostic for C/B reproduction or method for D, and
`cd_evidence_ref`. C/D native jobs use `native_purpose: development`.

B01 remains the explicit setup exception: an already owner-authorized
baseline qualification uses `native_purpose: qualification`, its actual
authorization/instruction/target pins and baseline-only arms. It cannot carry
a treatment or substitute for C's comparative diagnosis or D's method evidence.

`cd_evidence_ref` is `kind: research-cd-experiment`, `schema_version: 1` with:
`flow_profile`, `stage`, `candidate_id`, `goal_id`, `question`, `assumptions`
(nonempty text list), `mathematical_object`, `prediction`, `falsifier`, `code_plan`,
`code_bindings` ({mathematical_object, code_ref, location} list), `benchmark_ref`,
`model_ref`, `dataset_ref`, `evaluation_ref`, `controls`
({name, rationale, implementation_refs} list), `uncertainty_plan`,
`exposure_log_ref`, `condition_source_refs`, `problem_ref`, `mechanism_ref`.
Code creation may start with empty code_bindings; native work must have real
mapped code and executed baseline/intervention/control arms. Diagnosis remains
scientific development even when it rejects the hypothesis.

Native plans retain standard scientific protocol/scorer/coverage/transfer rules.
Use `evidence_mode: developmental`; native provenance binds `cd_evidence_ref`.
Protocol `cd_development` is exactly `{flow_profile, stage, cd_evidence_ref}`.
Do not mix legacy method_discovery into this development route. A successful
training/export receipt with deferred scoring cannot close a scientific gate.

## Result and revisit fields

The standard current-step result retains all existing fields. The profile adds
optional `revisit_request` or `cd_gate_ref`; never combine a revisit with child
tasks or a gate. A revisit has `mode`, `origin` (full sequence binding), `target`,
`return_to`, `reason`, `expected_output`, `evidence_refs`. `visit` targets one of
L01/L02/L03/X02/L04/X03/L05 and returns to the origin node. `revise` targets an
earlier/current C/D node and uses `return_to: null`. Review approval must judge
the specific request; unfinished origin requirements are not marked satisfied.

## C problem gate

B05 tasks=[] without revisit must cite `cd_gate_ref`, kind
`research-cd-problem`, schema_version 1:
`goal_id`, `version`, `method`, `conditions`, `dependency_or_failure`,
`assumptions`, `observables`, `competing_explanations`, `intervention`,
`consequences`, `uncertainty` (nonempty explanatory text), `evidence_refs`,
`run_receipt_refs`, `scored_runs`.
Actual run receipts are controller-archived native executions, including their
retained source/output pins. `scored_runs` is a nonempty list of
`{protocol_ref, manifest_ref}` for actual completed canonical native manifests.
Each arm prediction pin must match a declared, collected and archived output of
a cited native execution with the same protocol, arm role, group and seed. A
manifest assembled later is allowed; unrelated/manually substituted predictions
are not evidence of that run. Declare prediction outputs before execution.
The fixed verifier replays the existing scorer on the pinned GPU target before
independent acceptance. A low measured quality in C can be a real failure;
reviewer still checks implementation and baseline competence before supporting it.

## D scaleup gate

M05 tasks=[] without revisit must cite `cd_gate_ref`, kind
`research-cd-scaleup`, schema_version 1:
`goal_id`, `problem_ref` (current accepted C contract), `mechanism_ref`,
`candidate_id`, `code_ref`, `method_code_refs`, `protocol_ref`, `run_receipt_refs`, `analysis_refs`,
`exposure_ref`, `scored_runs`, `e_obligations`, `obligations`.

`obligations` contains exactly one `{id, finding, evidence_refs}` for each:
- problem_supported
- math_code_correspondence
- real_benchmark_comparison
- strong_simple_controls
- mechanism_prediction
- uncertainty_and_practical_effect
- confounds_checked
- nearest_work
- negative_results_and_exposure
- scope_and_e_obligations

`e_obligations` contains distinct IDs from the successor coverage snapshot, still
pending or blocked. Retain full confirmation, scale, transfer and repetition
requirements as appropriate to the claim. Prose outside coverage is insufficient.
The fixed native verifier checks scored_runs; reviewer then judges whether the
measured effect and mechanism evidence warrant scaling. Valid JSON, exit0,
non-significant differences, isolated winning examples and unscored exports do
not establish VERIFIED_FOR_SCALEUP.

## E handoff

The method_code_refs array pins the complete treatment code set, including code_ref.
Changing this set requires a reviewed D revision; E may vary protocol parameters
and data while keeping the accepted method implementation fixed.

Program records the M05 acceptance and actual builtin scoring verification,
then automatically advances to S02. Formal protocol uses `cd_scaleup` exactly
`{flow_profile, verified_ref, acceptance_ref}` from trusted sequence binding;
`cd_problem_ref` equals its accepted problem. E comparison must use the accepted
method code and formal evidence mode; development data exposure remains visible.
Preserve formal method/code/design validation, fair S04, freezing, full coverage,
actual native scorer replay and scientific closure. The handoff replaces old
Gate0/IPCG prerequisites, not E confirmation evidence.
