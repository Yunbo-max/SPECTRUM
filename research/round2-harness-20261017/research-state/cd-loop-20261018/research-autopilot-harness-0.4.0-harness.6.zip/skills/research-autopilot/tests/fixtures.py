"""Synthetic acceptance inputs, independent of the implementation's schemas."""
import copy
import datetime as dt
import hashlib
import json
import pathlib
import sys
import tempfile
import types

PACKAGE = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE / "scripts"))
import _autoresearch as C

DATE = "2026-09-01T00:00:00Z"
DIGEST = "1" * 64

def env(name, **fields):
    return {"schema_id": name, "schema_version": "1.0.0", **fields}

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)

def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()

def ref(root, relative):
    return {"path": relative, "sha256": hashlib.sha256((root / relative).read_bytes()).hexdigest()}

def write(root, relative, value):
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(canonical(value) + "\n")
    return ref(root, relative)

def state(origin="M"):
    return env("research-state", project_id="fixture", project_name="Fixture", entry_origin=origin,
        current_route={"I":"explore_problem", "M":"audit_method", "R":"audit_rejection"}[origin],
        lifecycle_phase="landscape", sequence=1, operating_mode="audit", asset_stage="A1_method",
        evidence_trust="E0_narrative", claim_clarity="C1_question", literature_state="L0_unsearched",
        gate_state="not_ready", validation_state="not_ready", writing_state="not_ready",
        terminal_status="none", suspension=None)

def request():
    return env("authority-request", operation_id="op-1", action="launch_compute", account_identity="fixture-user",
        target="fixture-job", revision_precondition=DIGEST, asset_scope=["asset-public"], path_scope=["runs/op-1"],
        destination_service="fixture-compute", purpose="test", effect_digest=DIGEST, command=["python", "train.py"],
        budget={"cost":2.0,"seconds":60.0,"storage_bytes":1000.0,"egress_bytes":0.0},
        persistence="once", expires_at="2026-11-01T00:00:00Z")

def sample_artifacts():
    r = {"path":"evidence/source.json", "sha256":DIGEST}
    p = env("gate-a-protocol", protocol_id="p1", evidence_mode="prospective_confirmatory",
        evidence_snapshot_ref=r, seed_policy={"seeds":[1,2],"allow_extra":False}, min_valid_runs=2,
        required_groups=["main"], guardrails={"seconds":120}, design="paired", aggregation="mean",
        rounding_policy="none", missing_policy="inconclusive", claim_ids=["claim-1"],
        contrasts={"treatment":"memory", "baseline":"matched recurrent state", "controls":["positive","shuffled"]},
        eligibility={"unblinding":"after_freeze", "complete_inventory":True},
        project_version="1", method_version=DIGEST, provenance_constraints={"git_tree_digest": DIGEST},
        statistical_design={"unit":"seed", "independence_justification":"Non-evaluation engineering contract units", "clustered":False},
        multiple_comparison_policy="bonferroni",
        criteria=[{"id":"effect", "claim_id":"claim-1", "metric":"accuracy", "direction":"maximize",
          "min_effect":0.125,"inclusive":True,"indispensable":True,"min_runs":2,"uncertainty":"none","confidence":0.95,
          "inference":{"kind":"deterministic_finite","rationale":"Fixed engineering fixture values only; no stochastic or population inference."}}])
    run = env("run-manifest", run_id="r1", protocol_id="p1", protocol_digest=DIGEST, seed=1,group="main",
        status="completed", baseline_qualified=True, positive_control_passed=True, result_recorded_at=DATE,
        evidence_mode="prospective_confirmatory", metrics={"accuracy":{"treatment":0.75,"control":0.5}},
        resources={"seconds":10}, provenance={"git_revision":"abc", "git_tree_digest":DIGEST,
        "dirty_patch_digest":DIGEST,"submodules":{},"lfs_refs":[],"data_revision":"data-v1",
        "model_revision":"model-v1","environment_digest":DIGEST,"metric_code_digest":DIGEST,
        "hardware":"fixture-cpu","checkpoint_refs":[],"command":["python","fixture.py"]},raw_output_refs=[r])
    decision = env("gate-a-decision", decision_id="d1",protocol_id="p1",protocol_digest=DIGEST,
        outcome="PASS",reason_codes=["ALL_REQUIRED_CONTRASTS_PASS"],eligible_run_ids=["r1"],
        run_manifest_refs=[r],criteria_results=[{"criterion_id":"effect","passed":True}])
    grant = env("authority-grant",grant_id="g1",approved_by="fixture-user",trusted_approval_event_id="approval-1",
        request_digest=DIGEST,effect_digest=DIGEST,operation_id="op-1",action="launch_compute",
        account_identity="fixture-user",target="fixture-job",destination_service="fixture-compute",purpose="test",
        revision_precondition=DIGEST,asset_scope=["asset-public"],path_scope=["runs/op-1"],persistence="once",
        budget=request()["budget"],approved_at=DATE,expires_at="2026-11-01T00:00:00Z")
    return {
        "research-intake":env("research-intake",project={"name":"Fixture","one_sentence_goal":"test","operating_mode":"audit"},
            entry_inference={"value":"M","status":"confirmed","basis":["observed method"]},assets={},sources={}),
        "research-state":state(),
        "parent-problem-card":env("parent-problem-card",problem_id="problem-1",natural_failure="Natural task failure",population_id="agent-failures",
            population="Eligible real failed episodes",prevalence="Affected failures divided by all eligible failures",
            consequence={"endpoint":"task_success_loss","description":"Final task loss"},strong_simple_alternative="general solver",
            simple_alternatives=["general solver"],benchmark_contract={"benchmark_id":"fixture-task-suite","version":"fixture-v1",
                "task":"Complete multi-agent tasks","primary_metric":"task_success_loss","evaluation_split":"discovery",
                "resource_constraints":{"seconds":60},"relevance_to_natural_failure":"Same final task endpoint","source_evidence_refs":[r]},
            falsifiable_prediction="Task success recovers beyond the simple alternative",gate_0_thresholds={"min_cases":20,"min_affected":3,
                "min_prevalence":0.1,"min_mean_loss":0.05,"min_unresolved_fraction":0.2}),
        "natural-gate-0":env("natural-gate-0",census_id="n1",parent_problem_ref=r,observations_ref=r,outcome="PASS"),
        "importance-decision":env("importance-decision",decision_id="i1",outcome="CONCURRENT",parent_problem_ref=r,natural_gate_0_ref=r,
            retained_problem={"natural_failure":"Natural task failure","population_id":"agent-failures","endpoint":"task_success_loss",
                "strong_simple_alternative":"general solver","falsifiable_prediction":"Task success recovers beyond the simple alternative"},
            reason="Original task population and consequence retained",functional_collision_work_refs=[],exclusion_basis=[],evidence_refs=[r]),
        "authority-request":request(),
        "approval-event":env("approval-event",approval_event_id="approval-1",host_identity="fixture-host",grant_id="g1",
            request_digest=DIGEST,effect_digest=DIGEST,operation_id="op-1",decision="approved",timestamp=DATE),
        "authority-grant":grant,
        "ledger-event":env("ledger-event",sequence=1,transition_id="t1",event_type="initialize",reason_code="ORIGIN_CONFIRMED",
            evidence_refs=[],actor="orchestrator",timestamp=DATE,previous_event_digest="0"*64,event_digest=DIGEST,
            previous_state_digest="0"*64,request_digest=DIGEST,next_state=state(),payload={"entry_origin":"M"}),
        "ledger-anchor":env("ledger-anchor",lineage_id="fixture",sequence=1,head_digest=DIGEST),
        "commit-journal":env("commit-journal",previous_head=DIGEST,files={"event-ledger.jsonl":"{}\n","research-state.json":"{}\n","ledger-anchor.json":"{}\n"},deletions=[],transaction_digest=DIGEST),
        "backup-manifest":env("backup-manifest",source_head=DIGEST,source_sequence=1,files={"event-ledger.jsonl":"{}\n","research-state.json":"{}\n","ledger-anchor.json":"{}\n"}),
        "search-run":env("search-run",search_id="s1",query_strings=["memory"],query_families=["mechanism"],
            provider="fixture",provider_version="1",searched_at=DATE,cutoff="2026-09-01",filters={},
            pagination={"complete":True},requested_count=10,returned_count=1,raw_capture_refs=[r],
            parser_version="capture-json-v1",canonicalization_version="work-v1",deduplication_version="identifier-v1",
            normalized_output_digest=DIGEST),
        "work-record":env("work-record",work_id="doi:10.1/fixture",title="Fixture memory",authors=["Example Author"],
            primary_source=True,canonical_url="https://example.org/fixture",version="1",publication_date="2026-08-01",
            read_depth="D2",full_text_status="available",claims=["claim-1"],evidence_refs=[r]),
        "evidence-unit":env("evidence-unit",evidence_id="e1",work_id="doi:10.1/fixture",claim="claim-1",
            locators=[{"artifact_ref":r,"section":"Methods","page":2}],scope={"regime":"toy"},observed_fact="Bounded contrast."),
        "evidence-snapshot":env("evidence-snapshot",snapshot_id="s1",created_at=DATE,cutoff="2026-09-01",
            artifact_refs=[r],claim_ids=["claim-1"],negative_result_refs=[]),
        "idea-atom":env("idea-atom",candidate_id="c1",kind="research_candidate",question="Can memory preserve dependencies?",
            importance="Long context",literature_tension="Compression loss",bottleneck="Unresolved edges",
            minimal_intervention="Preserve edge state",causal_chain=["store","resolve"],dominant_claim="claim-1",
            unique_prediction="Reverse order recovery",falsifier="Matched memory works equally",simplest_alternative="Reread",
            closest_work_hypothesis="Recurrent state",decisive_test="Paired reversed edges",compute_estimate={"seconds":60},
            risks=["leakage"],source_evidence_refs=[r],necessity_case={
                "simple_alternatives_compared":["general constraint solver"],"unresolved_task_failure":"Wrong final task outputs",
                "expected_advantage":"Hypothesized task recovery beyond the simple solver",
                "decisive_comparison":"Paired final task success under identical resource limits",
                "memory_representation_change":False,"baseline_evidence_refs":[r]}),
        "collision-decision":env("collision-decision",decision_id="d1",candidate_id="c1",outcome="ADVANCE",evidence_refs=[r],
            search_run_refs=[r],work_refs=[r],essential_claim_coverage=["claim-1"],coverage={"required_families":["mechanism"],
            "completed_families":["mechanism"],"no_new_high_risk_batches":2,"decisive_full_text_verified":True,"priority_verified":True}),
        "gate-a-protocol":p,
        "full-validation-protocol":{**copy.deepcopy(p),"schema_id":"full-validation-protocol",
            "claim_set":["claim-1"],"indispensable_claim_ids":["claim-1"],"multiple_comparison_policy":"bonferroni",
            "inventory_run_ids":["r1","r2"],"manuscript_ref":r},
        "run-manifest":run,
        "gate-a-decision":decision,
        "full-validation-decision":{**copy.deepcopy(decision),"schema_id":"full-validation-decision"},
        "redaction-event":env("redaction-event",redaction_id="x1",path="source.json",old_digest=DIGEST,new_digest=DIGEST,
            reason_code="USER_REQUESTED",timestamp=DATE),
        "handoff":env("handoff",handoff_id="handoff-1",project_version="1",method_version=DIGEST,evidence_snapshot_ref=r,
            allowed_claims=["claim-1"],forbidden_claims=["generalization"],limitations=["toy"],negative_result_refs=[],
            source_refs=[r],venue={"mode":"AI"},stage="planning",unresolved_risks=[],provenance={"git_revision":"abc"})
    }

class ProjectFixture:
    def __init__(self, origin="M"):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = pathlib.Path(self.tmp.name) / "project"
        with C.locked(self.root):
            C.init_project(types.SimpleNamespace(name="Fixture",goal="Test bounded research",entry=origin,mode="audit"),self.root)
        self.source = write(self.root,"evidence/source.json",{"classification":"public","fixture":True})
        self.snapshot = copy.deepcopy(sample_artifacts()["evidence-snapshot"])
        self.snapshot["artifact_refs"]=[self.source]
        self.snapshot_ref = write(self.root,"evidence/snapshots/s1.json",self.snapshot)
        self.counter=0
        from test_native_eval import trusted_engineering_replay
        self.runtime = C.evaluation_runtime(native_replay_context=trusted_engineering_replay(self.root))
        self.runtime.__enter__()

    def close(self):
        self.runtime.__exit__(None, None, None)
        self.tmp.cleanup()

    def transition(self, outcome, payload=None, refs=None, tid=None, seq=None):
        self.counter+=1
        current=C.project(self.root)[0]
        value={"transition_id":tid or "t-"+str(self.counter),"expected_sequence":current["sequence"] if seq is None else seq,
            "outcome":outcome,"reason_code":"FIXTURE","evidence_refs":refs if refs is not None else [self.source],"payload":payload or {}}
        path=self.root/"request.json"
        path.write_text(canonical(value)+"\n")
        with C.locked(self.root):
            return C.transition(types.SimpleNamespace(request=str(path)),self.root)

    def protocol(self, gate="gate-a", frozen=True):
        p=copy.deepcopy(sample_artifacts()[gate+"-protocol"])
        p["evidence_snapshot_ref"]=self.snapshot_ref
        from test_native_eval import native_contract_fixture
        contract = native_contract_fixture(self.root, p)
        if gate == "full-validation":
            p["claim_cards"] = [{"claim_id": "claim-1", "supported_wording": "Bounded engineering contract statement",
                "forbidden_wording": ["Unrestricted scientific generalization"], "limitations": ["Engineering contract fixture only"],
                "method_version": p["method_version"], "project_version": p["project_version"],
                "scope": {"benchmark_id": contract["benchmark_id"], "version": contract["benchmark_revision"], "split": contract["split"],
                    "sample_manifest_ref": contract["sample_manifest_ref"], "metrics": ["accuracy"], "groups": ["main"], "budget": contract["budget"]}}]
        if gate=="full-validation":p["inventory_run_ids"]=["p1-r1-main","p1-r2-main"]
        if frozen:
            p["frozen_at"]=DATE
            p["protocol_digest"]=digest({k:v for k,v in p.items() if k not in {"frozen_at","protocol_digest"}})
        return p

    def runs(self, p, effects=(0.25,0.25), group="main"):
        manifests, refs=[],[]
        for i,effect in enumerate(effects,1):
            m=copy.deepcopy(sample_artifacts()["run-manifest"])
            m.update(run_id=p["protocol_id"]+"-r"+str(i)+"-"+group,seed=i,group=group,protocol_id=p["protocol_id"],
                protocol_digest=p["protocol_digest"],result_recorded_at=(C.stamp(p["frozen_at"])+dt.timedelta(seconds=1)).isoformat(),evidence_mode=p["evidence_mode"])
            m["metrics"]={"accuracy":{"treatment":0.5+effect,"control":0.5},"scope":{"treatment":0.25,"control":0.5}}
            raw={k:copy.deepcopy(m[k]) for k in ("run_id","seed","group","baseline_qualified","positive_control_passed","resources","metrics")}
            m["raw_output_refs"]=[write(self.root,"raw/"+m["run_id"]+".json",raw)]
            from test_native_eval import native_run_fixture
            native_run_fixture(self.root, p, m)
            refs.append(write(self.root,"runs/"+p["protocol_id"]+"/"+m["run_id"]+".json",m));manifests.append(m)
        return manifests,refs
