"""Software fixtures for figure rendering; never scientific benchmark evidence."""
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as ET


SCRIPT = Path(__file__).resolve().parents[1] / "scripts/publication_plot.py"
spec = importlib.util.spec_from_file_location("publication_plot", SCRIPT)
plot = importlib.util.module_from_spec(spec)
spec.loader.exec_module(plot)


class PublicationPlotTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.data = self.root / "results.csv"
        self.design = self.root / "spec.json"
        self.rows = [
            {"panel": "comparison", "series": s, "x": x, "y": "", "value": v,
             "lower": v - 1, "upper": v + 2}
            for s, x, v in [("Reference", "A", 11), ("Reference", "B", 12),
                            ("Candidate", "A", 13), ("Candidate", "B", 14)]
        ]
        self.config = {
            "source_status": "engineering_fixture",
            "evidence_refs": ["software-fixture-only"],
            "width_inches": 6.8, "height_inches": 3.6,
            "panels": [{"id": "comparison", "kind": "bar",
                        "title": "Engineering fixture", "xlabel": "Setting",
                        "ylabel": "Fixture value", "metric": "fixture_metric",
                        "units": "fixture_units", "better": "higher",
                        "aggregation": "supplied aggregate; no recomputation",
                        "sample_unit": "software case", "sample_count": 4,
                        "uncertainty": "fixture interval, not scientific uncertainty",
                        "selection_rule": "all four software cases"}]
        }

    def write(self):
        with self.data.open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["panel", "series", "x", "y", "value", "lower", "upper"])
            w.writeheader(); w.writerows(self.rows)
        self.config["source_sha256"] = hashlib.sha256(self.data.read_bytes()).hexdigest()
        self.design.write_text(json.dumps(self.config))

    def run_render(self):
        self.write()
        return plot.render(self.data, self.design, self.root / "export")

    def test_exports_keep_exact_inputs_and_live_svg_text(self):
        receipt = self.run_render()
        out = self.root / "export"
        self.assertEqual((out / "source-data.csv").read_bytes(), self.data.read_bytes())
        self.assertEqual((out / "figure-spec.json").read_bytes(), self.design.read_bytes())
        self.assertEqual(receipt["data_sha256"], self.config["source_sha256"])
        self.assertEqual(receipt["validation"]["scientific_verification"], "not_performed")
        self.assertEqual(receipt["validation"]["visual_inspection"], "not_performed")
        self.assertEqual(receipt["panels"][0]["bar_baseline"], 0)
        for extension in ["png", "pdf", "svg"]:
            self.assertGreater((out / ("figure." + extension)).stat().st_size, 100)
        svg = ET.parse(out / "figure.svg")
        labels = ["".join(e.itertext()) for e in svg.iter() if e.tag.endswith("}text")]
        self.assertIn("Engineering fixture", labels)
        self.assertEqual([r["value"] for r in receipt["panels"][0]["rows"]], [11, 12, 13, 14])
        with self.assertRaisesRegex(ValueError, "already contains"):
            plot.render(self.data, self.design, out)

    def test_all_supported_families_render(self):
        for kind in ["line", "scatter", "heatmap"]:
            with self.subTest(kind=kind):
                self.config["panels"][0]["kind"] = kind
                if kind == "heatmap":
                    self.config["panels"][0]["uncertainty"] = "not applicable"
                    self.rows = [{"panel": "comparison", "series": "Matrix", "x": x, "y": y,
                                  "value": v, "lower": "", "upper": ""}
                                 for x, y, v in [("A", "C", 1), ("B", "C", 2),
                                                 ("A", "D", 3), ("B", "D", 4)]]
                else:
                    for row in self.rows:
                        row["x"] = 1 if row["x"] in ["A", 1] else 2
                self.write()
                plot.render(self.data, self.design, self.root / kind)
                self.assertTrue((self.root / kind / "figure.pdf").exists())

    def test_rejects_nonfinite_and_duplicate_observations(self):
        for value in ["NaN", "inf", "-inf"]:
            self.rows[0]["value"] = value
            with self.assertRaisesRegex(ValueError, "finite"):
                self.run_render()
        self.rows[0]["value"] = 11
        self.rows.append(dict(self.rows[0]))
        with self.assertRaisesRegex(ValueError, "duplicate"):
            self.run_render()

    def test_rejects_fabricated_or_inverted_uncertainty(self):
        self.rows[0]["lower"] = ""
        with self.assertRaisesRegex(ValueError, "interval"):
            self.run_render()
        self.rows[0]["lower"] = 20
        with self.assertRaisesRegex(ValueError, "interval"):
            self.run_render()
        self.rows[0]["lower"] = 10
        self.config["panels"][0]["uncertainty"] = "not reported"
        with self.assertRaisesRegex(ValueError, "uncertainty"):
            self.run_render()

    def test_rejects_truncated_bars_and_hidden_values(self):
        for limits in [[10, 20], [0, 12]]:
            self.config["panels"][0]["ylim"] = limits
            with self.assertRaisesRegex(ValueError, "baseline|clip"):
                self.run_render()

    def test_rejects_missing_groups_and_unmapped_panels(self):
        self.rows.pop()
        with self.assertRaisesRegex(ValueError, "complete"):
            self.run_render()
        self.rows[0]["panel"] = "unmapped"
        with self.assertRaisesRegex(ValueError, "unknown panel"):
            self.run_render()

    def test_rejects_changed_source_and_missing_provenance(self):
        self.write()
        with self.data.open("a") as f:
            f.write("\n")
        with self.assertRaisesRegex(ValueError, "digest"):
            plot.render(self.data, self.design, self.root / "changed")
        self.config["evidence_refs"] = []
        with self.assertRaisesRegex(ValueError, "evidence_refs"):
            self.run_render()

    def test_series_identity_survives_subset_figures(self):
        self.config["series_order"] = ["Unplotted", "Candidate", "Reference"]
        first = self.run_render()
        self.rows = [r for r in self.rows if r["series"] == "Candidate"]
        self.write()
        second = plot.render(self.data, self.design, self.root / "subset")
        self.assertEqual(first["series_identity"]["Candidate"], second["series_identity"]["Candidate"])


if __name__ == "__main__":
    unittest.main()
