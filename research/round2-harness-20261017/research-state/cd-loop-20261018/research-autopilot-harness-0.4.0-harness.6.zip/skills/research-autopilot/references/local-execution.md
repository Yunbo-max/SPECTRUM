# Research with a local agent

Use [single-experiment batching](single-experiment-batching.md): one active
experiment program, sequential descending batch calibration (for example
64 → 32 → 16 → 8 → 4 → 2), preserved scientific semantics and measured useful
throughput/headroom. Queue other experiments; keep Chat within CPU/4 GB.

The local agent runs on the user's computer as the research supervisor and control
agent. It reads, reasons, edits code, selects work, submits jobs, monitors progress
and reviews results. Experiments run on the selected execution machine, commonly
an already authorized SSH GPU server. Main uses this same control role after the
human selects a Web GPT plan. Work and Simple choose in-field next actions within
the existing authorization. Local-agent ownership does not restrict computation
to the user's computer or require an LLM agent on the GPU server.

## Decide the execution target first

Apply [GPU intake and feasibility](gpu-intake-feasibility.md) before hardware-bound planning. Ask for the target only when missing; inspect actual GPU/VRAM/native precision through the selected project interpreter and record stage-specific feasibility.

At startup/resume and before an executable task, restore the project host/path map,
authorized SSH alias/connection, remote project and environment, source pin, live
or unknown jobs, allocations, budgets and pauses. Read existing project runbooks
and SSH configuration as needed without exposing credentials. A configured alias
alone does not grant project authority; reuse already authorized targets without
asking again. Do not infer that the control computer is the experiment machine.

Classify the action and choose its actual target. Lightweight reading, editing and
analysis may stay on the control computer when feasible. If the project already
uses an authorized SSH GPU target for training/evaluation, inspect and reuse it:
perform a bounded connection/readiness check, identify the actual host, project
directory, interpreter/environment, CPU/RAM/disk, allocated GPU UUIDs/VRAM, current
usage and queue/time limits there. A laptop resource snapshot cannot qualify the
GPU server. Local workload execution is a deliberate choice supported by scope
and capacity, never the automatic consequence of the words 'local agent'.

If a needed remote target is unavailable, retain the blocked workload and its
identity while continuing source/code work. Do not silently move heavy jobs onto
the user's computer, rent resources or substitute a different SSH host. Ask only
for genuinely missing target/access/authority information. Reconcile uncertain
existing jobs before any replacement launch.

## Put the pinned code on the execution machine

1. Identify the exact authorized repository, source commit and effective configs.
   Save/publish the local changes through the project's existing Git route, then
   fetch/pull that code on the selected GPU machine. Use fast-forward-only updates
   for a safe existing checkout; otherwise use an isolated checkout/worktree of
   the intended commit. Preserve remote edits and live runs' source trees. Never
   reset an active checkout or silently run a moving branch tip instead of the pin.
2. If the GPU host has no repository access, use the already authorized SSH file
   transfer/Git-bundle route for the pinned files. Record commit/patch identity and
   verify received hashes. Do not copy private keys or require remote LLM-agent
   credentials. A laptop commit/push does not prove remote deployment occurred.
3. Read back the remote commit, working directory, effective config and interpreter.
   Stage data/models and use their native environment/cache paths on that target.
   Keep a local-to-remote path map. Qualify dependencies and resource costs on the
   actual execution machine before launching the claim-relevant workload.
4. Record host, cwd, environment, immutable code/config/data identity, command,
   allocated devices, bounded budget and output locations in the existing plan and
   receipt records. These are placement facts, not new unsupported runner fields.

## Keep training and final scoring dependencies separate

Read native-scoring-stages.md and the project's real configuration before launch.
Reuse its supported deferred scoring/export mode when the final scorer is not
ready. Execute independent training/generation on the selected GPU host, save
the pinned checkpoints/predictions and run native scoring later. Final-scoring
isolation is not automatically a prerequisite for training. Preserve real online
feedback dependencies and keep unscored outputs separate from verified metrics.

## Submit, supervise and collect

Use the target's existing supported runner, scheduler or bounded native process
mechanism through SSH. Retain the actual remote job/attempt ID, process identity
and start time, state/log paths, source pin and resource account. SSH exit status
alone is not a training outcome; a local SSH-process PID is not the remote job PID.
Poll remote status/logs with bounded waits, inspect failures and check outputs.
An SSH disconnect is an unknown observation, not proof the remote job stopped:
reconnect and reconcile the original identity before retrying or launching anew.

Collect/read the actual remote logs, metrics, checkpoints and failures, verifying
their source/version and bytes. Keep raw outputs at their declared durable target;
retrieve useful result packets under the existing storage budget. The local agent
reviews evidence, repairs code when warranted, syncs a new pinned revision and
selects the next task. Preserve old receipts, negative findings and cumulative costs.
Main returns this packet to Web GPT/human review for consequential direction choices.

## Native execution and runner placement

No Docker anywhere: the control computer, SSH targets and any other selected host
must not install, start, build with or depend on Docker, Compose or Docker-in-Docker.
Use the existing native Conda/venv/system-Python environment and qualified native
training/scoring entry points. Inspect scripts for hidden Docker calls. Reading a
Dockerfile for dependencies is allowed; running it is not. Do not evade this rule
with another container runtime. If a faithful native route is unavailable, retain
that dependency gap and continue independent work rather than fabricate a scorer.

The optional Simple runner requires compatible Linux/Python on the machine where
it actually runs. A macOS/Windows control agent may supervise that runner on the
authorized Linux GPU server over SSH; it need not run the Linux runner on the
laptop or install another agent on the server. Alternatively use the project's
existing native execution mechanism and collect its real receipts. The full
ACP/SQLite/harness runtime is optional unless already selected by the project.
Read its host/runbook contracts when using it; do not claim a local queue measures,
reserves or enforces remote GPU/RAM resources. Account control and workload costs
separately, and coordinate jobs against their actual shared host/resource domains.

Across turns, use an actual supported continuation mechanism for the control agent.
A remote training process can continue after SSH closes without restarting the
decision agent. Record both states separately, preserve checkpoints and report a
missing decision-consumer capability honestly. Honor user pauses and existing limits.
Use project-cooperation.md for actual independent concurrent participants; same-
workspace children use disjoint writes and one integration owner.
