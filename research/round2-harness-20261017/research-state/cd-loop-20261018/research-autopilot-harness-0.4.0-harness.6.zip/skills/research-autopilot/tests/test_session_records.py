"""Operational recording tests; synthetic host inputs, no model/GPU execution."""
import concurrent.futures
import json
import pathlib
import subprocess
import sys
import tempfile
import unittest

from fixtures import C, DATE, PACKAGE

try:
    import session_records as R
except ModuleNotFoundError:
    R = None


def schema_contract_examples():
    return {"session-record": ({"schema_id": "session-record", "schema_version": "1.0.0",
        "record_id": "engineering-record", "recorded_at": DATE, "project_path": "/engineering/project",
        "source": "codex_hook", "event_name": "UserPromptSubmit", "session_id": None,
        "payload": {"prompt": "engineering fixture"}, "transcript_captures": []}, "payload")}


class SessionRecordTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(R, "automatic session recorder is missing")
        self.tmp = tempfile.TemporaryDirectory(prefix="session-record-engineering-")
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name) / "project"
        self.root.mkdir()
        self.codex_home = pathlib.Path(self.tmp.name) / "host"
        (self.codex_home / "sessions").mkdir(parents=True)

    def event(self, event="UserPromptSubmit", **fields):
        return {"hook_event_name": event, "session_id": "engineering-session",
                "turn_id": "engineering-turn", "cwd": str(self.root),
                "model": "host-reported-model", **fields}

    def read(self, result):
        return [json.loads(line) for line in pathlib.Path(result["events_path"]).read_text().splitlines()]

    def cli_hook(self, payload, root=None):
        return subprocess.run([sys.executable, str(PACKAGE / "scripts/session_records.py"),
            "hook", "--project", str(root or self.root), "--codex-home", str(self.codex_home),
            "--owner", "research-autopilot"], input=json.dumps(payload), text=True, capture_output=True)

    def test_enable_preserves_other_hooks_and_existing_model_settings(self):
        config = self.root / ".codex"
        config.mkdir()
        previous = {"description": "Existing hooks", "hooks": {"PostToolUse": [
            {"matcher": "Bash", "hooks": [{"type": "command", "command": "echo existing"}]}]}}
        (config / "hooks.json").write_text(json.dumps(previous))
        (config / "config.toml").write_text('model = "existing-model"\n[features]\nhooks = false\nother = true\n')
        result = R.enable(self.root, self.codex_home)
        import tomllib
        settings = tomllib.loads((config / "config.toml").read_text())
        self.assertEqual(settings, {"model": "existing-model", "features": {"hooks": True, "other": True}})
        installed = json.loads((config / "hooks.json").read_text())
        self.assertEqual(installed["hooks"]["PostToolUse"][0], previous["hooks"]["PostToolUse"][0])
        self.assertEqual(installed["description"], "Existing hooks")
        self.assertEqual(result["host_hook_trust"], "review_in_client")
        self.assertTrue(list((self.root / ".research-autopilot/records/setup-backups").glob("*hooks.json")))

    def test_enable_twice_does_not_duplicate_callbacks(self):
        R.enable(self.root, self.codex_home)
        before = (self.root / ".codex/hooks.json").read_bytes()
        R.enable(self.root, self.codex_home)
        self.assertEqual(before, (self.root / ".codex/hooks.json").read_bytes())

    def test_shutdown_and_interrupt_timeouts_fit_the_native_client_limit(self):
        R.enable(self.root, self.codex_home)
        config = json.loads((self.root / ".codex/hooks.json").read_text())
        for event in ("SessionEnd", "Interrupt"):
            handler = config["hooks"][event][-1]["hooks"][0]
            self.assertLessEqual(handler["timeout"], 3)
            self.assertGreaterEqual(handler["timeout"], 1)

    def test_installed_callback_runs_from_a_quoted_project_path(self):
        project = self.root / "spaces ' and $(literal)"
        project.mkdir()
        R.enable(project, self.codex_home)
        config = json.loads((project / ".codex/hooks.json").read_text())
        command = config["hooks"]["UserPromptSubmit"][-1]["hooks"][0]["command"]
        child = subprocess.run(["/bin/sh", "-c", command], input=json.dumps(self.event(prompt="记录输入")),
                               text=True, capture_output=True)
        self.assertEqual(child.returncode, 0, child.stderr)
        self.assertEqual(json.loads(child.stdout), {})
        files = list((project / ".research-autopilot/records/sessions").glob("*/events.jsonl"))
        self.assertEqual(json.loads(files[0].read_text())["payload"]["prompt"], "记录输入")

    def test_malformed_existing_configuration_is_not_overwritten(self):
        config = self.root / ".codex"
        config.mkdir()
        (config / "hooks.json").write_text('{"hooks": [invalid]')
        before = (config / "hooks.json").read_bytes()
        with self.assertRaises(ValueError): R.enable(self.root, self.codex_home)
        self.assertEqual(before, (config / "hooks.json").read_bytes())
        self.assertFalse((config / "config.toml").exists())

    def test_invalid_toml_does_not_install_part_of_the_recorder(self):
        config = self.root / ".codex"
        config.mkdir()
        previous = b'{"hooks": {"Stop": [{"hooks": [{"command": "existing"}]}]}}'
        (config / "hooks.json").write_bytes(previous)
        (config / "config.toml").write_text('model = [invalid')
        with self.assertRaises(ValueError): R.enable(self.root, self.codex_home)
        self.assertEqual((config / "hooks.json").read_bytes(), previous)
        self.assertEqual((config / "config.toml").read_text(), 'model = [invalid')

    def test_disable_removes_only_this_recorder_and_keeps_records(self):
        R.enable(self.root, self.codex_home)
        config = self.root / ".codex/hooks.json"
        data = json.loads(config.read_text())
        data["hooks"]["Stop"].append({"hooks": [{"type": "command", "command": "echo existing"}]})
        config.write_text(json.dumps(data))
        result = R.record_hook(self.root, self.event(prompt="retained"), self.codex_home)
        R.disable(self.root)
        data = json.loads(config.read_text())
        self.assertEqual(data["hooks"]["Stop"], [{"hooks": [{"type": "command", "command": "echo existing"}]}])
        self.assertEqual(self.read(result)[0]["payload"]["prompt"], "retained")

    def test_visible_prompt_identity_and_observed_utc_time_are_retained(self):
        result = R.record_hook(self.root, self.event(prompt="当前证据", permission_mode="default"), self.codex_home)
        record = self.read(result)[0]
        self.assertEqual(record["payload"]["prompt"], "当前证据")
        self.assertEqual(record["session_id"], "engineering-session")
        self.assertEqual(record["source"], "codex_hook")
        self.assertTrue(record["recorded_at"].endswith("Z"))
        C.validate(record, "session-record")

    def test_failed_tool_output_is_kept_without_filtering(self):
        result = R.record_hook(self.root, self.event("PreToolUse", tool_name="Bash", tool_use_id="call-1",
            tool_input={"command": "engineering-only-command"}), self.codex_home)
        R.record_hook(self.root, self.event("PostToolUse", tool_name="Bash", tool_use_id="call-1",
            tool_input={"command": "engineering-only-command"}, tool_response={"exit_code": 9, "stderr": "failure"}),
            self.codex_home)
        records = self.read(result)
        self.assertEqual(len(records), 2)
        self.assertEqual(records[1]["payload"]["tool_response"], {"exit_code": 9, "stderr": "failure"})
        self.assertEqual(records[0]["payload"]["tool_use_id"], records[1]["payload"]["tool_use_id"])

    def test_concurrent_callbacks_do_not_lose_or_interleave_json_lines(self):
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda i: R.record_hook(self.root, self.event(prompt=str(i) + "字" * 2000),
                                                          self.codex_home), range(24)))
        records = self.read(results[0])
        self.assertEqual(len(records), 24)
        self.assertEqual({r["payload"]["prompt"].split("字")[0] for r in records}, {str(i) for i in range(24)})
        self.assertEqual(len({r["record_id"] for r in records}), 24)

    def test_host_transcript_append_copies_only_new_bytes(self):
        source = self.codex_home / "sessions/engineering.jsonl"
        first = b'{"type":"agent_message","text":"engineering reply"}\n'
        second = b'{"type":"reasoning","text":"visible engineering summary"}\n'
        source.write_bytes(first)
        a = R.record_hook(self.root, self.event("Stop", transcript_path=str(source)), self.codex_home)
        source.write_bytes(first + second)
        b = R.record_hook(self.root, self.event("Stop", transcript_path=str(source)), self.codex_home)
        captures = [r["transcript_captures"][0] for r in self.read(b)]
        self.assertEqual([c["offset_start"] for c in captures], [0, len(first)])
        self.assertEqual(pathlib.Path(captures[0]["segment_path"]).read_bytes(), first)
        self.assertEqual(pathlib.Path(captures[1]["segment_path"]).read_bytes(), second)
        R.record_hook(self.root, self.event("SessionEnd", transcript_path=str(source)), self.codex_home)
        self.assertEqual(self.read(a)[-1]["transcript_captures"][0]["status"], "unchanged")

    def test_malformed_cursor_does_not_drop_a_valid_stop_event(self):
        source = self.codex_home / "sessions/engineering.jsonl"
        source.write_bytes(b'engineering transcript\n')
        result = R.record_hook(self.root, self.event("Stop", transcript_path=str(source)), self.codex_home)
        capture = self.read(result)[0]["transcript_captures"][0]
        cursor = pathlib.Path(capture["segment_path"]).parent / "cursor.json"
        cursor.write_text('[]')
        child = self.cli_hook(self.event("Stop", transcript_path=str(source)))
        self.assertEqual(child.returncode, 0, child.stderr)
        self.assertEqual(json.loads(child.stdout), {})
        records = self.read(result)
        self.assertEqual(len(records), 2)
        self.assertEqual(records[-1]["transcript_captures"][0]["status"], "unavailable")

    def test_missing_native_path_marks_the_capture_gap(self):
        result = R.record_hook(self.root, self.event("Stop", transcript_path=None), self.codex_home)
        capture = self.read(result)[0]["transcript_captures"][0]
        self.assertEqual(capture["status"], "unavailable")
        self.assertEqual(capture["reason"], "no_host_path")

    def test_transcript_truncation_starts_a_new_generation_without_deleting_old_bytes(self):
        source = self.codex_home / "sessions/engineering.jsonl"
        source.write_bytes(b'old-engineering-content\n')
        result = R.record_hook(self.root, self.event("Stop", transcript_path=str(source)), self.codex_home)
        source.write_bytes(b'new\n')
        R.record_hook(self.root, self.event("Stop", transcript_path=str(source)), self.codex_home)
        captures = [r["transcript_captures"][0] for r in self.read(result)]
        self.assertEqual([c["generation"] for c in captures], [1, 2])
        self.assertEqual(pathlib.Path(captures[0]["segment_path"]).read_bytes(), b'old-engineering-content\n')
        self.assertEqual(pathlib.Path(captures[1]["segment_path"]).read_bytes(), b'new\n')

    def test_same_size_transcript_rewrite_preserves_both_generations(self):
        source = self.codex_home / "sessions/engineering.jsonl"
        source.write_bytes(b'old\n')
        result = R.record_hook(self.root, self.event("Stop", transcript_path=str(source)), self.codex_home)
        source.write_bytes(b'new\n')
        R.record_hook(self.root, self.event("Stop", transcript_path=str(source)), self.codex_home)
        captures = [r["transcript_captures"][0] for r in self.read(result)]
        self.assertEqual([c["generation"] for c in captures], [1, 2])
        self.assertEqual([pathlib.Path(c["segment_path"]).read_bytes() for c in captures], [b'old\n', b'new\n'])

    def test_subagent_transcript_is_kept_with_parent_and_agent_identity(self):
        source = self.codex_home / "sessions/child.jsonl"
        source.write_bytes(b'visible-child-output\n')
        result = R.record_hook(self.root, self.event("SubagentStop", agent_id="child-1",
            agent_transcript_path=str(source)), self.codex_home)
        record = self.read(result)[0]
        self.assertEqual(record["payload"]["agent_id"], "child-1")
        self.assertEqual(record["transcript_captures"][0]["status"], "copied")

    def test_arbitrary_file_is_not_copied_as_a_native_transcript(self):
        private_file = self.codex_home / "auth.json"
        private_file.write_text("engineering credential sentinel")
        result = R.record_hook(self.root, self.event("Stop", transcript_path=str(private_file)), self.codex_home)
        capture = self.read(result)[0]["transcript_captures"][0]
        self.assertEqual(capture["status"], "unavailable")
        self.assertNotIn("segment_path", capture)

    def test_session_id_cannot_escape_the_record_directory(self):
        result = R.record_hook(self.root, self.event(session_id="../../outside", prompt="safe path"), self.codex_home)
        self.assertTrue(pathlib.Path(result["events_path"]).is_relative_to(self.root / ".research-autopilot/records"))
        self.assertEqual(self.read(result)[0]["session_id"], "../../outside")

    def test_missing_host_identity_stays_unknown(self):
        payload = self.event(prompt="identity not exposed")
        del payload["session_id"]
        result = R.record_hook(self.root, payload, self.codex_home)
        record = self.read(result)[0]
        self.assertIsNone(record["session_id"])
        self.assertEqual(pathlib.Path(result["events_path"]).parent.name, "unidentified")
        C.validate(record, "session-record")

    def test_logging_failure_warns_but_does_not_deny_or_modify_an_operation(self):
        (self.root / ".research-autopilot").write_text("unwritable log directory engineering fixture")
        child = self.cli_hook(self.event("PreToolUse", tool_name="Bash", tool_input={"command": "untouched"}))
        self.assertEqual(child.returncode, 0)
        output = json.loads(child.stdout)
        self.assertIn("systemMessage", output)
        self.assertEqual(set(output), {"systemMessage"})

    def test_permission_and_stop_callbacks_never_control_the_operation(self):
        for event in ("PermissionRequest", "Stop", "SubagentStop", "Interrupt"):
            with self.subTest(event=event):
                child = self.cli_hook(self.event(event, last_assistant_message="visible reply"))
                self.assertEqual(child.returncode, 0, child.stderr)
                self.assertEqual(json.loads(child.stdout), {})

    def test_invalid_hook_input_is_nonblocking_and_reports_a_gap(self):
        child = subprocess.run([sys.executable, str(PACKAGE / "scripts/session_records.py"), "hook", "--project",
            str(self.root)], input="invalid JSON", text=True, capture_output=True)
        self.assertEqual(child.returncode, 0)
        self.assertIn("systemMessage", json.loads(child.stdout))

    def test_symlinked_record_directory_does_not_write_to_another_location(self):
        outside = pathlib.Path(self.tmp.name) / "outside"
        outside.mkdir()
        (self.root / ".research-autopilot").symlink_to(outside, target_is_directory=True)
        child = self.cli_hook(self.event(prompt="do not redirect"))
        self.assertEqual(child.returncode, 0)
        self.assertIn("systemMessage", json.loads(child.stdout))
        self.assertEqual(list(outside.iterdir()), [])

    def test_decision_record_retains_rationale_evidence_and_route_as_a_declared_note(self):
        note = {"decision": "continue", "rationale": "one unresolved explanation", "evidence_refs": ["existing/run.json"],
                "alternatives": ["switch"], "map_node": "H03", "next_action": "inspect existing evidence"}
        result = R.record_decision(self.root, note, "engineering-session")
        record = self.read(result)[0]
        self.assertEqual(record["payload"], note)
        self.assertEqual(record["source"], "worker_decision_note")
        self.assertEqual(record["event_name"], "ResearchDecision")
        C.validate(record, "session-record")

    def test_interrupted_event_tail_is_retained_and_next_record_is_parseable(self):
        note = {"decision": "continue", "rationale": "engineering recovery check"}
        result = R.record_decision(self.root, note)
        path = pathlib.Path(result["events_path"])
        partial = b'{"record_id":"interrupted-engineering-record",'
        with path.open('ab') as handle:
            handle.write(partial)
        R.record_decision(self.root, note)
        records = self.read(result)
        self.assertEqual(len(records), 2)
        retained = records[-1]["recovered_event_tail"]
        self.assertEqual(pathlib.Path(retained["path"]).read_bytes(), partial)
        self.assertEqual(retained["bytes"], len(partial))
        C.validate(records[-1], "session-record")

    def test_complete_event_without_newline_is_preserved_before_next_append(self):
        note = {"decision": "continue", "rationale": "engineering newline recovery"}
        result = R.record_decision(self.root, note)
        path = pathlib.Path(result["events_path"])
        original = self.read(result)[0]
        path.write_bytes(path.read_bytes().removesuffix(b'\n'))
        R.record_decision(self.root, note)
        records = self.read(result)
        self.assertEqual(len(records), 2)
        self.assertEqual(records[0], original)
        self.assertNotIn("recovered_event_tail", records[1])

    def test_empty_decision_note_is_not_presented_as_a_saved_explanation(self):
        with self.assertRaises(ValueError): R.record_decision(self.root, {"decision": "", "rationale": ""})
