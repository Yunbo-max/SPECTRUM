"""Current Chat control joins using explicit synthetic contracts and real files."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from test_chat_cycle import C
from chat_control_fixtures import ChatControlFixture


class ChatControlIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.path = self.root / 'state.json'
        self.f = ChatControlFixture(self.root, C)
        self.addCleanup(self.f.close)
        self.config = dict(goal_id='integration', goal='Investigate fixed engineering assertions',
            goal_contract=dict(mode='research', request_ref=self.f.source,
                               continuation_action='Resolve remaining fixed engineering assertions'),
            criteria=['verified'], deliveries=[], budget={'max_attempts': 20},
            procedure=dict(id='procedure-original', ref=self.f.source), tasks=[])

    def task(self, name, kind='action', dependencies=()):
        return dict(id=name, action='Perform engineering task ' + name, candidate_id='c',
                    kind=kind, dependencies=list(dependencies), input_refs=[])

    def init(self, tasks, controls=True):
        config = dict(copy.deepcopy(self.config), tasks=tasks)
        C.initialize(self.path, self.f.configure(config) if controls else config)
        if controls:
            self.f.activate(self.path)

    def event(self, op, **fields):
        return C.record(self.path, C.status(self.path)['revision'], dict(op=op, **fields))

    def advance(self):
        return C.advance(self.path, C.status(self.path)['revision'])

    def settle(self, attempt, outcome='completed', **extra):
        raw = self.f.write('actual-fixture-output', {'attempt': attempt['id'], 'result': outcome})
        evidence = self.f.write('envelope', dict(attempt_id=attempt['id'], task_id=attempt['task_id'],
            candidate_id=attempt['candidate_id'], procedure_id=attempt['procedure']['id'],
            outcome=outcome, raw_evidence=[raw], criteria_met=[], delivery_receipts={}))
        return self.event('result', attempt_id=attempt['id'], outcome=outcome, evidence_ref=evidence,
            reason='Engineering observation', next_action='Repair the measured fault',
            strategy_usage=self.f.usage(attempt['id'], [raw]), **extra)

    def test_unmigrated_research_is_readable_but_does_not_spend_dispatch_budget(self):
        self.init([self.task('first')], controls=False)
        before = self.path.read_bytes()
        self.assertEqual(self.advance()['reason'], 'strategy_migration_required')
        self.assertEqual(C.status(self.path)['started_attempts'], 0)
        self.assertEqual(self.path.read_bytes(), before)

    def test_new_invocation_cannot_resume_partial_using_old_bootstrap(self):
        self.init([self.task('first')])
        attempt = self.advance()['attempt']
        partial = self.f.write('partial', 'Observed partial engineering artifact')
        self.event('checkpoint', attempt_id=attempt['id'], reason='length_limit',
                   next_action='Continue original partial', evidence_refs=[partial])
        S = C._science_module('chat_session')
        with S.host_invocation('new-current-invocation'):
            before = self.path.read_bytes()
            blocked = self.advance()
            self.assertEqual(blocked['reason'], 'session_bootstrap_required')
            self.assertEqual(self.path.read_bytes(), before)
            self.f.invocation_id = 'new-current-invocation'
            state = C.status(self.path)
            self.event(**self.f.bootstrap_event(state))
            resumed = self.advance()
            self.assertEqual(resumed['kind'], 'execute')
            self.assertEqual(resumed['attempt']['id'], attempt['id'])
            self.assertEqual(resumed['attempt']['procedure'], attempt['procedure'])
            self.assertEqual(resumed['checkpoint_refs'], [partial])

    def test_classified_main_repair_precedes_ready_supplementary_work(self):
        self.init([self.task('main'), self.task('nearby')])
        first = self.advance()['attempt']
        self.assertEqual(first['task_id'], 'main')
        self.settle(first, 'failed', failure_class='implementation')
        next_work = self.advance()
        self.assertEqual(next_work['kind'], 'execute', next_work)
        state = C.status(self.path)
        repair = next(t for t in state['tasks'] if t['id'] == next_work['attempt']['task_id'])
        self.assertEqual(repair['repairs'], 'main')
        self.assertEqual(next(t for t in state['tasks'] if t['id'] == 'nearby')['status'], 'pending')
        self.assertEqual(state['attempts'][0]['outcome'], 'failed')
        self.assertEqual(repair['intent_ref'], first['intent_ref'])

    def test_pause_survives_version_policy_and_goal_revision_until_new_user_request(self):
        self.init([self.task('first')])
        stop = self.f.write('user-stop', 'User requested pause of research')
        self.event('pause', request_ref=stop, reason='Actual pause fixture')
        state = C.status(self.path)
        self.event('session_policy', contract=state['session_contract'], source_ref=self.f.source,
                   reason='Maintenance reread; no research resumption')
        self.event('revise_goal', goal=state['goal'], goal_contract=state['goal_contract'],
                   criteria=state['criteria'], deliveries=state['deliveries'])
        self.assertEqual(self.advance()['reason'], 'user_stopped')
        with self.assertRaisesRegex(ValueError, 'new user request'):
            self.event('resume_goal', request_ref=stop, reason='Cannot reuse stop as resume')
        resumed = self.f.write('user-resume', 'User explicitly authorizes resuming this paused fixture')
        self.event('resume_goal', request_ref=resumed, reason='New user request')
        self.f.activate(self.path)
        self.assertEqual(self.advance()['kind'], 'execute')

    def test_pause_does_not_prevent_observation_and_settlement(self):
        self.init([self.task('first'), self.task('second')])
        attempt = self.advance()['attempt']
        self.event('pause', request_ref=self.f.write('stop', 'Pause now'), reason='Pause running fixture')
        self.settle(attempt)
        self.assertIsNone(C.status(self.path)['current_attempt'])
        self.assertEqual(self.advance()['reason'], 'user_stopped')
        self.assertEqual(C.status(self.path)['started_attempts'], 1)

    def test_checkpoint_same_revision_edit_is_not_legitimized_by_next_event(self):
        self.init([self.task('first')])
        state = C.status(self.path)
        state['budget']['max_attempts'] = 999
        self.path.write_text(json.dumps(state))
        with self.assertRaisesRegex(ValueError, 'lineage'):
            self.advance()

    def test_rejected_intent_can_be_revised_without_spending_attempt_or_losing_history(self):
        self.init([self.task('first')])
        # A newly added task with an absent intent is retained for explicit revision,
        # never registered as a paid/scientific dispatch.
        bad = self.task('bad')
        self.event('add_task', task=bad)
        first = self.advance()['attempt']
        self.settle(first)
        self.assertEqual(self.advance()['kind'], 'replan')
        state = C.status(self.path)
        self.assertEqual(state['started_attempts'], 1)
        replacement = self.f.task(self.task('corrected'))
        self.event('revise_task', task_id='bad', task=replacement, reason='Supply actual missing intent')
        self.assertEqual(self.advance()['attempt']['task_id'], 'corrected')
        self.assertEqual(C.status(self.path)['started_attempts'], 2)


if __name__ == '__main__':
    unittest.main()
