"""Local filesystem/process tests; no global cloud scheduling claim."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
S=Path(__file__).resolve().parents[1]/'scripts'

class OperationsTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue((S/'research_operations.py').is_file(),'operational helpers are absent')
        spec=importlib.util.spec_from_file_location('ops_tested',S/'research_operations.py')
        self.m=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.m)
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
    def snap(self,limit=8192,current=7300):
        return dict(domain='fixture-host-cgroup',observed_at=time.time(),memory_current=current,memory_max=limit,
                    ancestor_headrooms=[],memory_stat={'file':5000,'anon':2100,'shmem':100},errors=[])
    def test_task_specific_headroom_not_global_7gb_rule(self):
        r=self.m.memory_advice(self.snap(),peak_bytes=421,margin_bytes=128)
        self.assertEqual(r['status'],'fits_observed_headroom');self.assertFalse(r['reservation'])
    def test_cache_never_credited_as_free(self):
        r=self.m.memory_advice(self.snap(current=8100),peak_bytes=421,margin_bytes=128)
        self.assertEqual(r['status'],'waiting_for_memory');self.assertEqual(r['cache_credit_bytes'],0)
    def test_ancestor_limit_is_respected(self):
        s=self.snap();s['ancestor_headrooms']=[50]
        self.assertEqual(self.m.memory_advice(s,peak_bytes=100,margin_bytes=10)['status'],'waiting_for_memory')
    def test_missing_memory_is_unknown_not_zero(self):
        s=self.snap();s['memory_current']=None
        self.assertEqual(self.m.memory_advice(s,peak_bytes=1,margin_bytes=1)['status'],'unknown_capacity')
    def test_probe_reads_stat_events_and_pressure(self):
        p=self.root/'cg';p.mkdir()
        for n,v in {'memory.current':'300','memory.max':'1000','memory.stat':'file 200\nanon 90\nshmem 10\n',
                    'memory.events':'oom 0\noom_kill 0\n','memory.pressure':'some avg10=0.01 avg60=0.02 avg300=0.03 total=1\n'}.items():(p/n).write_text(v)
        r=self.m.memory_snapshot(p);self.assertEqual(r['memory_stat']['file'],200)
        self.assertEqual(r['memory_events']['oom'],0);self.assertIn('some',r['memory_pressure'])
    def test_cooperating_reservations_prevent_double_admission(self):
        s=self.snap(limit=100,current=0)
        a=self.m.reserve(self.root/'leases',lambda:s,'p1','task',60,0)
        b=self.m.reserve(self.root/'leases',lambda:s,'p2','task',60,0)
        self.assertEqual(a['status'],'reserved');self.assertEqual(b['status'],'waiting_for_memory')
        self.m.release(self.root/'leases',a['token'],s['domain'])
        self.assertEqual(self.m.reserve(self.root/'leases',lambda:s,'p2','task',60,0)['status'],'reserved')
    def test_real_processes_share_one_lock(self):
        code="""import sys,json,time
from pathlib import Path
sys.path.insert(0,sys.argv[1]);import research_operations as o
s=dict(domain='same',observed_at=time.time(),memory_current=0,memory_max=100,ancestor_headrooms=[],errors=[])
r=o.reserve(Path(sys.argv[2]),lambda:s,sys.argv[3],'task',60,0);print(json.dumps(r))
"""
        ps=[subprocess.Popen([sys.executable,'-c',code,str(S),str(self.root/'leases'),str(i)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) for i in range(2)]
        values=[]
        for p in ps:
            out,err=p.communicate(timeout=8);self.assertEqual(p.returncode,0,err);values.append(json.loads(out)['status'])
        self.assertCountEqual(values,['reserved','waiting_for_memory'])
    def test_other_domain_cannot_release_lease(self):
        a=self.m.reserve(self.root/'l',lambda:self.snap(),'p','t',100,0)
        with self.assertRaises(ValueError):self.m.release(self.root/'l',a['token'],'other-host')
    def test_expired_observation_requires_new_probe(self):
        s=self.snap();s['observed_at']=time.time()-100
        with self.assertRaises(ValueError):self.m.reserve(self.root/'l',lambda:s,'p','t',100,0)
    def test_second_checkpoint_writes_only_changed_files(self):
        p=self.root/'project';p.mkdir();(p/'a.txt').write_text('aaa');(p/'b.txt').write_text('bbb')
        store=self.root/'store';r1=self.m.save_delta(p,store,['a.txt','b.txt'],project_id='p')
        (p/'a.txt').write_text('aaaa');r2=self.m.save_delta(p,store,['a.txt'],project_id='p',parent=r1['manifest'])
        self.assertEqual(r2['objects_added'],1);self.assertEqual(r2['content_bytes_added'],4)
        self.assertFalse(r2['remote_verified']);self.assertFalse(r2['cleanup_authorized'])
        dest=self.root/'restored';z=self.m.restore_subset(store,r2['manifest'],dest,['a.txt'])
        self.assertEqual((dest/'a.txt').read_text(),'aaaa');self.assertFalse((dest/'b.txt').exists());self.assertEqual(z['files_restored'],1)
    def test_no_implicit_deletion_from_partial_checkpoint(self):
        p=self.root/'p';p.mkdir();(p/'a').write_text('a');(p/'b').write_text('b')
        s=self.root/'s';r1=self.m.save_delta(p,s,['a','b'],project_id='p')
        (p/'a').write_text('c');r2=self.m.save_delta(p,s,['a'],project_id='p',parent=r1['manifest'])
        self.m.restore_subset(s,r2['manifest'],self.root/'out',['b']);self.assertEqual((self.root/'out/b').read_text(),'b')
    def test_cross_project_parent_rejected(self):
        p=self.root/'p';p.mkdir();(p/'a').write_text('a');s=self.root/'s'
        r=self.m.save_delta(p,s,['a'],project_id='p')
        with self.assertRaises(ValueError):self.m.save_delta(p,s,['a'],project_id='other',parent=r['manifest'])
    def test_symlink_and_sqlite_are_not_copied_blindly(self):
        p=self.root/'p';p.mkdir();(p/'x').symlink_to('/etc/hosts');(p/'live.sqlite3').write_text('not a backup')
        for name in ('x','../outside','live.sqlite3'):
            with self.assertRaises(ValueError):self.m.save_delta(p,self.root/'s',[name],project_id='p')
    def test_restore_refuses_overwrite(self):
        p=self.root/'p';p.mkdir();(p/'a').write_text('a');s=self.root/'s';r=self.m.save_delta(p,s,['a'],project_id='p')
        out=self.root/'out';out.mkdir();(out/'a').write_text('new work')
        with self.assertRaises(ValueError):self.m.restore_subset(s,r['manifest'],out,['a'])
        self.assertEqual((out/'a').read_text(),'new work')
    def test_corrupt_object_not_restored(self):
        p=self.root/'p';p.mkdir();(p/'a').write_text('a');s=self.root/'s';r=self.m.save_delta(p,s,['a'],project_id='p')
        (s/'objects'/hashlib.sha256(b'a').hexdigest()).write_text('corrupt')
        with self.assertRaises(ValueError):self.m.restore_subset(s,r['manifest'],self.root/'out',['a'])
    def test_load_failure_does_not_disable_scheduler(self):
        r=self.m.adoption_report('old','new',active_attempts=0,user_paused=False,source_accessible=False)
        self.assertEqual(r['status'],'waiting_for_skill');self.assertFalse(r['scheduler_mutated'])
    def test_running_project_not_hot_migrated(self):
        self.assertEqual(self.m.adoption_report('old','new',active_attempts=1,user_paused=False,source_accessible=True)['status'],'wait_for_quiet_boundary')
    def test_user_pause_is_preserved(self):
        self.assertEqual(self.m.adoption_report('old','new',active_attempts=0,user_paused=True,source_accessible=True)['status'],'user_paused')
if __name__=='__main__':unittest.main()
