# Object-first discovery: frame, explain, construct, discriminate

At entry, restore the selected field and cumulative paper/code/reproduction record.
Use [research-cycle.md](research-cycle.md) to choose the next unresolved question.
Reading, reproduction and diagnosis are legitimate selected actions before a new
method; mathematical procedures apply to consequential modeling/construction rather
than forcing equations for every source read. Reuse mature evidence; do not restart
completed reading or qualified baselines to satisfy a quota.

This is the shared Simple/Chat discovery contract. It extends the existing decision,
math DAG and quality records; it adds no research database, candidate pool, all-48
checklist, route-length requirement or automatic idea generator. The agent does the
scientific work. Software only checks recorded links and explicit contradictions.
It does not verify semantic diversity, mathematical truth or scientific originality.

## Connect discovery to problems, evaluation and resources

Use [research-cycle.md](research-cycle.md) to turn consequential analysis into
conditional predictions, relevant problems and a feasible existing-benchmark plan.
Check availability while forming the idea. After actual results, revise the affected
mathematical question or justify an in-scope transfer; retain ancestry, failures and
cumulative effort. Reuse existing inquiry/quality fields rather than a new ledger.


## Optional community observations as leads

At new research/idea intake offer/reuse the optional Xiaohongshu source choice.
Follow [xiaohongshu-idea-discovery.md](xiaohongshu-idea-discovery.md) to search
model architecture, training characteristics, failures and prior-work leads in
bounded public notes/comments. Keep author reports, speculation and our inference
separate. Turn supported observations into conditional mechanisms and falsifiable
contrasts, then verify closest work with primary papers and actual implementations.
Retain provenance, sampling gaps and contradictions in existing evidence records.
An unavailable or skipped source leaves the ordinary inquiry workflow intact.

## Trigger at the right level

Use this at a new substantive question, a material object/information/goal-link change,
an unexplained robust phenomenon, an experiment contradicting the selected account,
or a family-level investment review. For an ordinary bugfix, a prespecified seed or
unchanged mathematical object, cite/reuse the accepted frame and derivation. Do not
restart discovery merely because a batch ended. A settled necessary comparison should
be run rather than postponed by a new review campaign.

The invariant is the user's goal, not the present loss, parameterization or module.
Before selecting operations, ask what output is needed, what information is available,
and what objective is actually optimized. Inspect representation, training/deployment
distribution, computation or cost only when consequential. These are prompts, not six
mandatory essays. Changing a surrogate/object must preserve a route to the original
target; changing the user's goal requires the host's explicit scope-revision contract.

## Distinguish three work products

- A **lead** records a phenomenon, an uncertainty or a mathematical possibility. It may
  have no settled explanation. State what observation merits checking and the smallest
  informative replication, deletion, counterexample, source lookup or baseline probe.
- A **hypothesis** identifies an account, its conditions and a prediction. Multiple
  accounts can concern one active method. A fixed number is never required. A lone
  necessary repair is fine when its lack of an independent alternative is explained.
- A **construction** has an executable rule and its consequential mathematical path.
  It requires the existing trace, rival-distinguishing prediction and quality protocol.
  A correct construction can still be old, practically useless or empirically refuted.

Mathematics-first and phenomenon-first entry are equally legitimate. Do not invent
algebra to promote an empirical lead. Do not call a complete method comparison a
lead to bypass native-baseline, information, statistical or confirmation obligations.
An early probe establishes its diagnostic scope only, not a new-method success claim.

## Different explanations, not different names

An explanation answers why; a construction says what to change; a task says how to
check it. Keep them distinct. For consequential competing accounts, state a feasible
intervention, what is held fixed, and the conditional predictions that differ. If the
predictions coincide under all available checks, treat them as currently indistinguishable
rather than advertising multiple diverse ideas. Sharing an operation does not make two
accounts identical; different operation lists do not make two accounts different.

Do not weaken a rival to justify a favorite. Allow zero explanations for a genuinely
unexplained lead, one for a necessary scoped check, or several when the question needs
them. No mandatory counter-hypothesis generation on routine maintenance. Cheap rival
reading/derivation can overlap, but one coordinator keeps one major execution candidate,
the original resource accounting, independent-unit definitions and accepted results.

## Choose objects and routes without a familiarity trap

Keep prior evidence, uncertainty, expected decision value and cost separate. Published
paths, checked math, counterexamples and native observations inform the prior; analogy
alone is conditional. An unknown prior is not a low-value route. v4 ranking does not
break equal-value ties using prior familiarity. The agent explains the selection using
compatibility, decisive controls, opportunity cost and actual availability. A less-known
route may receive a bounded probe if it can distinguish an important uncertainty. Do
not spend on it simply to equalize operation frequencies or inflate path entropy.

The 48 operations, 14 example paths and 20 cases remain reusable, not exhaustive.
Custom justified operations are permitted. A concrete math DAG records intermediate
results and conditional edges; it is not restricted to 48 vertices. Depth is determined
by consequential unresolved steps, not a minimum or maximum node count. External proof
files can hold long algebra; pin them instead of truncating the derivation to metadata.

## Read papers for transferable decisions

When reading to change this decision, extract: the old default, the object/condition
changed, the justification, the experiment separating accounts, and the boundary where
the idea need not transfer. Seek the nearest collision and disconfirming evidence as well
as support. No per-round paper quota. The earlier 20-paper study is development material,
not a calibrated prior or a held-out evaluation of this policy.

## Use evidence to choose the next link

Classify each result by both outcome and affected layer: object, assumption, derivation,
implementation, evaluation, proxy-to-target link, population/scope, investment value or
infrastructure. A failed launch cannot refute a theorem. Failure of a theorem's premise
in a dataset does not disprove its conditional statement. A small approximation error
does not establish preserved minimizers or main-task quality. A stronger comparator can
remove investment value without showing mathematical incorrectness.

Preserve contradiction and select the affected frontier. Add a new frame for changed
objects and a new explanation ID for changed mechanism/conditions/prediction. Preserve
old explanations and observations, including rejected branches. A new frame reuses valid
math prefixes only with the existing trace validation; unchanged math under a changed
frame needs a pinned scoped revalidation. Exact algebra downstream never erases an
upstream approximation obligation. Repeated seeds refine one question, not idea count.

Before expanding, return to the important test the last repair unlocked. Keep unfinished
native comparisons and main-objective requirements visible. A controlled synthetic probe
or algebra fixture is not a replacement research benchmark. Development cases used to
choose a route remain exposed; confirmation needs the existing independent-evidence rules.

## One record, two host adapters

`research_decision` **v4** embeds `inquiry`; there is no separate persisted inquiry ledger.
It keeps the v3 decision ancestry, family accounting and selected_task_ids. Fields:

- problem_id/frame_id, entry, stage, pinned original goal_ref, question, goal_preservation;
- objects (target, information, objective; representation/cost_model when consequential);
- defaults with status/evidence; explanations with mechanism/conditions/prediction/status;
- contrasts with interventions/held-fixed/predictions; selected explanation/contrast;
- priority (basis, uncertainty, decision_value, cost), selection_reason, next_check;
- observations with attempt/task/receipt, outcome, affected explanation/layer, interpretation;
  based_on_observation_ids must consume the retained exact observation prefix.

`next_check` includes action, question, exact task_ids, input_refs and outcome_actions
for supports/refutes/inconclusive/invalid. For a lead without explanations record
unexplained_lead; for one necessary account record no_alternative_reason. These are
honest states, not placeholder excuses. The provided template is incomplete by design.
The executable example creates an inspectable fixture without inventing research data.

Construction decisions still pin trajectory_ref, math_trace_ref and quality_ref; the
full v3 requirements apply. Early lead/hypothesis decisions may omit those completed
artifacts and use an explicit diagnostic task with reasoning_ref=v4. They may not select
method compare/confirm, claim novelty or discharge old quality obligations. Promotion
must extend the prior decision and last same-candidate quality record, including debt.
Changing to another problem retains the original goal and decision ancestry but does
not require copying all irrelevant explanations; returning to a problem resumes its
last recorded frame. Problem IDs must not be renamed to reset effort or hide failures.

Simple: use the existing research_review event and tag early tasks research_scope=diagnostic,
phase=diagnostic, reasoning_ref and input_refs. Construction comparisons use method and
phase=experiment. Both are checked at intake/dispatch against the current accepted decision.
Chat: use the existing strategy_reasoning event; early probes use kind=action,
research_scope=diagnostic and a diagnostic task intent whose scope_ref explicitly has
claim_kind=investigation. This narrow entry does not require an already-established
novelty qualification. Source pins, finite reservations, pauses, cumulative strategy
limits and outcome accounting still apply. Formal research_experiment/new_method tasks
retain all existing canonical qualifications. A diagnostic label alone grants no bypass.

Both hosts retain receipts for explicitly tagged probes. Before the next v4 tagged action,
consume those receipts in inquiry.observations. A diagnostic reframe also consumes
earlier method receipts; renaming a problem cannot hide experimental feedback.
Method experiment receipts additionally
retain their existing adaptive-trajectory requirements. Invalid host execution can only
be recorded as invalid. No new host process or model call is installed by this policy.

## Verify behavior, not storytelling

Use condition-change pairs: identical mathematical content with renamed labels should
not need a new method; meaningful information/cost/representation changes should be
noticed and may justify a different route. Same operations can be appropriate in both.
Evaluate the reasoning, evidence and actual subsequent action, not one prescribed answer.
Track relevant alternatives considered and decisive tests, not equal use of all operations,
number of equations, total paths or average proof length. Keep hard cases and valid negative
results in denominators so fast trivial questions cannot game the evaluation.

The bundled cases and software tests are DEVELOPMENT fixtures based on known failures.
No model behavior is inferred from passing them. To evaluate discovery, separately freeze
unseen cases and compare the prior policy, record-only changes and full policy using the
same available model/tools/resources, preserving action traces and overhead. Never fabricate
independent agents or turn a self-review into a held-out trial.

Migration: package publication is not project adoption. Settle active/unknown attempts,
record the authorized source/procedure change at a quiet boundary and retain pauses,
old evidence, original allocations and cumulative effort. v1-v3 decisions remain readable
and unreviewed under v4; adopted v4 ancestry cannot be downgraded. No automatic project
restart, source-branch publication, cloud service or unlimited background compute follows.
