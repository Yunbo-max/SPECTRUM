#!/usr/bin/env python3
"""Local, bounded progress observations; never dispatch or change research state.

This standalone Python 3.11+ tool records explicit operational observations and
exports browser-local dashboard snapshots. Controller databases are read through
SQLite mode=ro/query_only transactions, without constructing a Controller (whose
ordinary reads may expire leases). No prompt, instruction file, worker payload,
network, token, scientific verdict or hidden reasoning is collected.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import datetime as dt
import json
import math
import os
from pathlib import Path
import sqlite3
import stat
import sys
import tempfile
import time
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


EDITIONS = ("main", "autonomous-rsi", "chat", "autonomous-rsi-chat")
STATUSES = ("running", "waiting", "blocked", "paused", "complete", "failed",
            "cancelled", "pending", "reconcile_required", "unknown")
TERMINAL = frozenset(("complete", "failed", "cancelled"))
ACTION_STAGES = {"source_read": 2, "math_work": 3, "math_review": 3,
                 "candidate_code": 4, "experiment_design": 4, "native_harness": 5,
                 "result_verify": 6, "writing": 8, "artifact_delivery": 8}
EVENT_STATES = {"task_registered": "pending", "claimed": "running",
                "reconciled_running": "running", "completed": "complete",
                "failed": "failed", "cancelled": "cancelled",
                "reconcile_required": "reconcile_required", "task_blocked": "blocked",
                "admission_denied": "blocked"}
OBSERVABLE_EVENTS = frozenset(EVENT_STATES) | {"heartbeat", "session_bound"}
MAX_TEXT = 16000
MAX_JOURNAL_BYTES = 16 * 1024 * 1024
MAX_SNAPSHOT_BYTES = 5 * 1024 * 1024
MAX_ROWS = 50000
MAX_PROJECTS = 100
MAX_TASKS = 5000
MAX_HISTORY = 1000
UTC = dt.timezone.utc


def _text(value, field, *, optional=False, limit=MAX_TEXT):
    if optional and value is None:
        return None
    if not isinstance(value, str) or not value.strip() or len(value) > limit or "\0" in value:
        raise ValueError(f"{field} must be nonempty text of at most {limit} characters")
    return value


def _strings(value, field):
    if value is None:
        return []
    if not isinstance(value, (list, tuple)) or len(value) > MAX_HISTORY:
        raise ValueError(f"{field} must be a bounded list of strings")
    return [_text(item, field, limit=256 if field == "dependencies" else MAX_TEXT) for item in value]


def _utc(value=None):
    if value is None:
        return dt.datetime.now(UTC)
    if isinstance(value, str):
        try:
            value = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValueError("invalid timestamp") from exc
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        if not math.isfinite(value) or value < 0:
            raise ValueError("invalid controller timestamp")
        try:
            value = dt.datetime.fromtimestamp(value, UTC)
        except (ValueError, OverflowError, OSError) as exc:
            raise ValueError("invalid controller timestamp") from exc
    if not isinstance(value, dt.datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("timestamps must include a timezone")
    return value.astimezone(UTC)


def _iso(value):
    # JavaScript Date parsers and the dashboard contract share millisecond precision.
    return _utc(value).isoformat(timespec="milliseconds").replace(".000+00:00", "+00:00").replace("+00:00", "Z")


def _runtime_time(value):
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise ValueError("controller timestamp must be a finite numeric value")
    return _utc(value)


def _safe_path(value, *, existing=False, directory=False):
    path = Path(os.path.abspath(os.fspath(value)))
    # Check ancestors without resolve(), which would hide supplied symlinks.
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        if current.is_symlink():
            raise ValueError(f"symlink paths are not accepted: {current.name}")
    if existing and not path.exists():
        raise ValueError("input path does not exist")
    if path.exists() and directory and not path.is_dir():
        raise ValueError("project root must be a directory")
    if path.exists() and not directory and not path.is_file():
        raise ValueError("input/output must be a regular file")
    return path


def _progress_paths(project, *, create=False):
    root = _safe_path(project, existing=True, directory=True)
    folder = root / ".research-autopilot/progress"
    _safe_path(folder, directory=True)
    if create:
        folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    return root, folder / "events.jsonl", folder / ".lock"


@contextmanager
def _lock(path, *, write=False):
    _safe_path(path)
    if not write and not path.exists():
        yield
        return
    flags = (os.O_RDWR | os.O_CREAT) if write else os.O_RDONLY
    descriptor = os.open(path, flags | getattr(os, "O_NOFOLLOW", 0), 0o600)
    try:
        if not stat.S_ISREG(os.fstat(descriptor).st_mode) or os.fstat(descriptor).st_nlink != 1:
            raise ValueError("lock must be a regular file with one hard link")
        try:
            import fcntl
        except ImportError:  # Windows uses a byte-range advisory lock.
            import msvcrt
            if write and os.fstat(descriptor).st_size == 0:
                os.write(descriptor, b"\0")
            os.lseek(descriptor, 0, os.SEEK_SET)
            msvcrt.locking(descriptor, msvcrt.LK_LOCK, 1)
            try:
                yield
            finally:
                os.lseek(descriptor, 0, os.SEEK_SET)
                msvcrt.locking(descriptor, msvcrt.LK_UNLCK, 1)
        else:
            fcntl.flock(descriptor, fcntl.LOCK_EX if write else fcntl.LOCK_SH)
            try:
                yield
            finally:
                fcntl.flock(descriptor, fcntl.LOCK_UN)
    finally:
        os.close(descriptor)


def _bounded_read(path, maximum):
    _safe_path(path, existing=True)
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(descriptor, "rb") as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode) or os.fstat(stream.fileno()).st_size > maximum:
            raise ValueError("input exceeds the bounded regular-file limit")
        result = stream.read(maximum + 1)
    if len(result) > maximum:
        raise ValueError("input exceeds the bounded regular-file limit")
    return result


def _decode(value):
    def reject_constant(_):
        raise ValueError("nonfinite JSON numbers are not accepted")
    def unique(pairs):
        result = {}
        for key, item in pairs:
            if key in result:
                raise ValueError("duplicate JSON keys are not accepted")
            result[key] = item
        return result
    try:
        return json.loads(value, parse_constant=reject_constant, object_pairs_hook=unique)
    except (json.JSONDecodeError, UnicodeDecodeError, RecursionError) as exc:
        raise ValueError("corrupt JSON") from exc


def _validate_record(event):
    if not isinstance(event, dict) or type(event.get("schema_version")) is not int or event.get("schema_version") != 1:
        raise ValueError("unsupported progress record")
    for name in ("project_id", "task_id"):
        _text(event.get(name), name, limit=256)
    for name in ("title", "description", "owner"):
        _text(event.get(name), name)
    for name in ("task_title", "blocker", "next_action", "summary"):
        _text(event.get(name), name, optional=True)
    if event.get("edition") not in EDITIONS or event.get("status") not in STATUSES:
        raise ValueError("unsupported edition or status")
    if type(event.get("stage")) is not int or not 1 <= event["stage"] <= 8:
        raise ValueError("stage must be an integer from 1 through 8")
    if not isinstance(event.get("timestamp"), str):
        raise ValueError("an explicit timestamp is required")
    _utc(event["timestamp"])
    for name in ("dependencies", "evidence"):
        _strings(event.get(name), name)
    return event


def _journal(path, *, strict=False):
    if not path.exists():
        return [], []
    raw = _bounded_read(path, MAX_JOURNAL_BYTES)
    lines = raw.splitlines()
    if len(lines) > MAX_ROWS:
        raise ValueError("progress journal has too many observations")
    result, warnings, latest = [], [], {}
    for index, line in enumerate(lines, 1):
        try:
            if len(line) > 128 * 1024:
                raise ValueError("oversized record")
            event = _validate_record(_decode(line))
            key = event["project_id"], event["task_id"]
            moment = _utc(event["timestamp"])
            if key in latest and moment < latest[key]:
                raise ValueError("reversed timestamp")
            latest[key] = moment
            result.append(event)
        except ValueError as exc:
            if strict:
                raise ValueError(f"corrupt progress journal at line {index}; bytes preserved") from exc
            warnings.append(f"Corrupt progress observation at line {index} ignored; bytes preserved.")
    if raw and not raw.endswith(b"\n"):
        if strict:
            raise ValueError("corrupt or unfinished journal tail; bytes preserved")
        warnings.append("Corrupt or unfinished journal tail; bytes preserved.")
    return result, warnings


def record(project, *, project_id, title, edition, task_id, description, stage,
           status, owner, task_title=None, blocker=None, next_action=None,
           summary=None, dependencies=None, evidence=None, now=None):
    """Append one explicit observation. This never registers or executes a task."""
    moment = _utc(now)
    event = dict(schema_version=1, project_id=project_id, title=title, edition=edition,
                 task_id=task_id, description=description, stage=stage, status=status,
                 owner=owner, timestamp=_iso(moment), blocker=blocker,
                 next_action=next_action, summary=summary)
    if task_title is not None:
        event["task_title"] = task_title
    if dependencies is not None:
        event["dependencies"] = _strings(dependencies, "dependencies")
    if evidence is not None:
        event["evidence"] = _strings(evidence, "evidence")
    _validate_record(event)
    root, path, lock = _progress_paths(project, create=True)
    encoded = (json.dumps(event, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n").encode()
    if len(encoded) > 128 * 1024:
        raise ValueError("progress record exceeds the bounded line limit")
    with _lock(lock, write=True):
        previous, _ = _journal(path, strict=True)
        if len(previous) >= MAX_ROWS:
            raise ValueError("progress journal has too many observations")
        matching = [row for row in previous if (row["project_id"], row["task_id"]) == (project_id, task_id)]
        if matching and moment < _utc(matching[-1]["timestamp"]):
            raise ValueError("observation timestamp is earlier than the retained task observation")
        _safe_path(path)
        descriptor = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
        with os.fdopen(descriptor, "ab") as stream:
            info = os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size + len(encoded) > MAX_JOURNAL_BYTES:
                raise ValueError("journal must be a bounded regular file with one hard link")
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
    return {"recorded_at": event["timestamp"], "project_id": project_id, "task_id": task_id,
            "events_path": str(path)}


def _new_task(task_id, *, stage=1, status="unknown", title=None, description=None, source="local_observation"):
    return dict(task_id=task_id, title=title or task_id, description=description or task_id,
                stage=stage, status=status, owner="unknown", started_at=None, updated_at=None,
                lease_until=None, blocker=None, next_action=None, dependencies=[], evidence=[],
                events=[], timing=[], source=source)


def _transition(task, moment, status, stage, summary, *, freshness=None):
    timestamp = _iso(moment)
    previous_time = _utc(task["updated_at"]) if task["updated_at"] else None
    gap = freshness is not None and previous_time is not None and moment > previous_time + dt.timedelta(seconds=freshness)
    changed = task["status"] != status or task["stage"] != stage
    if task["timing"] and (changed or gap):
        active = task["timing"][-1]
        if active["end_at"] is None:
            end = previous_time + dt.timedelta(seconds=freshness) if gap else moment
            active["end_at"] = _iso(end)
    if not task["timing"] or changed or gap:
        task["timing"].append(dict(start_at=timestamp, end_at=timestamp if status in TERMINAL else None,
                                   status=status, stage=stage))
    task["events"].append(dict(timestamp=timestamp, status=status, stage=stage, summary=summary))
    task.update(status=status, stage=stage, updated_at=timestamp)
    if status == "running" and task["started_at"] is None:
        task["started_at"] = timestamp


def _local_projects(root, moment, freshness):
    _, path, lock = _progress_paths(root)
    with _lock(lock):
        events, warnings = _journal(path)
    projects = {}
    for event in events:
        at = _utc(event["timestamp"])
        if at > moment:
            warnings.append("Future progress observation ignored; its timestamp exceeds snapshot time.")
            continue
        project_id = event["project_id"]
        project = projects.setdefault(project_id, dict(project_id=project_id, title=event["title"],
            edition=event["edition"], updated_at=None, source="local_observation", tasks={}, warnings=[]))
        project.update(title=event["title"], edition=event["edition"])
        if project["updated_at"] is None or at > _utc(project["updated_at"]):
            project["updated_at"] = _iso(at)
        task = project["tasks"].setdefault(event["task_id"], _new_task(event["task_id"]))
        _transition(task, at, event["status"], event["stage"], event.get("summary") or "Explicit operational observation",
                    freshness=freshness)
        task.update(title=event.get("task_title", task["title"]), description=event["description"],
                    owner=event["owner"], blocker=event.get("blocker"), next_action=event.get("next_action"))
        for name in ("dependencies", "evidence"):
            if name in event:
                task[name] = event[name]
    if not projects and warnings:
        projects["unregistered-observations"] = dict(project_id="unregistered-observations", title=root.name,
            edition="unknown", updated_at=None, source="local_observation", tasks={}, warnings=[])
    for project in projects.values():
        project["warnings"].extend(warnings)
        for task in project["tasks"].values():
            if task["timing"] and task["updated_at"]:
                segment = task["timing"][-1]
                expiry = _utc(task["updated_at"]) + dt.timedelta(seconds=freshness)
                if segment["end_at"] is None and expiry <= moment:
                    segment["end_at"] = _iso(expiry)
    return projects


def _edition(contract, warnings):
    skill_root = contract.get("skill_root")
    if not isinstance(skill_root, str):
        return "unknown"
    try:
        root = _safe_path(skill_root, existing=True, directory=True)
        candidates = (root.parent / "EDITION.json", root.parent.parent / "EDITION.json")
        for candidate in candidates:
            _safe_path(candidate)
            if candidate.exists():
                metadata = _decode(_bounded_read(candidate, 65536))
                edition = metadata.get("branch") if isinstance(metadata, dict) else None
                if edition in EDITIONS:
                    return edition
    except ValueError:
        warnings.append("Edition metadata could not be safely observed.")
    return "unknown"


def _contract(raw):
    if not isinstance(raw, str) or len(raw.encode("utf-8")) > 128 * 1024:
        raise ValueError("controller contract exceeds the bounded input limit")
    value = _decode(raw)
    if not isinstance(value, dict):
        raise ValueError("invalid controller contract")
    return value


def _rows(db, query, params=()):
    rows = db.execute(query, params).fetchmany(MAX_ROWS + 1)
    if len(rows) > MAX_ROWS:
        raise ValueError("controller query exceeds the bounded row limit")
    return rows


def _controller_projects(path, moment, freshness):
    """Read one consistent SQLite snapshot, including retained attempt history."""
    path = _safe_path(path, existing=True)
    # The explicit URI and query_only guard apply before every SELECT.
    db = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=5, isolation_level=None)
    db.row_factory = sqlite3.Row
    try:
        db.execute("PRAGMA query_only=ON")
        db.execute("BEGIN")
        project_rows = _rows(db, "SELECT project_id,contract FROM projects ORDER BY project_id")
        if len(project_rows) > MAX_PROJECTS:
            raise ValueError("too many controller projects")
        result = []
        for row in project_rows:
            project_id = _text(row["project_id"], "controller project_id", limit=256)
            contract = _contract(row["contract"])
            root_value = _text(contract.get("root"), "project root")
            if not Path(root_value).is_absolute():
                raise ValueError("controller project root must be absolute")
            root = _safe_path(root_value, existing=True, directory=True)
            warnings = []
            project = dict(project_id=project_id, title=project_id, edition=_edition(contract, warnings),
                           updated_at=_iso(moment), source="controller_sqlite", tasks={}, warnings=warnings)
            task_rows = _rows(db, "SELECT task_id,contract,state,run_id,outputs FROM tasks WHERE project_id=? ORDER BY task_id", (project_id,))
            if len(task_rows) > MAX_TASKS:
                raise ValueError("too many controller tasks")
            task_states = {item["task_id"]: item["state"] for item in task_rows}
            for task_row in task_rows:
                try:
                    task_id = _text(task_row["task_id"], "controller task_id", limit=256)
                    task_contract = _contract(task_row["contract"])
                    action = _text(task_contract.get("action"), "action", limit=256)
                    stage = ACTION_STAGES.get(action, 1)
                    if action not in ACTION_STAGES:
                        warnings.append(f"Task {task_id}: no observed research stage for action {action}; stage 1 is an unknown-stage fallback.")
                    task = _new_task(task_id, stage=stage, description=f"{task_id} ({action}); no task description registered",
                                     source="controller_sqlite")
                    task["dependencies"] = _strings(task_contract.get("dependencies", []), "dependencies")
                    task["run_id"] = task_row["run_id"]
                    if task["run_id"] is not None:
                        _text(task["run_id"], "run_id", limit=256)
                    events = _rows(db, "SELECT event_id,run_id,kind,timestamp FROM events WHERE project_id=? AND task_id=? ORDER BY event_id", (project_id, task_id))
                    last_time, segment_runs = None, {}
                    for event in events:
                        if event["kind"] not in OBSERVABLE_EVENTS:
                            continue
                        try:
                            at = _runtime_time(event["timestamp"])
                            if at > moment or (last_time is not None and at < last_time):
                                raise ValueError("reversed or future runtime timestamp")
                            state = EVENT_STATES.get(event["kind"], task["status"])
                            if last_time is not None and at > last_time + dt.timedelta(seconds=freshness):
                                warnings.append(f"Task {task_id}: runtime event gap exceeds freshness; historical timing coverage is incomplete and actual activity in the gap is unknown.")
                            _transition(task, at, state, stage, f"Controller: {event['kind']}", freshness=freshness)
                            if event["run_id"] is not None:
                                run_id = _text(event["run_id"], "event run_id", limit=256)
                                task["events"][-1]["run_id"] = run_id
                                if state == "running":
                                    segment_runs[id(task["timing"][-1])] = run_id
                            last_time = at
                        except ValueError:
                            warnings.append(f"Task {task_id}: invalid runtime event timestamp ignored.")
                    runs = _rows(db, "SELECT run_id,owner,state,started_at,lease_until FROM runs WHERE project_id=? AND task_id=? ORDER BY started_at", (project_id, task_id))
                    current = next((run for run in runs if run["run_id"] == task["run_id"]), None)
                    if current is not None:
                        start, lease = _runtime_time(current["started_at"]), _runtime_time(current["lease_until"])
                        if start > moment or lease < start:
                            raise ValueError("invalid runtime run timestamps")
                        task["owner"] = _text(current["owner"], "owner")
                        task["lease_until"] = _iso(lease)
                        task["started_at"] = task["started_at"] or _iso(start)
                        if not task["timing"]:
                            _transition(task, start, "running", stage, "Controller retained attempt start")
                            segment_runs[id(task["timing"][-1])] = current["run_id"]
                    for run in runs:
                        retained_lease = _runtime_time(run["lease_until"])
                        for segment in task["timing"]:
                            if segment_runs.get(id(segment)) != run["run_id"] or segment["status"] != "running":
                                continue
                            end = _utc(segment["end_at"]) if segment["end_at"] else moment
                            if retained_lease <= moment and end > retained_lease:
                                segment["end_at"] = _iso(max(_utc(segment["start_at"]), retained_lease))
                                warnings.append(f"Task {task_id}: known running time ends at retained lease expiry; later actual activity is unknown.")
                    state = "complete" if task_row["state"] == "completed" else task_row["state"]
                    if state not in STATUSES:
                        state = "unknown"
                        warnings.append(f"Task {task_id}: unrecognized controller state.")
                    task["last_activity_at"] = task["updated_at"]
                    if state == "running" and current is None:
                        state = "unknown"
                        task["blocker"] = "Running task has no retained attempt identity; observation requires reconciliation."
                        warnings.append(f"Task {task_id}: running state has no matching retained run.")
                        for segment in task["timing"]:
                            if segment["status"] == "running" and segment["end_at"] is None:
                                segment["end_at"] = task["last_activity_at"] or segment["start_at"]
                    elif state == "running" and lease <= moment:
                        state = "reconcile_required"
                        task["blocker"] = "Controller lease expired; actual attempt state is unknown. Reconcile the retained identity."
                        task["next_action"] = "Observe and reconcile the original retained run; do not launch a replacement."
                        warnings.append(f"Task {task_id}: expired lease; actual attempt state is unknown. Database unchanged.")
                        for segment in task["timing"]:
                            if segment["status"] == "running" and segment["end_at"] is None:
                                segment["end_at"] = _iso(max(_utc(segment["start_at"]), lease))
                    elif state == "reconcile_required":
                        task["blocker"] = "Controller requires reconciliation of the retained attempt."
                        task["next_action"] = "Observe the original run identity before any continuation."
                    elif state == "pending":
                        if task["status"] == "blocked":
                            state = "blocked"
                            task["blocker"] = "Controller recorded an admission denial or task block; inspect its retained evidence."
                            task["next_action"] = "Resolve the recorded blocker within the existing research authorization and gates."
                        else:
                            incomplete = [dependency for dependency in task["dependencies"]
                                          if task_states.get(dependency) != "completed"]
                            if incomplete:
                                state = "waiting"
                                task["blocker"] = "Waiting for dependencies: " + ", ".join(incomplete[:40])
                                if len(incomplete) > 40:
                                    task["blocker"] += f" (+{len(incomplete) - 40} more)"
                                task["next_action"] = "Observe the registered upstream tasks; completion does not waive scientific acceptance."
                    if state in TERMINAL and task["status"] not in TERMINAL:
                        for segment in task["timing"]:
                            if segment["end_at"] is None:
                                # Missing terminal event does not establish its completion time.
                                segment["end_at"] = task["last_activity_at"] or segment["start_at"]
                        warnings.append(f"Task {task_id}: terminal state has no observed terminal timestamp; elapsed coverage is incomplete.")
                    task.update(status=state, updated_at=_iso(moment))
                    outputs = _decode(task_row["outputs"])
                    if not isinstance(outputs, list) or len(outputs) > MAX_HISTORY:
                        raise ValueError("invalid controller output references")
                    task["evidence"] = [_text(item["path"], "output path") for item in outputs
                                        if isinstance(item, dict) and "path" in item]
                    project["tasks"][task_id] = task
                except (ValueError, TypeError, OverflowError):
                    try:
                        task_id = _text(task_row["task_id"], "controller task_id", limit=256)
                    except ValueError:
                        warnings.append("A controller task has an invalid bounded identity; observation ignored.")
                    else:
                        task = _new_task(task_id, description=f"{task_id}; invalid controller observation",
                                         source="controller_sqlite")
                        task.update(updated_at=_iso(moment), blocker="Controller observation contains invalid or reversed data; actual task state is unknown.")
                        if isinstance(task_row["run_id"], str) and len(task_row["run_id"]) <= 256:
                            task["run_id"] = task_row["run_id"]
                        project["tasks"][task_id] = task
                        warnings.append(f"Task {task_id}: invalid bounded controller observation; state is unknown.")
            result.append((root, project))
        db.rollback()
        return result
    finally:
        db.close()


def export_snapshot(*, projects=(), controller_dbs=(), timezone="UTC", freshness_seconds=300, now=None):
    """Return a bounded, observational snapshot; sources are never modified."""
    moment = _utc(now)
    try:
        ZoneInfo(timezone)
    except (ZoneInfoNotFoundError, TypeError, ValueError) as exc:
        raise ValueError("timezone must be a known IANA timezone") from exc
    if type(freshness_seconds) is not int or not 1 <= freshness_seconds <= 86400:
        raise ValueError("freshness_seconds must be 1 through 86400")
    if len(projects) > MAX_PROJECTS or len(controller_dbs) > MAX_PROJECTS or not (projects or controller_dbs):
        raise ValueError("supply bounded project roots and/or controller databases")
    roots = {_safe_path(root, existing=True, directory=True) for root in projects}
    runtime = []
    for path in dict.fromkeys(controller_dbs):
        runtime.extend(_controller_projects(path, moment, freshness_seconds))
    roots.update(root for root, _ in runtime)
    merged, identity_roots = {}, {}
    for root in sorted(roots, key=str):
        for project_id, project in _local_projects(root, moment, freshness_seconds).items():
            if project_id in merged:
                raise ValueError("duplicate project identity across project roots")
            merged[project_id] = project
            identity_roots[project_id] = root
    seen_runtime = set()
    for root, project in runtime:
        project_id = project["project_id"]
        if project_id in seen_runtime:
            raise ValueError("duplicate controller project identity across databases")
        seen_runtime.add(project_id)
        local = merged.get(project_id)
        if local is not None:
            if identity_roots[project_id] != root:
                raise ValueError("controller project identity conflicts with a different observed root")
            project["title"] = local["title"]
            if project["edition"] == "unknown":
                project["edition"] = local["edition"]
            project["source"] = "local_observation+controller_sqlite"
            project["warnings"].extend(local["warnings"])
            for task_id, local_task in local["tasks"].items():
                if task_id in project["tasks"]:
                    task = project["tasks"][task_id]
                    for field in ("title", "description"):
                        task[field] = local_task[field]
                    for field in ("blocker", "next_action"):
                        task[field] = task[field] or local_task[field]
                    task["evidence"] = list(dict.fromkeys(local_task["evidence"] + task["evidence"]))
                    task["source"] = "local_observation+controller_sqlite"
                else:
                    project["tasks"][task_id] = local_task
        merged[project_id] = project
    if len(merged) > MAX_PROJECTS or sum(len(project["tasks"]) for project in merged.values()) > MAX_TASKS:
        raise ValueError("snapshot exceeds project/task count limits")
    for project in merged.values():
        project["tasks"] = sorted(project["tasks"].values(), key=lambda task: task["task_id"])
        for task in project["tasks"]:
            for field in ("events", "timing", "evidence"):
                if len(task[field]) > MAX_HISTORY:
                    task[field] = task[field][-MAX_HISTORY:]
                    project["warnings"].append(f"Task {task['task_id']}: {field} limited to the last {MAX_HISTORY} observations; coverage is incomplete.")
        project["warnings"] = list(dict.fromkeys(project["warnings"]))[:MAX_HISTORY]
    snapshot = dict(schema_version=1, generated_at=_iso(moment), timezone=timezone,
                    freshness_seconds=freshness_seconds,
                    projects=sorted(merged.values(), key=lambda project: project["project_id"]))
    if len(_snapshot_bytes(snapshot)) > MAX_SNAPSHOT_BYTES:
        raise ValueError("snapshot exceeds the 5 MiB browser-import limit")
    return snapshot


def _snapshot_bytes(snapshot):
    return (json.dumps(snapshot, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def write_snapshot(snapshot, output, *, reserved=()):
    """Atomically write an export, refusing symlinks and source-file clobbering."""
    if not Path(output).is_absolute() or Path(output).suffix.lower() != ".json":
        raise ValueError("output must be an absolute .json path")
    path = _safe_path(output)
    for source in reserved:
        source = _safe_path(source)
        if path == source or (path.exists() and source.exists() and os.path.samefile(path, source)):
            raise ValueError("output cannot overwrite an observation source")
    data = _snapshot_bytes(snapshot)
    if len(data) > MAX_SNAPSHOT_BYTES:
        raise ValueError("snapshot exceeds the 5 MiB browser-import limit")
    if path.exists():
        if path.stat().st_nlink != 1:
            raise ValueError("output cannot replace a hard-linked source")
        previous = _decode(_bounded_read(path, MAX_SNAPSHOT_BYTES))
        if not isinstance(previous, dict) or previous.get("schema_version") != 1 or not isinstance(previous.get("projects"), list) or "generated_at" not in previous:
            raise ValueError("existing output is not a progress snapshot; bytes preserved")
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    _safe_path(path)
    descriptor, temporary = tempfile.mkstemp(prefix=".progress-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        if os.name == "posix":
            descriptor = os.open(path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return str(path)


def _parser():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    recording = commands.add_parser("record", help="append an explicit local observation")
    for option in ("project", "project-id", "title", "task-id", "description", "owner"):
        recording.add_argument("--" + option, required=True)
    recording.add_argument("--edition", choices=EDITIONS, required=True)
    recording.add_argument("--stage", type=int, choices=range(1, 9), required=True)
    recording.add_argument("--status", choices=STATUSES, required=True)
    for option in ("task-title", "blocker", "next-action", "summary"):
        recording.add_argument("--" + option)
    recording.add_argument("--dependency", dest="dependencies", action="append")
    recording.add_argument("--evidence", action="append")
    for name in ("export", "watch"):
        exporting = commands.add_parser(name, help="write a browser-local snapshot" + (" for a bounded watch" if name == "watch" else ""))
        exporting.add_argument("--project", dest="projects", action="append", default=[])
        exporting.add_argument("--controller-db", dest="controller_dbs", action="append", default=[])
        exporting.add_argument("--output", required=True)
        exporting.add_argument("--timezone", default="UTC")
        exporting.add_argument("--freshness-seconds", type=int, default=300)
        if name == "watch":
            exporting.add_argument("--interval", type=int, default=60)
            exporting.add_argument("--cycles", type=int, required=True)
    return parser


def main(argv=None):
    args = vars(_parser().parse_args(argv))
    command = args.pop("command")
    try:
        if command == "record":
            project = args.pop("project")
            result = record(project, **args)
        else:
            output = args.pop("output")
            interval = args.pop("interval", 0)
            cycles = args.pop("cycles", 1)
            if command == "watch" and (not 1 <= interval <= 3600 or not 1 <= cycles <= 10000):
                raise ValueError("watch requires interval 1..3600 seconds and cycles 1..10000")
            reserved = list(args["controller_dbs"])
            reserved += [str(_progress_paths(root)[1]) for root in args["projects"]]
            result = None
            for index in range(cycles):
                snapshot = export_snapshot(**args)
                result = {"output": write_snapshot(snapshot, output, reserved=reserved),
                          "generated_at": snapshot["generated_at"], "projects": len(snapshot["projects"])}
                if index + 1 < cycles:
                    print(json.dumps(result), flush=True)
                    time.sleep(interval)
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except (ValueError, OSError, sqlite3.Error) as exc:
        print(f"Progress observation unavailable: {exc}. Research execution remains unchanged.", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
