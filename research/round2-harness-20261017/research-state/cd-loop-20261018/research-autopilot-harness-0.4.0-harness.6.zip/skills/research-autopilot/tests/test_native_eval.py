"""Non-evaluation engineering contract tests; no scientific scorer is executed.

Reuse the installed workflow's ProjectFixture and artifact helpers. The archived
records below are software fixtures, never scientific benchmark/evidence claims.
"""
import copy
import hashlib
import pathlib
import sys
import unittest
import uuid
from fixtures import C, DATE, DIGEST, ProjectFixture, digest, env, ref, write

try:
    import _native_eval as N
except ModuleNotFoundError:
    N = None


def native_contract_fixture(root, protocol, *, namespace="engineering/native", benchmark_id="engineering-contract-fixture"):
    """Attach archived native-shaped *engineering* records to an existing fixture."""
    source = write(root, namespace + "/source.json", {
        "purpose": "non-evaluation engineering fixture", "benchmark_id": benchmark_id,
        "benchmark_revision": "fixture-v1", "published_at": DATE,
        "source_url": "https://example.org/existing-engineering-fixture"})
    labels = write(root, namespace + "/labels.json", {"purpose": "engineering", "fixture": True})
    code = write(root, namespace + "/scorer-identity.json", {"purpose": "engineering", "fixture": True})
    sample = write(root, namespace + "/sample-manifest.json", {
        "benchmark_id": benchmark_id, "benchmark_revision": "fixture-v1", "split": "main",
        "sample_ids": ["existing-fixture-1", "existing-fixture-2"], "denominator": 2,
        "predictions_per_sample": 1, "labels_or_tests_ref": labels,
        "sampling": {"policy": "native", "parameters": {"repetitions": 1}}, "budget": {"seconds": 120}})
    scorer = {"kind": "official", "identity": "existing-fixture-scorer", "revision": "fixture-scorer-v1",
        "source_refs": [source], "code_refs": [code],
        "command": ["existing-engineering-scorer", "{predictions}", "{samples}", "{labels}"], "cwd": ".",
        "output": {"format": "json", "source": "stdout"}, "denominator_path": ["denominator"]}
    metrics = [{"name": "accuracy", "output_path": ["native_metrics", "accuracy"]},
               {"name": "scope", "output_path": ["native_metrics", "scope"]}]
    definitions = write(root, namespace + "/definition.json", {
        "benchmark_id": benchmark_id, "benchmark_revision": "fixture-v1",
        "published_at": DATE, "source_url": "https://example.org/existing-engineering-fixture",
        "primary_metric": "accuracy", "metrics": metrics,
        "splits": [{"name": "main", "sample_manifest_ref": sample, "labels_or_tests_ref": labels}],
        "prediction_format": {"format": "json", "records_path": ["predictions"], "id_path": ["sample_id"]},
        "sampling": {"policy": "native", "parameters": {"repetitions": 1}}, "budget": {"seconds": 120},
        "scorer": scorer, "publication_refs": [source]})
    contrast = protocol["contrasts"]
    names = {"treatment": contrast["treatment"], "baseline": contrast["baseline"],
             **{role: role for role in contrast["controls"]}}
    arms = {role: {"name": name, "revision": "implementation-v1", "implementation_refs": [code]}
            for role, name in names.items()}
    qualification = {"metric": "accuracy", "operator": "ge", "threshold": 0.5, "reference_ref": source}
    controls = [{"role": role, "metric": "accuracy", "operator": "ge" if role == "positive" else "le",
                 "threshold": 0.5, "reference_ref": source} for role in contrast["controls"]]
    contract = env("native-eval-contract", benchmark_id=benchmark_id, benchmark_revision="fixture-v1",
        split="main", published_source_refs=[source], native_definition_ref=definitions, sample_manifest_ref=sample,
        labels_or_tests_ref=labels, primary_metric="accuracy", metrics=metrics,
        prediction_format={"format": "json", "records_path": ["predictions"], "id_path": ["sample_id"]},
        sampling={"policy": "native", "parameters": {"repetitions": 1}}, budget={"seconds": 120},
        scorer=scorer, contrasts=copy.deepcopy(contrast), arm_requirements=arms,
        baseline_qualification=qualification, control_qualifications=controls)
    protocol["native_eval_contract"] = contract
    return contract


def native_run_fixture(root, protocol, manifest):
    """Attach receipt files to a software fixture; metric literals are never scored."""
    contract = protocol.get("native_eval_contracts", {}).get(manifest["group"],protocol["native_eval_contract"])
    sample_ref = contract.get("selection", {}).get("selected_manifest_ref", contract["sample_manifest_ref"])
    samples = C.load_file(C.verify_ref(root, sample_ref))
    receipts = {}
    for role, arm in contract["arm_requirements"].items():
        arm_values = {metric: pair["treatment" if role == "treatment" else "control"]
                      for metric, pair in manifest["metrics"].items()}
        if role in contract["contrasts"]["controls"]:
            arm_values = {metric["name"]: 1.0 if role == "positive" else 0.0 for metric in contract["metrics"]}
        if role == "baseline" and not manifest["baseline_qualified"]:
            arm_values["accuracy"] = 0.0
        if role == "positive" and not manifest["positive_control_passed"]:
            arm_values["accuracy"] = 0.0
        base = "engineering/native/runs/" + manifest["run_id"] + "/" + role
        predictions = write(root, base + "/predictions.json", {"predictions": [
            {"sample_id": sample_id, "fixture_output": True} for sample_id in samples["sample_ids"]]})
        output = write(root, base + "/native-output.json", {"denominator": samples["denominator"], "native_metrics": arm_values})
        stderr = write(root, base + "/stderr.json", {"purpose": "engineering fixture"})
        receipt = env("native-eval-receipt", receipt_id=manifest["run_id"] + "-" + role,
            run_id=manifest["run_id"], protocol_id=protocol["protocol_id"], protocol_digest=manifest["protocol_digest"],
            contract_digest=digest(contract), arm_role=role, arm_name=arm["name"], implementation_revision=arm["revision"],
            implementation_refs=arm["implementation_refs"], benchmark_id=contract["benchmark_id"],
            benchmark_revision=contract["benchmark_revision"], split=contract["split"], seed=manifest["seed"], group=manifest["group"],
            sample_manifest_ref=sample_ref, labels_or_tests_ref=contract["labels_or_tests_ref"],
            denominator=samples["denominator"], predictions_ref=predictions, sampling=contract["sampling"], budget=contract["budget"],
            resources=manifest["resources"], scorer_identity=contract["scorer"]["identity"], scorer_revision=contract["scorer"]["revision"],
            scorer_code_refs=contract["scorer"]["code_refs"], scorer_command=contract["scorer"]["command"],
            native_metrics=arm_values, raw_output_refs=[output, stderr], native_output_ref=output,
            recorded_at=manifest["result_recorded_at"])
        receipts[role] = write(root, base + "/receipt.json", receipt)
    manifest["native_eval_receipts"] = receipts
    return manifest


def trusted_engineering_replay(root):
    """Live host double for unit tests, not a real scorer or scientific context."""
    def replay(request):
        receipt = request["receipt"]
        return {"nonce": request["nonce"], "request_digest": request["request_digest"],
            "execution_id": "engineering-" + uuid.uuid4().hex, "exit_code": 0,
            "argv": request["command"], "cwd": request["cwd"],
            "input_refs": request["input_refs"], "code_refs": request["scorer"]["code_refs"],
            "scorer_identity": request["scorer"]["identity"], "scorer_revision": request["scorer"]["revision"],
            "stdout_ref": receipt["native_output_ref"], "stderr_ref": receipt["raw_output_refs"][-1],
            "native_output_ref": receipt["native_output_ref"], "started_at": C.now(), "completed_at": C.now()}
    return replay


def schema_contract_examples():
    fixture = ProjectFixture()
    try:
        protocol = fixture.protocol(); native_contract_fixture(fixture.root,protocol)
        protocol["protocol_digest"] = C.protocol_hash(protocol)
        manifest = fixture.runs(protocol)[0][0]; native_run_fixture(fixture.root,protocol,manifest)
        receipt = C.load_file(C.verify_ref(fixture.root,manifest["native_eval_receipts"]["treatment"]))
        return {"native-eval-contract":(copy.deepcopy(protocol["native_eval_contract"]),"native_definition_ref"),
                "native-eval-receipt":(copy.deepcopy(receipt),"predictions_ref")}
    finally: fixture.close()


class NativeEvaluationTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(N, "native evaluation verifier is missing")
        self.f = ProjectFixture(); self.addCleanup(self.f.close)
        self.p = self.f.protocol(); native_contract_fixture(self.f.root, self.p)
        self.p["protocol_digest"] = C.protocol_hash(self.p)
        self.m = self.f.runs(self.p)[0][0]; native_run_fixture(self.f.root, self.p, self.m)
        self.live = trusted_engineering_replay(self.f.root)

    def reject(self, code, action):
        with self.assertRaises(C.Failure) as raised: action()
        self.assertEqual(raised.exception.code, code)

    def rewrite_receipt(self, role, mutation):
        item = C.load_file(C.verify_ref(self.f.root, self.m["native_eval_receipts"][role])); mutation(item)
        self.m["native_eval_receipts"][role] = write(self.f.root, self.m["native_eval_receipts"][role]["path"], item)

    def test_existing_native_contract_and_replayed_arms_return_only_native_metrics(self):
        result = N.verify_run(self.f.root, self.p, self.m, self.live)
        self.assertEqual(result["metrics"], {"accuracy": {"treatment": 0.75, "control": 0.5},
                                              "scope": {"treatment": 0.25, "control": 0.5}})
        self.assertTrue(result["baseline_qualified"]); self.assertTrue(result["positive_control_passed"])
        self.assertIn(self.m["native_eval_receipts"]["baseline"], result["proof_refs"])

    def test_hashed_receipts_without_live_replay_cannot_qualify(self):
        self.reject("NATIVE_SCORER_REPLAY_REQUIRED", lambda: N.verify_run(self.f.root, self.p, self.m))
        self.reject("NATIVE_SCORER_REPLAY_REQUIRED", lambda: N.verify_run(self.f.root, self.p, self.m, {"verified": True}))

    def test_static_callback_result_cannot_impersonate_live_execution(self):
        self.reject("NATIVE_SCORER_REPLAY_NOT_LIVE", lambda: N.verify_run(self.f.root, self.p, self.m,
            lambda request: {"exit_code": 0, "native_output_ref": request["receipt"]["native_output_ref"]}))

    def test_missing_native_contract_is_rejected(self):
        self.p.pop("native_eval_contract")
        self.reject("NATIVE_EVAL_CONTRACT_REQUIRED", lambda: N.verify_protocol(self.f.root, self.p))

    def test_custom_primary_metric_is_rejected_against_existing_native_definition(self):
        self.p["native_eval_contract"]["primary_metric"] = "custom-accuracy"
        self.reject("NATIVE_PRIMARY_METRIC_MISMATCH", lambda: N.verify_protocol(self.f.root, self.p))

    def test_non_native_gate_metric_is_rejected(self):
        self.p["criteria"][0]["metric"] = "bespoke-score"
        self.reject("NATIVE_CRITERION_METRIC_REQUIRED", lambda: N.verify_protocol(self.f.root, self.p))

    def test_hand_selected_split_samples_are_rejected(self):
        other = write(self.f.root, "engineering/native/subset.json", {"sample_ids": ["existing-fixture-1"]})
        self.p["native_eval_contract"]["sample_manifest_ref"] = other
        self.reject("NATIVE_SPLIT_MANIFEST_MISMATCH", lambda: N.verify_protocol(self.f.root, self.p))

    def test_sampling_and_budget_cannot_be_replaced_for_pilot(self):
        for key, replacement in (("sampling", {"policy": "custom", "parameters": {}}), ("budget", {"seconds": 1})):
            p = copy.deepcopy(self.p); p["native_eval_contract"][key] = replacement
            self.reject("NATIVE_" + key.upper() + "_MISMATCH", lambda: N.verify_protocol(self.f.root, p))

    def test_scorer_command_revision_and_code_must_match_archived_native_scorer(self):
        for key, value in (("command", ["custom-scorer"]), ("revision", "new-unverified-version"), ("code_refs", [self.f.source])):
            p = copy.deepcopy(self.p); p["native_eval_contract"]["scorer"][key] = value
            self.reject("NATIVE_SCORER_IDENTITY_MISMATCH", lambda: N.verify_protocol(self.f.root, p))

    def test_missing_control_receipt_does_not_accept_control_boolean(self):
        self.m["native_eval_receipts"].pop("positive")
        self.reject("NATIVE_ARM_RECEIPTS_INCOMPLETE", lambda: N.verify_run(self.f.root, self.p, self.m, self.live))

    def test_native_prediction_ids_and_denominator_are_verified(self):
        self.rewrite_receipt("treatment", lambda receipt: receipt.update(denominator=1))
        self.reject("NATIVE_DENOMINATOR_MISMATCH", lambda: N.verify_run(self.f.root, self.p, self.m, self.live))
        native_run_fixture(self.f.root, self.p, self.m)
        bad = write(self.f.root, "engineering/native/bad-predictions.json", {"predictions": [
            {"sample_id": "existing-fixture-1"}, {"sample_id": "unpublished-handcrafted-sample"}]})
        self.rewrite_receipt("treatment", lambda receipt: receipt.update(predictions_ref=bad))
        self.reject("NATIVE_PREDICTION_SAMPLE_MISMATCH", lambda: N.verify_run(self.f.root, self.p, self.m, self.live))

    def test_replayed_native_value_must_match_recorded_metric(self):
        bad = write(self.f.root, "engineering/native/disagreement.json", {"denominator": 2,
            "native_metrics": {"accuracy": 0.99, "scope": 0.25}})
        def replay(request):
            result = self.live(request)
            if request["arm_role"] == "treatment": result["native_output_ref"] = result["stdout_ref"] = bad
            return result
        self.reject("NATIVE_METRIC_REPLAY_DISAGREEMENT", lambda: N.verify_run(self.f.root, self.p, self.m, replay))

    def test_baseline_and_control_pass_flags_are_derived_from_replayed_native_values(self):
        self.rewrite_receipt("baseline", lambda receipt: receipt.update(native_metrics={"accuracy": 0.1, "scope": 0.5},
            native_output_ref=write(self.f.root, "engineering/native/unqualified.json", {"denominator": 2,
                "native_metrics": {"accuracy": 0.1, "scope": 0.5}})))
        result = N.verify_run(self.f.root, self.p, self.m, self.live)
        self.assertFalse(result["baseline_qualified"])

    def test_replay_refs_do_not_change_deterministic_native_proofs(self):
        first = N.verify_run(self.f.root, self.p, self.m, self.live)
        second = N.verify_run(self.f.root, self.p, self.m, self.live)
        self.assertEqual(first["proof_refs"], second["proof_refs"])
        self.assertEqual(first["metrics"], second["metrics"])

    def select_prefix(self):
        contract = self.p["native_eval_contract"]
        capability = write(self.f.root, "engineering/native/subset-capability.json", {"purpose":"engineering fixture"})
        definition = C.load_file(C.verify_ref(self.f.root, contract["native_definition_ref"]))
        definition["subset_capability"] = {"allowed_rules":["prefix","sha256_rank"],"denominator_rule":"sample_count","source_ref":capability}
        contract["native_definition_ref"] = write(self.f.root, contract["native_definition_ref"]["path"], definition)
        selected = C.load_file(C.verify_ref(self.f.root, contract["sample_manifest_ref"]))
        selected["sample_ids"] = ["existing-fixture-1"]; selected["denominator"] = 1
        contract["selection"] = {"source_manifest_ref":contract["sample_manifest_ref"],
            "selected_manifest_ref":write(self.f.root,"engineering/native/selected.json",selected),
            "rule":"prefix","seed":1,"count":1,"capability_ref":capability}
        self.p["protocol_digest"] = C.protocol_hash(self.p); self.m["protocol_digest"] = self.p["protocol_digest"]
        native_run_fixture(self.f.root, self.p, self.m)

    def test_predeclared_native_subset_is_verified_and_scope_is_retained(self):
        self.select_prefix()
        result = N.verify_run(self.f.root,self.p,self.m,self.live)
        self.assertEqual(result["evaluation_scope"]["selected_manifest_ref"], self.p["native_eval_contract"]["selection"]["selected_manifest_ref"])
        self.assertIn(result["evaluation_scope"]["selected_manifest_ref"], result["proof_refs"])

    def test_subsets_must_follow_declared_released_id_selection_and_native_capability(self):
        self.select_prefix(); contract = self.p["native_eval_contract"]
        bad = C.load_file(C.verify_ref(self.f.root,contract["selection"]["selected_manifest_ref"]))
        bad["sample_ids"] = ["new-handcrafted-sample"]
        contract["selection"]["selected_manifest_ref"] = write(self.f.root,"engineering/native/bad-subset.json",bad)
        self.reject("NATIVE_SUBSET_SELECTION_MISMATCH",lambda:N.verify_protocol(self.f.root,self.p))
        self.select_prefix()
        definition = C.load_file(C.verify_ref(self.f.root, contract["native_definition_ref"])); definition.pop("subset_capability")
        contract["native_definition_ref"] = write(self.f.root,contract["native_definition_ref"]["path"],definition)
        self.reject("NATIVE_SUBSET_CAPABILITY_REQUIRED",lambda:N.verify_protocol(self.f.root,self.p))

    def test_input_mutation_during_live_replay_invalidates_the_execution(self):
        def mutate(request):
            result = self.live(request)
            if request["arm_role"] == "treatment":
                path = C.verify_ref(self.f.root, request["input_refs"][1]); path.write_text('{}')
            return result
        self.reject("EVIDENCE_DIGEST_MISMATCH",lambda:N.verify_run(self.f.root,self.p,self.m,mutate))

    def test_faithful_harness_claim_without_official_parity_proof_is_rejected(self):
        self.p["native_eval_contract"]["scorer"]["kind"] = "faithful_harness"
        self.reject("NATIVE_FAITHFUL_HARNESS_VERIFICATION_REQUIRED",lambda:N.verify_protocol(self.f.root,self.p))

    def make_faithful_fixture(self, tolerance=0):
        contract = self.p["native_eval_contract"]
        official = copy.deepcopy(contract["scorer"])
        harness = copy.deepcopy(official); harness.update(kind="faithful_harness",identity="engineering-harness")
        verification = {"official_scorer":official,"harness_scorer":copy.deepcopy(harness),
            "sample_manifest_ref":contract["sample_manifest_ref"],"source_refs":contract["published_source_refs"],
            "metric_tolerances":{"accuracy":tolerance,"scope":tolerance}}
        harness["verification_ref"] = write(self.f.root,"engineering/native/harness-verification.json",verification)
        contract["scorer"] = harness
        self.p["protocol_digest"] = C.protocol_hash(self.p); self.m["protocol_digest"] = self.p["protocol_digest"]
        native_run_fixture(self.f.root,self.p,self.m)

    def test_faithful_harness_requires_live_official_parity_for_each_arm(self):
        self.make_faithful_fixture()
        self.assertTrue(N.verify_run(self.f.root,self.p,self.m,self.live)["baseline_qualified"])
        mismatch = write(self.f.root,"engineering/native/official-parity-mismatch.json",{
            "denominator":2,"native_metrics":{"accuracy":0.99,"scope":0.5}})
        def replay(request):
            result = self.live(request)
            if request["scorer"]["kind"] == "official": result["native_output_ref"] = result["stdout_ref"] = mismatch
            return result
        self.reject("NATIVE_FAITHFUL_HARNESS_PARITY_FAILED",lambda:N.verify_run(self.f.root,self.p,self.m,replay))

    def test_arbitrary_harness_tolerance_cannot_hide_replacement_scoring(self):
        self.make_faithful_fixture(tolerance=1000)
        self.reject("NATIVE_FAITHFUL_HARNESS_TOLERANCE_UNSOURCED",lambda:N.verify_protocol(self.f.root,self.p))

    def test_hash_selected_released_subset_uses_frozen_seed(self):
        self.select_prefix(); contract=self.p["native_eval_contract"]
        selected=C.load_file(C.verify_ref(self.f.root,contract["selection"]["selected_manifest_ref"]))
        selected["sample_ids"]=["existing-fixture-2"]
        contract["selection"].update(rule="sha256_rank",seed=7,
            selected_manifest_ref=write(self.f.root,"engineering/native/hash-subset.json",selected))
        self.p["protocol_digest"]=C.protocol_hash(self.p);self.m["protocol_digest"]=self.p["protocol_digest"]
        native_run_fixture(self.f.root,self.p,self.m)
        self.assertEqual(N.verify_run(self.f.root,self.p,self.m,self.live)["evaluation_scope"]["selection"]["seed"],7)

    def test_arm_specific_consumption_is_bound_separately_from_run_total_resources(self):
        self.m["native_arm_resources"] = {role:{"seconds":8 if role=="baseline" else 10}
            for role in self.p["native_eval_contract"]["arm_requirements"]}
        self.rewrite_receipt("baseline",lambda receipt:receipt.update(resources={"seconds":8}))
        self.assertTrue(N.verify_run(self.f.root,self.p,self.m,self.live)["baseline_qualified"])
        self.m["native_arm_resources"]["baseline"] = {"seconds":7}
        self.reject("NATIVE_RECEIPT_RESOURCE_MISMATCH",lambda:N.verify_run(self.f.root,self.p,self.m,self.live))

    def group_contracts(self):
        primary=self.p["native_eval_contract"];view=copy.deepcopy(self.p)
        secondary=native_contract_fixture(self.f.root,view,namespace="engineering/native-secondary",benchmark_id="engineering-secondary-fixture")
        # The second archived engineering shape exposes only its native accuracy.
        secondary["metrics"]=[secondary["metrics"][0]]
        definition=C.load_file(C.verify_ref(self.f.root,secondary["native_definition_ref"]));definition["metrics"]=secondary["metrics"]
        secondary["native_definition_ref"]=write(self.f.root,secondary["native_definition_ref"]["path"],definition)
        self.p["required_groups"]=["main","heldout"]
        self.p["native_eval_contracts"]={"main":primary,"heldout":secondary}
        rule=copy.deepcopy(self.p["criteria"][0]);rule.update(id="main-scope",metric="scope",groups=["main"])
        self.p["criteria"].append(rule)
        self.p["protocol_digest"]=C.protocol_hash(self.p);self.m["protocol_digest"]=self.p["protocol_digest"]
        native_run_fixture(self.f.root,self.p,self.m)
        heldout=copy.deepcopy(self.m);heldout.update(run_id="engineering-heldout",group="heldout",metrics={"accuracy":{"treatment":0.75,"control":0.5}})
        native_run_fixture(self.f.root,self.p,heldout)
        return secondary,heldout

    def test_group_specific_existing_contracts_check_only_metrics_selected_for_that_group(self):
        secondary,heldout=self.group_contracts()
        self.assertEqual(N.contract_for_group(self.p,"heldout"),secondary)
        N.verify_protocol(self.f.root,self.p)
        result=N.verify_run(self.f.root,self.p,heldout,self.live)
        self.assertEqual(result["evaluation_scope"]["benchmark_id"],"engineering-secondary-fixture")
        self.assertEqual(result["metrics"],{"accuracy":{"treatment":0.75,"control":0.5}})

    def test_group_contract_inventory_cannot_omit_or_invent_a_required_group(self):
        self.group_contracts();self.p["native_eval_contracts"].pop("heldout")
        self.reject("NATIVE_GROUP_CONTRACTS_INCOMPLETE",lambda:N.verify_protocol(self.f.root,self.p))

    def test_group_native_metric_cannot_be_borrowed_from_other_benchmark(self):
        self.group_contracts();self.p["criteria"][-1]["groups"]=["heldout"]
        self.reject("NATIVE_CRITERION_METRIC_REQUIRED",lambda:N.verify_protocol(self.f.root,self.p))

    def test_malformed_upstream_definition_blocks_as_contract_failure(self):
        contract=self.p["native_eval_contract"]
        definition=C.load_file(C.verify_ref(self.f.root,contract["native_definition_ref"]));definition["source_url"]=12
        contract["native_definition_ref"]=write(self.f.root,contract["native_definition_ref"]["path"],definition)
        with self.assertRaises(C.Failure):N.verify_protocol(self.f.root,self.p)

    def test_malformed_subset_capability_blocks_as_contract_failure(self):
        self.select_prefix();contract=self.p["native_eval_contract"]
        definition=C.load_file(C.verify_ref(self.f.root,contract["native_definition_ref"]))
        definition["subset_capability"]["allowed_rules"]=12
        contract["native_definition_ref"]=write(self.f.root,contract["native_definition_ref"]["path"],definition)
        with self.assertRaises(C.Failure):N.verify_protocol(self.f.root,self.p)

    def test_unavailable_host_replay_blocks_as_inconclusive_reason(self):
        def unavailable(request):raise RuntimeError("engineering host unavailable")
        self.reject("NATIVE_SCORER_REPLAY_UNAVAILABLE",lambda:N.verify_run(self.f.root,self.p,self.m,unavailable))


if __name__ == "__main__": unittest.main()
