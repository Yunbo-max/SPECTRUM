# GitHub and Hugging Face research round trips

**Autonomous branch:** read [autonomous-rsi](autonomous-rsi.md) with this module. Its finite delegated machine supervisor replaces routine human step-7 selection and selects the startup-authorized delivery branch; scientific evidence, existing goals, budgets and same-attempt recovery remain binding. Older human-at-every-batch/main-only wording below describes the baseline and is superseded only within that explicit delegation.

Support assistant preparation → repository delivery → user execution → result
return → evidence review → next decision. Reuse the project's goals, resources,
caller and scientific gates. A round label is a delivery identity, not a new
research-state phase, ledger schema, candidate approval or job scheduler.

Contents: [accounts](#connect-and-verify-accounts),
[web/local roles](#default-weblocal-responsibility-split),
[round delivery](#prepare-and-deliver-each-round),
[Local code entry](#explicit-local-code-entry),
[user execution](#user-execution-and-return),
[result review](#read-returned-evidence-and-route),
[transport examples](#transport-command-examples),
[acceptance](#capability-status-and-acceptance).

## GPT instructions for repository delivery

Apply the GitHub direct pull/push policy in [edition-policy.md](edition-policy.md)
first. Connector file/Git-data operations or authorized ordinary Git provide
transport; Actions, workflow runs and CI control APIs are outside this workflow.
The selected edition and explicit project branch contract override inherited
main-only examples below; never merge the four edition branches for delivery.

Treat an authorized GitHub update as work to finish, not an offer or a generated
push command. Read the saved project target and actual latest repo/branch/files,
reuse current authorization and inspect available write capability. Preserve
other changes and scientific versions; a delivery request does not satisfy a
missing math/code/design prerequisite or permit arbitrary repositories.

Prepare the actual scoped source, configs, complete evaluation coverage and
readable round packet appropriate to the current stage. Keep unfinished scientific
work explicit; a truthful investigation/partial-results packet may be delivered
without certifying the candidate. Stage only intended files, check the relevant
software/source contracts, commit and push or use the real provider writer with
conditional revision checks. Reconcile concurrent/lost-acknowledgment operations
before retrying; no blind reset, force push, secrets or regenerated experiments.

Read back the expected paths at the exact delivered commit and verify content
identity. Return repo, commit and entry-packet path with actual checks and pending
items. A local file/commit, ZIP, proposed command or successful build is not a
successful remote push. If an actual writer/credential/host capability is missing,
retain the concrete package and exact blocker; do not claim the upload happened
or ask again for a push already authorized within the same unchanged scope.

For code/design handoffs, also deliver and source-check the explicit Local entry
below; return its guide/round paths at the same read-back commit. A source push
without the required operating/debug instructions is an incomplete code handoff.

## Web GitHub delivery is main

The owner requires every Web GPT generated/updated code deliverable to reach the
selected GitHub project's literal `main`. Include method source, evaluation and
harness code, configs, complete experiment designs and their handoff records.
This overrides an older saved Web feature-branch/PR preference; record the sourced
target-policy change while keeping the same repo, authorized paths and visibility.
Do not select the default branch when it is not `main`, upload Web code to another
remote branch, or report a PR/unmerged branch as completed delivery. A future
explicit user policy change is recorded before changing this obligation.

1. Read actual current `main` and the relevant files before editing. Prepare only
   scoped changes, retain their parent, actual generated/unexecuted status and
   applicable scientific evidence. Web still does not execute project code/tests.
2. Serialize publication through one integration writer. Working branches used
   only for local isolation are not remote delivery targets. Merge/integrate the
   authorized scoped work into `main` without publishing alternate branches;
   parallel workers hand their outputs to that writer.
3. Commit/push `main` with normal fast-forward or the provider's exact expected-head
   conditional update. If another writer advanced it, reread and reconcile the
   scoped changes on its new head; never force-push, reset or overwrite that work.
   Preserve active remote GPU jobs at their original execution revisions.
4. Verify the delivered commit is reachable from `main`, then read back its exact
   expected source/config/design paths and content identities. Return repo,
   `main`, delivered commit and packet path; a local commit or another branch is
   not delivery. A subsequent advance of `main` does not invalidate a retained
   earlier delivery commit that remains in its ancestry.

If `main` is absent, inspect the actual authorized source snapshot and create it
only within existing repository write scope and supported capability; do not seed
from guessed content. An observed permission/protection/write limitation leaves
delivery pending with the concrete prepared work and exact blocker. Do not bypass
it with force push or silently substitute a PR/other branch. HF revisions and
Local-only delivery choices retain their separate scoped instructions; the Web
GitHub publication rule does not alter them or scientific approval.

## Connect and verify accounts

Apply the Web `main` delivery contract above when resolving GitHub branches;
reuse the selected repository and record the branch policy without repeating intake.

Inspect the named project, current checkout, available tools and saved connection
record first. At new-project startup, confirm both the GitHub delivery repository
and Hugging Face delivery choice before the first idea/work batch, following
[initial-intake.md](initial-intake.md). Reuse explicit choices; ask the two missing
destination questions in the first intake turn, within its three-question limit.
Do not wait for weights, experiments or publication to ask about HF. An explicit
choice not to use HF is valid and retained; an unanswered choice stays unknown.
Model/data download IDs and baseline/source repos are separate from output targets.
Inspect branch, repo type and visibility where possible; ask independently for
only remaining dependencies. Do not pick an unrelated project from history or
enumerate all private repositories. Reuse the current repository visibility;
propose private storage for a new unpublished project rather than silently making
it public. A private research round is distinct from an announced public release.

Save the selected repo/branch/path and Hub repo IDs/types/purposes (or explicit
non-use) with source and timestamp in the project's delivery-target card. Reuse
this map for the first and every subsequent round; each scientific project has its
own selection even inside one supervisor ChatGPT Project. Fetch the actual latest
target contents before editing. A changed destination requires an explicit human
choice and a retained version; avoid reselecting unchanged repos every round.
Unknown destinations allow read-only discovery but block shared round delivery
and dispatch. Do not guess a repo or create one merely to resolve intake.

For first use, provide the account steps supported by the user's current surface:

| Surface | Account handoff and check |
|---|---|
| ChatGPT/Codex connected tools | Use the installed plugin's account connection flow. For GitHub, current official guidance uses Settings → Plugins → GitHub and repository selection. Inspect exposed capabilities: a read-only ChatGPT connection cannot push; available Codex write tools can act within scope. Use the corresponding authenticated identity and exact-repository access check before mutation. |
| User's local/GPU terminal | With installed GitHub CLI, use `gh auth login --web --git-protocol https`, then `gh auth status` and `gh auth setup-git` when Git over HTTPS needs that credential helper. With installed HF CLI, use `hf auth login`, then `hf auth whoami`. Relay an actual supported device/browser authorization flow; older versions may require a token entered only on the user's machine. |
| No sufficient write/download capability | Prepare the same round package and explicit user-side push/upload/return commands, or an authorized attachment. Record the blocked operation. Follow host fallback rules; do not silently change tools or install missing dependencies. |

Never request passwords/tokens in chat or include them in code, commands, bundles,
logs or receipts. Browser login, connected-tool credentials and GPU-machine CLI
credentials are separate contexts; one does not prove another is authenticated.
Confirm destination ownership/repository access and existing visibility without
printing credentials. Expose only the connection facts needed for this project.

Follow existing scoped user instructions for writes; unchanged per-round sync
instructions need no repeated blanket approval. Show the concrete target and
changes before writing. Login does not authorize arbitrary repositories, public
visibility changes, gated terms, additional paid compute or unrelated assets.

## Default web/local responsibility split

Use the owner's selected division of work for the web/GitHub/local/SSH workflow.
Keep the existing scientific project, map, ledgers and selected delivery targets:

| Participant | Work and handoff |
|---|---|
| Web research supervisor | Read pinned evidence and join primary papers, actual code and official benchmark/scorer contents; perform mathematical discovery/review/selection and generate complete requested code plus H03/G01 designs. Review source but do not execute code/tests or model workloads. Push an exact `generated_unexecuted` handoff with all coverage and planned Local acceptance checks. Reuse unchanged qualified reading/evidence. |
| Local execution agent | Run the Codex/GPT control session on the user's computer. Pull the approved revision, stage it on the remote GPU host and use SSH to start harness tests/qualification and approved jobs. Subagents coordinate on the actual controller runtime; the GPU host runs ordinary Python/Conda processes. Retrieve remote raw records, perform E04/finite repairs, then push from the selected delivery checkout and read back the handoff. |
| Human | Review the consolidated report and choose changed requirements, direction reassessment, evidence repair or eligible validation/writing. Reuse explicit earlier decisions for unchanged work; a proposed plan alone does not authorize a new scientific branch. |

Treat this as the user's preferred allocation of analysis and execution. Role
names do not establish which model is stronger or give either surface extra
account, compute or approval capabilities. Local mechanical dispatch and finite
approved debugging continue without waiting for web analysis of every task.
Apply workflow-harness.md's role contract. A Web push confirms generated files
were delivered; a Local result push reports the actual tested/executed scope.
Neither successful upload certifies the other's work. Carry role, exact source
revision, coverage, planned/actual checks and pending acceptance in the packet.
Retain the controller/SSH/remote path map from local-execution-harness.md. Remote
Codex/GPT or remote GitHub credentials are not assumed. The Local controller can
collect results over SSH and use its own scoped GitHub writer; retain the remote
execution identity separately from the result delivery commit.

At each review boundary, the local agent delivers the snapshot and a locator for
web intake. Also deliver a final snapshot when the finite approved queue completes.
A window can end with jobs still running; do not call the whole queue complete,
kill healthy jobs or reset their budgets to make a handoff. Unchanged eligible work
can continue while the web supervisor reviews a pinned snapshot; hold new directions
and materially changed downstream designs for the human's consolidated decision.

Use one integration writer and separate active workspaces. Web publication is
always `main` under the contract above; preparatory branch isolation is not an
alternate remote delivery. The web
supervisor can prepare a proposed next plan while local jobs use their original
versions; coordinate its delivery to avoid overwriting concurrent result commits.
Read-back GitHub delivery does not wake an ordinary web chat. The human invokes
that chat with the locator below; read through actual authorized capabilities.

## Prepare and deliver each round

Include the current linked literature/code/benchmark/hypothesis-to-experiment
record from [literature-evidence.md](literature-evidence.md) in each scientific
round's plan. Deliver exact inspected source identities, read scope, comparison
rationale and unknowns alongside the next code/run tasks; a list of skill names
or experiment counts cannot stand in for completed evidence work.

Begin delivery with the first useful research round, including an initial idea
discussion or a human-chosen eight-hour planning window. Save its investigation,
readiness gaps, qualified ideas and plan to the selected GitHub location; include
code only when requested and scientifically ready. Use the selected HF destination
for actual permitted assets when they exist, with no placeholder upload required.
If HF was explicitly declined, preserve that choice and report any resulting
large-asset storage limitation instead of silently choosing another output repo.
Target selection does not bypass benchmark/baseline discovery, novelty/IPCG or
experiment gates, and does not install a timer, uploader or GPU worker.

Prepare one useful round, not a fixed sequence of every idea. Use a unique round
label and separate run IDs; retain the previous round and its decision. Supply
these deliverables through the approved repositories and the durable project
record. These are user-facing delivery assets; use registered schemas for helper
run/protocol/state artifacts rather than inventing a round-state schema.

| Deliverable | Required contents and normal destination |
|---|---|
| First-round investigation/idea record | Actual task/benchmark/baseline readiness, inspected sources, unresolved gaps, qualified hypotheses when supported, navigation decision and next inspection. GitHub retains this from the first round; a provisional plan is not candidate approval. |
| Plan, such as `rounds/ROUND/PLAN.md` | Question, observation/competing explanation, prediction/falsifier, comparison, metric and sampling/scoring rules, dev vs confirmation, relevant parent/protocol references, budget, stop/recovery rules and expected return files. GitHub stores the scoped export. |
| Code/config and run guide | Actual source, locked environment/setup, pinned model/data/evaluator versions, code changes and the populated Local runbook under local-code-handoff.md. README/AGENTS and the round packet link its exact commands, expected logs/outputs, debugging/recheck instructions and full benchmark coverage. GitHub stores them together; disclose unexecuted/pending steps. |
| Models and large assets | Existing base-model revision or actual produced checkpoint/adapter plus tokenizer/config and minimal usage/card. Hub model repo stores weights; a Hub dataset repo may store approved predictions/logs/result bundles. Record distinct repo IDs/types, sizes, revisions and purpose; do not upload restricted source data merely to make a round complete. |
| Delivery receipt | Round/caller/protocol identity, exact GitHub code commit and changed paths, actual Hub commits/asset digests, transfer status, supported checks and the user's next command. Retain in the project record; link a subsequent repository receipt if desired. |

Generate commands from inspected project files; implement and check a missing
collector in the project when code work is requested and permitted. Do not present
an example `run_round`/`collect_results` path as an existing tested script. Reuse
the native harness. Qualify result-affecting repairs and satisfy the current gate
prerequisites before method implementation/confirmation; preparing a plan does not
grant that readiness. Transport development results without claiming confirmation.

Commit the scoped code/plan/config together when the available writer permits.
Record the resulting code SHA after delivery; do not require a file to contain
its own commit SHA. The later user run must capture the actual checked-out commit
and dirty patch. Preserve prior round/run folders; point an index to the current
round instead of overwriting historical plans or negative runs. Include small
approved result summaries on GitHub and link larger immutable Hub assets.

Verify the actual provider receipt and read back expected paths/content at the
resolved revision. A generated package, submitted write or mutable `main` URL
is insufficient to claim successful delivery. If code succeeds but weights fail,
report each separately and reconcile the missing transfer before retrying it.
Do not rerun an experiment because its upload acknowledgment was lost.

## Explicit Local code entry

Read [local-code-handoff.md](local-code-handoff.md) before delivering experiment
code/config/design. Populate the [Local runbook template](../assets/templates/local-agent-runbook.md)
as the project's `LOCAL_AGENT_RUNBOOK.md` or mapped existing equivalent. Link it
directly from README, applicable AGENTS instructions and the immutable round
`WEB_HANDOFF.md`. Preserve existing instructions/history and use real files,
interfaces, native cases, output paths and host mappings; no invented run scripts.
Link the download section directly too: enumerate every selected benchmark/model
and baseline/control/scorer input with actual acquisition/preparation/check
commands, immutable source and cache/loader path. Bare URLs are not complete
download instructions; unknown access keeps its Local resolution step pending.
Web source/navigation review and `generated_unexecuted` status stay distinct from
Local testing. Read back the entry pointers and actual guide at the delivered
`main` commit, then give a copyable Local instruction with repo/commit/paths.

## User execution and return

Give the user a short next-step card: exact code/asset version, setup command,
run command, output location, collect/return command and what to send back. Follow
the pinned README/AGENTS/Local-guide/round entry above; Local reads it before
running acceptance or choosing a repair. Do not leave entry discovery to guessing.
Reuse existing environments/caches where valid. Fetch/pull only into a compatible clean
checkout; preserve local changes and running jobs. Use a separate worktree or
directory for the pinned round when necessary. No blind reset or force push.

Have the native runner/collector retain a coherent return bundle:

- Identity/provenance: round and run IDs, caller, protocol ID/digest, actual code
  SHA/dirty patch, config/evaluator hashes, data/model/checkpoint revisions,
  sampling/seeds, environment/device and input/output identities.
- Execution: command, start/end evidence, exit/status, resource usage, stdout,
  stderr and checkpoint/resume information. Interrupted/failed runs still return
  their partial files with status; an exit code alone does not prove validity.
- Evidence: per-example predictions/scores/errors and eligible denominators,
  native metric output, comparison labels, and all failed/negative/unselected
  trials. A readable summary accompanies raw evidence, not replaces it.

Keep the small inspection bundle separate from heavyweight checkpoints. Provide
a collector/ZIP command and a scoped Hub upload command if useful. Return to the
selected repo in a unique `rounds/ROUND/runs/RUN` path, to a supported artifact
location, or as an authorized chat attachment. Match the existing classification,
destination and storage allowance. Prefer normal data formats for inspection;
read uploaded code as evidence rather than executing it or unsafe pickle files.

After collection ask for one coherent bundle or its exact repository/revision
and path. For chat attachments use the host's attachment tool; for private Hub
files use authorized access. A private URL alone does not make its contents
readable. If access fails, offer once to reconnect, attach the allowed bundle or
continue provisionally; preserve the missing evidence instead of inventing it.

### Local GitHub result handoff

When already instructed to return results to the selected project GitHub repo,
the local agent completes this delivery as part of the cycle, without requesting
the same push permission again. Produce one readable entry point, normally
`rounds/ROUND/windows/WINDOW/REVIEW_PACKET.md`, or the project's existing equivalent.
Link it from the existing research index; retain earlier windows and a separate
final packet. These paths are delivery examples, not installed collector commands.
Reuse registered run manifests, harness reports and native receipts as raw records;
the packet is a readable view, not a new state schema or a writing/gate approval.

Include these slots in the packet, with unknowns and unfinished checks explicit:

| Slot | Required return contents |
|---|---|
| Snapshot and plan identity | Project/round/window, observed start/end and timezone, window versus final-queue status, approved plan/protocol digests, actual execution code SHA/dirty patch and source/data/model/evaluator versions. |
| Per-idea evidence | All positive/null/adverse/mixed results with run IDs, native scores, eligible samples/denominators, baselines/controls, per-example output locators and remaining comparisons. Preserve failed, unselected and partial trials. |
| Scoped verification | E04 checks actually performed, effective versus frozen parameters, code/scorer concerns, tuning/selection and independent-confirmation status; unresolved obligations and fixes with their version lineage. Execution success alone stays separate from verification. |
| Continuation and resources | Completed/running/queued/paused/failed/blocked tasks, actual job/checkpoint identities, newly produced artifacts and unbound downstream inputs, observed use and remaining cumulative time/GPU/spend/attempt limits. Distinguish eligible unchanged carryover from proposed work. |
| Web review request | Decision-relevant observations, source-reading changes/gaps, competing explanations to revisit, questions for human review and a tentative next-work proposal labeled as such. Include relevant explicit decision notes; do not claim a hidden-thought transcript. |

Collect a coherent snapshot of changing logs/reports into immutable window paths,
with observation times and content digests; preserve originals. Never describe
copied live files as a complete finished run. Keep small readable evidence on
GitHub and link approved larger immutable assets at the saved HF/other destination.
An explicit HF non-use stays binding; a missing large asset is a named evidence gap.

Stage only the authorized result/index paths. For Local-only results reuse the
saved delivery workflow; any Web code/design publication follows `main` above.
Preserve newer remote work and active run workspaces.
Verify that the remote contains the intended commit and read back the packet and
its linked evidence at that revision. If a push acknowledgment is lost, inspect
remote ancestry and content before retrying the same delivery; uploading failure
does not permit rerunning an experiment or force-pushing over another writer.

Return this short locator after remote verification, using actual values:

```text
Web intake: PROJECT_REPO / DELIVERED_COMMIT / REVIEW_PACKET_PATH
Window/final and observed time: ACTUAL_STATUS_AND_TIME
Evidence: VERIFIED_SCOPE / PENDING_CHECKS / RAW_RECORD_LOCATORS
Continuation: RUNNING_JOB_IDS_AND_ELIGIBLE_CARRYOVER / REMAINING_TOTAL_BOUNDS
Request: Read this snapshot, join papers/actual code/official benchmarks,
analyze all candidate outcomes, and propose the next complete experiment plan
for my consolidated decision.
```

The resulting commit SHA belongs in this later locator/receipt, not inside the
file that created that same commit. If push or readback remains blocked, retain
the local packet and report delivery pending; do not label it web-readable.

## Read returned evidence and route

For every returned result and feedback item, apply
[literature-evidence.md](literature-evidence.md)'s joined reading/design contract.
Check relevant primary-paper assumptions, actual GitHub code/config paths and
native benchmark contents/scoring against the new evidence; update the H03/G01
card and next discriminating experiment. Reuse current pinned reads and record
scope/unavailable portions. Every completed run/coherent batch needs E04's scoped
post-run verification before scientific interpretation; mixed scenario effects
route through its diagnosis/fair development tuning. A positive summary or critique
cannot permit a quick-test shortcut or establish the proposed cause by itself.

Within an agreed batch window, retain each result's verification and source links
while continuing the planned tasks under frozen stop/repair rules. Return one
consolidated batch report at the human's chosen checkpoint. Wait for that human
decision before direction reassessment, candidate expansion, a materially changed
design or validation/writing branch under state-and-routing.md; one failed idea
does not start a new direction immediately. Use soft progress reports and up-to-
24-hour continuous approved Local execution; carry unfinished work unchanged
within actual cumulative bounds. Web authoring uses web-background-work.md
without inheriting Local clocks, with durable milestone saves and main readback.
Retain stable idea/run/protocol IDs, source revisions, actual completed/remaining
units and legal checkpoint/job references across window records; completed outputs
remain authoritative at their original paths. A new window is not a new attempt
or confirmation draw. Reconcile actual remote files/job state before continuing.

Fetch the actual returned files at a resolved revision and retain their source
identity/digests. Inspect manifest/config/logs/raw predictions, reconcile them
against the delivered plan and code, and explain discrepancies. Verify completion,
run deduplication, split/seed/metric/sampling/denominator consistency, baseline
qualification and whether confirmation was frozen before results were viewed.
Recompute supported metrics from retained data with the appropriate evaluator;
otherwise disclose which parts remain user-reported or unrecomputable.

Map accepted evidence into the existing registered run manifests/protocol
references when using helpers. The paired-scalar helper is not a parser for every
task; retain native outputs for other designs. A successful upload/checksum proves
transport/content identity, not genuine timestamps or scientific validity.

Return a concise readout: files actually read, valid/partial/mismatched evidence,
observed effect and uncertainty, explanation candidates, remaining gaps and the
next useful action. Invalid implementation/scoring goes to evidence repair at
the actual caller; missing/power-limited evidence stays INCONCLUSIVE. Interpret
valid developmental findings with H01/H03's navigation decision card, preserving
negative evidence and the existing goal/resource brief. New hypotheses require
fresh independent confirmation; result-affecting fixes get the existing child
protocol checks. Apply Gate A/full-validation verdicts only under their contracts.

Update the project's current position and next-round plan from this readout.
Continue within already instructed scope. The user can trigger intake with
“round X finished; read this result bundle”; do not claim continuous monitoring
or start a scheduled task/remote GPU run unless that capability and scope exist.

### Resume the approved next round

The web supervisor first resolves the locator's exact commit and packet, then
reads linked raw records and relevant actual code before interpreting it. State
which linked files were read and which were inaccessible. Distinguish new remote
snapshots from the reviewed one; do not silently mix changing branch contents.
Reuse the human's resource brief and ask only about changed/missing dependencies.

Return the linked paper/code/benchmark analysis, validity and uncertainty, proposed
candidate convergence, and the next complete G01 card with dependencies, expected
outputs, E04 obligations, measured/estimated costs and remaining resource bounds.
Bind that plan to the reviewed result commit and exact affected inputs. Label a
new scientific branch proposed until the actual human decision or satisfied earlier
explicit conditional decision. Keep qualified carryover separate from new work.

Deliver the approved Web plan and requested code to the selected project's `main`,
with a new read-back commit locator. If the web surface cannot write, return the
concrete files/diff and scoped delivery instructions to the designated writer;
prepared text is not a pushed plan. The local agent fetches that exact revision,
reconciles current jobs/results and actual remaining budgets, and starts only
eligible work. Keep running attempts on their original pinned code. Use a separate
worktree for changed code, qualify newly generated inputs before binding them,
and create the required child protocol for result-affecting changes. Preserve
completed/live task IDs and confirmation lineage across this round trip.

## Transport command examples

These are templates for an installed CLI, not executed uploads. Resolve the exact
repo, existing branch, allowed paths and CLI version before rendering a runnable
command. Check local `--help` and current official docs if plugin examples disagree;
current upload/download guidance uses `--repo-type`. Check repository existence
and visibility before upload, since upload may create an absent repo.

```bash
hf upload OWNER/PROJECT-results ./return/round-001 rounds/round-001 --repo-type dataset --revision EXISTING_BRANCH
hf download OWNER/PROJECT-results --repo-type dataset --revision RESOLVED_COMMIT --include "rounds/round-001/*" --local-dir ./received/round-001
hf upload OWNER/PROJECT-model ./approved-checkpoint rounds/round-001 --repo-type model --revision EXISTING_BRANCH
```

For GitHub, use available scoped connector writes or normal Git commands from
the inspected checkout; stage named files and retain the parent commit. Web
delivery updates `main` with an exact-head conditional/fast-forward operation,
not another branch or PR. Local-only result delivery retains its saved scope.
Return attachment collection commands only after
checking the real output root. Never suggest uploading `.` indiscriminately.

## Capability status and acceptance

Report separately: account/access checked; package prepared and checks performed;
code/asset transfer receipt verified; user execution reported/observed; result
files read; evidence validity; next decision. Unknown stages stay unknown. A skill
binding test is not a successful account login, Hub upload or user's GPU run.

Accept a round handoff when the user has actual usable versioned code/commands,
the requested transfers have verified receipts (or a clearly named manual
handoff), and the return bundle/route is explicit. Accept result intake only after
reading accessible raw evidence and stating validity/limits. Each new project
uses its own account/destination scope; shared skills do not share credentials.

Official transport/account sources checked 2026-10-03; recheck on version/UI change:
[GitHub in ChatGPT](https://help.openai.com/en/articles/11145903-connecting-github-to-chatgpt),
[GitHub CLI login](https://cli.github.com/manual/gh_auth_login),
[HF CLI](https://huggingface.co/docs/huggingface_hub/en/guides/cli).
