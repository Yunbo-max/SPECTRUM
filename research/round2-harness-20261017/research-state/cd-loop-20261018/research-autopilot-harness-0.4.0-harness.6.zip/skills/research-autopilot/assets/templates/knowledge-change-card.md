<!-- Adapted from ScholarSkill reading/memory templates at c7cfa2aa305dcf85b3b824019878610175662f9b. MIT: ../licenses/scholar-skill-MIT.txt. Fields revised for scoped evidence, native experiments and batch review. -->
# Knowledge change card

- Card ID, version, project/topic, created/updated UTC:
- Type: semantic | episodic | procedural
- Proposed action: add | merge | update | contradict | deprecate
- Status: proposed | source-supported | contradicted | unresolved | superseded
- Earlier card/version links:

## Proposition and evidence

- Claim / explicit interpretation correction / candidate rule:
- Evidence IDs, primary source version, exact page/file/function/table locators:
- Support type: author report | static inspection | actual run | confirmed result | deduction | hypothesis
- Scope: task/population, assumptions, split, information, parameters and budget:
- Confidence basis, counterevidence, missing access and when not to reuse:

## Connections and revision

| Related card/work/version | Relation | Supporting locator | Scope match or unresolved difference |
|---|---|---|---|
| | supports / contradicts / extends / specializes / similar_to / useful_for / risky_for / standalone | | |

Record the earlier interpretation, the source that corrects it, the revised
understanding and unresolved rivals. Preserve older versions and negative data.
Do not infer hidden reasoning or globally overwrite condition-dependent claims.

## Decision and next experiment

- Impact: S0 context | S1 positioning | S2 evidence obligation | S3 thesis/novelty
- Affected H03/G01/protocol/claim/figure/website references:
- Rival explanation, decisive native-benchmark comparison and possible outcomes:
- Source/parameter/bug questions, fair cost, stop rule and confirmation status:
- Immediate authorized repair or deferred batch-end human decision:
- Consolidated report and actual human decision/readback links:
