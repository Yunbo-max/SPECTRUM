"""CPU contract regression with real canonical recomputation and a scorer double.

The deliberately synthetic engineering fixture does not establish any science.
"""
import copy
import json
import unittest

from fixtures import C as A, ProjectFixture, write
from test_chat_research_goal import C
from test_experiment_contract import ExperimentContractFixture
from test_method_verification import BatchFixture
import verify_methods as V
from chat_control_fixtures import ChatControlFixture


class ChatScienceBridgeTests(unittest.TestCase):
    def setUp(self):
        self.project = ProjectFixture()
        self.addCleanup(self.project.close)
        self.root = self.project.root
        self.f = ExperimentContractFixture(self.root)
        self.batch = BatchFixture(self.root)
        self.code = self.batch.implementation()
        self.path = self.root / 'chat.json'
        self.controls = ChatControlFixture(self.root, C)
        self.addCleanup(self.controls.close)

    def prepare(self, *, effects=(.25, .25), outcome='supported', guardrail=False, mixed=False):
        protocol = self.project.protocol('full-validation')
        protocol['method_version'] = self.code['method_version']
        protocol['native_eval_contract']['arm_requirements']['treatment']['implementation_refs'] = self.code['code_refs']
        protocol['claim_cards'][0]['method_version'] = self.code['method_version']
        if mixed:
            protocol['claim_set'].append('claim-2')
            protocol['indispensable_claim_ids'].append('claim-2')
            second = copy.deepcopy(protocol['criteria'][0])
            second.update(id='second-effect', claim_id='claim-2', contrast={'weights': {'treatment': 1, 'positive': -1}})
            protocol['criteria'].append(second)
            card = copy.deepcopy(protocol['claim_cards'][0])
            card['claim_id'] = 'claim-2'
            protocol['claim_cards'].append(card)
        if guardrail:
            protocol['guardrails'] = {'seconds': 1}
        protocol['protocol_digest'] = A.protocol_hash(protocol)
        protocol_ref = write(self.root, 'canonical-protocol.json', protocol)
        self.batch.design(protocol_ref)
        design_batch = write(self.root, 'design-batch.json', self.batch.batch)
        self.hypothesis = self.f.write(dict(kind='research_hypothesis', candidate_id='c1', proposal_task_id='proposal-a',
            hypothesis='Engineering fixture assertion', derivation='Fixed fixture derivation', prediction='Positive fixed effect',
            falsifier='Nonpositive exact effect'))
        self.design = self.f.write(dict(kind='research_design', candidate_id='c1', hypothesis_ref=self.hypothesis,
            mode='empirical', comparison='Fixed engineering contrast', protocol='Pinned full-validation fixture'))
        contract = self.f.contract
        contract.update(candidate_id='c1', hypothesis_ref=self.hypothesis, protocol_ref=protocol_ref)
        contract['claims'][0]['id'] = 'claim-1'
        contract['claims'][0]['inference']['independent_unit'] = protocol['statistical_design']['unit']
        for obligation in contract['obligations']:
            obligation['claim_ids'] = ['claim-1']
            if obligation.get('evidence_kind') == 'scientific_contrast':
                native = protocol['native_eval_contract']
                obligation['native_scope'] = dict(benchmark=native['benchmark_id'], revision=native['benchmark_revision'],
                    split=native['split'], metric='accuracy', denominator='2',
                    scorer_ref=native['scorer']['code_refs'][0], sample_manifest_ref=native['sample_manifest_ref'])
                obligation['contrast']['canonical_group_ids'] = ['main']
        for job in contract['jobs']:
            job['protocol_ref'] = protocol_ref
            calibration = self.read(job['calibration_ref'])
            calibration['protocol_ref'] = protocol_ref
            job['calibration_ref'] = self.f.write(calibration)
        if mixed:
            second = copy.deepcopy(contract['claims'][0])
            second['id'] = 'claim-2'
            contract['claims'].append(second)
            rows = copy.deepcopy(contract['obligations'])
            for obligation in rows:
                obligation['id'] += '-second'
                obligation['claim_ids'] = ['claim-2']
                if obligation['applicability'] == 'required':
                    contract['jobs'][0]['obligation_ids'].append(obligation['id'])
                if obligation.get('evidence_kind') == 'scientific_contrast':
                    obligation['contrast'].update(canonical_criterion_id='second-effect', weights={'treatment': 1, 'positive': -1})
            contract['obligations'].extend(rows)
        self.contract_ref, self.design_review_ref = self.f.freeze()
        procedure = self.f.write('Engineering-only procedure')
        self.request = self.f.write('Evaluate whether the fixed finite hypothesis is supported or refuted')
        config = dict(goal_id='goal', goal='Evaluate the fixed finite hypothesis', criteria=['evaluated'], deliveries=[],
            procedure=dict(id='v1', ref=procedure), budget=dict(max_attempts=5,
                limits=dict(wall_seconds=100, gpu_seconds=0, cost=0)),
            goal_contract=dict(mode='research', request_ref=self.request, allowed_outcomes=['supported', 'refuted'],
                continuation_action='Execute the frozen comparisons'), tasks=[dict(id='compare', candidate_id='c1',
                kind='research_experiment', action='Execute engineering comparison', dependencies=[],
                experiment_phase='confirmation', experiment_contract_ref=self.contract_ref,
                experiment_review_ref=self.design_review_ref, canonical_batch_ref=design_batch, experiment_job_ids=['compare'],
                input_refs=[self.hypothesis, self.design, self.contract_ref, self.design_review_ref, design_batch])])
        C.initialize(self.path, self.controls.configure(config))
        self.controls.activate(self.path)
        self.event('usage', totals=dict(wall_seconds=2, gpu_seconds=0, cost=0), receipt_ref=self.f.raw)
        handoff = C.advance(self.path, C.status(self.path)['revision'])
        self.assertEqual(handoff['kind'], 'execute', handoff)
        self.attempt = handoff['attempt']
        runs, self.run_refs = self.project.runs(protocol, effects)
        decision = A.evaluate(self.root, protocol, runs, self.run_refs, 'full-validation')
        self.batch.result(write(self.root, 'canonical-decision.json', decision))
        self.result_batch = write(self.root, 'result-batch.json', self.batch.batch)
        self.result_ref = self.batch.batch['candidates'][0]['result_ref']
        self.operational_outcome = 'refuted' if outcome == 'refuted' else 'completed'
        self.raw = [self.f.raw, *self.run_refs]
        envelope = self.f.write(dict(attempt_id=self.attempt['id'], task_id='compare', candidate_id='c1', procedure_id='v1',
            outcome=self.operational_outcome, raw_evidence=self.raw, criteria_met=['evaluated'], delivery_receipts={}))
        self.event('result', attempt_id=self.attempt['id'], evidence_ref=envelope, outcome=self.operational_outcome,
            reason='Observed engineering fixture result', next_action='Review exact comparison')
        cycle_review = self.f.write(dict(kind='research_cycle_review', cycle_id='cycle', candidate_id='c1',
            attempt_ids=[self.attempt['id']], hypothesis_ref=self.hypothesis, design_ref=self.design,
            proposal_task_id='proposal-a', review_task_id='independent-result-review', verdict=outcome,
            unresolved_obligations=[], next_action='Deliver the scoped result', execution_ref=self.f.raw, raw_evidence=[envelope]))
        self.event('research_cycle', cycle=dict(cycle_id='cycle', candidate_id='c1', attempt_ids=[self.attempt['id']],
            hypothesis_ref=self.hypothesis, design_ref=self.design, review_ref=cycle_review))
        completion = self.read(self.f.completion(self.contract_ref, outcome))
        completion['claim_outcomes'] = {'claim-1': 'supported', 'claim-2': 'refuted'} if mixed else {'claim-1': outcome}
        if mixed:
            completion['check_receipts']['reproducibility-second'] = copy.deepcopy(completion['check_receipts']['reproducibility'])
        completion['receipts'][0].update(attempt_id=self.attempt['id'], outcome=self.operational_outcome,
            protocol_ref=protocol_ref, raw_evidence=self.raw, verification_ref=self.result_ref)
        self.completion_ref = self.f.write(completion)
        self.packet = dict(cycle_id='cycle', contract_ref=self.contract_ref, design_review_ref=self.design_review_ref,
            completion_ref=self.completion_ref, canonical_batch_ref=self.result_batch)
        self.event('usage', totals=dict(wall_seconds=3, gpu_seconds=0, cost=0), receipt_ref=self.f.raw)
        return protocol_ref, decision

    def event(self, op, **fields):
        if op == 'result':
            fields.setdefault('strategy_usage', self.controls.usage(fields['attempt_id']))
        return C.record(self.path, C.status(self.path)['revision'], dict(op=op, **fields))

    def read(self, reference):
        return json.loads((self.root / reference['path']).read_text())

    def goal_review(self):
        state = C.status(self.path)
        return self.f.write(dict(kind='goal_review', goal_id=state['goal_id'], goal=state['goal'],
            goal_revision=state['goal_revision'], state_revision=state['revision'], goal_contract=state['goal_contract'],
            criteria=state['criteria'], deliveries=state['deliveries'], attempt_ids=[a['id'] for a in state['attempts']],
            cycle_ids=['cycle'], proposal_task_id='goal-proposal', review_task_id='goal-review', outcome='complete',
            execution_ref=self.f.raw, scientific_evidence=[self.packet],
            claim_coverage={'evaluated': [dict(cycle_id='cycle', claim_id='claim-1')]},
            raw_evidence=[state['attempts'][0]['evidence_ref'], state['research_cycles'][0]['review_ref'],
                          self.contract_ref, self.design_review_ref, self.completion_ref, self.result_batch]))

    def test_canonical_positive_cpu_fixture_closes_and_tamper_revokes_completion(self):
        self.prepare()
        self.event('goal_review', review_ref=self.goal_review())
        self.assertEqual(C.next_action(self.path)['kind'], 'bookkeeping_complete')
        (self.root / self.run_refs[0]['path']).write_text('{}')
        self.assertNotEqual(C.next_action(self.path)['kind'], 'bookkeeping_complete')

    def test_canonical_negative_hypothesis_goal_closes_without_positive_credit(self):
        self.prepare(effects=(0, 0), outcome='refuted')
        self.event('goal_review', review_ref=self.goal_review())
        self.assertEqual(C.next_action(self.path)['kind'], 'bookkeeping_complete')
        self.assertEqual(C.status(self.path)['research_cycles'][0]['recorded_verdict'], 'refuted')

    def test_resource_kill_cannot_become_scientific_refutation(self):
        _, decision = self.prepare(outcome='refuted', guardrail=True)
        self.assertEqual(decision['outcome'], 'KILL')
        self.assertIn('FATAL_RESOURCE_GUARDRAIL', decision['reason_codes'])
        with self.assertRaisesRegex(ValueError, 'canonical claim scope'):
            self.event('goal_review', review_ref=self.goal_review())

    def test_missing_live_native_replay_cannot_trust_saved_pass(self):
        self.prepare()
        with C.scientific_runtime(native_replay_context=None):
            with self.assertRaisesRegex(ValueError, 'canonical scientific verification pending'):
                self.event('goal_review', review_ref=self.goal_review())

    def test_mixed_claim_kill_retains_supported_and_refuted_scope_separately(self):
        protocol_ref, decision = self.prepare(outcome='refuted', mixed=True)
        self.assertEqual(decision['outcome'], 'KILL')
        actual = V.verify_chat_science(self.root, self.result_batch, 'c1', protocol_ref, through='results', contract=self.f.contract)
        self.assertEqual(actual['claim_outcomes'], {'claim-1': 'supported', 'claim-2': 'refuted'})
        review = self.read(self.goal_review())
        review['claim_coverage']['evaluated'].append(dict(cycle_id='cycle', claim_id='claim-2'))
        self.event('goal_review', review_ref=self.f.write(review))
        self.assertEqual(C.next_action(self.path)['kind'], 'bookkeeping_complete')

    def test_contract_contrast_metric_or_sample_cannot_claim_another_protocol(self):
        protocol_ref, _ = self.prepare()
        for key, value in [('metric', 'unmeasured'), ('sample_manifest_ref', self.f.raw)]:
            contract = copy.deepcopy(self.f.contract)
            contrast = next(o for o in contract['obligations'] if o.get('evidence_kind') == 'scientific_contrast')
            contrast['native_scope'][key] = value
            with self.subTest(key=key), self.assertRaises(A.Failure):
                V.verify_chat_science(self.root, self.result_batch, 'c1', protocol_ref, contract=contract)

    def test_claimed_mechanism_or_precision_cannot_reuse_weaker_native_comparison(self):
        protocol_ref, _ = self.prepare()
        for change in ('mechanism', 'precision', 'independent_unit'):
            contract = copy.deepcopy(self.f.contract)
            if change == 'mechanism':
                contrast = next(o for o in contract['obligations'] if o.get('evidence_kind') == 'scientific_contrast')
                contrast['contrast']['weights'] = {'treatment': 1, 'positive': -1}
            elif change == 'precision':
                contract['claims'][0]['inference']['planned_units'] = 10
            else:
                contract['claims'][0]['inference']['independent_unit'] = 'dataset'
            with self.subTest(change=change), self.assertRaises(A.Failure):
                V.verify_chat_science(self.root, self.result_batch, 'c1', protocol_ref, contract=contract)

    def test_final_accounting_must_cover_actual_job_consumption(self):
        self.prepare()
        completion = self.read(self.completion_ref)
        completion['receipts'][0]['actual_usage']['wall_seconds'] = 20
        self.completion_ref = self.f.write(completion)
        self.packet['completion_ref'] = self.completion_ref
        with self.assertRaisesRegex(ValueError, 'completion accounting'):
            self.event('goal_review', review_ref=self.goal_review())

    def test_frozen_completed_jobs_cannot_be_replayed_or_reuse_old_usage(self):
        self.prepare()
        task = copy.deepcopy(C.status(self.path)['tasks'][0])
        task['id'] = 'replay'
        self.event('add_task', task=task)
        action = C.advance(self.path, C.status(self.path)['revision'])
        self.assertEqual(action['kind'], 'replan')
        self.assertIn('settled frozen jobs', action['action'])
        self.assertEqual(C.status(self.path)['started_attempts'], 1)
        state = C.status(self.path)
        state['usage']['observed_attempt_ids'] = []
        with self.assertRaisesRegex(ValueError, 'refresh actual cumulative usage'):
            C._experiment_admission(self.root, task, state)


if __name__ == '__main__':
    unittest.main()
