#!/usr/bin/env python3
"""Evidence-bound research scheduling; no scientific oracle or executor.

The caller owns locking/atomic checkpoint saves and supplies ``read_ref(root,
ref, as_json=False)``. This module never launches work, changes scientific credit,
or measures usage. Independent receipts bind observed work, not guaranteed truth.
Legacy checkpoints remain readable and settleable; a sourced migration is needed
before new research work. Family and project counters never reset on renaming.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import importlib.util
from pathlib import Path
_reasoning_spec = importlib.util.spec_from_file_location('chat_research_reasoning', Path(__file__).with_name('research_reasoning.py'))
reasoning = importlib.util.module_from_spec(_reasoning_spec)
_reasoning_spec.loader.exec_module(reasoning)

UNITS = ('wall_seconds', 'gpu_seconds', 'cost')
INTENT_FIELDS = ('intent_ref',)
PURPOSES = {'acquire', 'qualify', 'unblock', 'independent_review', 'main_evidence',
            'analysis', 'diagnostic'}
RECOVERY = {'acquire', 'qualify', 'unblock', 'independent_review'}
PRIORITY = {'unblock': 0, 'qualify': 1, 'acquire': 2, 'independent_review': 3,
            'main_evidence': 4, 'analysis': 5, 'diagnostic': 6}


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + ' must be nonempty text')
    return value


def _ids(value, label, nonempty=True):
    if not isinstance(value, list) or (nonempty and not value):
        raise ValueError(label + ' must be a list')
    if len({_text(v, label) for v in value}) != len(value):
        raise ValueError(label + ' must be unique')
    return value


def _number(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
        raise ValueError(label + ' must be finite and nonnegative')
    return value


def _positive_int(value, label):
    if type(value) is not int or value < 1:
        raise ValueError(label + ' must be a positive finite integer')
    return value


def _amounts(value, label):
    if not isinstance(value, dict) or set(value) != set(UNITS):
        raise ValueError(label + ' must cover wall_seconds, gpu_seconds and cost')
    return {u: _number(value[u], label + '.' + u) for u in UNITS}


def _refs(root, values, read_ref, nonempty=True):
    if not isinstance(values, list) or (nonempty and not values):
        raise ValueError('pinned evidence references required')
    for value in values:
        read_ref(root, value)


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def _review(root, receipt, read_ref):
    if _text(receipt.get('review_task_id'), 'independent review task') == _text(receipt.get('proposal_task_id'), 'proposal task'):
        raise ValueError('separate strategy reviewer task required')
    read_ref(root, receipt.get('execution_ref'))
    _refs(root, receipt.get('raw_evidence'), read_ref)


def _research(state):
    return (state.get('goal_contract') or {}).get('mode') == 'research'


def _config(root, state, reference, read_ref, *, current_goal=True):
    value = read_ref(root, reference, as_json=True)
    if value.get('kind') != 'chat_research_strategy' or value.get('goal_id') != state['goal_id']:
        raise ValueError('strategy goal binding mismatch')
    if current_goal and value.get('request_ref') != (state.get('goal_contract') or {}).get('request_ref'):
        raise ValueError('strategy must retain the original sourced goal request')
    read_ref(root, value['request_ref'])
    read_ref(root, value.get('source_ref'))
    obligations = value.get('obligations')
    if not isinstance(obligations, list) or not obligations:
        raise ValueError('strategy obligations required')
    _ids([o.get('id') for o in obligations], 'obligation identities')
    for obligation in obligations:
        _text(obligation.get('description'), 'obligation description')
        if obligation.get('priority') not in {'critical', 'required', 'optional'}:
            raise ValueError('obligation priority required')
        for key in ('criterion_ids', 'delivery_ids'):
            _ids(obligation.get(key), key, nonempty=False)
    for key, original in (('criterion_ids', 'criteria'), ('delivery_ids', 'deliveries')):
        covered = {x for o in obligations for x in o[key]}
        if current_goal and covered != set(state[original]):
            raise ValueError('strategy must cover exactly all goal ' + original)
    families = value.get('families')
    if not isinstance(families, list) or not families:
        raise ValueError('stable research families required')
    _ids([f.get('id') for f in families], 'family identities')
    mechanisms = []
    for family in families:
        mechanisms.append(' '.join(_text(family.get('mechanism'), 'family mechanism').lower().split()))
        read_ref(root, family.get('mechanism_ref'))
        bounds = family.get('diagnostic_limits', {})
        _positive_int(bounds.get('max_attempts'), 'family diagnostic max_attempts')
        _amounts({u: bounds.get(u) for u in UNITS}, 'family diagnostic limits')
    if len(set(mechanisms)) != len(mechanisms):
        raise ValueError('renamed copies of one mechanism must share a family')
    limits = value.get('limits', {})
    for key in ('max_no_progress_attempts', 'max_diagnostic_attempts'):
        _positive_int(limits.get(key), key)
    for unit in UNITS:
        _number(limits.get('diagnostic_' + unit), 'diagnostic_' + unit)
    return value


def initialize(root, state, config, read_ref):
    """Initialize optional strategy; absence intentionally needs later migration."""
    state.pop('strategy', None)  # Never accept caller-injected counters at init.
    if config.get('strategy_ref') is not None:
        adopt_strategy(root, state, config['strategy_ref'], read_ref)


def adopt_strategy(root, state, reference, read_ref, review_ref=None):
    """Adopt at a settled boundary. Existing identity, obligations and limits persist."""
    if state.get('current_attempt'):
        raise ValueError('settle the current attempt before strategy adoption')
    config = _config(root, state, reference, read_ref)
    old = state.get('strategy')
    attempts = state.get('attempts', [])
    review = None
    if old or attempts:
        review = read_ref(root, review_ref, as_json=True)
        if (review.get('kind') != 'chat_strategy_adoption' or review.get('goal_id') != state['goal_id']
                or review.get('strategy_ref') != reference
                or review.get('previous_strategy_ref') != (old or {}).get('ref')
                or review.get('attempt_ids') != [a['id'] for a in attempts]):
            raise ValueError('strategy adoption must bind all historical attempts and previous strategy')
        _review(root, review, read_ref)
        _text(review.get('reason'), 'strategy adoption reason')
    if old:
        # A valid goal extension deliberately makes the old strategy incomplete.
        # Validate its historical bytes/structure, not against newly added scope.
        previous = _config(root, state, old['ref'], read_ref, current_goal=False)
        if previous['limits'] != config['limits']:
            raise ValueError('strategy adoption cannot reset or increase cumulative limits')
        new_obligations = {o['id']: o for o in config['obligations']}
        for obligation in previous['obligations']:
            new = new_obligations.get(obligation['id'])
            if not new or any(new.get(k) != obligation[k] for k in ('description', 'priority')):
                raise ValueError('strategy adoption cannot remove or weaken original obligations')
            if any(not set(obligation[k]) <= set(new[k]) for k in ('criterion_ids', 'delivery_ids')):
                raise ValueError('strategy adoption cannot shrink original obligation coverage')
        new_families = {f['id']: f for f in config['families']}
        if any(new_families.get(f['id']) != f for f in previous['families']):
            raise ValueError('existing family identity and diagnostic limits are immutable')
        old_ids = {f['id'] for f in previous['families']}
        added = set(new_families) - old_ids
        changes = review.get('new_families', {})
        if set(changes) != added:
            raise ValueError('new families require reviewed substantive mechanism differences')
        for family_id, change in changes.items():
            _text(change.get('substantive_delta'), 'substantive family difference')
            _refs(root, change.get('evidence_refs'), read_ref)
            predecessors = _ids(change.get('predecessor_family_ids'), 'previous families')
            if not set(predecessors) <= old_ids:
                raise ValueError('new family predecessor must retain known history')
        old['adoptions'].append({'previous_ref': old['ref'], 'ref': reference, 'review_ref': review_ref})
        old['ref'] = copy.deepcopy(reference)
        return
    ledger = dict(schema_version=1, ref=copy.deepcopy(reference), entries={},
                  candidate_families={}, qualifications=[], progress=[], progress_watermark=0,
                  settled_attempt_ids=[], reviews=[], adoptions=[], bindings=[])
    if attempts:
        historical = review.get('historical_attempts')
        if not isinstance(historical, list) or [x.get('attempt_id') for x in historical] != [a['id'] for a in attempts]:
            raise ValueError('migration must account every old attempt, including failures')
        family_ids = {f['id'] for f in config['families']}
        for attempt, entry in zip(attempts, historical):
            if entry.get('family_id') not in family_ids or type(entry.get('diagnostic')) is not bool:
                raise ValueError('historical attempt family and diagnostic classification required')
            if (attempt.get('kind') == 'research_experiment' and attempt.get('experiment_phase') != 'confirmation'
                    and not entry['diagnostic']):
                raise ValueError('historical diagnostic experiments cannot be relabeled to erase usage')
            # Actual unknown usage remains an unresolved reservation; no invented actuals.
            reserve = _amounts(entry.get('reservation'), 'historical reservation')
            read_ref(root, entry.get('reservation_source_ref'))
            actual = None
            if entry.get('usage') is not None:
                actual = _usage_receipt(root, attempt['id'], entry['usage'], read_ref)
            ledger['entries'][attempt['id']] = dict(attempt_id=attempt['id'], family_id=entry['family_id'],
                candidate_id=attempt['candidate_id'], diagnostic=entry['diagnostic'], estimate=reserve,
                actual=actual, usage_ref=(entry.get('usage') or {}).get('receipt_ref'),
                settled=True, outcome=attempt.get('outcome'), legacy=True)
            existing = ledger['candidate_families'].setdefault(attempt['candidate_id'], entry['family_id'])
            if existing != entry['family_id']:
                raise ValueError('candidate renaming cannot split historical family accounting')
            ledger['settled_attempt_ids'].append(attempt['id'])
        ledger['adoptions'].append({'previous_ref': None, 'ref': reference, 'review_ref': review_ref})
    state['strategy'] = ledger


def _loaded(root, state, read_ref):
    ledger = state.get('strategy')
    if not ledger or ledger.get('schema_version') != 1:
        raise ValueError('research strategy migration required before new dispatch')
    return ledger, _config(root, state, ledger['ref'], read_ref)


def validate_task(root, task, state, read_ref):
    """Validate intent structure; missing investment qualification is admission-only."""
    if not _research(state):
        return None
    ledger, config = _loaded(root, state, read_ref)
    intent = read_ref(root, task.get('intent_ref'), as_json=True)
    if (intent.get('kind') != 'chat_task_intent' or intent.get('goal_id') != state['goal_id']
            or intent.get('candidate_id') != task['candidate_id']):
        raise ValueError('task intent goal or candidate mismatch')
    if intent.get('family_id') not in {f['id'] for f in config['families']}:
        raise ValueError('task intent must retain a registered mechanism family')
    prior = ledger['candidate_families'].get(task['candidate_id'])
    if prior and prior != intent['family_id']:
        raise ValueError('a candidate cannot change family to reset accounting')
    if not set(_ids(intent.get('obligation_ids'), 'intent obligations')) <= {o['id'] for o in config['obligations']}:
        raise ValueError('task intent names an unknown goal obligation')
    if intent.get('purpose') not in PURPOSES:
        raise ValueError('declared research purpose required')
    for key in ('decision', 'falsifier'):
        _text(intent.get(key), 'intent ' + key)
    estimate = _amounts(intent.get('estimate'), 'intent estimate')
    if estimate['wall_seconds'] <= 0:
        raise ValueError('positive bounded wall-time estimate required')
    read_ref(root, intent.get('scope_ref'))
    experiment = task.get('kind') == 'research_experiment'
    if experiment and intent['purpose'] in RECOVERY:
        if (intent['purpose'] != 'qualify' or task.get('experiment_phase') != 'diagnostic'
                or intent.get('prerequisite_only') is not True
                or not set(_ids(intent.get('qualification_targets'), 'prerequisite checks')) <=
                {'baseline_fidelity', 'resource_calibration', 'metric_validity'}):
            raise ValueError('only bounded qualification checks may precede candidate investment')
    if intent['purpose'] == 'diagnostic' and task.get('experiment_phase') == 'confirmation':
        raise ValueError('diagnostic intent cannot relabel confirmation work')
    # Repair and task-version identities preserve their original scientific intent.
    by_id = {t['id']: t for t in state.get('tasks', [])}
    predecessor = by_id.get(task.get('repairs') or task.get('supersedes'))
    if predecessor and predecessor.get('intent_ref') and predecessor['intent_ref'] != task['intent_ref']:
        old = read_ref(root, predecessor['intent_ref'], as_json=True)
        if (old['family_id'] != intent['family_id'] or
                not set(old['obligation_ids']) <= set(intent['obligation_ids'])):
            raise ValueError('successor cannot drop the original family or obligations')
    return intent


def _diagnostic(task, intent):
    return intent['purpose'] == 'diagnostic' or (
        task.get('kind') == 'research_experiment' and task.get('experiment_phase') != 'confirmation')


def _purpose(task, intent, state):
    """Only an actual classified engineering failure grants repair priority.

    The unchanged intent still supplies family/obligations and all diagnostic
    accounting. A repair is not permission to claim scientific confirmation.
    """
    if task.get('repairs') and task.get('failure_context'):
        failure = next((a for a in state.get('attempts', [])
                        if a['id'] == task['failure_context'].get('attempt_id')), None)
        if (failure and failure.get('task_id') == task['repairs'] and failure.get('outcome') == 'failed'
                and failure.get('failure_class') in {'environment', 'implementation', 'evaluation'}):
            return 'unblock'
    return intent['purpose']


def _totals(ledger, family_id=None):
    entries = [e for e in ledger['entries'].values() if e['diagnostic'] and
               (family_id is None or e['family_id'] == family_id)]
    return {'attempts': len(entries), **{u: sum((e['actual'] if e['actual'] is not None else e['estimate'])[u]
                                               for e in entries) for u in UNITS}}


def summary(state):
    """Summarize saved observations; admission separately revalidates evidence."""
    ledger = state.get('strategy')
    if not ledger:
        return {'migration_required': _research(state)}
    return dict(diagnostic_usage=_totals(ledger),
        unsettled_usage_attempt_ids=[i for i, e in ledger['entries'].items() if e['actual'] is None],
        no_progress_attempts=len(ledger['settled_attempt_ids']) - ledger['progress_watermark'],
        total_settled_attempts=len(ledger['settled_attempt_ids']),
        progress_events=len(ledger['progress']), strategy_ref=ledger['ref'])


def _progress_watermark(root, state, ledger, read_ref):
    """Unavailable/replaced progress bytes cannot keep suppressing stagnation."""
    watermark = 0
    attempts = {a['id']: a for a in state.get('attempts', [])}
    for observation in ledger['progress']:
        try:
            receipt = read_ref(root, observation['ref'], as_json=True)
            _review(root, receipt, read_ref)
            for change in receipt['changes']:
                _refs(root, change['evidence_refs'], read_ref)
            for attempt_id in observation['attempt_ids']:
                read_ref(root, attempts[attempt_id]['evidence_ref'])
        except (ValueError, OSError, KeyError, TypeError):
            continue
        watermark = max(watermark, observation['watermark'])
    return watermark


def _review_authorizes(root, ledger, intent_ref, read_ref):
    for observation in reversed(ledger['reviews']):
        if intent_ref not in observation['intent_refs'] or observation['through_attempt_ids'] != ledger['settled_attempt_ids']:
            continue
        try:
            receipt = read_ref(root, observation['ref'], as_json=True)
            _review(root, receipt, read_ref)
        except (ValueError, OSError, KeyError, TypeError):
            continue
        if (receipt.get('strategy_ref') == ledger['ref'] and receipt.get('attempt_ids') == ledger['settled_attempt_ids']
                and receipt.get('next_intent_refs') == observation['intent_refs']):
            return True
    return False


def guard(root, state, read_ref):
    """Global dispatch guard only. Call after ongoing reconciliation/continuation."""
    if not _research(state):
        return None
    if not state.get('strategy'):
        return dict(kind='needs_strategy_review', reason='strategy_migration_required',
                    action='Adopt a sourced research strategy and bind pending task intents; preserve all history')
    try:
        _loaded(root, state, read_ref)
    except (ValueError, OSError, KeyError, TypeError) as error:
        return dict(kind='needs_strategy_review', reason='strategy_source_invalid', detail=str(error),
                    action='Restore the pinned strategy source without erasing counters or attempts')
    return None


def order_tasks(root, state, tasks, read_ref):
    """Stable ordering by obligation importance, critical dependency, purpose, cost.

    Invalid intents go last so a missing candidate qualification cannot suppress
    unrelated affordable acquisition, baseline qualification or independent review.
    """
    if not _research(state) or not state.get('strategy'):
        return list(tasks)
    _, config = _loaded(root, state, read_ref)
    obligations = {o['id']: {'critical': 0, 'required': 1, 'optional': 2}[o['priority']]
                   for o in config['obligations']}
    intents = {}
    for task in tasks:
        try:
            intents[task['id']] = validate_task(root, task, state, read_ref)
        except (ValueError, OSError, TypeError, KeyError):
            pass
    def key(task):
        intent = intents.get(task['id'])
        if intent is None:
            return (9, 9, 9, 0)
        priority = min(obligations[o] for o in intent['obligation_ids'])
        descendants = {task['id']}
        changed = True
        while changed:
            changed = False
            for other in state.get('tasks', []):
                if other['id'] not in descendants and set(other.get('dependencies', [])) & descendants:
                    descendants.add(other['id'])
                    changed = True
        downstream = [intents[i] for i in descendants if i in intents]
        critical_path = any(any(obligations[o] == 0 for o in i['obligation_ids']) for i in downstream)
        # Optional diagnostic tagging cannot outrank required evidence solely via dependencies.
        purpose = _purpose(task, intent, state)
        return (priority, 0 if critical_path and purpose in RECOVERY else 1,
                PRIORITY[purpose], intent['estimate']['wall_seconds'])
    selected_ids = set()
    reference = state['strategy'].get('reasoning_ref')
    if reference is not None:
        decision = read_ref(root, reference, as_json=True)
        report = reasoning.check_decision(root, decision, goal_id=state['goal_id'])
        if not report['gaps']:
            selected_ids = set(report['selected_task_ids'])
    return sorted(tasks, key=lambda task: (0 if task['id'] in selected_ids else 1, *key(task)))


def _qualification(root, state, intent, read_ref):
    ledger, _ = _loaded(root, state, read_ref)
    for reference in reversed(ledger['qualifications']):
        receipt = read_ref(root, reference, as_json=True)
        if (receipt.get('candidate_id') == intent['candidate_id'] and
                receipt.get('family_id') == intent['family_id'] and receipt.get('scope_ref') == intent['scope_ref']):
            _validate_qualification(root, state, receipt, read_ref)
            return
    raise ValueError('source, native baseline and nearest-work qualification required for this exact scope')


def _validate_qualification(root, state, receipt, read_ref):
    if receipt.get('kind') != 'chat_research_qualification' or receipt.get('goal_id') != state['goal_id']:
        raise ValueError('qualification goal binding mismatch')
    _, config = _loaded(root, state, read_ref)
    if receipt.get('family_id') not in {f['id'] for f in config['families']}:
        raise ValueError('qualification family is unknown')
    scope = read_ref(root, receipt.get('scope_ref'), as_json=True)
    if scope.get('kind') != 'chat_research_scope' or scope.get('candidate_id') != receipt.get('candidate_id'):
        raise ValueError('qualification scope candidate mismatch')
    for field in ('implementation_ref', 'protocol_ref', 'default_parameters_ref'):
        read_ref(root, scope.get(field))
    baselines = scope.get('baselines')
    if not isinstance(baselines, list) or not baselines:
        raise ValueError('qualified strong simple baseline pins required')
    for baseline in baselines:
        for field in ('implementation_ref', 'protocol_ref', 'default_parameters_ref'):
            read_ref(root, baseline.get(field))
        if baseline.get('implementation_kind') not in {'official', 'qualified_port'}:
            raise ValueError('distinguish official code from a qualified port')
    if scope.get('claim_kind') not in {'new_method', 'comparison', 'replication'}:
        raise ValueError('scoped claim kind required')
    checks = receipt.get('checks', {})
    for name in ('source', 'baseline', 'nearest_work'):
        check = checks.get(name, {})
        _refs(root, check.get('evidence_refs'), read_ref)
        _text(check.get('finding'), name + ' finding')
        expected = {'distinct_testable_gap'} if scope['claim_kind'] == 'new_method' else {'known_comparison', 'distinct_testable_gap'}
        if check.get('verdict') not in (expected if name == 'nearest_work' else {'verified'}):
            raise ValueError('unresolved ' + name + ' qualification')
    _review(root, receipt, read_ref)


def admit_task(root, task, state, read_ref):
    if not _research(state):
        return
    intent = validate_task(root, task, state, read_ref)
    ledger, config = _loaded(root, state, read_ref)
    diagnostic = _diagnostic(task, intent)
    purpose = _purpose(task, intent, state)
    no_progress = len(ledger['settled_attempt_ids']) - _progress_watermark(root, state, ledger, read_ref)
    threshold = config['limits']['max_no_progress_attempts']
    stalled = no_progress >= threshold
    # Missing qualification must not block acquiring it. Recovery itself still
    # gets one finite window; endlessly renamed acquisition tasks cannot evade review.
    if stalled and (purpose not in RECOVERY or no_progress >= 2 * threshold):
        authorized = _review_authorizes(root, ledger, task['intent_ref'], read_ref)
        if not authorized:
            raise ValueError('strategy_review_required: repeated attempts made no reviewed goal progress')
    early_inquiry = False
    if (task.get('research_scope') == 'diagnostic' and task.get('reasoning_ref')
            and task.get('kind') == 'action' and purpose == 'diagnostic'):
        decision = read_ref(root, task['reasoning_ref'], as_json=True)
        scope = read_ref(root, intent['scope_ref'], as_json=True)
        if (decision.get('schema_version') == 4
                and (decision.get('inquiry') or {}).get('stage') in {'lead', 'hypothesis'}
                and scope.get('kind') == 'chat_research_scope'
                and scope.get('candidate_id') == task.get('candidate_id')
                and scope.get('claim_kind') == 'investigation'):
            reasoning.require_task(root, task, candidate_id=task['candidate_id'],
                goal_id=state['goal_id'], accepted_ref=ledger.get('reasoning_ref'),
                require_accepted=True, expand=False)
            early_inquiry = True
    if not early_inquiry and purpose not in RECOVERY and (purpose in {'main_evidence', 'diagnostic'} or
            task.get('kind') == 'research_experiment'):
        _qualification(root, state, intent, read_ref)
    if purpose not in RECOVERY and any(e['settled'] and e['actual'] is None for e in ledger['entries'].values()):
        raise ValueError('actual prior usage or reconciliation required before new investment')
    if purpose not in RECOVERY:
        for entry in ledger['entries'].values():
            if entry['actual'] is not None:
                read_ref(root, entry.get('usage_ref'))
    if diagnostic:
        if any(e['settled'] and e['actual'] is None for e in ledger['entries'].values() if e['diagnostic']):
            raise ValueError('diagnostic actual usage or reconciliation required before new investment')
        family = next(f for f in config['families'] if f['id'] == intent['family_id'])
        for totals, bounds in ((_totals(ledger), dict(max_attempts=config['limits']['max_diagnostic_attempts'],
                **{u: config['limits']['diagnostic_' + u] for u in UNITS})),
                (_totals(ledger, intent['family_id']), family['diagnostic_limits'])):
            if totals['attempts'] >= bounds['max_attempts']:
                raise ValueError('cumulative diagnostic attempt limit reached; renamed tasks cannot reset it')
            if any(totals[u] + intent['estimate'][u] > bounds[u] for u in UNITS):
                raise ValueError('cumulative diagnostic reservation exceeds remaining budget')
    # Respect project-wide observations without inventing fresh per-round budgets.
    project_limits = state.get('budget', {}).get('limits', {})
    if project_limits and state.get('usage', {}).get('observed_attempt_ids', []) != [a['id'] for a in state.get('attempts', [])]:
        raise ValueError('refresh actual cumulative project usage through every settled attempt before new dispatch')
    for unit, limit in project_limits.items():
        if unit in UNITS:
            observed = state.get('usage', {}).get('totals', {}).get(unit)
            if observed is None or observed + intent['estimate'][unit] > limit:
                raise ValueError('intent exceeds observed remaining project ' + unit)


def before_begin(root, state, task, attempt, read_ref):
    if not _research(state):
        return
    reasoning.require_host_feedback(root, task, state.get('strategy', {}).get('reasoning_experiment_receipts', []))
    admit_task(root, task, state, read_ref)
    intent = validate_task(root, task, state, read_ref)
    ledger = state['strategy']
    if attempt['id'] in ledger['entries']:
        raise ValueError('strategy attempt already reserved')
    ledger['candidate_families'].setdefault(task['candidate_id'], intent['family_id'])
    ledger['entries'][attempt['id']] = dict(attempt_id=attempt['id'], family_id=intent['family_id'],
        candidate_id=task['candidate_id'], diagnostic=_diagnostic(task, intent), purpose=_purpose(task, intent, state),
        obligation_ids=copy.deepcopy(intent['obligation_ids']), intent_ref=copy.deepcopy(task['intent_ref']),
        estimate=copy.deepcopy(intent['estimate']), actual=None, settled=False)
    attempt['intent_ref'] = copy.deepcopy(task['intent_ref'])
    attempt['strategy_ref'] = copy.deepcopy(ledger['ref'])


def _usage_receipt(root, attempt_id, usage, read_ref):
    if not isinstance(usage, dict):
        raise ValueError('strategy usage receipt required')
    amounts = _amounts(usage.get('totals'), 'actual strategy usage')
    receipt = read_ref(root, usage.get('receipt_ref'), as_json=True)
    if (receipt.get('kind') != 'chat_strategy_usage' or receipt.get('attempt_id') != attempt_id
            or receipt.get('totals') != amounts or receipt.get('terminal') is not True):
        raise ValueError('actual strategy usage must bind the terminal attempt')
    _refs(root, receipt.get('raw_evidence'), read_ref)
    return amounts


def after_result(root, state, attempt, event, read_ref):
    # Explicitly tagged experiments require a fresh feedback-consuming decision.
    finished = next((t for t in state.get('tasks', []) if t['id'] == attempt['task_id']), {})
    if reasoning.feedback_kind(finished) and state.get('strategy'):
        state['strategy'].setdefault('reasoning_experiment_receipts', []).append({
            'attempt_id': attempt['id'], 'task_id': attempt['task_id'],
            'receipt_ref': attempt.get('evidence_ref'), 'valid_execution': event.get('outcome') == 'completed',
            'feedback_kind': reasoning.feedback_kind(finished)})
    """Settlement is always possible; missing measurements retain reservations."""
    ledger = state.get('strategy')
    if not ledger or attempt['id'] not in ledger['entries']:
        return  # Old in-flight work is reconciled, then explicitly migrated.
    entry = ledger['entries'][attempt['id']]
    if entry['settled']:
        raise ValueError('strategy attempt already settled')
    if event.get('strategy_usage') is not None:
        entry['actual'] = _usage_receipt(root, attempt['id'], event['strategy_usage'], read_ref)
        entry['usage_ref'] = event['strategy_usage']['receipt_ref']
    entry.update(settled=True, outcome=attempt.get('outcome', event.get('outcome')))
    ledger['settled_attempt_ids'].append(attempt['id'])


def _progress(root, state, reference, read_ref):
    ledger, config = _loaded(root, state, read_ref)
    receipt = read_ref(root, reference, as_json=True)
    if receipt.get('kind') != 'chat_strategy_progress' or receipt.get('goal_id') != state['goal_id']:
        raise ValueError('strategy progress goal mismatch')
    _review(root, receipt, read_ref)
    attempt_ids = _ids(receipt.get('attempt_ids'), 'progress attempts')
    if not set(attempt_ids) <= set(ledger['settled_attempt_ids']):
        raise ValueError('progress must bind actual settled attempts')
    attempts = {a['id']: a for a in state['attempts']}
    attached = []
    for attempt_id in attempt_ids:
        attempt = attempts[attempt_id]
        if attempt.get('outcome') not in {'completed', 'refuted'}:
            raise ValueError('failed or blocked execution is not resolved scientific progress; record the successful repair')
        if attempt.get('evidence_ref'):
            envelope = read_ref(root, attempt['evidence_ref'], as_json=True)
            attached += [attempt['evidence_ref'], *envelope.get('raw_evidence', [])]
    changes = receipt.get('changes')
    if not isinstance(changes, list) or not changes:
        raise ValueError('progress requires a concrete reviewed change')
    fingerprints = []
    used = {f for p in ledger['progress'] for f in p['fingerprints']}
    used_digests = {f for p in ledger['progress'] for f in p.get('evidence_digests', [])}
    evidence_digests = set()
    obligation_ids = {o['id'] for o in config['obligations']}
    for change in changes:
        if change.get('type') not in {'obligation_evidence', 'dependency_resolved', 'hypothesis_retired', 'qualification'}:
            raise ValueError('runs, timing repetitions and reports alone are not scientific progress')
        if not set(_ids(change.get('obligation_ids'), 'progress obligations')) <= obligation_ids:
            raise ValueError('progress is outside original goal obligations')
        _text(change.get('before'), 'prior unresolved state')
        _text(change.get('after'), 'new decision or evidence state')
        if change['before'].strip() == change['after'].strip():
            raise ValueError('unchanged state cannot reset stagnation')
        _refs(root, change.get('evidence_refs'), read_ref)
        if any(r not in attached for r in change['evidence_refs']):
            raise ValueError('progress evidence must come from the bound attempt outputs')
        # Ignore claim/round/task labels: relabeling identical evidence is not fresh progress.
        fingerprint = _digest(sorted(r['sha256'] for r in change['evidence_refs']))
        if fingerprint in used or fingerprint in fingerprints:
            raise ValueError('previous evidence cannot be renamed to reset stagnation')
        digests = {r['sha256'] for r in change['evidence_refs']}
        if not digests - used_digests:
            raise ValueError('recombining old evidence cannot reset stagnation')
        evidence_digests.update(digests)
        fingerprints.append(fingerprint)
    watermark = max(ledger['settled_attempt_ids'].index(a) + 1 for a in attempt_ids)
    ledger['progress'].append(dict(ref=reference, attempt_ids=attempt_ids, fingerprints=fingerprints,
                                   evidence_digests=sorted(evidence_digests),
                                   previous_watermark=ledger['progress_watermark'], watermark=watermark))
    ledger['progress_watermark'] = max(ledger['progress_watermark'], watermark)


def _strategy_review(root, state, reference, read_ref):
    ledger, config = _loaded(root, state, read_ref)
    receipt = read_ref(root, reference, as_json=True)
    if (receipt.get('kind') != 'chat_strategy_review' or receipt.get('goal_id') != state['goal_id']
            or receipt.get('strategy_ref') != ledger['ref']
            or receipt.get('attempt_ids') != ledger['settled_attempt_ids']):
        raise ValueError('strategy review must consider all settled attempts and current strategy')
    _review(root, receipt, read_ref)
    attempts = {a['id']: a for a in state['attempts']}
    relevant = ledger['settled_attempt_ids'][_progress_watermark(root, state, ledger, read_ref):]
    if any(attempts[i].get('evidence_ref') and attempts[i]['evidence_ref'] not in receipt['raw_evidence'] for i in relevant):
        raise ValueError('strategy review must retain the evidence of every no-progress attempt')
    for key in ('diagnosis', 'alternative_considered', 'why_changed_plan', 'exit_condition'):
        _text(receipt.get(key), 'strategy review ' + key)
    if set(_ids(receipt.get('retained_obligation_ids'), 'retained obligations')) != {o['id'] for o in config['obligations']}:
        raise ValueError('strategy review cannot silently shrink original obligations')
    refs = receipt.get('next_intent_refs')
    _refs(root, refs, read_ref)
    started = [e.get('intent_ref') for e in ledger['entries'].values()]
    earlier = [read_ref(root, r, as_json=True) for r in started if r is not None]
    for intent_ref in refs:
        intent = read_ref(root, intent_ref, as_json=True)
        if intent_ref in started or any(intent.get('family_id') == i.get('family_id') and
                intent.get('decision') == i.get('decision') and intent.get('falsifier') == i.get('falsifier')
                for i in earlier):
            raise ValueError('strategy review needs a changed decision/falsifier, not renamed work')
        task = next((t for t in state['tasks'] if t.get('intent_ref') == intent_ref and t['status'] == 'pending'), None)
        if task is None:
            raise ValueError('strategy review must bind a concrete pending next task')
        validate_task(root, task, state, read_ref)
    ledger['reviews'].append(dict(ref=reference, intent_refs=copy.deepcopy(refs),
                                  through_attempt_ids=copy.deepcopy(ledger['settled_attempt_ids'])))


def apply(root, state, event, read_ref):
    """Apply strategy_* event; return False for other event namespaces."""
    op = event.get('op')
    if not isinstance(op, str) or not op.startswith('strategy_'):
        return False
    if op == 'strategy_adopt':
        adopt_strategy(root, state, event.get('strategy_ref'), read_ref, event.get('review_ref'))
    elif op == 'strategy_reasoning':
        if state.get('current_attempt'):
            raise ValueError('settle the current attempt before adopting a new reasoning decision')
        ledger, _ = _loaded(root, state, read_ref)
        reference = event.get('decision_ref')
        decision = read_ref(root, reference, as_json=True)
        report = reasoning.check_decision(root, decision, goal_id=state['goal_id'])
        if report['gaps']:
            raise ValueError('reasoning decision incomplete: ' + ', '.join(g['code'] for g in report['gaps']))
        if decision.get('previous_ref') != ledger.get('reasoning_ref'):
            raise ValueError('reasoning decision must extend the last accepted selection')
        tasks = {t['id']: t for t in state.get('tasks', [])}
        for identity in report['selected_task_ids']:
            task = tasks.get(identity)
            if task is None or task['status'] not in {'pending', 'blocked'}:
                raise ValueError('reasoning selection must bind a concrete unstarted task')
            if task['candidate_id'] != decision['candidate_id']:
                raise ValueError('reasoning selection candidate mismatch')
        ledger['reasoning_ref'] = copy.deepcopy(reference)
        ledger.setdefault('reasoning_reviews', []).append(copy.deepcopy(reference))
    elif op == 'strategy_bind_task':
        task = next((t for t in state['tasks'] if t['id'] == event.get('task_id')), None)
        if task is None or task['status'] not in {'pending', 'blocked'} or task.get('intent_ref'):
            raise ValueError('only unstarted legacy tasks accept an initial intent binding')
        receipt = read_ref(root, event.get('review_ref'), as_json=True)
        if (receipt.get('kind') != 'chat_strategy_task_binding' or receipt.get('goal_id') != state['goal_id']
                or receipt.get('task_id') != task['id'] or receipt.get('intent_ref') != event.get('intent_ref')):
            raise ValueError('legacy intent binding requires an exact task review')
        _review(root, receipt, read_ref)
        pending = dict(task, intent_ref=event['intent_ref'])
        validate_task(root, pending, state, read_ref)
        task['intent_ref'] = copy.deepcopy(event['intent_ref'])
        state['strategy']['bindings'].append({'task_id': task['id'], 'intent_ref': event['intent_ref'], 'review_ref': event['review_ref']})
    elif op == 'strategy_qualify':
        receipt = read_ref(root, event.get('qualification_ref'), as_json=True)
        _validate_qualification(root, state, receipt, read_ref)
        if event['qualification_ref'] not in state['strategy']['qualifications']:
            state['strategy']['qualifications'].append(copy.deepcopy(event['qualification_ref']))
    elif op == 'strategy_usage':
        ledger, _ = _loaded(root, state, read_ref)
        entry = ledger['entries'].get(event.get('attempt_id'))
        if not entry or not entry['settled']:
            raise ValueError('late usage must bind an already settled strategy attempt')
        actual = _usage_receipt(root, event['attempt_id'], event.get('usage'), read_ref)
        if entry['actual'] is not None and any(actual[u] < entry['actual'][u] for u in UNITS):
            raise ValueError('actual settled strategy usage cannot decrease')
        entry.update(actual=actual, usage_ref=event['usage']['receipt_ref'])
    elif op == 'strategy_progress':
        _progress(root, state, event.get('progress_ref'), read_ref)
    elif op == 'strategy_review':
        _strategy_review(root, state, event.get('review_ref'), read_ref)
    else:
        raise ValueError('unknown strategy operation')
    return True
