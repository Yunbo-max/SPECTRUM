# Goal-linked scientific quality, not an aggregate PASS

Use alongside the mathematical DAG at new-method selection and meaningful batch boundaries.
This reference supersedes only the missing metric/claim/investment bridge. Retain long
proofs, competing explanations and failed branches; do not traverse all 48 operations.
A routine repair or extra prespecified seed reuses unchanged mathematics and protocol.

## Four independent questions

1. **Record integrity:** do the actual source, equations, implementation, results and
   decision link to each other? Hashes are necessary provenance, not scientific truth.
2. **Scientific validity:** does the protocol and analysis answer its stated question?
   Valid refutations and boundary findings count; an invalid run is neither support nor refutation.
3. **Goal relevance:** does the measured quantity match the parent objective and population?
   Lower residual, fewer flips, lower subspace movement, less FLOPs, or more accepted actions
   do not themselves establish better pose, fairness, time, risk or utility.
4. **Investment value:** does another action unlock an important unresolved result more
   efficiently than a strong existing comparator, alternative mechanism or scoped delivery?

Do not average these dimensions into a score that can compensate for an invalid metric
with more seeds or more documentation. A useful negative result needs no positive-score quota.
The helper reports record/work readiness and claim limitations, never scientific acceptance.

## Short record reused across batches

Use `assets/templates/research-quality.json`; link detailed derivations, formula-to-code
mappings and statistics plans rather than copying them each round. Required fields name:
- One primary metric, guardrails and proxies separately, with definition, direction, units,
  denominator, independent unit and before-decision information. Conditional proxy-to-target
  bridges require a separate reviewed claim: a proxy row cannot silently inherit the target.
- Exact theory-to-implementation mapping. List omitted and approximated terms. A lambda=0
  diagnostic does not test a temporal regularizer; known HMM parameters do not test estimation;
  a signal-only oracle does not silently become an all-history oracle.
- Compatible strong/exact/simple baselines, their real qualification status and information.
  Check intrinsic dimension/active support, update counts, evaluation temperature, initialization,
  optimizer and fallback semantics before scaling. Scope/fairness changes version the protocol.
- Closest mechanisms and the substantive delta. Classical IRLS, HMM filtering or finite-grid
  binomial calibration remain useful controls; combining them is not automatically novel.
  Unknown novelty permits a discriminator, not indefinite expansion of a known-component demo.
- Intended and actually observed populations, data manifest, sampling, selection/exposure,
  uncertainty and full cost. No synthetic-to-native or source-render-to-ground-truth promotion.
- Residual required comparisons with stable IDs, current evidence or blocking condition and
  exact next task IDs. No repeatedly copying 'next time use the native benchmark'.

`stage=acquire/diagnostic/derive/repair` can proceed with unresolved outcome evidence.
`stage=compare` permits a bounded decisive comparison; it need not know its final answer.
`stage=expand/confirm` requires relevant strong baseline qualification and any specifically
predeclared prerequisites. No full Cartesian experiment grid or universal sample quota.
`stage=deliver` cannot use supported wording contradicted by its declared measurements,
missing implementation, missing contrast or invalid scope. Narrow wording or obtain evidence;
do not silently alter an old failed target, risk unit, holdout or tolerance.

Costs distinguish core algorithm, full end-to-end runtime and total research effort. Report
startup, transfers, state maintenance, fallback and tuning where they matter. A complexity
reduction is not a speed measurement. Component-only time cannot support end-to-end speedup.
Descriptive paired summaries expose the effect direction without inventing confidence intervals.
Statistical review must justify dependence, repeated sampling, missing units, selection and
sequential stopping. Do not accept a one-seed win or an arbitrary 10% rule as universal proof.
For policy risk, freeze the whole policy and feedback law, calibration unit, finite candidate
selection and observed/counterfactual losses. A per-turn guarantee is not an episode guarantee.

## v3 quality within v4 discovery and migration

New construction work uses `research_decision` schema_version **4**, retaining the v3
quality_ref and v2 trajectory and embedding inquiry. Early diagnostic leads may defer
completed math and quality artifacts; they cannot make a supported-method claim or
erase prior obligations. See [inquiry-generation.md](inquiry-generation.md). `selected_task_ids`, candidate and goal must match all three records.
At normal task intake and dispatch, both Simple and Chat consume checked transitive references.
The same-candidate next decision must extend the last accepted quality record. A protocol
semantic change uses a new protocol ID; unresolved core obligations cannot disappear.
A v3 decision chain cannot downgrade to v2 to skip this contract. Existing v1/v2 records
remain legacy_unreviewed and old in-flight source snapshots remain immutable and settleable.
Adopt v3 at a quiet project boundary; migration does not rewrite earlier results or start jobs.
An agent mislabeling method work as a diagnostic can still defeat declarative checks. Review
actual task purpose and results; the code cannot certify honest labels or policy compliance.

## Review and stop semantics

Run a cheap critical test before expanding: strong comparator, measurement identity,
information-set check, implementation equivalence, or a mechanism discriminator as appropriate.
Prioritize the oldest consequential unresolved requirement, not merely the first queued task.
A blocked prerequisite retains its cause and recovery task; continue a genuinely independent
question rather than padding the same claim with extra toy seeds. A justified exception or
scope revision preserves the original obligation and changed authority/evidence.
Return after dependency repair to the concrete comparison it unlocked. Do not automatically
launch another audit campaign. Separate mathematical validity review, empirical validity
review, and whether further investment is worthwhile. Missing independent review is explicit.

## Process measurements (diagnostic, not optimization rewards)

Maintain denominators and source receipts. Never report an unavailable quantity as zero.
- Time to first strong compatible baseline and first decisive main-objective comparison.
- Age and count of unresolved *required* comparisons; new issue names do not reset age.
- Completed decision-changing comparisons / completed comparable investigations, alongside
  valid refutations, invalid runs, repairs and replays separately. Do not maximize this ratio
  by choosing trivial questions or excluding hard failures.
- End-to-end quality/cost frontier with protected outcomes, not only the best selected run.
- Time by scientific execution, environment/source recovery, review, storage and waiting;
  model/token cost is separate and unknown when not exposed.
- Bytes uploaded / actual changed bytes; bytes restored / required dependency bytes, only
  when both denominators are known. Local packing bytes are not remote traffic receipts.
- False admission waits, OOM events, duplicate launches, recovery delay and version adoption.

## Verification limits

Run `python scripts/research_quality.py --root PROJECT --packet quality.json`.
The check has three outputs: scoped missing work, claim limits, and priority task IDs.
It authenticates local byte identity and declared links only. A plan can be fully documented
but scientifically wrong. Software fixtures inspired by prior failures are not fresh-agent
or held-out behavior trials. Test future live agents on unseen variations before claiming
higher discovery efficiency; preserve behavior failures and do not tune on the confirmation set.
