# Autonomous RSI contract

This Work-derived `autonomous-rsi-harness` checkout adds the managed research
program in [research-harness.md](research-harness.md). Its program-owned Skill sequence, current-step worker, separate
reviewer, full-goal obligations and persisted result recovery govern the fifth
edition. Read [skill-sequence.md](skill-sequence.md) for navigation and acceptance;
it overrides inherited free next-action selection throughout this reference.
Read this inherited Work contract for scientific decision policy; a standalone worker or optional-backend setup is not the full program.

Local means the control agent on the user's computer. Before execution restore
the authorized SSH GPU route and choose the workload target under local-execution.md;
sync the pinned code there and monitor/collect its real results. No Docker anywhere.


Retain the selected field and cumulative knowledge under research-cycle.md. A failed
candidate invalidates only the supported scope of its claim. Before replacing it,
consider missing reading, baseline reproduction and causal diagnosis; all are valid
next actions. An in-field successor does not reset evidence or budgets. Use this
edition's host and decision ownership from edition-policy.md.

Current edition and continuation: read [edition-policy.md](edition-policy.md) and
[round-continuation.md](round-continuation.md) first. They supersede older host,
human/machine selection and manual-resume defaults in examples below.

## Scope and precedence

This edition executes the existing Work scientific method through the fixed
84-node Skill sequence. The program assigns the current active node and owns
acceptance, repetition and completion. The local agent performs scientific work
within that node and receives separate review; it cannot choose, skip or end
nodes. New permissions, charges and material scope expansion remain outside the
original authorization. Actual host routing follows local-execution.md.
The owner-selected 2026-10-09 policy replaces inherited human-at-each-batch,
mandatory Web-to-Local handoff and fixed 20-to-15 discovery defaults.

## Bootstrap from observable state

Restore the requested outcome and its completion criteria, current source and
procedure versions, candidate lineage, real attempts, evidence, actual tool and
resource capabilities, destination, failure history and remaining limits.
Choose work that can produce evidence on the available host. Pin inputs only
after their bytes exist. Keep one integration writer and reconcile uncertain
side effects before any retry. New chats and model changes do not reset budgets.
Independent source reading and preparation need no runtime hook or SQLite
bootstrap. The fifth edition's managed loop requires its actual registered
research-program state; a partial host-tool workflow must be reported as partial.
Restore the sourced goal_contract and distinguish the requested goal from its
current milestone. Use the scope rules in local-execution.md; an agent-authored
summary must not shrink continuing research into paper selection or preflight.
Restore pause and read the actually adopted procedure before selecting work.
Keep installed/source, adopted project and scheduled instruction versions distinct;
the source branch does not prove live installation or adoption. See
[Chat research decisions](chat-research-decisions.md) for the progress and
investment decision maintained across invocations.

## Separate proposal, verification and control

The proposer creates derivations, implementation or procedure changes. A genuinely
separate review task checks the fixed candidate against its declared criteria.
Program code checks fixed node requirements, evidence, child-result readback
and remaining limits before advancing the fixed sequence. It does not delegate
the cursor to the proposer or reviewer. Same-provider independent tasks are allowed; an actor
label or candidate self-assessment does not establish independent verification.
Missing independent review leaves only the affected claims pending.

Never change evaluator thresholds, holdouts or comparison conditions to pass.
A genuine evaluator defect gets its own evidence and versioned repair, followed
by rechecking the affected claims. Source hashes and software tests do not prove
scientific effectiveness. Every claim retains its actual evidence scope.

## Evidence-driven work within the assigned node

| Observation | Work required within the current node |
|---|---|
| Paper selected or resource/preflight check passed within a research goal | Continue the missing baseline, hypothesis, comparison or review obligation |
| Environment, configuration, resources or access invalid | Diagnose and repair within scope, or choose a feasible authorized path |
| Source coverage or originality missing | Read the specific primary paper, implementation or native protocol |
| Mathematical defect or missing falsifier | Repair/review the specific construction before candidate code |
| Candidate already covered by qualified prior work or a strong simple alternative | Retire the redundant mechanism; identify a consequential unresolved question |
| Implementation defect | Correct that version and rerun affected checks |
| Missing experimental evidence | Execute a concrete feasible comparison/control on the actual host |
| Missing independent review | Dispatch an available review task and continue other ready work |
| Valid counterevidence | Identify the claim and conditions actually refuted; revise, diagnose or retire only that supported scope, preserving evidence and field knowledge |
| Supported finding with remaining obligations | Perform the next required check or produce the requested evidence-linked artifact |
| Repeated nearby experiments without meaningful goal progress, or diagnostic allowance spent | Review strategy and family evidence before more same-family work; unblock, run a decisive control, materially revise, retire or retain a real blocker |
| All current-node requirements supported | Submit exact evidence for separate acceptance; program code advances or applies repeat/once closure |
| Real limit, user stop, or no remaining feasible work | Save distinct stop reason, unresolved obligations and exact resumption conditions |

Perform the required work for the assigned node in the active turn. A route,
ticket, summary or record is not execution. Read back real child outputs and
submit evidence for the fixed requirements. Missing evidence and rejected review
keep this node open; code determines the next active node only after acceptance.
An empty queue does not prove completion or authorize skipping ahead. Scientific
judgment chooses useful methods inside the current node, without changing the
catalog order. Keep outstanding obligations, budget and negative findings intact.

## Count research cycles accurately

A scientific evidence cycle is distinct from `state.sequence.cycle`, which counts
program-owned passes through the canonical Skill order. `max_rounds` counts
cumulative current-step worker attempts, not either kind of cycle.

Use research-cycle.md for the broader knowledge loop: focused reading, code tracing
or reproduction can resolve a question without a new method or empirical comparison.
Record such knowledge progress distinctly. The experimental-cycle receipt contract
below remains unchanged; never invent a run/receipt to satisfy its schema. Knowledge
cycles do not close pending empirical claims or inflate experimental-cycle counts.


Keep attempts, experiment runs and scientific cycles distinct. An experimental scientific cycle
links a specific hypothesis and falsifiable prediction to an executed comparison,
its reviewed evidence and the next decision. Retain the actual hypothesis,
protocol, run/output, review and decision references. The decision may continue
confirmation, repair evidence, retire a refuted candidate or start a materially
different successor. More seeds can strengthen that comparison without creating
another hypothesis or cycle. Three methods by three seeds are nine runs, not
nine scientific cycles; resource-only checks complete no scientific cycle.

A negative result counts as evidence only when the comparison is valid; setup
failure is not refutation. A cycle may be complete while the research goal still
has obligations. Neither one positive result nor one rejected candidate ends the
goal. Program-owned `once` closure requires the original request and required
evidence/deliveries; `repeat` carries unresolved knowledge into another accepted
ordered cycle after its current frozen empirical obligations are verified. Do not impose a minimum number of
successful candidates or silently turn an explicit bounded task into research.

## Candidate lifecycle and evidence

Default to one candidate with the explicitly recorded method batch targets in
local-execution.md. Keep substantive mathematics and semantic/selection reviews.
Use broader discovery only when selected by the actual scope. Existing valid
pools and unchanged evidence are reusable.
Allow bounded parallel reasoning and primary-source work on competing explanations
before selecting the one candidate for expensive verification. Retain an explicit
investment decision with nearest work, qualified baseline, unresolved consequence,
mechanism and falsifier; use existing canonical records rather than another gate.
Do not require final candidate evidence before acquiring its prerequisites.

Candidate failure and project termination are different. New canonical Gate A
or full-validation KILL records retain the failed decision, gate, protocol and
candidate while returning to exploration. For a successor research_candidate,
bind recovery.failed_decision_ref to that decision, supply substantive_delta and
real evidence_refs, and preserve parent_candidate_id when a previous candidate
exists. If there was no candidate, bind parent_protocol_ref. A renamed or
unchanged construction cannot serve as recovery. Explicit stop and already
terminal historical projects remain terminal; do not rewrite history to revive
them. Use an explicitly authorized linked new project if the old one was closed.

REVISE creates a versioned candidate/protocol as applicable; INCONCLUSIVE creates
specific evidence repair. Missing/invalid outputs are not counterevidence.
Retain family-level negative evidence and the failed predicate. New labels,
parameters or seeds do not reopen a retired mechanism or reset its diagnostic
allowance; new evidence or a substantive revision needs its own reviewed decision.
Apply Parent/Gate 0/IPCG, G01, E04 and native confirmation only where relevant
to the proposed action and claim. Diagnostic/baseline work may obtain their
missing prerequisites without asserting a final gate pass.

## History and convergence

Save goal/candidate/task/attempt identities, input and procedure versions, actual
commands/tool calls, source/output references, failed predicates, repair count,
scoped review and outstanding obligations, cumulative usage and exact next action.
Preserve append-only negative history and immutable running inputs.
Repair supersession explicitly links old/new tasks and rebuilds pending consumers
against new artifact versions; completing A2 does not retroactively complete A.
Unknown consumption remains unknown; do not represent reservations as measured
costs. Known pre-dispatch failures record actual time and zero model-call charge.

Use scripts/chat_cycle.py optionally for action bookkeeping with revision checks.
Its status is not canonical scientific acceptance. Completion requires explicit
requested outcomes and their receipts, not positive/no-gap feedback alone.
Turn-end checkpoints retain state. For automatic invocation, bind and verify
a real goal-owned host task, decision runner or callback under round-continuation.md.
The active agent must establish this binding for an authorized continuing goal.

## Optional external skills and procedure improvement

Identify the actual observed defect and retain the fixed baseline and proposed
patch. Pin genuine external source revisions, license and dependency assumptions.
Compare baseline and candidate against fixed behavior checks in separate review.
Preserve regressions, then explicitly adopt the accepted project-local procedure
at the next action boundary and record its real version. Existing attempts keep
their pins; rollback reads the previous accepted version.

Project-local adoption changes what the agent loads next. It neither changes
model weights or system instructions nor proves an installed plugin update.
Publishing this fork is authorized; changing other accounts/shared installations
requires their actual authority and supported update receipt.
An unavailable execution/installation adapter is recorded as a specific pending
step, not silently replaced by a fictitious promotion.

## Implementation and activation limits

The normal Chat path uses actual host tools and persistent project artifacts.
The optional runtime provides SQLite supervision and ACP/SSH execution only when
explicitly configured. Its trusted callbacks, budgets and native receipts are
backend requirements; they do not become default Chat prerequisites.
For this backend, read docs/RUNTIME.md. Hooks are bounded and must be trusted
read-only work; a missing review records waiting, not scientific completion.
Explicit verified requested outcomes are needed for its completion branch.
Registry promotion and installed-skill activation remain separate operations.
No skill file can guarantee infinite work, cross-turn wakeup or a provider's
billing limit. Report source delivery, actual execution and acceptance separately.

## Prospective trace and investment binding

At substantive method intake/revision and meaningful batch decisions, apply
[research-reasoning.md](research-reasoning.md). Preserve the public mathematical
work product from selected operations to the executable rule, its rival prediction
and falsifier. Conditional premises and accumulated error do not disappear at a
handoff. Check the selected action against the parent goal and a real alternative;
new repair hashes or issue names do not reset mechanism-family effort. Record the
current accepted decision and tag actual method tasks with research_scope=method
and reasoning_ref; keep source/baseline/evaluator acquisition scoped as diagnostic.
Use quiet-boundary adoption for old tasks and never overwrite their evidence or
resume a pause. Structural checks are not mathematical or scientific acceptance.
