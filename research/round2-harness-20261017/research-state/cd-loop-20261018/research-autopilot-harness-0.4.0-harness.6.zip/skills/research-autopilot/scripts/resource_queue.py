"""Cooperative, same-host FIFO admission. Waiting never launches a process.

The execution owner must persist its grant before dispatch and release only after
verified terminal cleanup. Missing owners/heartbeats never expire active grants.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import time

import host_resources
import research_operations as O

RECHECK_SECONDS = 5.0
ACTIVE = {"admitted", "dispatched"}


def validate(resources):
    fields = {"queue_dir", "cpu_slots", "peak_bytes", "margin_bytes", "min_disk_bytes"}
    if not isinstance(resources, dict) or set(resources) != fields:
        raise ValueError("resources requires queue_dir, cpu_slots, peak_bytes, margin_bytes, min_disk_bytes")
    if not isinstance(resources["queue_dir"], str) or not Path(resources["queue_dir"]).is_absolute():
        raise ValueError("queue_dir must be an absolute shared host path")
    cpu = resources["cpu_slots"]
    if type(cpu) not in (int, float) or not math.isfinite(cpu) or cpu < 0:
        raise ValueError("cpu_slots must be finite and nonnegative")
    for field in ("peak_bytes", "margin_bytes", "min_disk_bytes"):
        if type(resources[field]) is not int or resources[field] < 0:
            raise ValueError(field + " must be a nonnegative integer")
    return resources


def snapshot(disk_path):
    cpu, memory, diagnostics = host_resources.collect_cpu_memory()
    observations = memory["cgroup_observations"]
    known = host_resources.memory_constraints_known(cpu, memory)
    known = known and bool(cpu["cgroup"]["observations"]) and all(not o.get("quota_applicable", True) or o["quota_state"] != "unknown" for o in cpu["cgroup"]["observations"])
    identities = []
    for o in observations + cpu["cgroup"]["observations"]:
        st = Path(o["path"]).stat()
        identities.append([st.st_dev, st.st_ino])
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    domain = hashlib.sha256(json.dumps([boot, os.getuid(), identities]).encode()).hexdigest()
    disk = os.statvfs(disk_path)
    return {"domain": domain, "observed_at": time.time(),
            "cpu_slots": cpu["capacity_upper_bound"] if known else None,
            "memory_total": memory["effective_total_bytes_upper_bound"] if known else None,
            "memory_available": memory["observed_headroom_bytes"] if known else None,
            "disk_available": disk.f_bavail * disk.f_frsize,
            "disk_total": disk.f_blocks * disk.f_frsize,
            "disk_domain": os.stat(disk_path).st_dev,
            "diagnostics": diagnostics}


def _key(root, task_id):
    return hashlib.sha256(json.dumps([str(Path(root).resolve()), task_id]).encode()).hexdigest()


def _state(directory):
    return O._read_json(directory / "queue.json", {"version": 1, "domain": None, "next_sequence": 0, "tickets": {}})


def poll(root, task_id, resources, contract_digest, *, deadline_epoch=None, snapshot_fn=None):
    """Enqueue once, then periodically recheck under the shared admission lock.

    Legacy callers opt in with a measured resource contract; the queue cannot
    infer peak RAM from argv. Full reservations are conservatively deducted from
    observed headroom, even while running usage is also visible in that reading.
    """
    validate(resources)
    if not isinstance(task_id, str) or not task_id or not isinstance(contract_digest, str) or not contract_digest:
        raise ValueError("stable task and contract identities required")
    if deadline_epoch is not None and (type(deadline_epoch) not in (int, float) or not math.isfinite(deadline_epoch)):
        raise ValueError("finite original deadline required")
    root = Path(root).resolve()
    key = _key(root, task_id)
    contract = {"root": str(root), "task_id": task_id, "resources": resources,
                "contract_digest": contract_digest, "deadline_epoch": deadline_epoch}
    with O._locked(resources["queue_dir"]) as directory:
        state = _state(directory)
        now = time.time()
        ticket = state["tickets"].get(key)
        if ticket is not None and ticket["contract"] != contract:
            raise ValueError("resource ticket conflicts with immutable task contract")
        if ticket is None:
            ticket = {"key": key, "contract": contract, "sequence": state["next_sequence"],
                      "status": "queued", "reason": "waiting_for_resources", "created_at": now,
                      "last_checked_at": None, "next_check_at": now, "checks": 0}
            state["next_sequence"] += 1
            state["tickets"][key] = ticket
        for item in state["tickets"].values():
            deadline = item["contract"]["deadline_epoch"]
            if item["status"] in {"queued", "admitted"} and deadline is not None and now >= deadline:
                item.update(status="expired", reason="original_deadline_reached")
        if ticket["status"] == "admitted":
            observed = (snapshot_fn or (lambda: snapshot(root)))()
            if observed.get("domain") != state["domain"]:
                raise ValueError("admitted reservation belongs to another host; reconcile before dispatch")
        if ticket["status"] != "queued" or now < ticket["next_check_at"]:
            O._atomic_json(directory / "queue.json", state)
            return dict(ticket)
        ticket.update(last_checked_at=now, next_check_at=now + RECHECK_SECONDS, checks=ticket["checks"] + 1)
        try:
            observed = (snapshot_fn or (lambda: snapshot(root)))()
            if not 0 <= now - observed["observed_at"] <= 5:
                # A snapshot taken inside this transaction may be a few ms newer.
                if not 0 <= observed["observed_at"] - now <= 5:
                    raise ValueError("stale resource observation")
            if not observed.get("domain"):
                raise ValueError("unknown resource domain")
            if state["domain"] not in (None, observed["domain"]):
                ticket.update(status="wrong_domain", reason="queue_domain_mismatch")
                raise ValueError("queue belongs to another host/resource domain")
            state["domain"] = observed["domain"]
            ticket["observation"] = observed
            values = [observed.get(k) for k in ("cpu_slots", "memory_total", "memory_available", "disk_available", "disk_total")]
            if any(type(v) not in (int, float) or not math.isfinite(v) or v < 0 for v in values):
                ticket["reason"] = "resource_observation_unknown"
            else:
                memory = resources["peak_bytes"] + resources["margin_bytes"]
                if (memory > observed["memory_total"] or resources["cpu_slots"] > observed["cpu_slots"]
                        or resources["min_disk_bytes"] > observed["disk_total"]):
                    ticket.update(status="needs_replan", reason="request_exceeds_observed_capacity")
                else:
                    active = [t for t in state["tickets"].values() if t["status"] in ACTIVE]
                    pending = [t for t in state["tickets"].values() if t["status"] == "queued"]
                    used_cpu = sum(t["contract"]["resources"]["cpu_slots"] for t in active)
                    used_memory = sum(t["contract"]["resources"]["peak_bytes"] + t["contract"]["resources"]["margin_bytes"] for t in active)
                    used_disk = sum(t["contract"]["resources"]["min_disk_bytes"] for t in active
                                    if t.get("observation", {}).get("disk_domain") == observed["disk_domain"])
                    if min(t["sequence"] for t in pending) != ticket["sequence"]:
                        ticket["reason"] = "waiting_for_turn"
                    elif resources["cpu_slots"] + used_cpu > observed["cpu_slots"]:
                        ticket["reason"] = "waiting_for_cpu_slots"
                    elif memory + used_memory > observed["memory_available"]:
                        ticket["reason"] = "waiting_for_memory"
                    elif resources["min_disk_bytes"] + used_disk > observed["disk_available"]:
                        ticket["reason"] = "waiting_for_disk"
                    else:
                        ticket.update(status="admitted", reason="resources_reserved", admitted_at=now)
        except (OSError, ValueError, KeyError, TypeError) as error:
            if ticket["status"] == "queued":
                ticket["reason"] = "resource_observation_unknown"
            ticket["diagnostic"] = str(error)[:400]
        # No grant is returned unless its durable atomic write succeeded.
        O._atomic_json(directory / "queue.json", state)
        return dict(ticket)


def transition(resources, key, status, reason):
    """An executor attests dispatch/terminal cleanup; this is not a verifier."""
    validate(resources)
    if status not in {"dispatched", "settled", "cancelled"} or not reason:
        raise ValueError("explicit resource transition and reason required")
    with O._locked(resources["queue_dir"]) as directory:
        state = _state(directory)
        ticket = state["tickets"][key]
        current = ticket["status"]
        if status == "dispatched":
            deadline = ticket["contract"]["deadline_epoch"]
            if deadline is not None and time.time() >= deadline:
                raise ValueError("original deadline reached before dispatch")
            if snapshot(ticket["contract"]["root"])["domain"] != state["domain"]:
                raise ValueError("resource domain changed before dispatch")
        if current == status:
            return dict(ticket)
        if status == "cancelled" and current not in {"queued", "admitted", "needs_replan", "expired", "wrong_domain"}:
            raise ValueError("dispatched resources require terminal reconciliation")
        if status == "dispatched" and current != "admitted":
            raise ValueError("dispatch requires the original admitted ticket")
        if status == "settled" and current not in ACTIVE | {"expired", "cancelled"}:
            raise ValueError("settlement requires an active reservation")
        ticket.update(status=status, reason=str(reason)[:400], changed_at=time.time())
        O._atomic_json(directory / "queue.json", state)
        return dict(ticket)
