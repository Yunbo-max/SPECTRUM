# Learn published designs and fit actual compute

Use [single-experiment batching](single-experiment-batching.md): one active
experiment program, sequential descending batch calibration (for example
64 → 32 → 16 → 8 → 4 → 2), preserved scientific semantics and measured useful
throughput/headroom. Queue other experiments; keep Chat within CPU/4 GB.

Before blocking a stage on scorer availability/isolation, apply
[native-scoring-stages.md](native-scoring-stages.md). Restore real deferred scoring
support from the project. Independent training/export may proceed with saved
unscored artifacts; final metric claims wait for actual native scoring. No Docker
on any host. Requirements for a scorer that executes generated programs belong
to that operation, not automatically to training or prediction generation.


Before substantial method investment or a changed-condition experiment, read
[benchmark-discovery.md](benchmark-discovery.md). Prefer the original native
benchmark when it can test the prediction; otherwise actively search suitable
existing protocols/data using primary sources, Web and accessible discussion leads.
Record condition fit, strong baselines and a credible validation path before
comparative outcomes. Missing evaluation coverage is a research task, not a reason
to build the method first or silently substitute favorable datasets.


Read before the first empirical design, a material claim change, or a changed
compute allocation. Use this workflow with G01/V01-V06, not as an extra research
stage. Reuse pinned source notes and measured profiles that remain valid.

Read in order: [extract](#read-and-extract), [transfer](#transfer-to-our-question),
[resources](#observe-resources-and-calibrate), [execution/review](#freeze-execute-and-review).

## Read and extract

Select sources by the question: the closest method, strongest relevant competitor,
strong simple alternative, native benchmark/evaluator and informative conflicting
results. One paper can fill several roles; a fixed paper quota cannot establish
coverage. Retrieve primary full text and appendices, actual released code/configs
at exact commits and official benchmark definitions. Abstracts, leaderboards and
paper counts cannot supply missing experimental details. Record unavailable
appendices, code or settings as gaps; do not infer successful reproduction.

Use [the extraction card](../assets/templates/paper-experiment-design.md). For each
decision-relevant experiment retain paper/version, URL, captured source hash,
page/section/table/figure or code path/config/commit, and:

- Question, claim, mathematical prediction, rival explanation and falsifier.
- Treatment, published and simple baselines, ablations/replacements, model/data
  sizes, training/inference information and tuning/search/selection budgets.
- Dataset/revision, train/validation/test or temporal split, leakage controls,
  sample selection, native scorer, metric direction, aggregation and denominator.
- Independent unit, pairing, seeds/repetitions, variability sources, intervals
  or tests and their assumptions, multiplicity and missing/failed runs.
- Generalization/robustness axes, relevant failure regimes, mechanism findings
  and which conclusions the design cannot distinguish.
- Reported hardware, peak memory, per-run/total compute, throughput and exact
  commands/environment. Mark unreported values unknown; source-reported costs
  are estimates for our allocation until measured there.

Compare text, appendix and implementation. Resolve material conflicts before
adopting a setting; preserve the disagreement and chosen evidence. Publication
does not certify design quality. Identify weak/outdated baselines, unmatched
tuning, ambiguous units, test-set selection, missing controls or omitted costs.
Do not repeat such weaknesses because an accepted paper used them.

Qualify the actual comparison implementations before an expanded campaign. Pin
official source/defaults, initialization and state-update order, numerical
precision, stopping criteria, line-search tolerances and tuning allowances.
Retain a small published/source-backed parity check and any discrepancy. Label
official unmodified code, a faithful port and a proposed source repair separately.
If a material mismatch is discovered later, review the affected claims and rerun
the necessary comparisons under a versioned correction; do not backdate parity.
Source/qualification checks are allowed to acquire missing prerequisites.

## Transfer to our question

For each extracted practice choose **adopt**, **adapt** or **reject**, give the
reason, and name the claim/obligation it informs. Preserve task semantics and
fairness when adapting scale or implementation. Explain gaps the source paper
does not answer. Rejection means rejecting that practice, not deleting our own
required comparison. Track unavailable strong competitors and their consequence
for claim scope rather than silently replacing them with weak baselines.

Bind each claim to its prediction, strongest rival and decisive experiment.
Review all six contract dimensions: `main_comparison`, `mechanism`,
`generalization`, `uncertainty`, `cost`, `reproducibility`. Each is required or
explicitly `not_applicable` with a claim-specific reason. A method with no
mechanistic claim need not manufacture one; a mechanistic claim cannot omit its
identifying control. Main comparison and reproducibility remain required for
this empirical contract. Keep actual native benchmark scope and a concrete command,
config, output and verification path for every required job.

Specify the estimand, not just experiment names. A performance contrast might be
`method - baseline`; a component claim needs `method - removed_component`; an
interaction may require `AB - A - B + base`. Passing the main comparison does
not establish the latter two. Bind each contrast to the canonical criterion and
groups that evaluate it. Unsupported contrast/dependence analysis needs a reviewed
live project adapter; an authored statistic or scalar threshold cannot replace it.

Choose independent units and precision for the actual inference. Use development
evidence, source variance or a justified prospective precision analysis and state
assumptions. A small point screen is diagnostic, not final stochastic/generalization
confirmation. Deterministic finite-scope findings can use exact values if justified.
No universal seed, dataset or run count replaces this reasoning. New benchmark,
group, seed or method selection after seeing results is exploration: version the
plan and obtain fresh confirmation appropriate to the resulting claim.

For optimization efficiency, compare time or full computational cost to the same
prospective native quality targets, including nonattainment/censoring. Separately
report fixed-iteration/kernel timings and iteration/oracle counts; none alone
establishes end-to-end speed. Charge direction selection, line searches, rejected
trials, curvature estimates, transfers and scoring at the actual claim boundary.
Apply equivalent engineering optimizations and fair tuning to competing methods.
Calibrate timing duration above measurement noise, declare warmup/JIT policy and
counterbalance execution order when relevant; timing repeats are not new datasets.

For nonconvex tasks, stationarity or a small surrogate gap does not by itself
establish useful task performance. Include native objective/task quality and
relevant trivial controls such as zero prediction or unchanged initialization.
Explain mismatches among these endpoints. Choose them prospectively; do not
replace the primary endpoint after inspecting results.

## Observe resources and calibrate

Record sourced, timestamped resource facts separately: owned/historically mentioned;
authorized for this project; reachable using this Chat's actual tools; available
now or allocated/queued. Include CPU/RAM/storage/I/O, GPU model/count/free and total
memory, device identities/topology, sharing, queue/time limits, software/data access
and cumulative budget. Never infer a current allocation from remembered H200/4090
ownership. A currently authorized remote GPU reachable here is usable without
requiring a separate Local agent. No credential or paid resource is invented.

Run bounded native calibration on the actual target hardware with the real workload
shape after its prerequisites. Retain commands, configuration, time, peak memory,
throughput and observations under the real allocation. Measure strong baselines
and new-method costs separately when materially different; allow development
calibration while final jobs are unready. Preserve precision, effective batch,
sampling and metric semantics when choosing implementation settings. Distinguish
measured values, reported estimates and extrapolations with uncertainty. Recheck
availability at dispatch; recalibrate material hardware/workload changes.

Budget data preparation, baseline qualification, tuning/search, candidate runs,
controls, confirmation, scoring/analysis, storage and finite retry reserve. Include
failed and discarded exploration in total usage. A paper's final training time
is not the full research budget. Admit jobs against dependency, memory/topology,
queue and remaining limits; nominal GPU count alone does not establish parallelism.

Order work by expected decision value: obtain missing scorer/baseline/resource
evidence; test a decisive bounded comparison; then cover remaining claim obligations
and frozen confirmation. A stage is complete only at its own scope. If time or
memory is insufficient, split jobs across feasible batches, choose a justified
prospective smaller scope or keep named work pending. Never silently delete the
strong baseline, indispensable control or precision requirement. Preserve the
agreed complete matrix and broader claims as unresolved until their evidence exists.
Use [research decisions](chat-research-decisions.md) at each batch boundary.
Extra task families and repeated timing checks cannot silently fill original
coverage gaps. Count valid refutation and dependency recovery as meaningful
progress; review strategy when repeated work changes no remaining decision.

## Freeze, execute and review

Use `schemas/experiment-design-contract.schema.json` and the accompanying
`assets/templates/experiment-design-contract.json` for source transfer, resource evidence,
claim coverage, explicit contrasts and jobs. Bind real hashed artifacts only after
they exist. Run `scripts/experiment_contract.py --help` for exact CLI usage; the
Python entry is `inspect_contract(root, ref, phase="design"|"completion",
review_ref=..., completion_ref=...)`. Inspect `ready`, `eligible_job_ids`, `pending`
and `coverage_complete`; a syntactically valid contract need not be ready.
Use `eligible_job_ids` for resource-eligible subsets; global `ready: false` for an
unreachable GPU must not block unrelated ready work. Other task prerequisites and
dependencies and canonical scientific checks still apply to each selected job.

The contract checks evidence bindings and declared coverage. Its
`scientific_truth_verified: false` is intentional: it cannot determine that a
paper was understood, a baseline is competitive or a review is genuinely
independent. Apply canonical method/G01/native/E04/result verification to actual
evidence and obtain independent review before scientific acceptance. Review the
strongest alternative explanation, unfair advantages, inference assumptions and
remaining coverage; preserve dissent and generate concrete repairs.

Use the same frozen obligations at completion. Require actual result receipts,
evaluated contrasts and scoped interpretation for every necessary comparison;
do not substitute a goal-complete sentence, file hash or run count. Supported,
refuted and inconclusive findings retain their different scientific meanings.
Negative evidence can answer a bounded question; missing essential evidence
cannot. Feed the actual result and remaining obligations into the next action.

Reuse the qualified runner, timing and aggregation path across batches. Finalize
attempt-specific outputs atomically and retain raw logs, launch errors, timeout
state, native validity and process receipts separately. Never parse live logs as
final results or change the verification algorithm solely to meet a deadline.
An evaluator repair gets a frozen revision and rechecks of affected evidence.

Use the current official [NeurIPS Paper Checklist](https://neurips.cc/public/guides/PaperChecklist)
for claims, assumptions/limitations, reproducibility, baseline/settings disclosure,
uncertainty and compute reporting (checked 2026-10-10). This workflow supports a
NeurIPS-aligned review; it neither guarantees acceptance nor certifies an experiment
as sufficient merely because all fields are present.
