#!/usr/bin/env python3
"""Read-only mathematical work-product and research-decision checks.

Record completeness, identity and control flow are NOT mathematical truth,
novelty, authentic independent review, or a guarantee of agent compliance.
The existing host/journal owns state, task dispatch, pauses and actual evidence.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat

MAX_BYTES = 4 * 1024 * 1024
OPERATIONS = {f'{family}{number:02d}' for family in 'ABCDEFGH' for number in range(1, 7)}
ACTIONS = {'continue', 'repair', 'compare', 'explore', 'reframe', 'park', 'retire', 'close_scoped'}
GOAL_CHANGES = {'prediction_supported', 'prediction_refuted', 'boundary', 'dependency_unlocked'}


def _text(value):
    return isinstance(value, str) and bool(value.strip())


def _norm(value):
    return ' '.join(str(value).lower().split())


def _strict_json(data):
    def reject(value):
        raise ValueError('nonfinite JSON: ' + value)
    def unique(pairs):
        out = {}
        for key, value in pairs:
            if key in out:
                raise ValueError('duplicate JSON key: ' + key)
            out[key] = value
        return out
    return json.loads(data, parse_constant=reject, object_pairs_hook=unique)


def read_ref(root, reference, *, metadata=True):
    """Read bounded UTF-8 metadata, or stream-hash binary evidence without loading it."""
    if not isinstance(reference, dict) or set(reference) != {'path', 'sha256'}:
        raise ValueError('reference requires exactly path and sha256')
    name, digest = reference['path'], reference['sha256']
    if (not _text(name) or PurePosixPath(name).is_absolute() or '\\' in name or '\x00' in name
            or any(p in {'', '.', '..'} for p in name.split('/'))
            or not isinstance(digest, str) or re.fullmatch('[0-9a-f]{64}', digest) is None):
        raise ValueError('unsafe path or invalid digest')
    fds = []
    try:
        fd = os.open(Path(root), os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW); fds.append(fd)
        for part in name.split('/')[:-1]:
            fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd); fds.append(fd)
        fd = os.open(name.split('/')[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd); fds.append(fd)
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or (metadata and before.st_size > MAX_BYTES):
            raise ValueError('reference must be a bounded regular file')
        chunks, size, hasher = [], 0, hashlib.sha256()
        while block := os.read(fd, 65536):
            size += len(block)
            if metadata and size > MAX_BYTES:
                raise ValueError('reference grew beyond metadata bound')
            hasher.update(block)
            if metadata:
                chunks.append(block)
        after = os.fstat(fd)
        signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        data = b''.join(chunks)
        if signature(before) != signature(after) or hasher.hexdigest() != digest:
            raise ValueError('reference changed or hash mismatch')
        return data.decode('utf-8') if metadata else None
    except (OSError, UnicodeError) as error:
        raise ValueError('cannot read exact reference: ' + str(error)) from error
    finally:
        for fd in reversed(fds):
            os.close(fd)


class Check:
    def __init__(self, root):
        self.root, self.gaps, self.bound_refs = Path(root), [], {}

    def gap(self, code, path, action):
        self.gaps.append(dict(code=code, path=path, next_action=action))

    def need(self, value, code, path):
        if not _text(value):
            self.gap(code, path, 'Supply the actual scoped content, not a PASS label.')

    def refs(self, refs, path, required=False):
        if not isinstance(refs, list) or (required and not refs):
            self.gap('missing_evidence', path, 'Acquire and reference the actual evidence; keep its claim pending.')
            return set()
        hashes = set()
        for ref in refs:
            try:
                read_ref(self.root, ref, metadata=False); hashes.add(ref['sha256'])
                self.bound_refs[ref['path']] = ref
            except ValueError as error:
                self.gap('invalid_reference', path, str(error))
        return hashes

    def document(self, ref, path):
        try:
            value = _strict_json(read_ref(self.root, ref))
            self.bound_refs[ref['path']] = ref
            if not isinstance(value, dict):
                raise ValueError('referenced document must be an object')
            return value
        except (ValueError, TypeError) as error:
            self.gap('invalid_reference', path, str(error)); return {}

    def entries(self, value, path):
        if not isinstance(value, list):
            self.gap('missing_list', path, 'Record the actual list, including [] when there are no branches or obligations.')
            return {}
        result = {}
        for item in value:
            name = item.get('id') if isinstance(item, dict) else None
            if not _text(name) or name in result:
                self.gap('duplicate_identity', path, 'Use distinct stable identities for actual objects/steps.'); continue
            result[name] = item
        return result

    def ids(self, value, path, required=False):
        if (not isinstance(value, list) or any(not _text(x) for x in value)
                or len(set(value)) != len(value) or (required and not value)):
            self.gap('invalid_id_list', path, 'Supply distinct actual identifiers.'); return []
        return value

    def report(self, **extra):
        return dict(status='record_incomplete' if self.gaps else 'record_complete', gaps=self.gaps,
                    mathematical_truth_verified=False, scientific_certification=False,
                    required_input_refs=list(self.bound_refs.values()), **extra)


def check_trace(root, trace, *, candidate_id=None):
    """Check the selected derivation graph and its retained alternatives."""
    c = Check(root)
    if not isinstance(trace, dict): trace = {}
    if trace.get('kind') != 'mathematical_trace' or trace.get('schema_version') != 1:
        c.gap('trace_kind', 'kind', 'Create a mathematical_trace work product; a math_verified flag is not one.')
    for key in ('trace_id', 'candidate_id'):
        c.need(trace.get(key), 'missing_identity', key)
    if type(trace.get('revision')) is not int or trace['revision'] < 1:
        c.gap('invalid_revision', 'revision', 'Bind the actual positive candidate revision.')
    if candidate_id is not None and trace.get('candidate_id') != candidate_id:
        c.gap('candidate_mismatch', 'candidate_id', 'Use the derivation for this candidate, not a neighboring method.')
    objects, assumptions, obligations = (c.entries(trace.get(k), k) for k in ('objects', 'assumptions', 'obligations'))
    if not objects: c.gap('missing_objects', 'objects', 'State mathematical objects and their domains.')
    for name, obj in objects.items(): c.need(obj.get('definition'), 'missing_object', 'objects.' + name)
    for name, a in assumptions.items():
        c.need(a.get('statement'), 'missing_assumption', name)
        if a.get('status') not in {'established', 'conditional', 'false'}:
            c.gap('assumption_status', name, 'Distinguish established, conditional and false assumptions.')
        c.refs(a.get('evidence_refs', []), name, required=a.get('status') in {'established', 'false'})
    for name, o in obligations.items():
        c.need(o.get('statement'), 'missing_obligation', name)
        if o.get('status') not in {'open', 'discharged'}:
            c.gap('obligation_status', name, 'Keep the error obligation open unless its evidence discharges it.')
        c.refs(o.get('evidence_refs', []), name, required=o.get('status') == 'discharged')
    steps = c.entries(trace.get('steps'), 'steps')
    if not steps: c.gap('missing_steps', 'steps', 'Carry out a consequential operation; there is no operation-count quota.')
    inherited_a, inherited_o, ancestors = {}, {}, {}
    seen = set(objects); operations = []
    for name, s in steps.items():
        if name in objects: c.gap('duplicate_identity', name, 'Step and input-object IDs must differ.')
        operation = s.get('operation')
        if not isinstance(operation, str) or operation not in OPERATIONS:
            if not (_text(operation) and operation.startswith('custom:') and _text(s.get('operation_justification'))):
                c.gap('unknown_operation', name, 'Choose a relevant catalog operation or derive a justified custom move.')
        if operation not in operations: operations.append(operation)
        c.refs(s.get('evidence_refs', []), name + '.evidence_refs')
        for field in ('transition', 'derivation', 'output'):
            c.need(s.get(field), 'missing_' + field, name + '.' + field)
        if s.get('validity') not in {'exact', 'conditional', 'approximation', 'conjecture'}:
            c.gap('step_validity', name, 'Distinguish exact algebra, conditional statements, approximation and conjecture.')
        inputs = c.ids(s.get('inputs'), name + '.inputs', True)
        aa, oo, closure = set(), set(), set()
        for source in inputs:
            if source not in seen: c.gap('unknown_input', name, 'Derive the missing input before using it; no forward/cyclic proof edges.')
            aa |= inherited_a.get(source, set()); oo |= inherited_o.get(source, set())
            closure |= ancestors.get(source, set()); closure.add(source)
        declared_a = set(c.ids(s.get('assumptions'), name + '.assumptions'))
        declared_o = set(c.ids(s.get('obligations'), name + '.obligations'))
        if declared_a - assumptions.keys(): c.gap('unknown_assumption', name, 'Define each condition explicitly.')
        if declared_o - obligations.keys(): c.gap('unknown_obligation', name, 'Define the error obligation explicitly.')
        if aa - declared_a: c.gap('dropped_assumption', name, 'Carry inherited assumptions through downstream transformations.')
        still_open = {o for o in oo if obligations.get(o, {}).get('status') != 'discharged'}
        if still_open - declared_o: c.gap('dropped_obligation', name, 'Carry unresolved approximation errors through this exact/approximate step.')
        if s.get('validity') == 'approximation' and not declared_o:
            c.gap('approximation_without_error', name, 'Record a remainder/error obligation, even when its bound is unresolved.')
        inherited_a[name] = aa | declared_a; inherited_o[name] = oo | declared_o
        ancestors[name] = closure; seen.add(name)
    method = trace.get('method') if isinstance(trace.get('method'), dict) else {}
    c.need(method.get('rule'), 'missing_method', 'method.rule')
    method_steps = c.ids(method.get('from_steps'), 'method.from_steps', True)
    selected = set(method_steps)
    for name in method_steps:
        if name not in steps: c.gap('unknown_method_step', name, 'Connect the executable rule to its actual derivation.')
        selected |= ancestors.get(name, set()) & steps.keys()
    selected_a = set().union(*(inherited_a.get(n, set()) for n in selected))
    if any(assumptions.get(a, {}).get('status') == 'false' for a in selected_a):
        c.gap('false_condition_on_method_path', 'method', 'Backtrack or revise the construction; a false edge cannot support it.')
    conditional = any(assumptions.get(a, {}).get('status') != 'established' for a in selected_a)
    conditional |= any(steps[n].get('validity') in {'conditional', 'approximation', 'conjecture'} for n in selected if n in steps)
    selected_o = set().union(*(inherited_o.get(n, set()) for n in selected))
    conditional |= any(obligations.get(o, {}).get('status') != 'discharged' for o in selected_o)
    for group in ('branches', 'frontier'):
        records = trace.get(group)
        if not isinstance(records, list):
            c.gap('missing_list', group, 'Keep branches/backtracks and unresolved frontier explicit, even when empty.'); continue
        for item in records:
            if not isinstance(item, dict): c.gap('invalid_branch', group, 'Record the actual branch or frontier object.'); continue
            if group == 'branches':
                if item.get('at') not in steps or any(x not in steps for x in c.ids(item.get('targets'), 'branch.targets', True)):
                    c.gap('unknown_branch_target', group, 'Bind branch/merge/backtrack to existing intermediate results.')
                if item.get('choice') not in {'branch', 'merge', 'backtrack', 'reject'}: c.gap('invalid_branch', group, 'Name the actual branch decision.')
                c.need(item.get('reason'), 'missing_branch_reason', group)
            else:
                if item.get('step_id') not in steps: c.gap('unknown_frontier', group, 'Bind the unresolved question to an intermediate result.')
                for key in ('question', 'next_action'): c.need(item.get(key), 'missing_frontier', group + '.' + key)
    prediction = trace.get('prediction') if isinstance(trace.get('prediction'), dict) else {}
    for key in ('ours', 'rival', 'distinguishing_test', 'falsifier'):
        c.need(prediction.get(key), 'missing_prediction', 'prediction.' + key)
    if _text(prediction.get('ours')) and _norm(prediction['ours']) == _norm(prediction.get('rival')):
        c.gap('identical_predictions', 'prediction', 'Find a genuinely discriminating prediction, or report equivalence instead of a new-method difference.')
    invalidated = set()
    reused = c.ids(trace.get('reused_steps', []), 'reused_steps')
    if trace.get('parent_ref') is not None:
        old = c.document(trace['parent_ref'], 'parent_ref')
        if old.get('candidate_id') != trace.get('candidate_id') or type(old.get('revision')) is not int or old['revision'] >= trace.get('revision', 0):
            c.gap('parent_binding', 'parent_ref', 'Preserve candidate identity and strictly advance its revision.')
        old_steps = {s['id']:s for s in old.get('steps', []) if isinstance(s,dict) and _text(s.get('id'))}
        for group in ('objects', 'assumptions', 'obligations'):
            before={x['id']:x for x in old.get(group,[]) if isinstance(x,dict) and _text(x.get('id'))}
            after={x['id']:x for x in trace.get(group,[]) if isinstance(x,dict) and _text(x.get('id'))}
            changed={x for x in before.keys() | after.keys() if before.get(x)!=after.get(x)}
            for name,s in steps.items():
                used=set(s.get('inputs',[])) | set(s.get('assumptions',[])) | set(s.get('obligations',[]))
                if changed & used: invalidated.add(name)
        invalidated |= {name for name in old_steps.keys() | steps.keys() if old_steps.get(name)!=steps.get(name)}
        for name in steps:
            if ancestors.get(name,set()) & invalidated: invalidated.add(name)
        for name in reused:
            if name not in steps or name in invalidated or old_steps.get(name)!=steps.get(name):
                c.gap('changed_reused_prefix', name, 'Do not borrow old reviews; revalidate affected descendants and dependent claims/code/tests.')
    elif reused:
        c.gap('missing_parent_trace', 'reused_steps', 'Pin the actual earlier trace before claiming prefix reuse.')
    return c.report(operations_used=operations, conditional=bool(conditional),
                    invalidated_step_ids=sorted(invalidated), selected_step_ids=sorted(selected))


def _decision_chain(c, decision):
    chain, seen_refs, seen_ids = [], set(), set()
    current = decision
    while current:
        identity = current.get('decision_id')
        if identity in seen_ids:
            c.gap('decision_cycle', 'previous_ref', 'Retain an acyclic, append-only sequence of distinct decisions.'); break
        seen_ids.add(identity); chain.append(current)
        ref = current.get('previous_ref')
        if ref is None: break
        digest = ref.get('sha256') if isinstance(ref, dict) else None
        if digest in seen_refs:
            c.gap('decision_cycle', 'previous_ref', 'Do not loop through the decision ancestry.'); break
        seen_refs.add(digest)
        current = c.document(ref, 'previous_ref')
        if current and (current.get('kind') != 'research_decision' or current.get('goal_id') != decision.get('goal_id')):
            c.gap('goal_ancestry_mismatch', 'previous_ref', 'Preserve the original goal and its full decision history.'); break
        if len(chain) >= 10000:
            c.gap('history_bound', 'previous_ref', 'Checkpoint a verified history summary before a larger bounded read; do not reset usage.'); break
    return list(reversed(chain))


def check_decision(root, decision, *, task_id=None, candidate_id=None, goal_id=None, paused=False):
    c=Check(root)
    if not isinstance(decision,dict): decision={}
    if decision.get('kind')!='research_decision' or decision.get('schema_version') not in {1,2,3,4}:
        c.gap('decision_kind','kind','Record the actual goal-level selection.')
    for key in ('decision_id','goal_id','candidate_id','family_id','mechanism','why_selected','stop_or_pivot'):
        c.need(decision.get(key),'missing_decision_field',key)
    c.need(decision.get('if_repairs_free'),'missing_parent_value','if_repairs_free')
    for key,expected in [('goal_id',goal_id),('candidate_id',candidate_id)]:
        if expected is not None and decision.get(key)!=expected: c.gap(key+'_mismatch',key,'Bind this decision to the actual consuming goal/candidate.')
    selected_tasks=c.ids(decision.get('selected_task_ids'),'selected_task_ids',True)
    if task_id is not None and task_id not in selected_tasks: c.gap('task_not_selected','selected_task_ids','Run the actually selected task or make a new decision.')
    options=c.entries(decision.get('options'),'options')
    if len(options)<2 and not _text(decision.get('no_alternative_reason')):
        c.gap('missing_alternative','options','Compare a real alternative, or explain its concrete absence; do not invent a candidate quota.')
    for name,o in options.items():
        if o.get('action') not in ACTIONS: c.gap('unknown_action',name,'Choose a supported scoped action.')
        for key in ('value_if_success','cost'): c.need(o.get(key),'missing_option',name+'.'+key)
    selected=options.get(decision.get('selected_option'))
    if selected is None:
        c.gap('missing_selected_option','selected_option','Select an actual considered action.'); selected={}
    route=selected.get('action','analysis')
    if route=='repair' and not c.ids(selected.get('unlocks',[]),'selected.unlocks'):
        c.gap('repair_without_unlock','selected.unlocks','Name the concrete valuable comparison/result this repair unlocks.')
    threshold=decision.get('review_after_rounds')
    if type(threshold)is not int or threshold<1:
        c.gap('review_policy_missing','review_after_rounds','Declare a justified strategy-review cadence, not a lifetime research budget.');threshold=1
    chain=_decision_chain(c,decision)
    family=decision.get('family_id'); total=0; debt=0; evidence_seen=set()
    for old in chain:
        if old.get('family_id')!=family:
            if _norm(old.get('mechanism'))==_norm(decision.get('mechanism')):
                c.gap('renamed_family','family_id','The same mechanism keeps the same family across issues, filenames and sessions.')
            continue
        total+=1
        if old.get('review_after_rounds')!=threshold:
            c.gap('changed_review_policy','review_after_rounds','Do not silently weaken the retained review cadence.')
        hashes=c.refs(old.get('evidence_refs',[]),'decision.evidence_refs')
        change=old.get('evidence_change')
        if change not in GOAL_CHANGES | {'engineering_only','none'}:
            c.gap('unknown_evidence_change','evidence_change','Separate engineering completion from a goal-level evidence change.')
        meaningful=change in GOAL_CHANGES and bool(hashes-evidence_seen) and _text(old.get('objective_change'))
        if change in GOAL_CHANGES and not meaningful and not hashes:
            c.gap('missing_evidence','evidence_change','A claimed goal-level change requires its actual evidence.')
        if change=='dependency_unlocked' and not old.get('unlocks_task_ids'):
            meaningful=False;c.gap('unlock_without_task','unlocks_task_ids','Identify the now-ready decisive task; a repaired file alone is not a goal-level result.')
        debt=0 if meaningful else debt+1
        evidence_seen|=hashes
    if debt>=threshold and not _text(decision.get('strategy_reassessment')):
        c.gap('strategy_reassessment_due','strategy_reassessment','Reconsider parent value and alternatives across the whole repair family; preserve all spent effort.')
    facts=decision.get('facts',[])
    if not isinstance(facts,list):c.gap('invalid_facts','facts','Record sourced facts.');facts=[]
    for fact in facts:
        if not isinstance(fact,dict) or type(fact.get('value')) is not bool:
            c.gap('invalid_fact','facts','Use a sourced boolean observation, not a success label.');continue
        c.refs(fact.get('evidence_refs',[]),'facts.evidence_refs',required=fact['value'])
        if (fact.get('name') in {'mechanism_refuted','strong_baseline_removes_value'} and fact['value']
                and route in {'continue','repair'} and not _text(decision.get('substantive_delta'))):
            c.gap('retire_or_reframe','selected_option','Do not continue a refuted/redundant mechanism via a renamed repair; retire or propose an evidenced substantive change.')
    inquiry_report = None
    prior_v4 = next((d for d in reversed(chain[:-1]) if d.get('schema_version') == 4), None)
    if decision.get('schema_version') == 4:
        from research_inquiry import evaluate as evaluate_inquiry
        inquiry = decision.get('inquiry') if isinstance(decision.get('inquiry'), dict) else {}
        previous_problem = next((d for d in reversed(chain[:-1]) if d.get('schema_version') == 4
            and (d.get('inquiry') or {}).get('problem_id') == inquiry.get('problem_id')), None)
        if prior_v4:
            if (prior_v4.get('inquiry') or {}).get('goal_ref') != inquiry.get('goal_ref'):
                c.gap('inquiry_goal_changed','inquiry.goal_ref','Preserve the original goal source across local problem changes.')
            if (prior_v4.get('inquiry') or {}).get('problem_id') != inquiry.get('problem_id'):
                c.need(inquiry.get('problem_change_reason'),'problem_change_reason_missing','inquiry.problem_change_reason')
        inquiry_report = evaluate_inquiry(root, inquiry, decision=decision,
            previous=(previous_problem or {}).get('inquiry'))
        if (previous_problem and inquiry.get('stage') == 'construction'
                and (previous_problem.get('inquiry') or {}).get('objects') != inquiry.get('objects')
                and previous_problem.get('math_trace_ref') == decision.get('math_trace_ref')):
            if not inquiry.get('revalidation_ref'):
                c.gap('framing_math_revalidation_required','math_trace_ref','Changed objects need an updated trace or a pinned scoped revalidation of the unchanged derivation.')
            else:
                c.refs([inquiry['revalidation_ref']],'inquiry.revalidation_ref',True)
        c.gaps.extend(inquiry_report['gaps'])
        for ref in inquiry_report['required_input_refs']:
            c.bound_refs[ref['path']] = ref
    elif prior_v4:
        c.gap('inquiry_policy_downgrade', 'schema_version', 'Do not omit adopted object-first inquiry by reverting to a legacy decision.')
    early = bool(inquiry_report and inquiry_report.get('stage') in {'lead', 'hypothesis'})
    trajectory_report = None
    if decision.get('schema_version') in {2,3,4} and not early:
        trajectory = c.document(decision.get('trajectory_ref'), 'trajectory_ref')
        trajectory_report = check_trajectory(root, trajectory, candidate_id=decision.get('candidate_id'), goal_id=decision.get('goal_id'),
            rank_by_prior=decision.get('schema_version') != 4)
        c.gaps.extend(trajectory_report['gaps'])
        for ref in trajectory_report['required_input_refs']:
            c.bound_refs[ref['path']] = ref
        if trajectory_report['selected_task_ids'] != selected_tasks:
            c.gap('trajectory_task_mismatch', 'selected_task_ids', 'The selected experimental route must choose these exact tasks.')
        if trajectory_report['selected_trace_ref'] != decision.get('math_trace_ref'):
            c.gap('trajectory_trace_mismatch', 'math_trace_ref', 'Use the mathematical revision selected by the adaptive DAG.')
        compatible = {'repair': {'repair', 'derive'}, 'continue': {'derive', 'experiment', 'repeat', 'confirm'},
            'compare': {'experiment', 'repeat', 'confirm'}, 'explore': {'derive', 'experiment'},
            'reframe': {'derive', 'backtrack'}, 'park': {'park'}, 'retire': {'retire'}, 'close_scoped': {'park', 'retire'}}
        if trajectory_report['selected_action'] not in compatible.get(route, set()):
            c.gap('trajectory_action_mismatch', 'selected_option', 'Goal-level choice and mathematical/experimental route disagree.')
    quality_report = None
    if decision.get('schema_version') in {3,4} and (not early or decision.get('quality_ref')):
        if not decision.get('quality_ref'):
            c.gap('quality_required','quality_ref','Bind the goal-linked metric/protocol/obligation record before new v3 method investment.')
        else:
            from research_quality import evaluate
            quality = c.document(decision['quality_ref'], 'quality_ref')
            quality_report = evaluate(root, quality, task_id=task_id,
                candidate_id=decision.get('candidate_id'), goal_id=decision.get('goal_id'))
            c.gaps.extend(quality_report['gaps'])
            for ref in quality_report['required_input_refs']:
                c.bound_refs[ref['path']] = ref
            if quality.get('selected_task_ids') != selected_tasks:
                c.gap('quality_task_mismatch','quality_ref','Quality obligations and selected DAG route must bind the same tasks.')
            prior = next((d for d in reversed(chain[:-1]) if d.get('schema_version') in {3,4} and d.get('quality_ref')
                          and d.get('candidate_id') == decision.get('candidate_id')), None)
            if prior and quality.get('previous_ref') != prior.get('quality_ref'):
                c.gap('quality_history_not_consumed','quality_ref','Extend the last accepted quality record; do not erase comparison debt.')
    elif decision.get('schema_version') not in {3,4} and any(d.get('schema_version') in {3,4} for d in chain[:-1]):
        c.gap('quality_policy_downgrade','schema_version','Do not bypass adopted quality obligations with a legacy decision.')
    if inquiry_report:
        iq_action = inquiry_report.get('selected_action')
        compatible_inquiry = {'continue': {'derive','probe','repeat','confirm'},
            'repair': {'repair','qualify','derive'}, 'compare': {'compare','probe','repeat','confirm','qualify'},
            'explore': {'derive','probe','literature','qualify'}, 'reframe': {'derive','probe','literature'},
            'park': {'park'}, 'retire': {'retire'}, 'close_scoped': {'park','retire'}}
        if iq_action not in compatible_inquiry.get(route, set()):
            c.gap('inquiry_action_mismatch','selected_option','The next inquiry and goal-level action must agree.')
        if early and quality_report and quality_report.get('stage') not in {'acquire','diagnostic','derive','repair'}:
            c.gap('early_claim_expansion','quality_ref','Early inquiry is not an expanded or confirmed method comparison.')
    if c.gaps:route='analysis'
    if paused:route='preserve_pause'
    return c.report(route=route, family_rounds=total, rounds_without_goal_evidence=debt,
                    strategy_review_due=debt>=threshold, selected_task_ids=selected_tasks,
                    trajectory_action=(trajectory_report or {}).get('selected_action'),
                    inquiry_stage=(inquiry_report or {}).get('stage'), inquiry_report=inquiry_report,
                    quality_report=quality_report, quality_policy='goal_linked_v1' if quality_report else 'legacy_unreviewed')


def check_task(root, task, *, candidate_id=None, goal_id=None):
    """Explicit task bindings are checked at intake AND before a new dispatch.

    Untagged legacy tasks are settleable, not silently certified or migrated.
    Baseline/data/diagnostic work may proceed without a qualified new-method trace.
    """
    c=Check(root);scope=task.get('research_scope')
    if scope is None:return dict(status='legacy_unreviewed',gaps=[],scientific_certification=False)
    if scope not in {'method','diagnostic','maintenance'}:
        c.gap('invalid_scope','research_scope','Declare method, diagnostic or maintenance.');return c.report()
    reference=task.get('reasoning_ref')
    if reference is None:
        if scope=='method':c.gap('missing_decision','reasoning_ref','Acquire the missing derivation/decision in a diagnostic task; do not admit a qualified method claim.')
        return c.report()
    if reference not in task.get('input_refs',[reference]):
        c.gap('unpinned_decision','input_refs','Pin the actual reasoning_ref among the consuming task inputs.')
    decision=c.document(reference,'reasoning_ref')
    if scope == 'method' and decision.get('schema_version') not in {2,3,4}:
        c.gap('adaptive_trajectory_required', 'reasoning_ref', 'New-method work requires a version-2 decision with an adaptive trajectory; legacy records remain readable without certification.')
    report=check_decision(root,decision,task_id=task.get('task_id',task.get('id')),candidate_id=candidate_id,goal_id=goal_id)
    c.gaps.extend(report['gaps'])
    for ref in report['required_input_refs']:
        c.bound_refs[ref['path']] = ref
    if (decision.get('schema_version') == 4 and scope != 'method'
            and report.get('inquiry_stage') == 'construction'
            and ((decision.get('inquiry') or {}).get('next_check') or {}).get('action') in {'compare','confirm'}):
        c.gap('construction_mislabeled','research_scope','A constructed method comparison cannot use the early-investigation exception.')
    if scope=='method' and report['route'] in {'park', 'retire', 'close_scoped'}:
        c.gap('method_after_closure', 'research_scope', 'A parked or retired selection cannot launch candidate investment; create an explicit reviewed successor.')
    if scope=='method':
        if report.get('inquiry_stage') in {'lead','hypothesis'}:
            c.gap('lead_not_method','research_scope','Use an explicitly bound diagnostic probe until there is a construction; do not invent a completed derivation.')
        quality_report = report.get('quality_report')
        if quality_report and (task.get('phase') == 'experiment' or task.get('kind') == 'research_experiment') and quality_report.get('stage') not in {'compare','expand','confirm'}:
            c.gap('quality_stage_mismatch','quality_ref','An empirical method task needs a comparison/expansion/confirmation protocol, not a derivation or repair label.')
        if (task.get('phase') == 'experiment' or task.get('kind') == 'research_experiment') and report.get('trajectory_action') not in {'experiment','repeat','confirm'}:
            c.gap('experiment_not_selected','research_scope','Derivation or repair selection cannot launch an empirical method comparison.')
        trace=c.document(decision.get('math_trace_ref'),'math_trace_ref')
        trace_report = check_trace(root,trace,candidate_id=candidate_id or decision.get('candidate_id'))
        c.gaps.extend(trace_report['gaps'])
        for ref in trace_report['required_input_refs']:
            c.bound_refs[ref['path']] = ref
    return c.report(route=report['route'])



def require_task(root, task, *, candidate_id=None, goal_id=None, accepted_ref=None,
                 require_accepted=False, expand=False):
    """Validate scoped work and return its immutable evidence inventory.

    At intake expand=True adds verified transitive dependencies. At dispatch their
    prior presence is required; a changed record cannot silently repin a task.
    This function does not dispatch, update a journal or certify scientific truth.
    """
    report = check_task(root, task, candidate_id=candidate_id, goal_id=goal_id)
    if require_accepted and (task.get('research_scope') == 'method' or is_inquiry_task(root, task)):
        if accepted_ref is None or task.get('reasoning_ref') != accepted_ref:
            raise ValueError('reasoning decision must be the current accepted selection')
    if report['gaps']:
        raise ValueError('reasoning record incomplete: ' + ', '.join(g['code'] for g in report['gaps']))
    refs = list(task.get('input_refs', []))
    for ref in report.get('required_input_refs', []):
        if ref not in refs:
            if not expand:
                raise ValueError('reasoning transitive reference was not pinned at task intake')
            if any(old['path'] == ref['path'] for old in refs):
                raise ValueError('reasoning reference conflicts with an immutable task input')
            refs.append(ref)
    return refs


TRAJECTORY_ACTIONS = {'derive', 'experiment', 'repeat', 'confirm', 'repair', 'backtrack', 'park', 'retire'}
ORDINAL = {'unknown': 0, 'low': 1, 'medium': 2, 'high': 3}


def check_trajectory(root, trajectory, *, candidate_id=None, goal_id=None, rank_by_prior=True):
    """Check an adaptive selection over versioned derivation DAGs.

    The reusable operation graph can be cyclic. Concrete proof dependencies cannot.
    Priors are sourced ordinal preferences, not invented Bayesian probabilities.
    Outcome interpretation is supplied evidence: this checker cannot certify it.
    """
    c = Check(root)
    t = trajectory if isinstance(trajectory, dict) else {}
    if t.get('kind') != 'adaptive_trajectory' or t.get('schema_version') != 1:
        c.gap('trajectory_kind', 'kind', 'Use an adaptive_trajectory with actual prior, experiment and outcome bindings.')
    for key in ('trajectory_id', 'goal_id'):
        c.need(t.get(key), 'missing_identity', key)
    if type(t.get('revision')) is not int or t['revision'] < 1:
        c.gap('invalid_revision', 'revision', 'Use a positive immutable trajectory revision.')
    if goal_id is not None and t.get('goal_id') != goal_id:
        c.gap('goal_mismatch', 'goal_id', 'Keep the same research goal across mathematical routes.')
    routes = c.entries(t.get('routes'), 'routes')
    if not routes:
        c.gap('missing_routes', 'routes', 'Name at least one justified route; there is no fixed candidate quota.')
    selection = t.get('selection') if isinstance(t.get('selection'), dict) else {}
    selected_id = selection.get('route_id')
    selected = routes.get(selected_id, {})
    if not selected:
        c.gap('route_not_found', 'selection.route_id', 'Select a recorded route, not an invented path.')
    if candidate_id is not None and selected.get('candidate_id') != candidate_id:
        c.gap('candidate_mismatch', 'selection', 'Bind the selected route to the actual method candidate.')
    experiments, states = {}, {r: 'unexamined' for r in routes}
    for rid, route in routes.items():
        c.need(route.get('candidate_id'), 'missing_identity', rid + '.candidate_id')
        prior = route.get('prior') if isinstance(route.get('prior'), dict) else {}
        if prior.get('priority') not in ORDINAL:
            c.gap('prior_priority', rid, 'Use a sourced ordinal prior and keep its uncertainty explicit.')
        c.need(prior.get('basis'), 'prior_basis_missing', rid)
        c.need(prior.get('uncertainty'), 'prior_uncertainty_missing', rid)
        c.refs(prior.get('evidence_refs', []), rid + '.prior', required=True)
        if any(key in prior for key in ('probability', 'posterior', 'bayes_factor')):
            c.gap('unsupported_probability', rid, 'This ordinal selector computes no probabilities. A quantitative model needs its own likelihood, dependence and calibration evidence.')
        if route.get('decision_value') not in ORDINAL:
            c.gap('decision_value_missing', rid, 'State the anticipated decision value, not a fabricated probability of discovery.')
        c.need(route.get('cost'), 'cost_missing', rid)
        if route.get('availability') not in {'ready', 'blocked'}:
            c.gap('availability_missing', rid, 'State whether the route has the inputs needed for its next action.')
        if route.get('availability') == 'blocked':
            c.need(route.get('blocker'), 'blocker_missing', rid)
        # An unselected empirical lead may not have its derivation yet.
        trace = c.document(route['trace_ref'], rid + '.trace_ref') if route.get('trace_ref') else {}
        if trace and trace.get('candidate_id') != route.get('candidate_id'):
            c.gap('candidate_mismatch', rid, 'The route and its mathematical work product must refer to the same candidate.')
        if rid == selected_id and selection.get('action') in {'experiment', 'repeat', 'confirm'}:
            tr = check_trace(root, trace, candidate_id=route.get('candidate_id'))
            c.gaps.extend(tr['gaps'])
            for ref in tr['required_input_refs']:
                c.bound_refs[ref['path']] = ref
        steps = {s.get('id') for s in trace.get('steps', []) if isinstance(s, dict) and _text(s.get('id'))}
        plans = c.entries(route.get('experiments'), rid + '.experiments')
        for eid, experiment in plans.items():
            experiments[(rid, eid)] = experiment
            for key in ('question', 'contrast', 'analysis_plan', 'independent_unit', 'sampling_plan', 'budget'):
                c.need(experiment.get(key), 'missing_experiment_contract', rid + '.' + eid + '.' + key)
            if experiment.get('scope') not in {'development', 'confirmation', 'diagnostic'}:
                c.gap('experiment_scope', eid, 'Separate exploration, diagnostic checks and frozen confirmation.')
            targets = c.ids(experiment.get('target_step_ids'), eid + '.target_step_ids', True)
            if trace and any(s not in steps for s in targets):
                c.gap('unknown_experiment_step', eid, 'Tie the experiment to the intermediate statement it tests.')
            actions = experiment.get('outcome_actions', {})
            for outcome in ('supports', 'refutes', 'inconclusive', 'invalid'):
                if not isinstance(actions, dict) or actions.get(outcome) not in TRAJECTORY_ACTIONS:
                    c.gap('missing_outcome_action', eid, 'Predeclare what support, refutation, uncertainty and invalid execution change.')
    observations = t.get('observations')
    if not isinstance(observations, list):
        c.gap('missing_observations', 'observations', 'Record actual outcomes in order; [] is correct before the first experiment.'); observations = []
    obs_ids, attempts, questions, units = [], set(), set(), set()
    refuted_traces, invalid_traces = set(), set()
    for o in observations:
        if not isinstance(o, dict):
            c.gap('invalid_observation', 'observations', 'Keep an actual outcome envelope.'); continue
        oid, rid, eid = o.get('id'), o.get('route_id'), o.get('experiment_id')
        if not _text(oid) or oid in obs_ids:
            c.gap('duplicate_identity', 'observations', 'Observation IDs must be distinct.')
        obs_ids.append(oid)
        attempt = o.get('attempt_id')
        if not _text(attempt) or attempt in attempts:
            c.gap('duplicate_attempt', oid, 'A repeated receipt is not a new experimental attempt.')
        attempts.add(attempt); questions.add((rid, eid))
        result = c.document(o.get('result_ref'), str(oid) + '.result_ref')
        if result.get('kind') != 'trajectory_outcome' or result.get('terminal') is not True:
            c.gap('nonterminal_result', oid, 'Only terminal observed results can update a route; retain active/unknown jobs separately.')
        for key in ('attempt_id', 'route_id', 'experiment_id', 'trace_ref', 'experiment_ref', 'outcome'):
            if result.get(key) != o.get(key):
                c.gap('result_binding_mismatch', str(oid) + '.' + key, 'Bind this outcome to the exact run, mathematical revision and frozen experiment.')
        c.refs(result.get('raw_refs', []), str(oid) + '.raw_refs', required=True)
        c.need(result.get('interpretation'), 'missing_interpretation', oid)
        unit_ids = c.ids(result.get('independent_unit_ids'), str(oid) + '.independent_unit_ids')
        units |= {(rid, eid, unit) for unit in unit_ids}
        contract = c.document(o.get('experiment_ref'), str(oid) + '.experiment_ref')
        if experiments.get((rid, eid)) != contract:
            c.gap('experiment_contract_changed', oid, 'Do not change the test after observing outcomes; retain its old ID and add a versioned experiment.')
        if rid not in routes:
            c.gap('route_not_found', oid, 'Retain the route that produced this negative or positive evidence.')
        elif o.get('trace_ref') != routes[rid].get('trace_ref'):
            c.gap('trace_revision_changed', oid, 'Keep the old route/trace immutable and append a new route on revised mathematics.')
        outcome = o.get('outcome')
        if outcome not in {'supports', 'refutes', 'inconclusive', 'invalid'}:
            c.gap('invalid_outcome', oid, 'Use a scoped supported/refuted/inconclusive/invalid result.')
        state = {'supports': 'supported_scoped', 'refutes': 'refuted_scoped',
                 'inconclusive': 'inconclusive', 'invalid': 'needs_repair'}.get(outcome, 'unknown')
        if rid in states:
            # Later support cannot silently erase an earlier conflicting result.
            if states[rid] == 'refuted_scoped' and state == 'supported_scoped':
                state = 'conflicting_evidence'
            states[rid] = state
        digest = o.get('trace_ref', {}).get('sha256') if isinstance(o.get('trace_ref'), dict) else None
        if outcome == 'refutes': refuted_traces.add(digest)
        if outcome == 'invalid': invalid_traces.add(digest)
    action = selection.get('action')
    if action not in TRAJECTORY_ACTIONS:
        c.gap('selection_action', 'selection.action', 'Choose a bounded derivation, experiment, repetition, confirmation, repair or retirement.')
    tasks = c.ids(selection.get('task_ids'), 'selection.task_ids', True)
    for key in ('reason', 'alternative'):
        c.need(selection.get(key), 'selection_reason_missing', 'selection.' + key)
    consumed = c.ids(selection.get('based_on_observation_ids'), 'selection.based_on_observation_ids')
    if consumed != obs_ids:
        c.gap('feedback_not_consumed', 'selection', 'Account for every accumulated result, including negative and invalid outcomes.')
    sid = selected.get('trace_ref', {}).get('sha256') if isinstance(selected.get('trace_ref'), dict) else None
    if action in {'experiment', 'repeat', 'confirm'}:
        if selected.get('availability') != 'ready':
            c.gap('selected_route_blocked', 'selection', 'Acquire missing evidence or choose independent ready work.')
        if sid in refuted_traces:
            c.gap('refuted_route_selected', 'selection', 'Do not re-run a refuted route as new support. Preserve it and derive a substantive successor; investigate conflicting evidence as diagnosis.')
        if sid in invalid_traces and states.get(selected_id) == 'needs_repair':
            c.gap('invalid_result_needs_repair', 'selection', 'An invalid run is not scientific refutation; repair or requalify it before another method claim.')
        exp = experiments.get((selected_id, selection.get('experiment_id')))
        if exp is None:
            c.gap('experiment_not_found', 'selection.experiment_id', 'Choose a retained experiment contract.')
        if action == 'confirm' and (not exp or exp.get('scope') != 'confirmation'):
            c.gap('confirmation_scope_required', 'selection', 'Confirmation requires a separately frozen, appropriately unexposed experiment; renaming exposed data does not suffice.')
    # Qualitative decision value outranks library familiarity. This is a transparent
    # heuristic, not an optimal information-gain or posterior probability claim.
    rank = sorted((rid for rid, route in routes.items() if route.get('availability') == 'ready'
                   and (route.get('trace_ref') or {}).get('sha256') not in refuted_traces),
                  key=lambda rid: (-ORDINAL.get(routes[rid].get('decision_value'), 0),
                                   -ORDINAL.get(routes[rid].get('prior', {}).get('priority'), 0) if rank_by_prior else 0, rid))
    if (action in {'experiment', 'repeat', 'confirm'} and rank
            and (selected_id != rank[0] if rank_by_prior else
                 ORDINAL.get(selected.get('decision_value'), 0) < ORDINAL.get(routes[rank[0]].get('decision_value'), 0))
            and not _text(selection.get('override_reason'))):
        c.gap('selection_override_required', 'selection', 'Explain why cost, dependencies or a decisive control outweighs the current qualitative ranking.')
    old_ref = t.get('previous_ref')
    if old_ref is not None:
        old = c.document(old_ref, 'previous_ref')
        if (old.get('kind') != 'adaptive_trajectory' or old.get('trajectory_id') != t.get('trajectory_id')
                or old.get('goal_id') != t.get('goal_id') or type(old.get('revision')) is not int
                or type(t.get('revision')) is not int or old['revision'] >= t['revision']):
            c.gap('trajectory_parent_mismatch', 'previous_ref', 'Advance the same trajectory with immutable ancestry.')
        old_obs = old.get('observations', [])
        if not isinstance(old_obs, list) or observations[:len(old_obs)] != old_obs:
            c.gap('lost_observation_history', 'observations', 'Retain the exact earlier observation prefix; no negative-result deletion or rewriting.')
        for old_route in old.get('routes', []):
            rid = old_route.get('id') if isinstance(old_route, dict) else None
            if rid not in routes:
                c.gap('lost_route_history', 'routes', 'Keep earlier branches even when parked or rejected.'); continue
            new = routes[rid]
            if new.get('prior') != old_route.get('prior'):
                c.gap('prior_rewritten', rid, 'Preserve the original prior; experimental evidence updates selection, not history.')
            if any(new.get(k) != old_route.get(k) for k in ('candidate_id', 'trace_ref')):
                c.gap('route_identity_changed', rid, 'Append a new route for a different mathematical revision.')
            old_experiments = {e['id']: e for e in old_route.get('experiments', []) if isinstance(e, dict) and 'id' in e}
            new_experiments = {e['id']: e for e in new.get('experiments', []) if isinstance(e, dict) and 'id' in e}
            if any(new_experiments.get(eid) != exp for eid, exp in old_experiments.items()):
                c.gap('experiment_contract_changed', rid, 'Retain frozen earlier experiments; add a new version instead of retuning them.')
    return c.report(selected_task_ids=tasks, selected_candidate_id=selected.get('candidate_id'),
                    selected_trace_ref=selected.get('trace_ref'), selected_route_id=selected_id,
                    selected_action=action, recommended_route_order=rank, route_states=states,
                    attempt_count=len(attempts), question_count=len(questions), observed_unit_count=len(units),
                    posterior_probability_computed=False)


def is_inquiry_task(root, task):
    # Only explicitly tagged decisions adopt the new policy; legacy diagnostics stay usable.
    ref = task.get('reasoning_ref')
    if not ref or task.get('research_scope') not in {'method','diagnostic'}:
        return False
    return _strict_json(read_ref(root, ref)).get('schema_version') == 4


def feedback_kind(task):
    # Pure classification of the immutable task. Never read mutable files at settlement.
    if task.get('research_scope') == 'method' and (task.get('phase') == 'experiment' or task.get('kind') == 'research_experiment'):
        return 'method'
    if task.get('research_scope') == 'diagnostic' and task.get('reasoning_ref'):
        return 'inquiry'
    return None


def require_host_feedback(root, task, receipts):
    """Consume actual host-observed experimental attempts before new investment.

    A receipt proves execution state, not the scientific interpretation. Old jobs
    and diagnostic acquisition remain settleable. In-flight work keeps its pins.
    """
    if not receipts or task.get('research_scope') not in {'method','diagnostic'} or not task.get('reasoning_ref'):
        return
    decision = _strict_json(read_ref(root, task['reasoning_ref']))
    v4 = decision.get('schema_version') == 4
    if v4:
        inquiry_observations = {o['attempt_id']: o for o in (decision.get('inquiry') or {}).get('observations', [])}
        for receipt in receipts:
            if receipt.get('feedback_kind') != 'inquiry' and task.get('research_scope') == 'method':
                continue
            obs = inquiry_observations.get(receipt['attempt_id'])
            if obs is None:
                raise ValueError('new inquiry must consume the latest host probe: ' + receipt['attempt_id'])
            if obs.get('receipt_ref') != receipt.get('receipt_ref') or obs.get('task_id') != receipt.get('task_id'):
                raise ValueError('inquiry must bind the actual host probe receipt and task')
            read_ref(root, obs['receipt_ref'], metadata=False)
            if receipt.get('valid_execution') is not True and obs.get('outcome') != 'invalid':
                raise ValueError('invalid host probe cannot support or refute a scientific hypothesis')
    if task.get('research_scope') != 'method':
        return
    receipts = [r for r in receipts if r.get('feedback_kind', 'method') == 'method']
    trajectory = _strict_json(read_ref(root, decision['trajectory_ref']))
    observed = {o['attempt_id']: o for o in trajectory.get('observations', [])}
    for receipt in receipts:
        observation = observed.get(receipt['attempt_id'])
        if observation is None:
            raise ValueError('new reasoning selection must consume the latest host experiment: ' + receipt['attempt_id'])
        result = _strict_json(read_ref(root, observation['result_ref']))
        ref = receipt.get('receipt_ref')
        if ref is not None and ref not in result.get('raw_refs', []):
            raise ValueError('trajectory feedback must bind the actual host execution receipt')
        if receipt.get('valid_execution') is not True and observation.get('outcome') != 'invalid':
            raise ValueError('an invalid host execution cannot be scientific support or refutation')


def metadata_reference(root, name):
    """Compute a CLI metadata pin without following links or loading large files."""
    if (not _text(name) or PurePosixPath(name).is_absolute() or '\\' in name or '\x00' in name
            or any(part in {'', '.', '..'} for part in name.split('/'))):
        raise ValueError('unsafe metadata path')
    fds = []
    try:
        fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW); fds.append(fd)
        for part in name.split('/')[:-1]:
            fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd); fds.append(fd)
        fd = os.open(name.split('/')[-1], os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW, dir_fd=fd); fds.append(fd)
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_BYTES:
            raise ValueError('metadata must be a bounded regular file')
        data = bytearray()
        while block := os.read(fd, min(65536, MAX_BYTES + 1 - len(data))):
            data.extend(block)
            if len(data) > MAX_BYTES:
                raise ValueError('metadata grew beyond limit')
        return dict(path=name, sha256=hashlib.sha256(data).hexdigest())
    finally:
        for fd in reversed(fds):
            os.close(fd)


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',required=True)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--trace');group.add_argument('--decision');group.add_argument('--task');group.add_argument('--trajectory')
    args=parser.parse_args(argv);kind=next(k for k in ('trace','decision','task','trajectory') if getattr(args,k))
    try:
        p=Path(getattr(args,kind));p=p if p.is_absolute() else Path(args.root)/p
        relative=p.relative_to(Path(args.root)).as_posix()
        ref=metadata_reference(args.root, relative)
        value=_strict_json(read_ref(args.root,ref))
        result=globals()['check_'+kind](args.root,value)
    except (ValueError,OSError,TypeError) as error:
        result=dict(status='record_incomplete',gaps=[dict(code='unreadable_input',next_action=str(error))],scientific_certification=False)
    print(json.dumps(result,indent=2,allow_nan=False))
    return 0 if result['status'] in {'record_complete','legacy_unreviewed'} else 2

if __name__=='__main__':raise SystemExit(main())
