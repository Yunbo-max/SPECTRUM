"""RSI workflow regression fixtures; these are not scientific experiments."""
import copy
import tempfile
import types
import unittest
from pathlib import Path

from fixtures import C, ProjectFixture, digest, sample_artifacts, write
from ipcg_fixtures import candidate, importance, ready_problem
from test_method_verification import BatchFixture, RANK_CHECKS, V
from test_workflow import primary_snapshot, to_gate


def candidate_gate(f):
    """Reach a frozen candidate gate using real ledger and collision validation."""
    import _evidence as E
    ready_problem(f)
    snapshot = primary_snapshot(f)
    f.transition("update_evidence", {"claim_clarity": "C2_falsifiable",
                 "literature_state": "L2_primary_verified", "evidence_snapshot_ref": snapshot}, refs=[snapshot])
    work = copy.deepcopy(sample_artifacts()["work-record"])
    work["evidence_refs"] = [f.source]
    unit = copy.deepcopy(sample_artifacts()["evidence-unit"])
    unit["locators"][0]["artifact_ref"] = f.source
    wref = write(f.root, "evidence/recovery-work.json", work)
    uref = write(f.root, "evidence/recovery-unit.json", unit)
    capture = write(f.root, "evidence/recovery-capture.json", {"works": [work], "evidence_units": [unit]})
    searches = []
    for i in (1, 2):
        search = copy.deepcopy(sample_artifacts()["search-run"])
        search.update(search_id="recovery-search-" + str(i), raw_capture_refs=[capture],
                      query_families=sorted(E.FAMILIES),
                      normalized_output_digest=digest({"works": [work], "evidence_units": [unit]}))
        searches.append(write(f.root, "evidence/recovery-search-" + str(i) + ".json", search))
    cref = candidate(f)
    f.transition("research_candidate", {"candidate_ref": cref})
    roles = {role: write(f.root, "audits/recovery-" + role + ".json", {
        "role": role, "context_id": "engineering-" + role, "evidence_refs": [uref], "fixture": True})
        for role in ("retriever", "prosecutor", "defender", "equivalence_verifier", "provenance_auditor", "adjudicator")}
    report = copy.deepcopy(sample_artifacts()["collision-decision"])
    report.update(candidate_ref=cref, evidence_refs=[uref], search_run_refs=searches, work_refs=[wref],
                  coverage_batches=[{"new_high_risk_families": [], "search_run_refs": [r]} for r in searches],
                  claim_audits=[{"claim_id": "claim-1", "work_ids": [work["work_id"]],
                                 "evidence_refs": [uref], "role_refs": roles}])
    report["coverage"].update(required_families=sorted(E.FAMILIES), completed_families=sorted(E.FAMILIES))
    rref = write(f.root, "audits/recovery-collision.json", report)
    f.transition("importance_decision", {"importance_decision_ref": importance(f, collision_ref=rref)})
    f.transition("collision_ADVANCE", {"collision_ref": rref})
    protocol = f.protocol(frozen=False)
    protocol["evidence_snapshot_ref"] = snapshot
    source = write(f.root, "recovery-protocol-input.json", protocol)
    with C.locked(f.root):
        result = C.freeze_gate(types.SimpleNamespace(protocol=str(f.root / source["path"]), gate="gate-a"), f.root)
    return C.verify_ref(f.root, result["protocol_ref"], "gate-a-protocol"), result["protocol_ref"]


class CandidateRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.f = ProjectFixture()
        self.addCleanup(self.f.close)

    def decision(self, protocol, pref, gate, effects):
        self.f.runs(protocol, effects)
        args = types.SimpleNamespace(protocol=str(self.f.root / pref["path"]),
                                     runs=str(self.f.root / "runs" / protocol["protocol_id"]),
                                     gate=gate, root=str(self.f.root))
        with C.locked(self.f.root):
            return C.evaluate_command(args, self.f.root)

    def kill(self, gate="gate-a", named_candidate=True):
        protocol, pref = candidate_gate(self.f) if named_candidate else to_gate(self.f)
        if gate == "full-validation":
            passed = self.decision(protocol, pref, "gate-a", (.25, .25))
            self.f.transition("gate_a_PASS", {"decision_ref": passed["decision_ref"]})
            full = self.f.protocol("full-validation", frozen=False)
            full.update(protocol_id="recovery-full", evidence_snapshot_ref=protocol["evidence_snapshot_ref"],
                        inventory_run_ids=["recovery-full-r1-main", "recovery-full-r2-main"])
            source = write(self.f.root, "recovery-full-input.json", full)
            with C.locked(self.f.root):
                frozen = C.freeze_gate(types.SimpleNamespace(protocol=str(self.f.root / source["path"]),
                                                            gate=gate), self.f.root)
            pref = frozen["protocol_ref"]
            protocol = C.verify_ref(self.f.root, pref, "full-validation-protocol")
        result = self.decision(protocol, pref, gate, (0, 0))
        self.assertEqual(result["decision"]["outcome"], "KILL")
        prefix = "gate_a" if gate == "gate-a" else "full_validation"
        state = self.f.transition(prefix + "_KILL", {"decision_ref": result["decision_ref"]})["state"]
        return state, result["decision_ref"], pref

    def successor(self, decision_ref, parent="c1", changed=True):
        cref = candidate(self.f, id="c2", parent=parent)
        value = C.verify_ref(self.f.root, cref, "idea-atom")
        if changed:
            value["minimal_intervention"] = "Retain only causally identified edge constraints"
            value["unique_prediction"] = "Remove spurious constraints while retaining reversal recovery"
        cref = write(self.f.root, "ideas/c2.json", value)
        evidence = write(self.f.root, "audits/recovery-diagnosis.json", {
            "fixture": "engineering recovery record", "failed_decision_ref": decision_ref,
            "finding": "Unfiltered edge retention is the failed predicate; selective retention changes it"})
        return {"candidate_ref": cref, "recovery": {"failed_decision_ref": decision_ref,
                "substantive_delta": "Selective retention changes the failed intervention and prediction",
                "evidence_refs": [evidence]}}

    def test_gate_kill_retires_candidate_but_preserves_project_and_evidence(self):
        state, dref, pref = self.kill()
        self.assertEqual(state["terminal_status"], "none")
        self.assertEqual((state["current_route"], state["lifecycle_phase"]), ("explore_problem", "landscape"))
        self.assertEqual(state["gate_state"], "kill")
        self.assertEqual(state["candidate_id"], "c1")
        self.assertEqual(state["gate_a_protocol_ref"], pref)
        self.assertEqual(C.verify_ref(self.f.root, dref, "gate-a-decision")["outcome"], "KILL")

    def test_full_validation_kill_also_allows_new_research_direction(self):
        state, _, _ = self.kill("full-validation")
        self.assertEqual(state["terminal_status"], "none")
        self.assertEqual(state["validation_state"], "kill")
        self.assertEqual(state["writing_state"], "not_ready")

    def test_bound_changed_child_continues_and_retains_failed_parent(self):
        _, dref, _ = self.kill()
        state = self.f.transition("research_candidate", self.successor(dref))["state"]
        self.assertEqual(state["candidate_id"], "c2")
        self.assertEqual(state["current_route"], "develop_candidate")
        self.assertEqual(state["gate_state"], "not_ready")
        _, events, _ = C.project(self.f.root)
        failed = [event for event in events if event["payload"].get("outcome") == "gate_a_KILL"]
        self.assertEqual(failed[0]["next_state"]["candidate_id"], "c1")
        self.assertEqual(failed[0]["payload"]["decision_ref"], dref)

    def test_renaming_failed_candidate_is_not_a_substantive_recovery(self):
        _, dref, _ = self.kill()
        with self.assertRaises(C.Failure) as error:
            self.f.transition("research_candidate", self.successor(dref, changed=False))
        self.assertEqual(error.exception.code, "CANDIDATE_RECOVERY_DELTA_REQUIRED")

    def test_successor_requires_failed_decision_binding_and_parent(self):
        _, dref, _ = self.kill()
        for field, expected in (("record", "CANDIDATE_RECOVERY_REQUIRED"),
                                ("decision", "CANDIDATE_RECOVERY_DECISION_MISMATCH"),
                                ("parent", "CHILD_CANDIDATE_REQUIRED")):
            payload = self.successor(dref, parent="unrelated" if field == "parent" else "c1")
            if field == "record":
                payload.pop("recovery")
            elif field == "decision":
                payload["recovery"]["failed_decision_ref"] = self.f.source
            with self.subTest(field=field), self.assertRaises(C.Failure) as error:
                self.f.transition("research_candidate", payload)
            self.assertEqual(error.exception.code, expected)

    def test_missing_recovery_evidence_cannot_open_successor(self):
        _, dref, _ = self.kill()
        payload = self.successor(dref)
        payload["recovery"]["evidence_refs"] = []
        with self.assertRaises(C.Failure) as error:
            self.f.transition("research_candidate", payload)
        self.assertEqual(error.exception.code, "CANDIDATE_RECOVERY_EVIDENCE_REQUIRED")

    def test_existing_method_without_idea_atom_binds_its_failed_protocol(self):
        _, dref, pref = self.kill(named_candidate=False)
        payload = self.successor(dref, parent=None)
        with self.assertRaises(C.Failure) as error:
            self.f.transition("research_candidate", payload)
        self.assertEqual(error.exception.code, "CANDIDATE_RECOVERY_PROTOCOL_REQUIRED")
        payload["recovery"]["parent_protocol_ref"] = pref
        state = self.f.transition("research_candidate", payload)["state"]
        self.assertEqual(state["current_route"], "develop_candidate")
        self.assertEqual(state["candidate_id"], "c2")

    def test_explicit_project_stop_remains_terminal(self):
        self.f.transition("explicit_stop")
        with self.assertRaises(C.Failure) as error:
            self.f.transition("restart_problem_exploration")
        self.assertEqual(error.exception.code, "PROJECT_TERMINAL")

    def test_historical_terminal_kill_replays_without_automatic_resurrection(self):
        protocol, pref = candidate_gate(self.f)
        result = self.decision(protocol, pref, "gate-a", (0, 0))
        state, events, _ = C.project(self.f.root)
        archived = copy.deepcopy(state)
        archived.update(gate_state="kill", current_route="stopped", lifecycle_phase="terminal", terminal_status="stopped")
        with C.locked(self.f.root):
            C.append(self.f.root, state, events, "transition", "LEGACY_ENGINEERING_FIXTURE", [result["decision_ref"]],
                     {"outcome": "gate_a_KILL", "decision_ref": result["decision_ref"]}, archived)
        self.assertEqual(C.project(self.f.root)[0]["terminal_status"], "stopped")
        with self.assertRaises(C.Failure) as error:
            self.f.transition("restart_problem_exploration")
        self.assertEqual(error.exception.code, "PROJECT_TERMINAL")


class SingleCandidateScopeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.f = BatchFixture(self.root)
        self.f.batch.update(pool_target=1, selection_target=1,
                            target_override="Owner-selected autonomous Chat single-candidate research scope")
        self.f.batch["candidates"] = self.f.batch["candidates"][:1]
        self.f.selection()
        selection = C.load_file(C.verify_ref(self.root, self.f.batch["selection_ref"]))
        selection.update(pool_target=1, selection_target=1)
        self.f.batch["selection_ref"] = write(self.root, "selection.json", selection)
        self.f.batch["selection_review_ref"] = self.f.review(self.f.batch["batch_id"], "selection",
                                                            self.f.batch["selection_ref"], RANK_CHECKS)

    def test_explicit_single_candidate_scope_uses_real_math_and_selection_checks(self):
        report = V.verify_batch(self.root, self.f.batch, through="code")
        self.assertTrue(report["selection_verified"], report["selection_blockers"])
        self.assertEqual(report["counts"]["math_verified"], 1)
        self.assertEqual(report["counts"]["selected"], 1)
        self.assertFalse(report["candidates"][0]["code_verified"])

    def test_single_candidate_scope_does_not_waive_math_review(self):
        self.f.batch["candidates"][0].pop("math_review_ref")
        report = V.verify_batch(self.root, self.f.batch, through="code")
        self.assertFalse(report["selection_verified"])
        self.assertFalse(report["candidates"][0]["math_verified"])

    def test_single_candidate_scope_requires_explicit_override_record(self):
        self.f.batch.pop("target_override")
        with self.assertRaises(C.Failure) as error:
            V.verify_batch(self.root, self.f.batch, through="code")
        self.assertEqual(error.exception.code, "EXPLICIT_TARGET_OVERRIDE_REQUIRED")


if __name__ == "__main__":
    unittest.main()
