"""Operational bookkeeping tests; no model calls or scientific scoring."""
import concurrent.futures
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts/chat_cycle.py'
if SCRIPT.exists():
    SPEC = importlib.util.spec_from_file_location('chat_cycle', SCRIPT)
    C = importlib.util.module_from_spec(SPEC)
    SPEC.loader.exec_module(C)
else:
    C = None


class ChatCycleTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(C, 'optional Chat bookkeeping helper is missing')
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.state = self.root / 'cycle.json'
        self.procedure = {'id': 'procedure-v1', 'ref': self.write('procedure.md', 'Initial procedure')}

    def write(self, name, value):
        path = self.root / name
        data = value if isinstance(value, str) else json.dumps(value, sort_keys=True)
        path.write_text(data, encoding='utf-8')
        return {'path': name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

    def task(self, task_id, *, dependencies=(), candidate_id='candidate-v1', **extra):
        return dict(id=task_id, action='Perform ' + task_id, candidate_id=candidate_id,
                    dependencies=list(dependencies), input_refs=[], **extra)

    def init(self, tasks=None, criteria=None, deliveries=None, budget=None):
        config = dict(goal_id='goal-1', goal='Produce reviewed output',
                      goal_contract={'mode': 'bounded_task',
                          'request_ref': self.write('request.txt', 'Produce this reviewed output only.'),
                          'continuation_action': 'Finish the requested output'},
                      criteria=criteria or ['reviewed'], deliveries=deliveries or ['repository'],
                      budget=budget or {'max_attempts': 12}, procedure=self.procedure,
                      tasks=tasks if tasks is not None else [self.task('draft')])
        return C.initialize(self.state, config)

    def event(self, op, **values):
        return C.record(self.state, C.status(self.state)['revision'], dict(op=op, **values))

    def begin(self, task_id):
        return self.event('begin', task_id=task_id)['current_attempt']

    def evidence(self, attempt, outcome='completed', *, criteria=None, deliveries=None, name=None):
        raw = self.write((name or attempt['id']) + '-raw.txt', 'Observed output of ' + attempt['id'])
        receipt_refs = {}
        for delivery_id in deliveries or []:
            receipt_refs[delivery_id] = self.write(attempt['id'] + '-' + delivery_id + '-receipt.json', {
                'attempt_id': attempt['id'], 'destination': 'actual-repository/commit',
                'delivered_sha256': raw['sha256'], 'readback_sha256': raw['sha256']})
        return self.write((name or attempt['id']) + '-evidence.json', {
            'attempt_id': attempt['id'], 'task_id': attempt['task_id'],
            'candidate_id': attempt['candidate_id'], 'procedure_id': attempt['procedure']['id'],
            'outcome': outcome, 'raw_evidence': [raw], 'criteria_met': criteria or [],
            'delivery_receipts': receipt_refs})

    def finish(self, attempt, outcome='completed', **values):
        evidence = self.evidence(attempt, outcome, **values)
        return self.event('result', attempt_id=attempt['id'], outcome=outcome,
                          evidence_ref=evidence, reason='Observed ' + outcome,
                          next_action='Inspect remaining obligations')

    def test_stage_completion_selects_next_eligible_action(self):
        self.init([self.task('read'), self.task('review', dependencies=['read'])])
        self.finish(self.begin('read'))
        self.assertEqual(C.next_action(self.state)['task_id'], 'review')
        self.assertEqual(C.status(self.state)['tasks'][0]['status'], 'completed')

    def test_repair_never_marks_failed_predecessor_as_passed(self):
        self.init([self.task('draft'), self.task('dependent', dependencies=['draft'])])
        self.finish(self.begin('draft'), 'failed')
        self.event('add_task', task=self.task('repair', repairs='draft', candidate_id='candidate-v2'))
        self.finish(self.begin('repair'))
        tasks = {t['id']: t for t in C.status(self.state)['tasks']}
        self.assertEqual(tasks['draft']['status'], 'failed')
        self.assertEqual(tasks['dependent']['status'], 'pending')
        self.assertEqual(C.next_action(self.state)['kind'], 'blocked')

    def test_same_old_evidence_path_cannot_complete_a_new_attempt(self):
        self.init([self.task('first'), self.task('second')])
        first = self.begin('first')
        old = self.evidence(first)
        self.event('result', attempt_id=first['id'], outcome='completed', evidence_ref=old)
        second = self.begin('second')
        before = self.state.read_bytes()
        with self.assertRaisesRegex(ValueError, 'binding'):
            self.event('result', attempt_id=second['id'], outcome='completed', evidence_ref=old)
        self.assertEqual(self.state.read_bytes(), before)

    def test_changed_raw_output_invalidates_completion_and_does_not_rewrite_state(self):
        self.init()
        attempt = self.begin('draft')
        evidence = self.evidence(attempt)
        self.write(attempt['id'] + '-raw.txt', 'Replaced output')
        before = self.state.read_bytes()
        with self.assertRaisesRegex(ValueError, 'hash'):
            self.event('result', attempt_id=attempt['id'], outcome='completed', evidence_ref=evidence)
        self.assertEqual(self.state.read_bytes(), before)

    def test_local_access_block_leaves_independent_host_work_eligible(self):
        self.init([self.task('missing-resource'), self.task('dependent', dependencies=['missing-resource']),
                   self.task('independent')])
        attempt = self.begin('missing-resource')
        self.event('result', attempt_id=attempt['id'], outcome='blocked',
                   reason='Referenced Local host is unavailable', next_action='Obtain an authorized resource')
        self.assertEqual(C.next_action(self.state)['task_id'], 'independent')

    def test_candidate_refutation_does_not_end_the_goal(self):
        self.init([self.task('candidate-a'), self.task('candidate-b', candidate_id='candidate-v2')])
        self.finish(self.begin('candidate-a'), 'refuted')
        self.assertEqual(C.next_action(self.state)['task_id'], 'candidate-b')
        self.assertNotEqual(C.next_action(self.state)['kind'], 'bookkeeping_complete')
        self.assertEqual(C.status(self.state)['attempts'][0]['outcome'], 'refuted')

    def test_no_ready_task_does_not_mean_goal_complete(self):
        self.init()
        self.finish(self.begin('draft'), criteria=['reviewed'])
        self.assertEqual(C.next_action(self.state)['kind'], 'blocked')
        self.assertEqual(C.next_action(self.state)['missing_deliveries'], ['repository'])
        self.event('add_task', task=self.task('deliver'))
        self.finish(self.begin('deliver'), deliveries=['repository'])
        self.assertEqual(C.next_action(self.state)['kind'], 'bookkeeping_complete')
        self.assertEqual(C.status(self.state)['authority'], 'operational_bookkeeping_only')
        self.assertNotIn('scientific_verdict', C.status(self.state))

    def test_partial_then_resume_keeps_attempt_and_budget_without_scientific_failure(self):
        self.init()
        attempt = self.begin('draft')
        self.event('checkpoint', attempt_id=attempt['id'], reason='Active turn limit',
                   next_action='Continue section 2 from saved draft')
        self.assertEqual(C.next_action(self.state)['kind'], 'continuation')
        self.assertEqual(C.next_action(self.state)['action'], 'Continue section 2 from saved draft')
        resumed = C.resume(self.state, C.status(self.state)['revision'])
        self.assertEqual(resumed['current_attempt']['id'], attempt['id'])
        self.assertEqual(resumed['started_attempts'], 1)
        self.assertEqual(resumed['attempts'], [])
        self.assertEqual(resumed['current_attempt']['status'], 'active')

    def test_adoption_requires_bound_review_and_changes_only_future_attempts(self):
        self.init([self.task('current'), self.task('next')])
        attempt = self.begin('current')
        candidate = {'id': 'procedure-v2', 'ref': self.write('procedure-v2.md', 'Changed procedure')}
        with self.assertRaises(ValueError):
            C.adopt(self.state, C.status(self.state)['revision'], candidate, None)
        review = self.write('procedure-review.json', {
            'kind': 'procedure_review', 'base_procedure_id': 'procedure-v1',
            'base_procedure_sha256': self.procedure['ref']['sha256'],
            'candidate_procedure_id': candidate['id'], 'candidate_sha256': candidate['ref']['sha256'],
            'proposal_task_id': 'proposal', 'review_task_id': 'independent-review',
            'outcome': 'supported', 'raw_evidence': [self.write('review.txt', 'Actual review evidence')]})
        C.adopt(self.state, C.status(self.state)['revision'], candidate, review)
        self.assertEqual(C.status(self.state)['current_attempt']['procedure']['id'], 'procedure-v1')
        self.finish(attempt)
        following = self.begin('next')
        self.assertEqual(following['procedure']['id'], 'procedure-v2')
        self.assertEqual(C.status(self.state)['attempts'][0]['procedure']['id'], 'procedure-v1')

    def test_procedure_self_review_or_unbound_candidate_cannot_be_adopted(self):
        self.init()
        candidate = {'id': 'procedure-v2', 'ref': self.write('procedure-v2.md', 'Changed')}
        for review_task, candidate_hash in [('same-task', candidate['ref']['sha256']), ('review', '0' * 64)]:
            review = self.write('invalid-review.json', {
                'kind': 'procedure_review', 'base_procedure_id': 'procedure-v1',
                'base_procedure_sha256': self.procedure['ref']['sha256'],
                'candidate_procedure_id': 'procedure-v2', 'candidate_sha256': candidate_hash,
                'proposal_task_id': 'same-task', 'review_task_id': review_task,
                'outcome': 'supported', 'raw_evidence': [self.write('raw-review.txt', 'Review')]})
            with self.assertRaises(ValueError):
                C.adopt(self.state, C.status(self.state)['revision'], candidate, review)
        self.assertEqual(C.status(self.state)['procedure']['id'], 'procedure-v1')

    def test_expected_revision_serializes_two_writers(self):
        self.init()
        revision = C.status(self.state)['revision']
        def write(index):
            try:
                C.record(self.state, revision, {'op': 'add_task', 'task': self.task('parallel-' + str(index))})
                return 'written'
            except ValueError:
                return 'conflict'
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            self.assertCountEqual(list(pool.map(write, [1, 2])), ['written', 'conflict'])
        self.assertEqual(C.status(self.state)['revision'], revision + 1)

    def test_finite_attempt_budget_blocks_new_work_but_allows_settlement(self):
        self.init([self.task('first'), self.task('second')], budget={'max_attempts': 1})
        attempt = self.begin('first')
        self.finish(attempt)
        self.assertEqual(C.next_action(self.state)['reason'], 'attempt_budget_exhausted')
        with self.assertRaisesRegex(ValueError, 'eligible'):
            self.begin('second')

    def test_external_usage_requires_receipt_and_is_never_assumed_zero(self):
        self.init(budget={'max_attempts': 2, 'limits': {'tokens': 100}})
        self.assertEqual(C.next_action(self.state)['reason'], 'usage_observation_required')
        with self.assertRaises(ValueError):
            self.event('usage', totals={'tokens': 0})
        receipt = self.write('usage.json', {'provider_observed_tokens': 20})
        self.event('usage', totals={'tokens': 20}, receipt_ref=receipt)
        self.assertEqual(C.next_action(self.state)['kind'], 'action')
        with self.assertRaises(ValueError):
            self.event('usage', totals={'tokens': 10}, receipt_ref=receipt)
        self.assertEqual(C.status(self.state)['usage']['totals'], {'tokens': 20})

    def test_init_rejects_unbounded_budget_and_cycles(self):
        with self.assertRaises(ValueError):
            self.init(budget={'max_attempts': 0})
        with self.assertRaises(ValueError):
            self.init([self.task('a', dependencies=['b']), self.task('b', dependencies=['a'])])
        self.assertFalse(self.state.exists())

    def test_completed_output_that_changes_reopens_bookkeeping_obligation(self):
        self.init()
        attempt = self.begin('draft')
        self.finish(attempt, criteria=['reviewed'], deliveries=['repository'])
        self.assertEqual(C.next_action(self.state)['kind'], 'bookkeeping_complete')
        self.write(attempt['id'] + '-raw.txt', 'A later unreviewed replacement')
        decision = C.next_action(self.state)
        self.assertEqual(decision['kind'], 'blocked')
        self.assertEqual(decision['missing_criteria'], ['reviewed'])
        self.assertEqual(decision['invalid_evidence'][0]['task_id'], 'draft')

    def test_criteria_still_needed_when_all_delivery_receipts_exist(self):
        self.init()
        self.finish(self.begin('draft'), deliveries=['repository'])
        decision = C.next_action(self.state)
        self.assertEqual(decision['kind'], 'blocked')
        self.assertEqual(decision['missing_criteria'], ['reviewed'])
        self.assertEqual(decision['missing_deliveries'], [])

    def test_refutation_invalidates_that_candidates_earlier_completion_evidence(self):
        self.init([self.task('draft'), self.task('check')])
        self.finish(self.begin('draft'), criteria=['reviewed'])
        self.finish(self.begin('check'), 'refuted')
        self.assertEqual(C.next_action(self.state)['missing_criteria'], ['reviewed'])
        self.assertEqual(C.status(self.state)['attempts'][0]['outcome'], 'completed')

    def test_receipt_with_mismatched_readback_is_rejected(self):
        self.init()
        attempt = self.begin('draft')
        evidence = self.evidence(attempt, criteria=['reviewed'], deliveries=['repository'])
        envelope = json.loads((self.root / evidence['path']).read_text())
        receipt_ref = envelope['delivery_receipts']['repository']
        receipt = json.loads((self.root / receipt_ref['path']).read_text())
        receipt['readback_sha256'] = '0' * 64
        envelope['delivery_receipts']['repository'] = self.write(receipt_ref['path'], receipt)
        bad = self.write(evidence['path'], envelope)
        with self.assertRaisesRegex(ValueError, 'readback'):
            self.event('result', attempt_id=attempt['id'], outcome='completed', evidence_ref=bad)
        self.assertEqual(C.status(self.state)['current_attempt']['id'], attempt['id'])

    def test_task_input_versions_are_pinned_until_settlement(self):
        original = self.write('candidate.py', 'Candidate version 1')
        task = self.task('review')
        task['input_refs'] = [original]
        self.init([task])
        attempt = self.begin('review')
        evidence = self.evidence(attempt)
        self.write('candidate.py', 'Candidate version 2')
        with self.assertRaisesRegex(ValueError, 'hash'):
            self.event('result', attempt_id=attempt['id'], outcome='completed', evidence_ref=evidence)
        self.assertEqual(C.status(self.state)['current_attempt']['input_refs'], [original])

    def test_no_delivery_requirement_is_invented_when_none_was_requested(self):
        config = dict(goal_id='read-only-goal', goal='Review existing evidence',
                      goal_contract={'mode': 'bounded_task',
                          'request_ref': self.write('request.txt', 'Review existing evidence only.'),
                          'continuation_action': 'Finish the requested review'},
                      criteria=['reviewed'], deliveries=[], budget={'max_attempts': 1},
                      procedure=self.procedure, tasks=[self.task('review')])
        C.initialize(self.state, config)
        self.finish(self.begin('review'), criteria=['reviewed'])
        self.assertEqual(C.next_action(self.state)['kind'], 'bookkeeping_complete')

    def test_changed_prerequisite_invalidates_downstream_completion_credit(self):
        self.init([self.task('source'), self.task('deliver', dependencies=['source'])])
        source = self.begin('source')
        self.finish(source)
        self.finish(self.begin('deliver'), criteria=['reviewed'], deliveries=['repository'])
        self.write(source['id'] + '-raw.txt', 'Changed prerequisite')
        decision = C.next_action(self.state)
        self.assertEqual(decision['kind'], 'blocked')
        self.assertEqual(decision['missing_criteria'], ['reviewed'])
        self.assertEqual(decision['missing_deliveries'], ['repository'])

    def test_active_dependent_cannot_resume_or_settle_after_prerequisite_changes(self):
        self.init([self.task('source'), self.task('deliver', dependencies=['source'])])
        source = self.begin('source')
        self.finish(source)
        delivery = self.begin('deliver')
        self.write(source['id'] + '-raw.txt', 'Changed prerequisite')
        with self.assertRaises(ValueError):
            self.finish(delivery, criteria=['reviewed'], deliveries=['repository'])
        with self.assertRaises(ValueError):
            C.resume(self.state, C.status(self.state)['revision'])
        self.assertEqual(C.status(self.state)['current_attempt']['id'], delivery['id'])

    def review(self, base, candidate):
        return self.write(candidate['id'] + '-review.json', {
            'kind': 'procedure_review', 'base_procedure_id': base['id'],
            'base_procedure_sha256': base['ref']['sha256'],
            'candidate_procedure_id': candidate['id'], 'candidate_sha256': candidate['ref']['sha256'],
            'proposal_task_id': 'proposer', 'review_task_id': 'independent-review',
            'outcome': 'supported', 'raw_evidence': [self.write('comparison.txt', 'Observed comparison')]})

    def test_procedure_id_cannot_be_reused_for_another_version(self):
        self.init()
        second = {'id': 'procedure-v2', 'ref': self.write('p2.md', 'Second')}
        C.adopt(self.state, 0, second, self.review(self.procedure, second))
        renamed = {'id': 'procedure-v1', 'ref': self.write('renamed.md', 'A different baseline')}
        with self.assertRaisesRegex(ValueError, 'version'):
            C.adopt(self.state, 1, renamed, self.review(second, renamed))

    def test_adoption_review_must_bind_the_baselines_actual_hash(self):
        self.init()
        second = {'id': 'procedure-v2', 'ref': self.write('p2.md', 'Second')}
        incorrect_base = {'id': 'procedure-v1', 'ref': self.write('wrong-baseline.md', 'Other baseline')}
        with self.assertRaisesRegex(ValueError, 'binding'):
            C.adopt(self.state, 0, second, self.review(incorrect_base, second))

    def test_delivery_receipt_must_match_an_attached_raw_artifact(self):
        self.init()
        attempt = self.begin('draft')
        evidence = self.evidence(attempt, criteria=['reviewed'], deliveries=['repository'])
        envelope = json.loads((self.root / evidence['path']).read_text())
        ref = envelope['delivery_receipts']['repository']
        receipt = json.loads((self.root / ref['path']).read_text())
        receipt['delivered_sha256'] = receipt['readback_sha256'] = '0' * 64
        envelope['delivery_receipts']['repository'] = self.write(ref['path'], receipt)
        bad = self.write(evidence['path'], envelope)
        with self.assertRaises(ValueError):
            self.event('result', attempt_id=attempt['id'], outcome='completed', evidence_ref=bad)

    def test_cli_status_and_next_are_read_only(self):
        self.init()
        before = self.state.read_bytes()
        for command in ('status', 'next'):
            result = subprocess.run([sys.executable, str(SCRIPT), command, '--state', str(self.state)],
                                    text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIsInstance(json.loads(result.stdout), dict)
        self.assertEqual(self.state.read_bytes(), before)

    def advance(self):
        return C.advance(self.state, C.status(self.state)['revision'])

    def fail_engineering(self, attempt, failure_class='implementation'):
        evidence = self.evidence(attempt, 'failed')
        return self.event('result', attempt_id=attempt['id'], outcome='failed',
            evidence_ref=evidence, reason='Observed CPU check error',
            next_action='Correct the diagnosed error and rerun the CPU check',
            failure_class=failure_class)

    def test_advance_partial_repair_downstream_and_finish_with_real_cpu_artifact(self):
        self.init([self.task('compute'), self.task('deliver', dependencies=['compute'])])
        initial = self.advance()
        self.assertEqual(initial['procedure_text'], 'Initial procedure')
        self.assertEqual(initial['executor'], 'active_chat_host')
        partial = self.write('partial.txt', 'Computed first operand: 2')
        self.event('checkpoint', attempt_id=initial['attempt']['id'], reason='Acknowledged length limit',
                   next_action='Finish CPU computation from saved operand', evidence_refs=[partial])
        continuation = self.advance()
        self.assertEqual(continuation['attempt']['id'], initial['attempt']['id'])
        self.assertEqual(continuation['checkpoint_refs'], [partial])
        self.assertEqual(C.status(self.state)['started_attempts'], 1)
        self.fail_engineering(continuation['attempt'])
        repair = self.advance()
        self.assertEqual(repair['repair_generation'], 1)
        self.assertEqual(repair['failure_context']['attempt_id'], initial['attempt']['id'])
        self.assertIn('Observed CPU check error', repair['failure_context']['reason'])
        # Acting host executes a real CPU action and records its observed output.
        result = subprocess.run([sys.executable, '-c', 'print(2 + 3)'],
                                text=True, capture_output=True, check=True)
        raw = self.write('repaired-result-v2.txt', result.stdout)
        attempt = repair['attempt']
        envelope = self.write('repaired-evidence.json', {
            'attempt_id': attempt['id'], 'task_id': attempt['task_id'],
            'candidate_id': attempt['candidate_id'], 'procedure_id': attempt['procedure']['id'],
            'outcome': 'completed', 'raw_evidence': [raw], 'output_refs': [raw]})
        self.event('result', attempt_id=attempt['id'], outcome='completed', evidence_ref=envelope)
        downstream = self.advance()
        state = C.status(self.state)
        tasks = {t['id']: t for t in state['tasks']}
        successor_id = tasks['deliver']['replacement_task_id']
        self.assertEqual(downstream['attempt']['task_id'], successor_id)
        self.assertEqual(tasks['deliver']['dependencies'], ['compute'])
        self.assertEqual(tasks['deliver']['status'], 'superseded')
        self.assertEqual(tasks['compute']['status'], 'failed')
        self.assertEqual(tasks[successor_id]['dependencies'], [attempt['task_id']])
        self.assertIn(raw, downstream['dependency_evidence_refs'])
        self.assertEqual((self.root / raw['path']).read_text(), '5\n')
        self.finish(downstream['attempt'], criteria=['reviewed'], deliveries=['repository'])
        self.assertEqual(self.advance()['kind'], 'bookkeeping_complete')
        self.assertEqual(C.status(self.state)['started_attempts'], 3)

    def test_advance_active_unknown_is_not_replayed_or_charged_again(self):
        self.init()
        handoff = self.advance()
        before = self.state.read_bytes()
        unknown = self.advance()
        self.assertEqual(unknown['reason'], 'active_attempt_requires_observation')
        self.assertEqual(unknown['attempt_id'], handoff['attempt']['id'])
        self.assertEqual(self.state.read_bytes(), before)
        with self.assertRaisesRegex(ValueError, 'acknowledged'):
            C.resume(self.state, C.status(self.state)['revision'])

    def test_advance_partial_keeps_old_procedure_and_next_task_reads_adopted_bytes(self):
        self.init([self.task('first'), self.task('next')])
        first = self.advance()
        second = {'id': 'procedure-v2', 'ref': self.write('p2.md', 'Actually execute revised steps')}
        C.adopt(self.state, C.status(self.state)['revision'], second, self.review(self.procedure, second))
        self.event('checkpoint', attempt_id=first['attempt']['id'], reason='Length limit',
                   next_action='Continue the original procedure')
        resumed = self.advance()
        self.assertEqual(resumed['procedure_text'], 'Initial procedure')
        self.assertEqual(resumed['procedure_ref'], self.procedure['ref'])
        self.finish(resumed['attempt'])
        following = self.advance()
        self.assertEqual(following['procedure_text'], 'Actually execute revised steps')
        self.assertEqual(following['attempt']['procedure']['id'], 'procedure-v2')
        self.assertEqual(following['procedure_ref'], second['ref'])

    def test_advance_refuted_hypothesis_is_not_repaired_and_independent_task_runs(self):
        self.init([self.task('hypothesis'), self.task('same-candidate'),
                   self.task('independent', candidate_id='candidate-v2')])
        self.finish(self.advance()['attempt'], 'refuted')
        action = self.advance()
        self.assertEqual(action['attempt']['task_id'], 'independent')
        self.assertFalse(any(t.get('repairs') for t in C.status(self.state)['tasks']))

    def test_unknown_failure_can_be_classified_then_repaired_without_new_user_input(self):
        self.init()
        failed = self.advance()['attempt']
        self.finish(failed, 'failed')
        self.assertEqual(self.advance()['reason'], 'needs_classification')
        observation = self.write('classification.txt', 'CPU traceback identifies a parser defect')
        self.event('classify_failure', attempt_id=failed['id'], failure_class='implementation',
                   evidence_ref=observation, next_action='Fix the parser and rerun its failing check')
        repair = self.advance()
        self.assertEqual(repair['failure_context']['failure_class'], 'implementation')
        self.assertEqual(repair['action'], 'Fix the parser and rerun its failing check')

    def test_unknown_failure_does_not_block_independent_action(self):
        self.init([self.task('fails'), self.task('independent')])
        self.finish(self.advance()['attempt'], 'failed')
        self.assertEqual(self.advance()['attempt']['task_id'], 'independent')

    def test_repair_generations_are_persistently_bounded_at_three(self):
        self.init()
        for generation in range(4):
            handoff = self.advance()
            self.assertEqual(handoff['repair_generation'], generation)
            self.fail_engineering(handoff['attempt'])
            # Every call reloads durable JSON; attempt and generation bounds survive restart.
            self.assertEqual(C.status(self.state)['started_attempts'], generation + 1)
        self.assertEqual(self.advance()['reason'], 'repair_limit_or_evidence_block')
        self.assertEqual(len(C.status(self.state)['tasks']), 4)

    def test_repairs_obey_original_attempt_budget_and_partial_does_not_reset_it(self):
        self.init(budget={'max_attempts': 2})
        self.fail_engineering(self.advance()['attempt'])
        repair = self.advance()['attempt']
        self.event('checkpoint', attempt_id=repair['id'], reason='Length limit', next_action='Continue repair')
        self.assertEqual(self.advance()['attempt']['id'], repair['id'])
        self.fail_engineering(repair)
        self.assertEqual(self.advance()['reason'], 'attempt_budget_exhausted')
        self.assertEqual(C.status(self.state)['started_attempts'], 2)

    def test_repair_chain_reconnects_original_downstream_after_second_repair_succeeds(self):
        self.init([self.task('source'), self.task('consumer', dependencies=['source']),
                   self.task('final', dependencies=['consumer'])])
        self.fail_engineering(self.advance()['attempt'])
        first_repair = self.advance()['attempt']
        self.fail_engineering(first_repair)
        second_repair = self.advance()['attempt']
        self.finish(second_repair)
        consumer = self.advance()['attempt']
        tasks = {t['id']: t for t in C.status(self.state)['tasks']}
        self.assertEqual(tasks[consumer['task_id']]['dependencies'], [second_repair['task_id']])
        self.assertEqual(tasks['source']['replacement_task_id'], first_repair['task_id'])
        self.assertEqual(tasks[first_repair['task_id']]['replacement_task_id'], second_repair['task_id'])
        self.assertEqual(tasks['consumer']['dependencies'], ['source'])
        final_id = tasks['final']['replacement_task_id']
        self.assertEqual(tasks[final_id]['dependencies'], [consumer['task_id']])
        self.finish(consumer)
        self.assertEqual(self.advance()['attempt']['task_id'], final_id)

    def test_stale_repair_output_cannot_release_consumer(self):
        self.init([self.task('source'), self.task('consumer', dependencies=['source'])])
        self.fail_engineering(self.advance()['attempt'])
        repair = self.advance()['attempt']
        self.finish(repair)
        self.write(repair['id'] + '-raw.txt', 'An unreviewed replacement')
        decision = self.advance()
        self.assertEqual(decision['kind'], 'blocked')
        self.assertTrue(decision['invalid_evidence'])
        self.assertIsNone(C.status(self.state)['current_attempt'])

    def test_unrelated_stale_input_is_not_rebound_by_producer_repair(self):
        static = self.write('dataset.txt', 'Frozen dataset')
        consumer = self.task('consumer', dependencies=['source'])
        consumer['input_refs'] = [static]
        self.init([self.task('source'), consumer])
        self.fail_engineering(self.advance()['attempt'])
        self.finish(self.advance()['attempt'])
        self.write('dataset.txt', 'Unreviewed data change')
        decision = self.advance()
        self.assertEqual(decision['kind'], 'blocked')
        self.assertTrue(decision['blocked_inputs'])
        tasks = {t['id']: t for t in C.status(self.state)['tasks']}
        successor = tasks[tasks['consumer']['replacement_task_id']]
        self.assertEqual(successor['input_refs'], [static])

    def test_advance_rejects_stale_partial_and_procedure_without_saving_dispatch(self):
        self.init()
        first = self.advance()['attempt']
        ref = self.write('partial.txt', 'Saved partial')
        self.event('checkpoint', attempt_id=first['id'], reason='Length limit',
                   next_action='Continue', evidence_refs=[ref])
        self.write('partial.txt', 'Changed without observation')
        before = self.state.read_bytes()
        with self.assertRaisesRegex(ValueError, 'hash'):
            self.advance()
        self.assertEqual(self.state.read_bytes(), before)

    def test_advance_cas_and_cli_return_concrete_procedure_handoff(self):
        self.init()
        command = [sys.executable, str(SCRIPT), 'advance', '--state', str(self.state),
                   '--expected-revision', '0']
        result = subprocess.run(command, text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['procedure_text'], 'Initial procedure')
        repeated = subprocess.run(command, text=True, capture_output=True)
        self.assertEqual(repeated.returncode, 2)
        self.assertIn('revision conflict', repeated.stderr)

    def test_attempt_budget_is_checked_before_creating_repair(self):
        self.init(budget={'max_attempts': 1})
        self.fail_engineering(self.advance()['attempt'])
        before = self.state.read_bytes()
        self.assertEqual(self.advance()['reason'], 'attempt_budget_exhausted')
        self.assertEqual(self.state.read_bytes(), before)

    def test_pending_delivery_cannot_be_skipped_when_criteria_already_recorded(self):
        self.init([self.task('first'), self.task('remaining')])
        self.finish(self.advance()['attempt'], criteria=['reviewed'], deliveries=['repository'])
        self.assertEqual(self.advance()['attempt']['task_id'], 'remaining')

    def test_repaired_output_logical_binding_updates_only_producer_inputs_to_new_hash(self):
        previous = self.write('result-v1.txt', 'Incorrect output')
        frozen = self.write('fixed-dataset.txt', 'Unchanged data')
        consumer = self.task('consumer', dependencies=['source'])
        consumer['input_refs'] = [previous, frozen]
        self.init([self.task('source'), consumer])
        source = self.advance()['attempt']
        failure = self.evidence(source, 'failed')
        envelope = json.loads((self.root / failure['path']).read_text())
        envelope['raw_evidence'].append(previous)
        envelope['output_bindings'] = {'result': previous}
        failure = self.write(failure['path'], envelope)
        self.event('result', attempt_id=source['id'], outcome='failed', failure_class='implementation',
                   reason='Wrong CPU output', next_action='Fix arithmetic', evidence_ref=failure)
        repair = self.advance()['attempt']
        updated = self.write('result-v2.txt', 'Correct output')
        repair_evidence = self.evidence(repair)
        envelope = json.loads((self.root / repair_evidence['path']).read_text())
        envelope['raw_evidence'].append(updated)
        envelope['output_bindings'] = {'result': updated}
        repair_evidence = self.write(repair_evidence['path'], envelope)
        self.event('result', attempt_id=repair['id'], outcome='completed', evidence_ref=repair_evidence)
        downstream = self.advance()
        self.assertEqual(downstream['input_refs'], [updated, frozen])
        self.assertNotEqual(updated['sha256'], previous['sha256'])
        tasks = {t['id']: t for t in C.status(self.state)['tasks']}
        self.assertEqual(tasks['consumer']['input_refs'], [previous, frozen])
        self.write('result-v2.txt', 'Changed after dispatch')
        with self.assertRaisesRegex(ValueError, 'hash|prerequisite'):
            self.finish(downstream['attempt'])

    def test_output_binding_cannot_reference_unattached_evidence(self):
        self.init()
        attempt = self.advance()['attempt']
        evidence = self.evidence(attempt)
        envelope = json.loads((self.root / evidence['path']).read_text())
        envelope['output_bindings'] = {'result': self.write('unrelated.txt', 'Not attached')}
        evidence = self.write(evidence['path'], envelope)
        with self.assertRaisesRegex(ValueError, 'attached'):
            self.event('result', attempt_id=attempt['id'], outcome='completed', evidence_ref=evidence)


if __name__ == '__main__':
    unittest.main()
