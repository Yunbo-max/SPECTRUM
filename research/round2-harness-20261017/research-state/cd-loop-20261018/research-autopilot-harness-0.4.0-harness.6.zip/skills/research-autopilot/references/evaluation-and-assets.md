# Evaluation harness and research assets

Before blocking a stage on scorer availability/isolation, apply
[native-scoring-stages.md](native-scoring-stages.md). Restore real deferred scoring
support from the project. Independent training/export may proceed with saved
unscored artifacts; final metric claims wait for actual native scoring. No Docker
on any host. Requirements for a scorer that executes generated programs belong
to that operation, not automatically to training or prediction generation.


Before substantial method investment or a changed-condition experiment, read
[benchmark-discovery.md](benchmark-discovery.md). Prefer the original native
benchmark when it can test the prediction; otherwise actively search suitable
existing protocols/data using primary sources, Web and accessible discussion leads.
Record condition fit, strong baselines and a credible validation path before
comparative outcomes. Missing evaluation coverage is a research task, not a reason
to build the method first or silently substitute favorable datasets.


Choose evaluator and assets to answer the human's goal and frozen problem, within
P04 resources. lm-evaluation-harness and Inspect AI are adapters, not validity
certificates. Read their current actual task/config and retain its version.

## B01 Exact task and metric contract

For Work Harness, apply [B01 upstream setup](b01-upstream-setup.md). This node
configures and identifies the existing upstream assets and checks startup.
Actual scorer qualification belongs to B03 and the scoring stage; a successful
import is not a scientific score. Do not repeat source audits once the same
versions/configuration are recorded and startup evidence is available.

Freeze population, endpoint, input/output, information allowed, evaluation unit,
data/split/revision, prompt/chat template, few-shot examples, answer extraction,
normalization, scorer version, direction, aggregation and exclusions. Save
per-example outputs. Metrics with similar names can implement different tasks.

| Task | Distinctions to resolve |
|---|---|
| Multiple-choice QA | likelihood or generation; length-normalized acc vs raw acc; option ordering; letter/text parser; invalid answers |
| Short QA | exact match normalization/case/punctuation/articles; multiple references; token F1 implementation and empty answers |
| Long QA/RAG | answer correctness and citation faithfulness separately; retrieval access; rubric/judge/prompt/version; blind order and human audit |
| Math/code | final-answer parsing, symbolic tolerance or executable tests; environment/timeouts; public/hidden tests; pass@1 vs pass@k |
| Vision/segmentation | preprocessing, sample/patient grouping, IoU/Dice aggregation, prompts, thresholds and test-time information |

Record generations per example, temperature/top-p, seed policy, max tokens,
stop sequences, retries, majority/self-consistency/selection rule and compute.
A single draw, mean of draws, majority vote, best-of-k and pass@k are different
estimands. k is not a number of independent datasets. Do not compare them without
matched budgets and stated selection rules. For pass@k name the estimator and
total n/correct c; preserve all draws. Training seeds and decoding seeds differ.

Report attempted, scored, unscored and error counts, plus applicable coverage.
Under Inspect's documented policy, invalid MUT answers count incorrect, unparseable
grader verdicts are unscored, and infrastructure faults are errors. Options can
change handling; preserve effective configuration. Never silently exclude bad
model answers or score only successful infrastructure calls. Scorer error and
unscored flags may overlap other scorer outcomes; report per-scorer denominators.

## B03 Baseline and measurement qualification

Use strongest reasonable simple alternatives, not strawman prompts. Check
published evaluation scripts against the actual dataset task. Match information,
retrieval/tools, inference calls/tokens, tuning opportunities and hardware where
appropriate; disclose unmatched resources. Test the evaluator with sourced
benchmark-provided cases or traceable actual correct, incorrect and error outputs.
Never manufacture eval/scorer cases or replace the native scoring contract.
Non-evaluation software fixtures cannot qualify the grader. A broken baseline
or grader prevents a verdict.

## S01 Benchmark selection

For Work Harness, worker and reviewer apply [evidence reuse and stage dependencies](evidence-reuse-and-stage-dependencies.md). Reuse sufficient existing artifacts; resolve concrete current-stage gaps through targeted work.

At every round, use the linked reading/design record in
[literature-evidence.md](literature-evidence.md). Inspect the contents and actual
config/scorer files for every benchmark being considered, preserve the native
contract and record claim coverage and exclusions. Reuse unchanged inspected
versions; source changes and new claims require rechecking affected mappings.

Apply [research-quality-bar.md](research-quality-bar.md)'s benchmark-first
feasibility record before method investment: verify actual data/splits, native
evaluator and baseline availability, claim fit and the affordable comparison.
Missing resources remain blockers to that method recommendation. Never construct
eval/diagnostic cases or use subjective convenient examples as an eval fallback.

Make a selection matrix linking each candidate dataset to natural failure,
population, endpoint, representative conditions, development/confirmation/external
role, size, leakage risk, license and cost. Explain exclusions and what each
dataset cannot represent. Public availability alone is insufficient. Choose a
minimum decisive set before expansion; do not switch to favorable tests after
seeing results. Mechanism evaluation uses the same sourced benchmark inputs and
native scoring; never create synthetic eval cases or manipulate reference labels.

## S02 Data and split audit

Freeze dataset revision, config, split, sampling IDs and preprocessing digest.
Check cross-split duplicates/near duplicates, patient/person/task overlap, label
quality and transformation leakage. Record training/pretraining contamination as
known, tested or unknown. Restrict fit/tuning/retrieval to allowed information.
Keep development and confirmation separate; previously inspected test outcomes
remain developmental. Report filtering denominator and exclusions. Check licenses,
restricted access and privacy from actual sources; unknown is not permission.

## S03 Models and provider choices

Choose models to expose or test the mechanism, not a brand ranking. Compare
capability, modality, context, deployment, data constraints and P04 budget.
Keep model family, precise API ID/snapshot or weight revision, tokenizer/chat
template, quantization, precision, tools, decoding and access date. ChatGPT product
availability and OpenAI API availability are separate. A model switch requires
representative requalification and an explicit protocol version; no silent switch.
Proposed AI Lab roles describe configurable responsibilities, not tested superiority
or a claim that an account/endpoint is connected. No paid calls are implied.

## S04 Fair settings and tuning

For mixed scenario effects, use E04's scientific debug/tuning contract in
[development-and-execution.md](development-and-execution.md). Investigate the cause
before parameter changes; treat missing tuning as an explanation to test.
Define any scene-conditioned selection policy from development data and observable
deployment inputs, with matched baseline allowances and held-out confirmation.
Weight fine-tuning remains distinct from inference/config tuning and must respect
the project's declared scope. Preserve unsuccessful scenes and complete search cost.

Define development-only tuning ranges and budgets for each method/baseline,
selection metric and stopping rules. Resource differences must be reported and
scientifically justified. Equal parameter counts alone are not fairness. Include
modern training-free/simple alternatives when their function overlaps the method.
Avoid applying a novel module only to a weak baseline if stronger methods already
address the failure. Keep developmental and selected configurations visible.

## S05 Run manifest

The effective manifest contains project/protocol/run IDs; code/dirty-patch digest;
paper and claim versions; model/tokenizer/data revisions; sample IDs; prompts;
task/evaluator commit/config; extraction/normalization; generation and selection;
seeds; tuning provenance; precision/device placement; environment lock; hardware;
resource limits; retry/error/exclusion policy; raw logs/predictions; uncertainty
unit and aggregation; timestamps and result digests. Store secrets separately.
Retain enough to replay measured results. Documentation-only manifests are not
execution receipts. Bind the exact command and provider ID on actual execution.
