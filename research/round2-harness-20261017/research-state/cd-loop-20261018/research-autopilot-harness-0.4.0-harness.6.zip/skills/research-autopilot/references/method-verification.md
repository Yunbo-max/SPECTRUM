# Verified mathematical discovery and method evidence

**Chat RSI scope:** follow chat-execution.md for execution host, continuation
and candidate count. The current host may run authorized feasible checks; new
discovery defaults to one candidate with the recorded target_override. Local
acceptance and 20-to-15 references describe optional legacy-backend/broad-discovery
modes. Preserve the evidence requirements for the actual action and claim.

For a new or explicitly reopened **method-discovery batch**, the default order is:
**perform mathematical reasoning → about 20 justified candidates (target 20) →
screen each candidate against existing work and verify every mathematical card →
rank the pool and select the top 15 → design
code and complete experiments → verify each method's scoped outcome**.
The owner's instruction is “数学推理生成20个左右，挑选前15个，然后再设计code”.
Use the skill's [48 mathematical operations](math-operation-graph.md),
[derivation paths](math-derivation-paths.md) and [core procedure](math-analysis.md)
to construct candidates; naming a tool or adding a formula to an existing module
does not perform the reasoning.

This order governs new method investment, not all thinking. Observations can
initiate the mathematical question. Intake, paper/code reading, baseline audits,
instrument repair and clearly labelled teaching can precede it. M/R may conclude
`no_new_idea_needed`, evidence repair or writing-only work. A normal resume reuses
the qualified pool, selection and unfinished comparisons, and later rounds
converge from evidence; do not restart 20→15 on every chat turn.

In Stage 3, apply [collision-audit.md](collision-audit.md)'s candidate screen to
every justified construction, including reserves, before ranking it as a new
method or writing candidate code. Join primary-paper/full-text, actual
author/baseline GitHub and native benchmark/scorer reading; retain candidate-level
sources/locators, semantic comparison, coverage/gaps and finding/disposition.
Already-existing or functionally equivalent mechanisms become attributed
comparators/baselines subject to qualification, or are replaced by substantively
distinct justified hypotheses. Do not label them novel or fill the new-method
quota with renamed prior work. Preserve legitimate scoped non-method
contributions, historical candidates and current qualified readings. Missing
implementation/reproduction evidence stays unknown; it does not negate prior
work. The screen supplements the full collision/IPCG audit and its human `KILL`
and Parent restart rules.

## Mandatory boundaries and honest counts

Apply [workflow-harness.md](workflow-harness.md) before generation, not after
writing speculative modules or an experiment matrix. Conversation text, a desired
run count or an eight-hour request cannot supply missing derivations/reviews.
`verify_methods.py --before code --candidate METHOD_ID` fixes the required boundary
at verified selection and the selected candidate; `--before experiment-design`
requires current verified code before Local accepts the draft as executable,
and `--before dispatch` its complete verified design. Web authors complete
`generated_unexecuted` code/designs under workflow-harness.md's role contract;
it does not execute tests or pretend the acceptance boundaries passed.
Missing evidence returns a nonzero exit and preserves pending status. Each check
re-reads actual evidence; a saved green report cannot survive changed dependencies.
Other project/scientific/authority gates still apply; this is not a launch permit.

The code boundary also requires the selected candidate's current source-backed
closest-work disposition and applicable full collision/IPCG obligations. Check
these actual records alongside `verify_methods.py`; its derived mathematical or
selection flags do not automatically establish originality, coverage or priority.

Before designing new candidate code, run `verify_methods.py --require
selection_verified`. Before candidate experiment dispatch, require that
candidate's `design_verified` and the existing scientific/authority gates.
Before declaring success or failure, recompute its complete native comparison
and close E04; require `verdict_verified`. Keep the resulting report with the
batch's evidence, and report each method's current stage and blockers.
Do not author verified booleans on an IdeaAtom; the validator rejects true
self-certification. The helper derives flags from current evidence.

| Derived scope | Required evidence | Does not establish |
|---|---|---|
| `math_verified` | Actual derivation, conditions, constructed rule, distinguishing prediction/falsifier, and a pinned semantic review of each obligation | Empirical benefit, originality, or an automatically proved theorem |
| `math_pool_verified` | All target candidates have current mathematical evidence; exact duplicate constructions are rejected and semantic distinctness is reviewed | That a quota excuses weak candidates |
| `selection_verified` | The complete ranked pool, per-candidate reasons, exact top 15, pinned math cards/reviews, and selection review | Natural Gate 0/IPCG approval, code correctness or launch authority |
| `code_verified` | Selected candidate, math/selection bindings, actual code identities, derivation-to-code mapping, meaningful software logs and semantic review | Native performance or general bug freedom |
| `design_verified` | Current code, a frozen native protocol, strongest simple baseline, discriminating controls, fair information/cost, split/seeds/uncertainty, outcome rules and bounded G01 schedule review | An executed experiment or measured success |
| `results_verified` / `verdict_verified` | Complete comparison under the existing evaluator, trusted live native replay, exact versions and an E04 review; PASS/KILL alone yield a final success/failure flag | Unrestricted effectiveness or failure beyond the frozen scope |

Target **20 candidates and 15 selected**; five unselected candidates remain
reserve/history, rather than receiving candidate implementation investment now.
If only 12 sound candidates exist, report 12/20 with eight missing and at most
12/15 available; leave default selection incomplete. Do not pad with names,
parameter settings, seeds, ablations or copies of the same construction. State
the shortfall and continue the bounded mathematical investigation, or follow an
explicit changed user scope. Non-default targets require a recorded
`target_override` explaining that scope and appear in the report; this field is
not authorization or proof of user identity. The cap remains 20 active ideas.

Ranking compares consequential problem value, the derivation's operational
consequence, substantive closest-work delta, distinguishing prediction,
feasibility and total cost. Explain pairwise tradeoffs or a justified order;
do not invent scores or declare originality from algebra. Unresolved literature,
assumption and benchmark questions stay visible. Selection is not permission to
bypass Natural Gate 0, collision/IPCG, Gate A or full validation for each method.

## Candidate code-generation instructions

1. Read the selected candidate's actual math card, review, ranking and applicable
   project gates, including its current closest-work sources, locators, semantic
   comparison and disposition. Check `--before code` on real records before
   writing candidate implementation, including code delivered directly in chat.
   Reuse existing qualified code through an honest audit; do not invent a new
   discovery history.
2. Inspect the actual baseline/upstream interfaces, dependencies, input/output
   contracts and native evaluation paths. Implement the derived construction,
   including assumptions, numerical choices and result-affecting parameters.
   Map each consequential derivation step to the actual source location.
3. For an authorized complete-code request, finish the required data, inference
   or training, native evaluation and result-collection interfaces and exact run
   configuration. File names, pseudocode, empty adapters, TODOs, guessed commands
   and interfaces that only raise NotImplementedError are not complete code.
   Keep unavailable or deliberately out-of-scope paths explicit and unfinished.
4. Web reviews the generated source and supplies precise planned Local checks;
   it does not execute the code/tests. Deliver complete source and design drafts
   as `generated_unexecuted`, pinning their identities and pending acceptance.
   Apply local-code-handoff.md: include a populated project Local runbook with
   all required dataset/model/baseline/scorer download and verification commands,
   exact acceptance/run/collect commands and source/log/debug pointers, linked
   directly by README/AGENTS and the round handoff. The bundled authoring template
   or a generic test/debug promise is not the generated project's guide.
   Local performs meaningful software/semantic checks through the project
   harness, pins the tested code and retains actual logs/reviews. State which
   model/GPU or benchmark paths were not executed. Static checks support only
   their software property, not scorer qualification or method effectiveness.
5. Local recomputes `--before experiment-design` from current implementation
   evidence before accepting the complete draft for execution. Continue missing
   implementation/qualification rather than substitute a reduced experiment.
   First read the applicable AGENTS, Local runbook and linked round handoff at
   the delivered commit; follow their scoped failure/recheck instructions.
   Each role returns actual files, source identity, its completed scope and gaps,
   and delivers them through the agreed repository when authorized. Web does not
   wait for future Local tests to finish its authorized generation/delivery.
   Web GitHub code/config/design delivery goes to `main` under
   repository-round-trips.md, with an actual commit and exact-version readback;
   a feature-branch upload or unmerged PR does not finish that handoff.

## Evidence packets

Retain these as project-relative JSON/YAML records. All packet records have
`kind` and `version: "1.0.0"`; all refs have exactly `path` and the **SHA-256 of
the actual retained file bytes**. Hashes establish identity, not mathematical
truth, authentic reviewer identity or trusted chronology. Review the mathematics
itself and preserve its assumptions; where formal proof verification is required,
use the existing supported formal evaluator, not this evidence checker.

- **`method-verification-batch`**: `batch_id`, `candidates`, optional
  `pool_target`/`selection_target` (20/15 by default) and `target_override` for
  changed targets. Each candidate has a stable `candidate_id` and references
  added as work proceeds: `math_card_ref`, `math_review_ref`,
  `implementation_ref`, `code_review_ref`, `design_ref`, `design_review_ref`,
  `result_ref`, `e04_review_ref`. The batch has `selection_ref` and
  `selection_review_ref`. Empty/missing evidence stays pending; it is not a
  failed mathematical hypothesis or scientific KILL.
- **`math-card`**: `candidate_id`, `formal_object`, nonempty `operations`
  (`id` from A01–H06, actual `input`, `condition`, `condition_status` established
  or conditional, and derived `output`), `derivation_steps` (unique `id`, actual
  `statement`, mathematical `justification`), explicit nonempty `assumptions`,
  `method_expression`, `distinguishing_prediction`, `falsifier`,
  `closest_alternative`, `decisive_comparison`, and retained `source_refs` where
  sources are used. An executable objective/update/estimator/constraint/algorithm
  is appropriate; not every idea must be a new loss. Conditional reasoning is
  valid only within its stated assumptions and reviewed transition conditions.
- **`method-selection`**: `batch_id`, targets, `math_bindings` with every
  candidate's ID and current math card/review refs in batch order, a `ranking`
  containing every candidate once, and `selected_ids` equal to the ranked prefix.
  Every rank entry has `candidate_id` and `rationale` fields `problem_value`,
  `mathematical_consequence`, `closest_work_delta`, `distinguishing_prediction`,
  `feasibility_and_cost`. Explain why the selected candidates outrank reserves.
  Bind each `closest_work_delta` rationale to the candidate screen's retained
  sources and disposition; a derivation or missing upstream code is not a novelty
  finding. Preserve covered candidates outside the new-method pool as historical
  evidence/comparators and review any substantive replacement before ranking.
- **`implementation-card`**: `candidate_id`, `math_card_ref`, `selection_ref`,
  actual nonempty `code_refs`, `code_version` equal to the canonical SHA-256 of
  that ordered refs array, and separately `method_version` retaining the existing
  full `provenance_constraints.git_tree_digest` identity. Pin `source_identity_ref`
  to the actual retained source/provenance capture: its `git_tree_digest` equals
  `method_version` and its `method_code_refs` matches `code_refs`. Review this
  identity against the actual repository/source capture; the helper checks the
  retained binding, not repository authenticity. Do not relabel a method-file
  refs digest as a full Git tree. Provide complete `mapping` from each `derivation_step` to a
  member `code_ref`, meaningful `location` and `rationale`; `software_checks`
  contain actual `command` argument arrays, `status: "passed"`, matching
  `tested_code_refs` and retained `log_refs`. Include semantic interpretation
  rather than pretending a command exit proves the implementation is correct.
- **`experiment-design`**: `candidate_id`, current `math_card_ref`,
  `selection_ref`, `implementation_ref` and `protocol_ref`. Reuse the existing
  frozen `gate-a-protocol` or `full-validation-protocol`, native evaluation
  contract, uncertainty/multiplicity rules and claim scope. Its `method_version`
  remains the full Git tree version and every treatment arm's `implementation_refs` matches
  the actual method code. Do not substitute a baseline-only census or a proxy.
- **`method-result`**: `candidate_id`, current `design_ref`,
  `implementation_ref`, `protocol_ref`, `decision_ref` from the existing
  evaluator. Retain all required, failed, negative and unscored attempts and
  compare every indispensable claim/control under G01. Gate A PASS remains
  screening, not a complete method success. Full-validation PASS/KILL supports
  success/failure **under that protocol**; REVISE/INCONCLUSIVE is reported as
  such, rather than forced into a binary verdict. Missing raw outputs, unmatched
  versions or missing replay/reviews remains pending.

## Semantic review record

A **`method-review`** has `subject_id` (candidate ID, or batch ID for selection),
`scope` (`math`, `selection`, `code`, `design`, `e04`), exact `artifact_ref`,
`reviewer`, `reviewed_at` and `outcome`. Every required `checks` entry has
`status`, a substantive `rationale` describing what was checked and what supports
it, and retained `evidence_refs`. A bare checkbox or `verified: true` is
insufficient. Record unresolved conditions and limitations in the artifact and
the review. Do not fill generic rationales to obtain a green report.

Required review keys are:

| Scope | Check keys |
|---|---|
| math | `formal_object`, `operations_and_conditions`, `derivation`, `assumptions`, `method_expression`, `prediction_and_falsifier`, `closest_alternative` |
| selection | `structural_distinctness`, `all_candidates_compared`, `ranking_basis`, `top_selection` |
| code | `math_to_code`, `software_checks`, `actual_code_identity` |
| design | `native_benchmark`, `strong_simple_baseline`, `distinguishing_controls`, `fair_information_and_cost`, `splits_seeds_uncertainty`, `outcome_rules`, `bounded_schedule` |
| e04 | `execution_and_parameters`, `implementation_semantics`, `native_measurement_and_baseline`, `optimization_validity`, `confirmation_and_scope`, `complete_inventory` |

Use the existing math `closest_alternative` and selection `structural_distinctness`/
`ranking_basis` rationales and `evidence_refs` to review each candidate's
source-backed semantic comparison and disposition. These checks add no new key
or automated novelty verdict; full collision coverage and adjudication remain
separate scientific obligations.

The helper checks review coverage and bindings; semantic validity depends on
actually doing the review. It cannot detect all paraphrased duplicates, validate
arbitrary mathematics, establish priority or guarantee every chat follows it.
Do not report engineering contract fixtures as native scientific evaluation.

## Code and runner integration

```bash
python3 "$SKILL_DIR/scripts/verify_methods.py" --root "$PROJECT_DIR" --batch evidence/method-batch.json --candidate METHOD_ID --before code
python3 "$SKILL_DIR/scripts/verify_methods.py" --root "$PROJECT_DIR" --batch evidence/method-batch.json --candidate METHOD_ID --before experiment-design
python3 "$SKILL_DIR/scripts/verify_methods.py" --root "$PROJECT_DIR" --batch evidence/method-batch.json --candidate METHOD_ID --before dispatch
python3 "$SKILL_DIR/scripts/verify_methods.py" --root "$PROJECT_DIR" --batch evidence/method-batch.json --through code --require selection_verified
python3 "$SKILL_DIR/scripts/verify_methods.py" --root "$PROJECT_DIR" --batch evidence/method-batch.json --through design --candidate METHOD_ID --require design_verified
```

For **new or substantively revised candidate protocols**, add
`method_discovery: {candidate_id, batch_ref}` before freezing. `batch_ref` pins an
immutable discovery batch ending at verified code (math pool, ranking and code
receipts). The native protocol validator and its freeze/runner/evaluator callers
recheck those prerequisites and treatment/code identity; a missing or stale
declared prerequisite blocks admission. Preserve old untagged protocols as
historical evidence and do not call them compliant with the new discovery order.

A new tagged method's scientific `experiment-run-plan` additionally pins the
current complete code/design batch in `provenance.method_verification_ref`.
This is distinct from the protocol's immutable code-only discovery batch, avoiding
circular references. `run_experiments.validate_plan` and consequently the outer
local harness require current `design_verified`, matching discovery selection
and the exact design/protocol ref before any attempt or command. Code evidence
alone, an old design or explicit command authorization cannot satisfy this check.
Untagged archived protocols are not retroactively rewritten or certified; their
historical compatibility is not permission to omit discovery on a new method.
This migration is explicit, not a retroactive global schema/state change.

Avoid circular hashes: save discovery batch version D ending at code, freeze
protocol P referencing D, then save batch D+1 with design/results referencing P.
Preserve D and all old cards/files. If a method changes, create child records,
re-review affected mathematics/selection/code and freeze a new protocol. The
current design must retain the same discovery bindings as its protocol.

Final outcomes must be checked **inside the authorized evaluation host**:
call `verify_batch(root, batch)` from `verify_methods` while the existing
`_autoresearch.evaluation_runtime(...)` holds trusted live native scorer/analysis
contexts. Reuse the existing evaluator and outcome thresholds. A standalone CLI
does not install a trusted scorer or execute GPU jobs; saved PASS receipts alone
will not produce a verified final verdict there. `--require verdict_verified`
returns nonzero when the required evidence/context is unavailable.

## Resume, changes and reporting

Reuse unchanged cards, reviews, ranking and exact code/protocol versions.
Reuse current qualified candidate screens; refresh affected primary-paper,
actual GitHub and native benchmark comparisons after a substantive claim,
mechanism, assumption, information-flow or benchmark-contract revision, newly
relevant closest work or material feedback. Reassess disposition before further
candidate code and retain earlier evidence and collision history.
Changes revoke affected downstream verification; recompute the report before
planning code, dispatching experiments or presenting an outcome. Historical code
may be audited and reused after selection; do not backdate its authorship or
claim that retrospective mathematical review proves a math-first origin.
Earlier missing verification is a gap to repair, not evidence that all methods
were failures.
Anchored historical IdeaAtoms with old self-declared flags remain readable during
ledger replay; those flags produce no derived verification. They are rejected on
fresh admission. To advance such a candidate, retain the original and create a
child record without the old self-certification fields, then complete its current
math/selection/code and existing scientific obligations. Readable history is not
transparent eligibility for new code or experiments.

Report candidate counts, math-verified count, selected IDs and rank reasons,
code/design coverage, **candidate methods tested** under complete native
comparisons, verified successes/failures, REVISE/INCONCLUSIVE/pending cases and
their evidence/next checks. Asset counts, test counts, module counts and elapsed
hours remain separate. A Local cycle uses measured capacity and complete
comparisons, with soft reports and up to 24 elapsed hours under the current owner
policy; unfinished approved work carries forward, with no fixed
number of completed methods. Keep the existing scientific gates and negative
history intact.
