# Resource waiting and automatic continuation

Use [single-experiment batching](single-experiment-batching.md): one active
experiment program, sequential descending batch calibration (for example
64 → 32 → 16 → 8 → 4 → 2), preserved scientific semantics and measured useful
throughput/headroom. Queue other experiments; keep Chat within CPU/4 GB.

Apply the edition resource profile before launch. Pure ChatGPT Chat plans CPU-only
work under 4,000,000,000 total bytes, including children and margin, or the lower
observed available allocation. Local Work/Simple and main's local executor use their
actual authorized workload-target resources. The queue's admission estimate is not an OS memory
enforcement mechanism; a profile in EDITION.json is not measured capacity.

CPU utilization, RAM measured in GB, and disk space are different resources.
100% CPU utilization normally means the operating system is scheduling busy
processes; it does not by itself mean a research goal should stop. RAM exhaustion
can kill a process. Disk exhaustion can prevent saving a checkpoint. Measure the
actual execution allocation/cgroup and destination filesystem, not only host totals.

For local-control editions, separate controller resources from SSH workload
resources. Observe/admit the remote CPU/RAM/GPU workload on that actual target;
local SSH-wrapper measurements cover only the control process. Use the target's
existing scheduler/runner and real job identities. The bundled local FIFO does
not reserve remote devices or enforce remote job memory. See local-execution.md
in main/Work/Simple; Chat has no SSH workload route.

## Resource feasibility during scientific selection

Use [research-cycle.md](research-cycle.md) before substantial method development
and after consequential evidence: budget the method, strong baselines, data,
scoring and independent confirmation. Compare scientific value with complete
cost using actual project authority and measured capacity. The admission queue
below handles launch-time availability; passing it does not prove that the
complete evaluation plan is affordable or the method is scientifically useful.


## Admission before execution

For new CPU experiments and local agent commands, attach a measured `resources`
contract to the Simple task/agent command or Chat execution plan:

```json
{
  "resources": {
    "queue_dir": "/absolute/shared-host/research-resource-queue",
    "cpu_slots": 1,
    "peak_bytes": 536870912,
    "margin_bytes": 134217728,
    "min_disk_bytes": 67108864
  }
}
```

These numbers illustrate the interface, not an approved allocation or a safe
estimate for an arbitrary workload. Use a measured bounded pilot and account for
children, BLAS threads, loading, copies and output growth. Set thread counts in the
actual workload. CPU slots are cooperative scheduling reservations, not OS quotas.
The queue cannot impose a memory limit or reserve resources against outside jobs.
Existing unprofiled contracts retain legacy behavior; do not claim that installing
this version retroactively protects those jobs. Adopt the source at a quiet
boundary and add resource contracts to new versioned tasks and agent commands.

`resource_queue.py` uses a durable FIFO and a short shared lock. While driven by a live executor, every five seconds
it takes a new cgroup-aware CPU/RAM and disk observation, records the reason and
next check, and admits the oldest eligible ticket when its declared resources fit.
Repeated checks retain the same ticket; they do not increment experiment attempts,
create scientific receipts, change hypotheses, or disable the overall goal.
Full active reservations are subtracted conservatively from measured headroom;
no cache reclaim credit or predicted release is treated as available RAM.

Use the same absolute queue directory only for cooperating executors in the same
actual host/resource domain. Different Chat containers sharing a GitHub repository
do not share CPU, RAM or a queue. A host with a different domain cannot adopt an old
host's active reservations automatically. Recover the actual checkpoint and
reconcile identities before creating host-local replacements.

## Executor behavior

- Simple checks admission before `_reserve`, so waiting consumes no attempt or
  command-time reservation. `run` keeps polling `waiting_resources`; `tick` makes
  one check and must be driven by the actual running host coordinator. Agent
  commands can declare their own resources. A resource-free external model API
  must not inherit an invented local memory profile.
- Chat `execute` waits and rechecks for a bounded slice, default 30 seconds, then
  returns a nonterminal resource-wait record. Continue the same `execution_id` and
  plan digest on the next active step. The CLI accepts `--resource-wait-seconds`;
  set `resource_deadline_epoch` in the plan when the authorized wait has a deadline.
  A returned wait is not completion. The coordinator must continue calling it or
  hand it to the verified round-continuation mechanism before ending the turn.
- Native harness retains its existing per-batch resource and pool ownership
  rules; RAM admission now uses visible cgroup headroom. Its exclusive host-driver
  lock is not the shared Simple/Chat FIFO. If another native driver owns the pool,
  queue the unlaunched batch at the coordinator and recheck that pool; do not record
  a scientific failure or repeatedly create new controller attempts.

An installed skill does not create a permanent service. Keep scheduler-enabled,
coordinator-alive, task-queued, command-running and result-accepted as separate
observations. Use `round-continuation.md` to establish the real executor and next
agent turn. Preserve exact task/run IDs and the same original cumulative budget,
finite deadline and explicit user pause across waits and restarts.

The resource observer distinguishes a verified cgroup v2 hierarchy root, whose
CPU and memory limit files are not applicable, from a container namespace root
or missing/unreadable controls. Root-only omissions do not erase real descendant
or ancestor limits; unknown non-root observations continue to block admission.

## Recovery and failure boundaries

| Observation | Required response |
| --- | --- |
| Temporary CPU slot/RAM/disk contention | Keep queued, record the reason, recheck, and do independent useful work when possible. |
| Declared need exceeds observed hard capacity | Mark `needs_replan`; shrink/chunk the workload or select an authorized host. Do not retry an impossible allocation forever. |
| Unknown or unreadable resource telemetry | Keep queued and repair observation; do not infer free memory. |
| Queue/checkpoint write fails | Launch nothing. Report the persistence failure through the available channel, preserve the previous checkpoint, and retry after storage recovers. Do not claim the new state was saved. |
| Worker or acknowledgment disappears | Retain its active reservation and reconcile the original process/receipt. Heartbeat age is not proof that resources are free. |
| Explicit pause, stop, original deadline or budget | Preserve that boundary. Cancel only unlaunched queue eligibility; reconcile already dispatched work. |
| OOM after launch despite admission | Preserve the failed execution and partial outputs; inspect actual memory and revise the task profile. It is an infrastructure outcome, not evidence against the scientific hypothesis. |

Only the execution owner may transition an admitted ticket to dispatched and then
settled after verified terminal cleanup. No time-to-live releases uncertain work.
Cancellation of an unlaunched ticket is separate from killing a running command.
Never delete another project's state or files to obtain resources.

## Learn from results, not bookkeeping

Resource recovery and schema/path repairs are engineering progress. Scientific
progress must identify the uncertainty resolved by a real comparison. Before the
next hypothesis, consume the actual prior receipt and distinguish invalid execution
from evidence for or against a mechanism. State which failure mechanism motivates
the new prediction; changing a paper, formula name or parameter is insufficient.

Keep stable domain data/account/metric engines behind reusable interfaces. Each
derivation should produce a measurable differential prediction and a strong fixed
comparison. Preserve the user's overall joint target separately from a hypothesis's
attribution criteria; do not add post-hoc goal gates. Track actual candidate and
parameter selection and prior data exposure; re-splitting seen history does not
create fresh confirmation. These are research obligations, not financial-engine
features supplied by this generic plugin.

Main retains human scientific direction decisions. Auto Work, Auto Chat and Simple
choose the next in-scope scientific step themselves; routine resource rechecking
and recovery do not require a new user message.
