"""Software tests of analysis contracts, never substitute benchmark metrics."""
import copy
import unittest
from fixtures import C, sample_artifacts
try:
    import _statistical as S
except ImportError:
    S = None


class StatisticalAnalysisTests(unittest.TestCase):
    def analyze(self, values, method="normal", **overrides):
        self.assertIsNotNone(S, "Statistical analysis adapter is required")
        rule = copy.deepcopy(sample_artifacts()["gate-a-protocol"]["criteria"][0])
        rule["uncertainty"] = method
        args = dict(unit_ids=list(range(len(values))), unit_policy={"unit": "seed", "independence_justification": "Engineering independent-unit contract"})
        args.update(overrides)
        return S.analyze(values, rule, **args)

    def test_paired_t_reports_wider_small_sample_interval_than_normal(self):
        normal = self.analyze([0, .5])
        student = self.analyze([0, .5], "paired_t")
        self.assertLess(student["lower"], normal["lower"])
        self.assertGreater(student["upper"], normal["upper"])

    def test_bonferroni_widens_interval_over_declared_family(self):
        one = self.analyze([0, .5, .25])
        family = self.analyze([0, .5, .25], family_size=3, multiple_policy="bonferroni")
        self.assertLess(family["lower"], one["lower"])
        self.assertAlmostEqual(family["adjusted_confidence"], 1 - .05 / 3)

    def test_single_claim_policy_cannot_cover_multiple_tests(self):
        self.assertIsNotNone(S, "Statistical analysis adapter is required")
        with self.assertRaises(C.Failure):
            self.analyze([0, .5], family_size=2)

    def test_repeated_unit_cannot_count_as_independent_replicates(self):
        self.assertIsNotNone(S, "Statistical analysis adapter is required")
        with self.assertRaises(C.Failure):
            self.analyze([0, .5], unit_ids=["same", "same"])

    def test_external_analysis_requires_live_recompute(self):
        self.assertIsNotNone(S, "Statistical analysis adapter is required")
        with self.assertRaises(C.Failure):
            self.analyze([0, .5], "external", frozen_scope={"analysis_plan_digest": "1" * 64})

    def test_external_analysis_is_bound_to_input_and_frozen_scope(self):
        def replay(request):
            return {"input_digest": request["input_digest"], "scope_digest": request["scope_digest"],
                    "n": 2, "effect": .25, "lower": -.5, "upper": 1.0,
                    "method": "project-native-results-analysis", "software_version": "pinned"}
        result = self.analyze([0, .5], "external", frozen_scope={"analysis_plan_digest": "1" * 64}, analysis_context=replay)
        self.assertEqual(result["method"], "project-native-results-analysis")
        self.assertEqual(result["lower"], -.5)

    def test_clustered_units_require_the_external_design(self):
        self.assertIsNotNone(S, "Statistical analysis adapter is required")
        with self.assertRaises(C.Failure):
            self.analyze([0, .5], unit_policy={"unit": "task", "clustered": True, "independence_justification": "tasks in same subject"})

    def test_unavailable_external_analysis_is_a_named_blocker(self):
        def unavailable(request):
            raise RuntimeError("Engineering host unavailable")
        with self.assertRaises(C.Failure) as raised:
            self.analyze([0, .5], "external", frozen_scope={"analysis_plan_digest": "1" * 64}, analysis_context=unavailable)
        self.assertEqual(raised.exception.code, "PROJECT_ANALYSIS_REPLAY_UNAVAILABLE")

    def test_frozen_bootstrap_is_repeatable_and_not_a_point_verdict(self):
        policy = {"unit": "seed", "independence_justification": "Engineering contract only",
                  "bootstrap": {"method": "percentile", "resamples": 200, "seed": 7}}
        first = self.analyze([-.5, 0, .25, .5, 1], "bootstrap", unit_policy=policy)
        second = self.analyze([-.5, 0, .25, .5, 1], "bootstrap", unit_policy=policy)
        self.assertEqual(first, second)
        self.assertLess(first["lower"], first["upper"])


if __name__ == "__main__":
    unittest.main()
