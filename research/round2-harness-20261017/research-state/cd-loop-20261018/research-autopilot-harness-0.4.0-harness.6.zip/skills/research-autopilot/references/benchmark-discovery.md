# Find benchmarks that can test the changed condition

Use this before substantial method investment, while designing experiments and
whenever a changed condition alters what must be observed or evaluated. A method
needs a credible validation path. Resolve a missing path as research work rather
than implementing the whole method and later searching for favorable datasets.
Pure theory still has its own proof/assumption obligations; this governs empirical
claims. An early bounded probe may help assess feasibility without implying that
the full validation plan is ready.

## Start with the original benchmark

Write the original method/task, the exact changed condition, the mechanism's
prediction and what observation would distinguish it from the strongest existing
and simpler methods. Prefer the original dataset, split, scorer and protocol when
they genuinely expose that condition and discriminate the prediction. Continuity
helps comparisons; a familiar dataset alone does not establish suitability.
Check that the condition is observable/measurable and occurs with adequate coverage,
variation and sample size. Verify that labels, evaluation inputs and metrics support
the actual claim; aggregate accuracy can conceal the phenomenon of interest.

Distinguish three cases:
1. Original native benchmark already tests it: retain the standard protocol.
2. Same public data can support a justified changed-condition protocol: search for
   an existing published variant first. Define any adaptation prospectively and
   label the result as adapted; do not call it the unchanged native score.
3. The task, information, labels or data distribution must change: search afresh for
   suitable existing benchmarks/datasets and their strongest relevant baselines.
   Do not force the old dataset to answer a question it cannot identify.

## Search broadly within the selected question

Search more than the first familiar result. Use primary papers and their evaluation
sections, official benchmark/data/evaluator repositories, dataset documentation,
follow-up work and Web search. Combine the field with the new condition, task and
synonyms, and terms such as benchmark, dataset, evaluation, robustness, missing
information or distribution shift as appropriate. Follow promising citations and
compare plausible alternatives until coverage and the remaining gap are defensible;
there is no fixed dataset count or endless-search requirement.

When Xiaohongshu research is enabled and actually accessible, search text/image
discussions, questions, reproduction failures and comments for practical dataset
limitations, overlooked benchmarks and evaluation pitfalls. Skip videos/promotion,
read selected threads one at a time and retain the poster/comment/our-inference
distinction. Verify names, availability, protocols and claims against primary sources.
Discussion popularity and absence of search hits prove neither validity nor absence.
Pure Chat uses its actual accessible sources or supplied discussion exports; it does
not require a connection to a user's local MCP. Record unavailable sources explicitly
and continue independent Web/paper work without inventing access or search results.

## Keep a candidate comparison and validation path

Use the existing project experiment notes/matrix to record:

| Item | Required reasoning or evidence |
|---|---|
| Source and availability | Direct paper/official links, version, access/license, files and evaluator availability |
| Condition fit | Which new condition is present, how it is measured, coverage, confounders and what remains unknown |
| Claim fit | Prediction/falsifier, observable endpoints and whether success/failure separates rival explanations |
| Comparison | Qualified strong and simple baselines under matched information, tuning and resource rules |
| Protocol | Native or adapted, splits/leakage, units/uncertainty, scoring, labels and implementation fidelity |
| Feasibility | Whole data/baseline/method/scoring/confirmation cost within the edition's actual resource profile |
| Decision | Select, reject or investigate, with reasons recorded before comparative outcomes |

Preserve search queries, inspected candidates, rejection reasons, unresolved access
or coverage and the next action. Trace each empirical method claim to a plausible
condition, dataset/protocol, baseline and falsifiable observation. A table of names
is not proof that the files, scorer or condition work. Inspect representative data
and protocol/code, and perform an authorized bounded feasibility check when needed.
Do not execute full jobs merely to qualify an irrelevant dataset.

If no suitable existing evaluation is found, distinguish an incomplete search from
a documented coverage gap. Continue targeted search, acquisition or modeling; retain
the unvalidated claim. A custom benchmark requires substantial independent problem
value, demonstrated reuse/adaptation failure, trustworthy labels/scoring, strong
baselines and protocol review under research-cycle.md. Convenience or a desired win
does not justify inventing one. A small synthetic diagnostic remains a diagnostic.

## Freeze choices before comparative outcomes

Preserve the original results and standard-condition control when relevant. Changing
datasets, splits or conditions after seeing a failure creates an exploratory question;
record the change and require fresh confirmation for the revised claim. Report the
selected coverage including unfavorable results. A new condition can justify a new
dataset, but it cannot retrospectively justify cherry-picking. Reopen this search
when the scientific condition changes, not merely when the proposed method loses.
