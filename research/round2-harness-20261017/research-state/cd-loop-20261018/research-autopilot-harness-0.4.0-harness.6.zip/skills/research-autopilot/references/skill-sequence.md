# Program-owned execution of the existing Skill

## Work Harness C/D profile

Restore `sequence.flow_profile` before applying inherited workflow rules. For
`work-harness-cd-v1`, read [C/D mathematical diagnosis and executable idea development](cd-math-code-loop.md).
The versioned catalog `assets/skill-sequence-cd-v1.json` and its overriding node
guides govern C's condition/failure/dependency diagnosis, D's mechanism construction
and real local experiments, reviewed B/C/D revisits and M05 `VERIFIED_FOR_SCALEUP`.
B05 validates a supported problem contract; old Natural Gate 0/IPCG prerequisites
do not apply to this profile's local diagnostic/development work. Independent
verified review plus program checks advances automatically into E, which retains
full settings, freezing, fair comparisons, scale and confirmation.

The worker proposes typed revisits and code applies approved transitions; no raw
skip/jump is allowed. Preserve source/evidence lineage, failed findings, external
jobs, cumulative usage and pause state. Omitted `flow_profile` retains legacy
catalog/transition behavior. Profile-specific rules override conflicting inherited
C/D ordering/admission text below only when the profile is actually adopted.
Installation alone does not migrate a running project or change another edition.

Read this before doing any program task in the Work Harness or DSH Harness
edition. It governs step order, acceptance, repetition and completion wherever
an inherited reference says that an agent chooses the next action or round.
The scientific methods in the existing Autopilot Skill remain the methods to use.

## Restore the current step

The adopted `assets/skill-sequence.json` maps the canonical 84-node registry to
one fixed ordered inventory. The entire catalog and required module contents are
protected by the actual skill digest. Every node remains represented: an active
node requires execution and acceptance; an optional-scope node outside the user
objective is recorded inactive by program rules. An agent cannot remove a node,
change its scope, reorder it, invent an alternative catalog or mark it skipped.

The immutable schema-2 program contract supplies `sequence.mode` (`repeat` or
`once`) and `sequence.scopes`. `research` is mandatory. `manuscript`, `revision`,
`release` and `communication` are included only when the user objective authorizes
that work. Research authorization alone does not authorize drafting/submitting a
paper, releasing code, publishing a site or sending a message. Scope inactivity is
a code-determined applicability decision, not an agent's shortcut around research.

At each invocation, restore the exact sequence/cycle/current-node identity,
fixed requirements, previously accepted evidence, outstanding child tasks,
actual outputs and original remaining limits from the program handoff. The legacy
configuration key and role `planner` mean the **current-step worker**. They retain
transport compatibility; they do not grant control over the workflow cursor.

## Execute, read back and accept each active node

1. Read the current node's actual source modules and pinned inputs. Perform its
   work under the existing scientific and execution rules. Research judgment
   chooses methods within that step; program code chooses the step itself.
2. Bind every fixed requirement to real evidence at an actual path/hash. Preserve
   paper/code provenance, assumptions, method comparisons, implementation and
   observed results as required by that node. A generic summary or unchecked
   `done` statement cannot satisfy missing evidence.
3. If child work is necessary, describe only work serving the current node. Use
   the admitted execution route and wait for its real results. Process exit,
   queued jobs, a response file or a child task marked completed does not advance
   the node. Read back outputs, logs, scores and failures before proposing acceptance.
4. A separately executed reviewer evaluates the exact requirement/evidence
   bindings and result interpretation. Deterministic program checks validate
   identities, pins, coverage and applicable scientific admission. Rejection,
   repair or missing evidence keeps the cursor on the same node.
5. Only the program accepts the node and advances to the next canonical active
   node. The worker and reviewer cannot select a successor, jump to delivery,
   terminate the sequence or declare the parent goal complete.

Unchanged, valid prior evidence may be re-read and accepted where the node allows
reuse; the new step still needs its own requirement bindings and review. Do not
rerun experiments merely to produce activity, fabricate a new mechanism, or claim
all Skill steps ran because a few modules were supplied in a prompt.

## Retain the scientific research loop

Within the chosen field, carry the existing progression through the actual nodes:
read relevant papers and code; understand original computation rules; purposefully
reproduce representative strong baselines; identify a specific limitation or
changed condition; use mathematical modeling, derivation and optimization for that
question; establish a native benchmark or justified published alternative; compare
strong and simple counterfactuals under matched conditions; execute admitted work;
read the real results and negative findings; update cumulative field knowledge.

Mathematics is a tool for the concrete problem. This sequence does not replace the
scientific method with a new one, force a new architecture each cycle or turn a
failed hypothesis into automatic abandonment of the field. A missing or refuted
claim must be represented honestly. Missing evidence stays an obligation; it is
never converted to a success flag to move the cursor.

Preserve actual local/authorized SSH target identity, native scorer semantics,
strong baselines, falsifiers, full costs and independent review. No Docker. Keep
one experiment program at a time and descend supported batches while preserving
effective batch and protocol. Restore real deferred-scoring support: independent
training/export may proceed, while a claim requiring a score remains unaccepted.

## Repetition, completion and recovery belong to the program

`repeat` returns to the first active node after every active node and the
current frozen empirical matrix are accepted, with actual native verification
where applicable. Unresolved knowledge obligations and negative findings carry
forward; completing a cycle does not claim the open-ended goal is complete. The
original scope, pause state and cumulative allowances still bound each cycle.
Future experiment/scoring obligations may remain pending only when a fresh
canonical decision establishes the lead/hypothesis stage and those unfinished
obligations have no materialized task IDs. Program code retains this evidence
for independent review. All already-frozen contracts must still finish; this
rule cannot delete obligations, forgive a missing job or claim empirical success.
`once` additionally requires complete whole-goal coverage and applicable
scientific closure before the program can complete. The agent has no
`next`, `skip` or `complete` authority. An empty ready queue and positive prose
are not sequence completion. Scientific PASS remains a separate evidence claim.

Use the existing durable user pause/resume path. Exhausted limits and real
blockers are program states, not permission to skip a node. Recovery restores the
same cursor, accepted evidence, child/run identities, source pins and cumulative
usage; unknown operations require reconciliation before any retry. A live driver
must actually exist to continue after a host turn/process boundary. Stored files
alone do not schedule execution.

New programs require schema 2. A retained schema-1 program may only be restored
under its exact existing contract and source-policy identity. Do not initialize
a new schema-1 program or silently migrate a live project. Source publication,
runtime installation, project adoption and observed execution remain distinct.
