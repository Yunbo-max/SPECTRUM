# Contribution-specific value gates

Freeze a `contribution_type` in every new Parent Problem before developing a
candidate. Preserve consequential question selection, substantive originality,
and the strongest simple or known alternative on every route. A different
contribution type changes the relevant evidence; it does not remove the value
screen or lower the originality requirement. Contribution type is not a venue,
quality score, or guarantee of acceptance.

For the active Chat, use [research decisions](chat-research-decisions.md) before
substantial investment and after repeated diagnostics. Reuse these canonical
value records; do not create another pass/fail gate. First investigate whether
the nearest primary work or strongest simple control already resolves the claimed
limitation. Distinguish an unknown literature gap from verified originality.
Source acquisition, baseline qualification, mathematical counterexamples and
bounded engineering checks may obtain missing evidence before candidate admission;
they do not need an already successful final candidate. Keep their actual scope
and finite diagnostic allowance. A label such as diagnostic cannot exempt an
empirical research claim from native evaluation or justify endless nearby runs.

The existing `natural-gate-0` artifact, `record_natural_gate_0` transition, and
`natural_gate_0_*` state fields continue to carry Gate 0. Their names are retained
for compatibility. The validator dispatches from the frozen parent, never from
a requested PASS or a conveniently chosen report route.

| Frozen type | Gate 0 route | Required value evidence |
| --- | --- | --- |
| `natural_failure`, `method`, `replication_or_transfer` | `failure_census` | Captured naturally occurring failed episodes, task consequence, and unresolved strongest simple alternative. |
| `efficiency`, `systems` | `performance_frontier` | Native benchmark performance and resource evidence showing a consequential gap at the frozen quality/resource target. |
| `phenomenon` | `replicated_observations` | A native, consequence-bearing observation reproduced in at least two independently recorded eligible replications against the strongest known explanation. |
| `data` | `data_coverage` | Existing native benchmark/data coverage evidence, its published coverage definition, consequence of missing coverage, and the strongest existing alternative. |
| `theory` | `formal_obligations` | Frozen theorem statements/definitions, checked proof obligations, consequential mathematical implications, and formal comparisons with the closest and strongest known theorem. |

Changing type, population, endpoint, or scientific problem requires an explicit
restart and a new parent with lineage. A non-method contribution can legitimately
need no new method. An equivalent theorem, a cheaper implementation without a
consequential frontier gap, an unreplicated phenomenon, or another dataset with
adequate existing coverage cannot pass by changing its label.
Conversely, do not force a new method when the authorized contribution is a useful
replication, valid negative result, phenomenon or theory. An investment decision
can retire a redundant hypothesis while preserving its evidence and other goal
obligations. Reopen a refuted family only for new evidence or a substantive change
addressing the failed prediction, not another seed or renamed parameter.

## Parent contracts

Keep the six parent fields and `simple_alternatives`, including
`strong_simple_alternative`. For non-failure contributions, `natural_failure`
names the real unresolved limitation or contradiction; it does not assert that
the project has naturally failed agent episodes. `population` and `prevalence`
describe the relevant observation/domain coverage and denominator. State the
actual scientific consequence and falsifiable prediction.

Empirical parents retain `benchmark_contract`. It binds `benchmark_id`, `version`,
`evaluation_split`, `primary_metric`, resource constraints, and captured published
sources. Numeric routes also bind `scorer_identity` and `scorer_revision`.
Every scientific evaluation at every stage uses existing published native data,
splits, metrics, and official evaluation code or a verified faithful harness.
Diagnostics and controls do not create an exception. Reduce run size within the
existing protocol; never handcraft research cases, a benchmark, or a scorer.

The contextual failure census remains the existing value screen in
[importance-preserving-gate.md](importance-preserving-gate.md). It does not certify
official evaluation or a method effect. Benchmark identity and retained episode
records alone do not prove native sample/scoring origin. Any quantitative
evaluation claim additionally needs the native evaluator receipts.

Other parents carry `value_gate` with `route`, nonempty retained `evidence_refs`,
and exactly the following positive project-specific thresholds:

| Route | Frozen thresholds |
| --- | --- |
| `performance_frontier` | `min_observations`, `min_mean_resource_gap`, `max_quality_shortfall`, `min_mean_consequence`, `min_unresolved_fraction` |
| `replicated_observations` | `min_observations`, `min_independent_replications`, `min_mean_effect`, `min_mean_consequence`, `min_unresolved_fraction` |
| `data_coverage` | `min_observations`, `min_coverage_gap`, `min_mean_consequence`, `min_unresolved_fraction` |
| `formal_obligations` | `min_obligations`, `min_strict_improvements`, `min_consequential_obligations` |

Counts are positive integers; independent replication count is at least two.
Fractions lie in `(0,1]`; consequence/effect/resource-gap thresholds are positive.
Only `max_quality_shortfall` can be zero. Explain why thresholds are scientifically
meaningful; the helper validates their structure, not that judgment.

Frontier parents additionally freeze `resource_metric`, `required_quality`, and
`effect_direction` (`maximize` or `minimize`) in `value_gate`. The resource limit
comes from `benchmark_contract.resource_constraints[resource_metric]`.
Phenomenon parents freeze `effect_direction`. Data parents require
`value_gate.coverage_definition_ref`: a retained primary capture in
`native-coverage-definition-v1` format with benchmark identity, `coverage_meaning`,
`source_url`, published `source_evidence_refs`, and the published native
`qualification: {role, rule}`. It must match the existing native evaluator rule.
Do not relabel model accuracy or a failing control as dataset coverage without
a published coverage definition. Unsupported coverage designs need a suitable
existing native evaluator/adapter before the check can proceed.

Pure theory needs no empirical benchmark. Replace `benchmark_contract` and the
failure-count thresholds with `formal_contract`: `formal_system`,
`definitions_ref`, `theorem_statement_ref`, `obligation_ids`,
`closest_theorem_work_refs`, `strongest_known_alternative_work_ref`, and positive
`review_max_age_seconds`. Read the compared primary theorem records at D2/D3.
Include the strongest known theorem among the closest works. With several
obligations, freeze `obligation_statement_refs` keyed by every obligation ID;
with one obligation its statement defaults to the frozen theorem statement.

## Native numeric observations

A numeric raw capture has `sampling_kind` matching the route, `observations`,
the frozen `benchmark_id`, `benchmark_version`, `evaluation_split`,
`primary_metric`, `scorer_identity`, `scorer_revision`, and nonempty
`native_output_refs`, `native_eval_receipt_refs`, `native_protocol_ref`,
`native_run_manifest_refs`. The native protocol retains the full existing
`native_eval_contract`; see [native-evaluation.md](native-evaluation.md).

Every observation has a unique `observation_id`, parent `population_id`,
`endpoint`, `strong_simple_alternative`, native `downstream_loss`, boolean
`alternative_solves`, and `source_ref`. The retained source equals the observation
without `source_ref`. Additional measurements are:

| Route | Additional fields |
| --- | --- |
| Frontier | Nonnegative `resource`, positive frozen `resource_limit`, and native `quality`. |
| Phenomenon | Native `observed_metric`, native `reference_metric`, and a retained `replication_id`. |
| Data | Boolean `covered` bound to the published native coverage rule. |

The generic native adapter binds all measured fields through
`measurement_bindings`. A binding uses `run_id` and one of:

- `kind: metric`, `arm_role`, `metric`: an actual native metric. Quality/phenomenon
  metrics must be the frozen primary metric; loss must be the frozen endpoint.
- `kind: resource`, `arm_role`, `metric`: the native receipt's retained resource
  measurement selected by the frozen resource metric.
- `kind: qualification`, `role`: a qualification recomputed under an existing
  native rule. `alternative_solves` must select the strongest baseline;
  `covered` must select the frozen published coverage qualification.

This adapter supports run-level observations whose ID equals the native run ID.
Phenomenon replication IDs match those runs and require distinct seed/group
records. Other sampling/replication designs need their native source-backed
adapter and scientific independence analysis; different strings alone do not
establish independence.

The screen recomputes mean loss and unresolved fraction. Frontier resource gap
is `max(0, resource-limit)/limit`; every observation must meet the frozen quality
tolerance. Phenomenon effect is the signed native primary-metric difference.
Data coverage gap is the uncovered fraction in the explicitly scoped native
observation denominator. These are value summaries of native evidence, not
replacement scientific scoring functions or population-level estimators.

## Formal observations

The raw capture has `sampling_kind: formal_obligations`, matching `formal_system`,
and `obligations` covering exactly the frozen IDs. Every obligation retains its
frozen `statement_ref`, actual `proof_ref`, `review_ref`, `comparison_ref`, and
`consequence_ref`. A `proved: true` declaration has no evidential force.

A proof-assistant review binds obligation ID, formal system, statement/proof
SHA-256 digests, `checked_at`, checker version, command, and `checker_output_ref`.
The output repeats the same binding, exit code zero, no unresolved goals, and
no admitted axioms. An independent formal review instead retains its reviewer
role, independence, primary evidence, proved conclusion, no unresolved obligations,
and no admitted axioms. Review age is checked against the report's retained
`evaluated_at` and frozen maximum age.

The formal comparison binds the obligation, strongest known alternative, closest
theorem reference, comparison proof, and its review. The supported relations are
`strict_strengthening`, `assumption_removal`, `tight_bound`, `separation`,
`equivalent`, and `weaker`. An equivalent/weaker result supplies no strict
improvement. The comparison currently shares the obligation proof and review;
another proof structure needs a supported formal adapter. Consequence evidence
binds the parent endpoint and retains `scientific_implication`, `justification`,
and primary evidence. A name or boolean cannot replace either proof or consequence.

## Live validation and historical replay

New numeric records require a callable trusted `value_gate_validator`, or the
generic `native_value_gate_validator` with a live native scorer context. New formal
records require a callable trusted `formal_review_validator`. Missing adapters or
missing evidence produce named INCONCLUSIVE blockers. Actual sample correctness,
resource accounting, mathematical validity, and consequential originality require
the appropriate trusted execution/review; this skill is not a proof solver or
scientific importance oracle.
Software tests and complete record fields demonstrate only their tested record
and execution properties. Scientific value, baseline strength and prior-art
coverage need substantive review with actual source evidence and reviewer
identities; a self-authored independent flag is insufficient.

Before recording a gate, retain an attestation and bind its ref in the raw capture:
`native_eval_attestation_ref` for numeric routes or `formal_review_attestation_ref`
for theory. The capture format is respectively `value-gate-attestation-v1` or
`formal-review-attestation-v1`. Both bind `parent_problem_sha256`,
`observations_digest` (canonical hash of raw capture without its attestation ref),
`status: verified`, and all used immutable `proof_refs`. Numeric attestations
retain verified `observations`; formal attestations retain sorted `obligation_ids`.

Live callbacks return `status`, the same `attestation_ref`, the exact retained
`proof_refs`, and the verified observations/obligation IDs. Their signatures are
`value_gate_validator(root, card, raw)` and
`formal_review_validator(root, card, raw, report)`. Stored flags or a non-callable
object cannot authorize a new PASS. Historical event replay rechecks retained
attestation/input/evidence bindings without running the scorer or proof checker
again. Historical mode is an internal replay path, not a new-record approval.

All artifact schema versions remain `1.0.0` with additive fields. Legacy parents
without `contribution_type` replay under the original failure-census semantics;
they provide no native-evaluation or formal-proof attestation. New parent freezes
must choose a type. Gate 0 PASS preserves the separate collision/IPCG, Gate A,
full validation, and claim closure requirements. The paired scalar evaluator
cannot certify a theorem; pure-theory Gate A/full validation needs a supported
formal evaluator and must otherwise remain blocked.
