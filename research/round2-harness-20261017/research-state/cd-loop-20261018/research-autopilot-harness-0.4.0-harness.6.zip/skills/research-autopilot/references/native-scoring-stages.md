# Native scoring and stage-specific readiness

Training, prediction generation/export and final scoring are distinct executable
stages. Apply readiness requirements to the stage that actually consumes them.
All editions and hosts use native execution: no Docker, Compose, Docker-in-Docker
or hidden container helper for training, generation, scoring or verification.

## Restore the project's actual scoring mode first

Read the pinned project README/runbook, configuration, CLI and implementation to
find its existing deferred/offline scoring or prediction-export route. Verify what
the mode actually skips and which artifacts it writes; reuse the existing choice
and authorization. Do not invent a universal `--defer-scoring` flag or assume every
project exposes the same mode. Inspect transitive helpers so a deferred/native
path does not import or launch Docker during setup or after training.

When the project supports delayed scoring, use its real train/generate/export
path, retain the outputs and schedule native scoring separately. If scoring is
unnecessarily coupled to a standalone training/export path, make a scoped change
to that project's stage selection/configuration after reading the real entry points;
preserve the scientific algorithm and output contract. Do not delete metric
computation, substitute a score, or label a placeholder evaluator as qualified.

## Determine which dependency belongs to which stage

| Stage | Required for this stage | Requirement that must not be inherited automatically |
|---|---|---|
| Training without evaluator feedback | Authorized target, code/data/environment, actual training dependencies, finite budget and checkpoint/export plan | Availability or isolation of an independent final scorer |
| Prediction generation/export | Selected model/checkpoint, inputs, decoding config, output IDs/schema and resource envelope | A final scorer that consumes these saved predictions later |
| Offline native scoring | Frozen predictions/labels/tests, exact scorer code/interpreter, runtime needs of this scorer and actual output receipt | Docker just because an upstream example uses it |
| Result verification/reporting | Required real scores, denominator/case accounting, failed/unscored inventory, relevant replay/controls | A training success or export file is not a measured score |

If a score supplies a training reward, gradient, online filter, early-stopping or
checkpoint-selection decision, it is a genuine dependency of that stage. Inspect
the code to locate the dependency; preserve it or explicitly redesign the affected
protocol within the existing authority. Do not silently disable feedback and call
the run the same training method. Independent final scoring can still be deferred.

## Use the actual native scorer

Prefer the published official Python/binary/library entry point in the target's
qualified Conda/venv/system environment. Read a Dockerfile only to recover genuine
dependencies, then inspect the native entry points and helper calls. Preserve task,
data/split, sample IDs, tests/labels, metric, denominator, sampling and timeout rules.
Changing the launcher to a faithful native route does not authorize changing the
benchmark or reporting a different metric under its name. Pin revised native argv,
interpreter, dependencies and scorer source; do not keep a stale Docker command in
an otherwise 'native' plan or mutate an existing frozen run receipt.

The bundled `run_experiments.py` already offers native subprocess execution and
`build_official_replay_context(...)` for pinned scorer replay. `_native_eval.verify_run`
consumes real scoring/replay evidence; it is a result-verification step, not an
instruction to run the final scorer before independent training starts. Protocol
and source-contract checks still apply at the relevant scientific admission boundary.
Do not relabel research as an engineering run to bypass those contracts. If a
project's existing phase-capable executor supplies the unscored artifacts, preserve
its real receipts and pending verification rather than inventing helper support.

Native tasks that only compare saved numeric/text predictions do not acquire a
generated-program execution requirement by analogy with a coding benchmark. When
a scorer actually executes generated programs, identify that concrete operation
and any required native OS isolation. Conda is dependency management, not an OS
sandbox. Missing capability holds that scoring operation; it does not by itself
hold independent training/generation. Never convert this distinction into running
unreviewed generated programs without their required controls.

## Preserve an honest pending-scoring handoff

For delayed scoring retain the run/job and host, code/model/checkpoint/config pin,
dataset/split/case IDs and sample order, seeds/decoding settings, prediction format,
artifact paths and hashes, failures, observed usage, intended native scorer and
the next scoring action. Keep all selected cases, including missing/failed outputs.
Use existing project/runner fields and accepted artifact types; a note that scoring
is pending is not a new supported CLI state or permission to patch old receipts.

Report training, export and scoring readiness separately. An unscored artifact has
no invented zero, success or official score. Reserve the remaining scoring cost
within the cumulative budget. On resume, locate and verify existing outputs before
rerunning training. Score them through the qualified native route, save actual logs
and metric/case receipts, then perform the claim's remaining checks. A training run
may finish while the empirical claim remains pending; neither state erases the other.
