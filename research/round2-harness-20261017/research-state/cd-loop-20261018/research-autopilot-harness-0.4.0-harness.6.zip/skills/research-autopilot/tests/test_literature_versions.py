"""Engineering identity/replay contracts; these fixtures make no research claim."""
import copy
import importlib
import importlib.util
import unittest
from fixtures import C, ProjectFixture, sample_artifacts, write


class LiteratureVersionTests(unittest.TestCase):
    def setUp(self):
        self.f = ProjectFixture()
        self.addCleanup(self.f.close)

    def literature(self):
        self.assertIsNotNone(importlib.util.find_spec("_literature"),
                             "Canonical work/version mapping is not implemented")
        return importlib.import_module("_literature")

    def work(self, work_id, version="v1", **fields):
        record = copy.deepcopy(sample_artifacts()["work-record"])
        record.update(work_id=work_id, version=version, evidence_refs=[self.f.source], **fields)
        return record

    def linked(self):
        assertion = {"capture_format":"work-identity-link-v1", "relation":"same_work",
                     "identifiers":["arxiv:2401.00001", "doi:10.1234/example"],
                     "primary_source":True, "source_url":"https://arxiv.org/abs/2401.00001",
                     "locator":"DOI field", "excerpt":"The published version of this work is doi:10.1234/example"}
        source = write(self.f.root, "evidence/identity.json", assertion)
        link = {"from_id":"arxiv:2401.00001", "to_id":"doi:10.1234/example",
                "relation":"same_work", "evidence_refs":[source]}
        return [self.work("arxiv:2401.00001", identity_links=[link]),
                self.work("doi:10.1234/example", version="published")], source

    def test_arxiv_versions_share_one_work_but_keep_distinct_versions(self):
        result = self.literature().canonicalize_search_records(self.f.root, [
            self.work("arxiv:2401.00001v1", "v1"), self.work("arxiv:2401.00001v2", "v2")])
        self.assertEqual(result["work_ids"], ["arxiv:2401.00001"])
        self.assertEqual(result["version_ids"], ["arxiv:2401.00001v1", "arxiv:2401.00001v2"])
        self.assertEqual(len(result["works"]), 2)

    def test_equal_titles_do_not_link_arxiv_and_published_records(self):
        result = self.literature().canonicalize_search_records(self.f.root, [
            self.work("arxiv:2401.00001"), self.work("doi:10.1234/example", "published")])
        self.assertEqual(result["work_ids"], ["arxiv:2401.00001", "doi:10.1234/example"])

    def test_primary_identity_capture_links_arxiv_and_publication(self):
        records, source = self.linked()
        result = self.literature().canonicalize_search_records(self.f.root, records)
        self.assertEqual(result["work_ids"], ["doi:10.1234/example"])
        self.assertEqual(result["identity_evidence_refs"], [source])
        self.assertEqual(self.literature().canonical_work_id(self.f.root, "arxiv:2401.00001v2", records),
                         "doi:10.1234/example")

    def test_declared_alias_without_link_evidence_remains_unresolved(self):
        record = self.work("arxiv:2401.00001", identity_aliases=["doi:10.1234/example"])
        result = self.literature().canonicalize_search_records(self.f.root, [record])
        self.assertEqual(result["work_ids"], ["arxiv:2401.00001"])
        self.assertEqual(result["works"][0]["unresolved_aliases"], ["doi:10.1234/example"])

    def test_generic_source_cannot_certify_same_work_identity(self):
        record = self.work("arxiv:2401.00001", identity_links=[{
            "from_id":"arxiv:2401.00001", "to_id":"doi:10.1234/example",
            "relation":"same_work", "evidence_refs":[self.f.source]}])
        with self.assertRaises(C.Failure):
            self.literature().canonicalize_search_records(self.f.root, [record])

    def test_read_depth_does_not_promote_publication_or_reproduction_status(self):
        result = self.literature().canonicalize_search_records(self.f.root, [
            self.work("doi:10.1234/example", read_depth="D3")])
        version = result["works"][0]
        self.assertEqual(version["read_depth"], "D3")
        self.assertEqual(version["publication_status"], "unknown")
        self.assertEqual(version["reproduction_status"], "unknown")

    def test_publication_and_preprint_keep_their_own_evidence_depth(self):
        records, _ = self.linked()
        records[0].update(read_depth="D2", publication_status="preprint", reproduction_status="not_attempted")
        records[1].update(read_depth="D0", full_text_status="unread", evidence_refs=[],
                          publication_status="formally_published", reproduction_status="not_attempted")
        result = self.literature().canonicalize_search_records(self.f.root, records)
        self.assertEqual(result["d2_work_ids"], ["doi:10.1234/example"])
        published = next(w for w in result["works"] if w["publication_status"] == "formally_published")
        self.assertEqual(published["read_depth"], "D0")
        self.assertEqual(published["full_text_status"], "unread")

    def test_identity_evidence_mutation_is_detected(self):
        records, source = self.linked()
        self.literature().canonicalize_search_records(self.f.root, records)
        write(self.f.root, source["path"], {"changed":True})
        with self.assertRaises(C.Failure):
            self.literature().canonicalize_search_records(self.f.root, records)


if __name__ == "__main__":
    unittest.main()
