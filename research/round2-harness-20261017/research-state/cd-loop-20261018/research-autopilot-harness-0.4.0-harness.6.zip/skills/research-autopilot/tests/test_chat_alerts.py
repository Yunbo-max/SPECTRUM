"""Incident durability, reporting failures and delivery claims; no network sends."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import redirect_stderr
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts/chat_alerts.py'
SPEC = importlib.util.spec_from_file_location('chat_alerts_test_module', SCRIPT)
A = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(A)


class ChatAlertsTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.arguments = dict(category='cpu_unavailable', source='host_preflight',
                              scope='project-1', summary='Python CPU tool unavailable',
                              next_action='Report blocked computation and continue literature review')

    def write(self, path, value):
        target = self.root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(value if isinstance(value, str) else json.dumps(value), encoding='utf-8')
        return dict(path=path, sha256=hashlib.sha256(target.read_bytes()).hexdigest())

    def report(self, **changes):
        return A.report(self.root, **dict(self.arguments, **changes))

    def receipt(self, incident, **changes):
        value = dict(kind='chat-alert-delivery', status='delivered',
                     incident_id=incident['incident_id'], version=incident['version'],
                     channel='test-provider', destination='test-owner', provider_operation_id='test-operation',
                     execution_ref=self.write('delivery-observation.txt', 'Synthetic provider receipt for engineering test'))
        value.update(changes)
        return self.write('receipt.json', value)

    def test_local_report_is_pending_and_survives_reload(self):
        canonical = self.write('checkpoint.json', {'budget': 10, 'science': 'pending'})
        result = self.report()
        self.assertEqual(result['notification_status'], 'pending')
        self.assertEqual(A.read(self.root, result['incident_id']), result)
        self.assertEqual(A.pending(self.root), [result])
        self.assertEqual(hashlib.sha256((self.root / canonical['path']).read_bytes()).hexdigest(), canonical['sha256'])

    def test_identical_repeats_increment_occurrences_without_notification_version(self):
        first = self.report()
        second = self.report()
        self.assertEqual(first['incident_id'], second['incident_id'])
        self.assertEqual(second['occurrences'], 2)
        self.assertEqual(second['version'], 1)
        self.assertEqual(len(A.pending(self.root)), 1)

    def test_immutable_observation_replay_does_not_inflate_fault_count(self):
        first = self.report(observation_id='immutable-observation-1')
        for _ in range(3):
            replay = self.report(observation_id='immutable-observation-1')
        self.assertEqual(replay['occurrences'], 1)
        self.assertEqual(replay['version'], 1)
        distinct = self.report(observation_id='immutable-observation-2')
        self.assertEqual(distinct['occurrences'], 2)
        self.assertEqual(distinct['version'], 1)
        changed = self.report(observation_id='immutable-observation-2', next_action='CPU quota confirmed; wait')
        self.assertEqual(changed['occurrences'], 3)
        self.assertEqual(changed['version'], 2)

    def test_material_observation_reopens_notification_with_history(self):
        first = self.report()
        receipt = self.receipt(first)
        A.delivery(self.root, first['incident_id'], 1, 'delivered', receipt_ref=receipt)
        self.assertEqual(self.report()['notification_status'], 'delivered')
        changed = self.report(next_action='CPU quota confirmed exhausted; wait for real reset')
        self.assertEqual(changed['version'], 2)
        self.assertEqual(changed['notification_status'], 'pending')
        self.assertEqual(changed['history'][0]['notification_status'], 'delivered')
        with self.assertRaisesRegex(ValueError, 'stale'):
            A.delivery(self.root, changed['incident_id'], 1, 'delivered', receipt_ref=receipt)

    def test_real_evidence_refs_are_required_and_not_raw_log_text(self):
        ref = self.write('preflight.txt', 'Private raw observation stays in evidence file')
        result = self.report(evidence_refs=[ref])
        self.assertEqual(result['evidence_refs'], [ref])
        self.assertNotIn('Private raw observation', json.dumps(result))
        (self.root / ref['path']).write_text('changed')
        with self.assertRaisesRegex(ValueError, 'hash mismatch'):
            self.report(evidence_refs=[ref])
        self.assertEqual(A.read(self.root, result['incident_id'])['occurrences'], 1)

    def test_delivery_failure_unknown_and_unavailable_remain_visible(self):
        result = self.report()
        for status in ('failed', 'unknown', 'unavailable'):
            observed = A.delivery(self.root, result['incident_id'], 1, status, detail='Actual adapter observation')
            self.assertEqual(observed['notification_status'], status)
            self.assertEqual(len(A.pending(self.root)), 1)
        self.assertEqual(len(observed['delivery_attempts']), 3)

    def test_delivered_requires_current_bound_receipt_and_existing_execution(self):
        result = self.report()
        for changes in ({'version': 2}, {'incident_id': 'another'}, {'status': 'queued'},
                        {'provider_operation_id': ''}, {'execution_ref': {'path': 'missing', 'sha256': '0' * 64}}):
            with self.subTest(changes=changes):
                ref = self.receipt(result, **changes)
                with self.assertRaises((ValueError, FileNotFoundError)):
                    A.delivery(self.root, result['incident_id'], 1, 'delivered', receipt_ref=ref)
        with self.assertRaises(ValueError):
            A.delivery(self.root, result['incident_id'], 1, 'delivered')
        ref = self.receipt(result)
        delivered = A.delivery(self.root, result['incident_id'], 1, 'delivered', receipt_ref=ref)
        self.assertEqual(delivered['notification_status'], 'delivered')
        self.assertEqual(A.pending(self.root), [])
        self.assertEqual(A.delivery(self.root, result['incident_id'], 1, 'delivered', receipt_ref=ref), delivered)
        with self.assertRaisesRegex(ValueError, 'downgraded'):
            A.delivery(self.root, result['incident_id'], 1, 'failed', detail='later error')

    def test_recovery_is_a_new_pending_notification_and_recurrence_reopens(self):
        result = self.report(observation_id='immutable-receipt-1')
        arguments = dict(summary='CPU smoke test succeeded', next_action='Resume authorized compute',
                         evidence_refs=[self.write('cpu-test.json', {'returncode': 0})])
        recovered = A.resolve(self.root, result['incident_id'], **arguments)
        self.assertEqual((recovered['version'], recovered['lifecycle'], recovered['notification_status']),
                         (2, 'resolved', 'pending'))
        self.assertEqual(A.resolve(self.root, result['incident_id'], **arguments)['version'], 2)
        reread = self.report(observation_id='immutable-receipt-1')
        self.assertEqual((reread['version'], reread['lifecycle']), (2, 'resolved'))
        reopened = self.report(observation_id='immutable-receipt-2')
        self.assertEqual((reopened['version'], reopened['lifecycle']), (3, 'open'))
        self.assertNotIn('recovery', reopened)
        with self.assertRaisesRegex(ValueError, 'evidence'):
            A.resolve(self.root, result['incident_id'], **dict(arguments, evidence_refs=[]))

    def test_same_controller_error_after_delivered_recovery_is_reported_again(self):
        result = self.report()
        recovered = A.resolve(self.root, result['incident_id'], summary='CPU smoke test succeeded',
                              next_action='Resume compute', evidence_refs=[self.write('recovery.txt', 'test success')])
        receipt = self.receipt(recovered)
        A.delivery(self.root, result['incident_id'], 2, 'delivered', receipt_ref=receipt)
        self.assertEqual(A.pending(self.root), [])
        recurrence = self.report()
        self.assertEqual((recurrence['version'], recurrence['lifecycle'], recurrence['notification_status']),
                         (3, 'open', 'pending'))
        self.assertEqual(len(A.pending(self.root)), 1)

    def test_held_outbox_lock_has_bounded_unsaved_fallback(self):
        self.report()
        captured = io.StringIO()
        with (self.root / 'runs/chat-alerts/outbox.lock').open('a') as held:
            A.fcntl.flock(held, A.fcntl.LOCK_EX)
            start = time.monotonic()
            with patch.object(A, 'LOCK_TIMEOUT_SECONDS', 0.03), redirect_stderr(captured):
                result = A.safe_report(self.root, **self.arguments)
            elapsed = time.monotonic() - start
        self.assertLess(elapsed, 0.5)
        self.assertEqual(result['notification_status'], 'unsaved')
        self.assertIn('TimeoutError', result['storage_error'])
        self.assertEqual(json.loads(captured.getvalue()), result)
        self.assertEqual(A.pending(self.root)[0]['occurrences'], 1)

    def test_safe_report_storage_failure_does_not_replace_original_error(self):
        captured = io.StringIO()
        original = RuntimeError('Original compute failure')
        with redirect_stderr(captured), patch.object(A, '_edit', side_effect=OSError('disk full token=secretvalue')):
            try:
                raise original
            except RuntimeError as observed:
                result = A.safe_report(self.root, **self.arguments)
                self.assertIs(observed, original)
        self.assertFalse(result['stored'])
        self.assertEqual(result['notification_status'], 'unsaved')
        self.assertEqual(json.loads(captured.getvalue()), result)
        self.assertNotIn('secretvalue', captured.getvalue())

    def test_safe_report_survives_failed_stderr(self):
        with patch.object(A, '_edit', side_effect=OSError('disk full')), patch.object(A.sys, 'stderr') as stream:
            stream.write.side_effect = OSError('broken pipe')
            self.assertFalse(A.safe_report(self.root, **self.arguments)['stored'])

    def test_credentials_redacted_in_summary_action_and_delivery_details(self):
        result = self.report(summary='token=verysecret Authorization: Bearer abcdefghi https://user:pass@host sk-abcdefgh123456',
                             next_action='password=secretpass api_key=secretkey hf_abcdefgh123456')
        result = A.delivery(self.root, result['incident_id'], 1, 'failed', detail='Bearer secrettokenvalue')
        serialized = json.dumps(result)
        for secret in ('verysecret', 'abcdefghi', 'user:pass', 'secretpass', 'secretkey', 'secrettokenvalue'):
            self.assertNotIn(secret, serialized)
        value = A.redact('AWS_SECRET_ACCESS_KEY=awssecret client_secret="space containing value" {"password":"some phrase"}')
        for secret in ('awssecret', 'containing', 'phrase'):
            self.assertNotIn(secret, value)
        value = A.redact('Failed https://bucket/file?X-Amz-Signature=aws-signed-secret&Expires=42 and https://azure/blob?sv=v1&sig=azure-signed-secret')
        for secret in ('aws-signed-secret', 'azure-signed-secret', 'Expires=42', 'sv=v1'):
            self.assertNotIn(secret, value)
        self.assertEqual(value.count('?[REDACTED]'), 2)

    def test_concurrent_reporters_do_not_lose_occurrences(self):
        with ThreadPoolExecutor(max_workers=6) as workers:
            results = list(workers.map(lambda _: self.report(), range(30)))
        incident = A.read(self.root, results[0]['incident_id'])
        self.assertEqual(incident['occurrences'], 30)
        self.assertEqual(len(A.read(self.root)['incidents']), 1)
        self.assertEqual(incident['version'], 1)

    def test_corrupt_outbox_is_not_overwritten_and_failure_is_visible(self):
        self.report()
        path = self.root / 'runs/chat-alerts/outbox.json'
        path.write_text('corrupt original')
        with redirect_stderr(io.StringIO()):
            result = A.safe_report(self.root, **self.arguments)
        self.assertEqual(result['notification_status'], 'unsaved')
        self.assertEqual(path.read_text(), 'corrupt original')

    def test_cli_reports_and_lists_outbox(self):
        args = self.write('incident.json', self.arguments)
        completed = subprocess.run([sys.executable, str(SCRIPT), 'report', str(self.root), '--record', str(self.root / args['path'])],
                                   capture_output=True, text=True, check=True)
        reported = json.loads(completed.stdout)
        output = subprocess.run([sys.executable, str(SCRIPT), 'pending', str(self.root)], capture_output=True, text=True, check=True)
        self.assertEqual(json.loads(output.stdout), [reported])


if __name__ == '__main__':
    unittest.main()
