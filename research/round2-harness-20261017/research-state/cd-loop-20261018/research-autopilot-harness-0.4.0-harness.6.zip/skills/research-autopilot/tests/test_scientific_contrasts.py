"""Engineering regression fixtures, never scientific benchmark evidence.

The native replay double deliberately returns fixed fixture outputs. These tests
exercise contrast/scope admission and binding, not any real method's efficacy.
"""
import copy
import unittest

from fixtures import C, ProjectFixture, write
from test_native_eval import trusted_engineering_replay
from _native_eval import criterion_contrast
from _statistical import validate_inference
from _writing import validate_claim_cards


class ScientificContrastTests(unittest.TestCase):
    def setUp(self):
        self.f = ProjectFixture()
        self.addCleanup(self.f.close)
        self.p = self.f.protocol("full-validation")
        self.live = trusted_engineering_replay(self.f.root)

    def evaluate(self, *, arms=None):
        self.p["protocol_digest"] = C.protocol_hash(self.p)
        manifests, refs = [], []
        for group in self.p["required_groups"]:
            rows, row_refs = self.f.runs(self.p, group=group)
            for row, row_ref in zip(rows, row_refs):
                for role, metric_values in (arms or {}).items():
                    receipt_ref = row["native_eval_receipts"][role]
                    receipt = C.load_file(C.verify_ref(self.f.root, receipt_ref))
                    output = C.load_file(C.verify_ref(self.f.root, receipt["native_output_ref"]))
                    output["native_metrics"].update(metric_values)
                    output_ref = write(self.f.root, receipt["native_output_ref"]["path"], output)
                    receipt["native_metrics"].update(metric_values)
                    receipt["native_output_ref"] = output_ref
                    receipt["raw_output_refs"][0] = output_ref
                    row["native_eval_receipts"][role] = write(self.f.root, receipt_ref["path"], receipt)
                manifests.append(row)
                refs.append(write(self.f.root, row_ref["path"], row))
        return C.evaluate(self.f.root, self.p, manifests, refs, "full-validation", replay_context=self.live)

    def permissive_shuffled_qualification(self):
        for rule in self.p["native_eval_contract"]["control_qualifications"]:
            if rule["role"] == "shuffled":
                rule.update(operator="ge", threshold=0)

    def test_ablation_contrast_does_not_pass_when_ablation_equals_full_method(self):
        self.permissive_shuffled_qualification()
        self.p["criteria"][0]["contrast"] = {"weights": {"treatment": 1, "shuffled": -1}}
        decision = self.evaluate(arms={"shuffled": {"accuracy": 0.75}})
        self.assertEqual(decision["outcome"], "KILL", decision)
        result = decision["criteria_results"][0]
        self.assertEqual(result["effect"], 0)
        self.assertEqual(result["contrast"], self.p["criteria"][0]["contrast"])
        self.assertTrue(any("/shuffled/receipt.json" in ref["path"] for ref in result["proof_refs"]))

    def test_factorial_interaction_uses_all_four_verified_arms(self):
        self.permissive_shuffled_qualification()
        self.p["criteria"][0]["contrast"] = {"weights": {
            "treatment": 1, "baseline": 1, "positive": -1, "shuffled": -1}}
        # .75 + .5 - .75 - .5 = 0; the main treatment-baseline gain is .25.
        decision = self.evaluate(arms={"positive": {"accuracy": 0.75}, "shuffled": {"accuracy": 0.5}})
        self.assertEqual(decision["outcome"], "KILL", decision)
        self.assertEqual(decision["criteria_results"][0]["effect"], 0)

    def test_direction_applies_to_explicit_contrast(self):
        self.p["criteria"][0].update(direction="minimize", contrast={"weights": {"baseline": 1, "treatment": -1}})
        decision = self.evaluate()
        self.assertEqual(decision["outcome"], "PASS", decision)
        self.assertEqual(decision["criteria_results"][0]["effect"], 0.25)

    def test_legacy_main_comparison_is_preserved_with_explicit_finite_scope(self):
        decision = self.evaluate()
        self.assertEqual(decision["outcome"], "PASS", decision)
        self.assertEqual(decision["criteria_results"][0]["effect"], 0.25)
        self.assertNotIn("contrast", decision["criteria_results"][0])

    def legacy_gate(self, *, external=False, explicit=False):
        protocol = self.f.protocol("gate-a")
        protocol["criteria"][0].pop("inference")
        if explicit:
            protocol["criteria"][0]["contrast"] = {"weights": {"treatment": 1, "baseline": -1}}
        if external:
            protocol["criteria"][0]["uncertainty"] = "external"
            protocol["analysis_plan_ref"] = write(self.f.root, "engineering/analysis-plan.json", {
                "purpose": "Fixed paired values for engineering compatibility test only."})
        protocol["protocol_digest"] = C.protocol_hash(protocol)
        pref = write(self.f.root, "engineering/legacy-protocol.json", protocol)
        rows, refs = self.f.runs(protocol)
        return protocol, pref, rows, refs

    def test_saved_implicit_gate_decision_recomputes_with_historical_packet_shape(self):
        protocol, pref, rows, refs = self.legacy_gate()
        decision = C.evaluate(self.f.root, protocol, rows, refs, "gate-a", replay_context=self.live)
        self.assertEqual(decision["outcome"], "PASS", decision)
        # Historical decision packets have neither criterion contrasts nor an
        # inference declaration. Reconstruct that serialization and save it;
        # recomputation must still execute the actual canonical verifier.
        historical = copy.deepcopy(decision)
        historical.pop("decision_id")
        for result in historical["criteria_results"]:
            result.pop("contrast", None)
        historical["decision_id"] = "decision-" + C.hashed(historical)[:20]
        dref = write(self.f.root, "engineering/historical-decision.json", historical)
        with C.evaluation_runtime(native_replay_context=self.live):
            actual, frozen = C.recompute_decision(self.f.root, {"gate_a_protocol_ref": pref},
                {"decision_ref": dref}, "gate-a")
        self.assertEqual(actual, historical)
        self.assertEqual(actual, decision)
        self.assertEqual(frozen, protocol)

    def test_legacy_external_scope_is_unchanged_and_explicit_contrast_is_bound(self):
        for explicit in (False, True):
            with self.subTest(explicit=explicit):
                protocol, pref, rows, refs = self.legacy_gate(external=True, explicit=explicit)
                expected_scope = {"protocol_digest": protocol["protocol_digest"], "criterion_id": "effect",
                    "group": "main", "run_manifest_refs": refs,
                    "analysis_plan_digest": protocol["analysis_plan_ref"]["sha256"]}
                if explicit:
                    expected_scope["contrast"] = {"weights": {"baseline": -1, "treatment": 1}}
                requests = []
                def analysis(request):
                    requests.append(request)
                    self.assertEqual(request["scope"], expected_scope)
                    effect = sum(request["values"]) / len(request["values"])
                    return {"input_digest": request["input_digest"], "scope_digest": request["scope_digest"],
                        "n": len(request["values"]), "effect": effect, "lower": effect, "upper": effect,
                        "method": "fixed-engineering-fixture", "software_version": "engineering-1"}
                with C.evaluation_runtime(native_replay_context=self.live, analysis_context=analysis):
                    decision = C.evaluate(self.f.root, protocol, rows, refs, "gate-a")
                    self.assertEqual(decision["outcome"], "PASS", decision)
                    result = decision["criteria_results"][0]
                    self.assertEqual(result["analysis"]["analysis_scope_digest"], C.hashed(expected_scope))
                    self.assertEqual("contrast" in result, explicit)
                    dref = write(self.f.root, "engineering/external-decision.json", decision)
                    actual, _ = C.recompute_decision(self.f.root, {"gate_a_protocol_ref": pref},
                        {"decision_ref": dref}, "gate-a")
                    self.assertEqual(actual, decision)
                self.assertEqual(len(requests), 2)

    def test_full_validation_without_inference_scope_is_honestly_inconclusive(self):
        self.p["criteria"][0].pop("inference")
        decision = self.evaluate()
        self.assertEqual(decision["outcome"], "INCONCLUSIVE", decision)
        self.assertIn("FULL_VALIDATION_INFERENCE_SCOPE_REQUIRED", decision["reason_codes"])

    def test_point_screen_is_not_final_validation(self):
        self.p["criteria"][0]["inference"] = {"kind": "point_screen", "rationale": "Pilot comparison only."}
        decision = self.evaluate()
        self.assertEqual(decision["outcome"], "INCONCLUSIVE", decision)
        self.assertIn("POINT_SCREEN_NOT_FULL_VALIDATION", decision["reason_codes"])

    def test_stochastic_and_generalization_claims_need_uncertainty(self):
        for kind in ("stochastic", "generalization"):
            self.p["criteria"][0]["inference"] = {"kind": kind, "rationale": "Inference over future runs.",
                "precision_rationale": "Replications chosen for the prespecified effect."}
            decision = self.evaluate()
            self.assertEqual(decision["outcome"], "INCONCLUSIVE", decision)
            self.assertIn("INFERENTIAL_UNCERTAINTY_REQUIRED", decision["reason_codes"])

    def test_inferential_precision_is_explicit_without_universal_seed_count(self):
        rule = self.p["criteria"][0]
        rule.update(uncertainty="paired_t", inference={"kind": "stochastic", "rationale": "Replicated fits."})
        with self.assertRaises(C.Failure) as raised:
            validate_inference(rule, full_validation=True)
        self.assertEqual(raised.exception.code, "INFERENTIAL_PRECISION_RATIONALE_REQUIRED")
        rule["inference"]["precision_rationale"] = "A priori variance estimate and decision precision justify the run count."
        validate_inference(rule, full_validation=True)

    def test_heterogeneous_claim_groups_are_evaluated_only_in_their_frozen_scope(self):
        self.p["required_groups"] = ["main", "secondary"]
        self.p["claim_set"] = self.p["indispensable_claim_ids"] = ["claim-1", "claim-2"]
        self.p["claim_required_groups"] = {"claim-1": ["main"], "claim-2": ["secondary"]}
        self.p["criteria"][0]["groups"] = ["main"]
        second = copy.deepcopy(self.p["criteria"][0])
        second.update(id="secondary-effect", claim_id="claim-2", metric="scope", direction="minimize", groups=["secondary"])
        self.p["criteria"].append(second)
        card = copy.deepcopy(self.p["claim_cards"][0])
        card["claim_id"] = "claim-2"
        card["scope"].update(groups=["secondary"], metrics=["scope"])
        self.p["claim_cards"].append(card)
        validate_claim_cards(self.p)
        self.p["inventory_run_ids"] += ["p1-r1-secondary", "p1-r2-secondary"]
        decision = self.evaluate()
        self.assertEqual(decision["outcome"], "PASS", decision)
        self.assertEqual({(r["claim_id"], r["group"], r["metric"]) for r in decision["criteria_results"]},
                         {("claim-1", "main", "accuracy"), ("claim-2", "secondary", "scope")})
        self.p["claim_required_groups"]["claim-1"].append("secondary")
        decision = self.evaluate()
        self.assertEqual(decision["outcome"], "INCONCLUSIVE", decision)
        self.assertIn("REQUIRED_REPLICATION_CONTRAST_MISSING", decision["reason_codes"])

    def test_claim_scope_inventory_cannot_drop_unknown_or_unmeasured_groups(self):
        cases = [({}, "SCHEMA_MIN_PROPERTIES"),
                 ({"claim-1": ["unknown"]}, "CLAIM_REQUIRED_GROUPS_INVALID"),
                 ({"claim-1": ["main", "main"]}, "CLAIM_REQUIRED_GROUPS_INVALID")]
        for scopes, code in cases:
            self.p["claim_required_groups"] = scopes
            with self.assertRaises(C.Failure) as raised:
                C.validate(self.p, "full-validation-protocol")
            self.assertEqual(raised.exception.code, code)
        self.p["required_groups"] = ["main", "secondary"]
        self.p["criteria"][0]["groups"] = ["main"]
        self.p["claim_required_groups"] = {"claim-1": ["main"]}
        with self.assertRaises(C.Failure) as raised:
            C.validate(self.p, "full-validation-protocol")
        self.assertEqual(raised.exception.code, "UNCLAIMED_REQUIRED_GROUP")

    def test_indispensable_claim_cannot_make_difficult_group_severable(self):
        self.p["required_groups"] = ["main", "secondary"]
        self.p["claim_required_groups"] = {"claim-1": ["main", "secondary"]}
        self.p["criteria"][0]["groups"] = ["main"]
        second = copy.deepcopy(self.p["criteria"][0])
        second.update(id="secondary-effect", groups=["secondary"], indispensable=False)
        self.p["criteria"].append(second)
        with self.assertRaises(C.Failure) as raised:
            C.validate(self.p, "full-validation-protocol")
        self.assertEqual(raised.exception.code, "INDISPENSABLE_CLAIM_COVERAGE_MISSING")

    def test_claim_card_cannot_extend_the_criterion_group_scope(self):
        self.p["claim_required_groups"] = {"claim-1": ["main"]}
        self.p["claim_cards"][0]["scope"]["groups"].append("unsupported")
        with self.assertRaises(C.Failure) as raised:
            validate_claim_cards(self.p)
        self.assertEqual(raised.exception.code, "CLAIM_GROUP_SCOPE_MISMATCH")

    def test_unknown_or_unbalanced_contrasts_are_rejected(self):
        for weights, error in (({"treatment": 1, "invented": -1}, "CRITERION_CONTRAST_ARM_UNDECLARED"),
                ({"treatment": 1, "baseline": 1}, "CRITERION_CONTRAST_NOT_ZERO_SUM"),
                ({"treatment": True, "baseline": -1}, "CRITERION_CONTRAST_INVALID")):
            with self.assertRaises(C.Failure) as raised:
                criterion_contrast({"contrast": {"weights": weights}}, {"treatment", "baseline"})
            self.assertEqual(raised.exception.code, error)


if __name__ == "__main__":
    unittest.main()
