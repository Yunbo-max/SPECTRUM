# Local installation, session records and harnesses

Use the same research contracts in local workers and the cloud supervisor. The
installed instructions, actual host execution and saved project evidence remain
distinct. The bundled recorder uses native Codex hooks for automatic local
records. It does not control operations or require a separate agent framework.

Contents:

- [Install the complete source](#install-the-complete-source)
- [Enable automatic local recording](#enable-automatic-local-recording)
- [Separate four kinds of records](#separate-four-kinds-of-records)
- [Capture one explicit Codex CLI run](#capture-one-explicit-codex-cli-run)
- [Save decisions and map progress](#save-decisions-and-map-progress)
- [Reuse the existing experiment harness](#reuse-the-existing-experiment-harness)
- [Retention and delivery](#retention-and-delivery)
- [Official host references](#official-host-references)

## Install the complete source

The portable repository is `https://github.com/Yunbo-max/Research_Autopilot`.
A complete installation of this version requires four sibling skill folders:
`research-autopilot`, `writing-top-tier-papers`, `designing-pipeline-figures`, and
`designing-experiment-figures`. Mathematical discovery is bundled inside
`research-autopilot/references/math-*.md`; install the whole folder, with no
separate mathematical skill. Verify the actual checkout contains these internal
references before copying. Do not claim a GitHub delivery from a personal-skill
update alone. Keep the four folders together when using the 84-node source map. Node sources resolve by frontmatter name and verify section digests;
duplicate names, missing dependencies or changed sources are explicit blockers.
Copy actual folders rather than symlinking them: the node-source verifier rejects
symlinked source directories even though Codex itself supports local skill symlinks.

Codex loads user skills from `~/.agents/skills` and repository skills from
`.agents/skills`. Local Codex can perform the copy or use its actual available
installer with the authorized repository paths. A private repository is sufficient
when the host has read permission. Do not claim that a web detail-page link or a
Cloud toggle installed files in another execution environment.

Inspect `/skills` and explicitly invoke `$research-autopilot`. Preserve any existing
different skill before replacement, and store backups outside the scanned skills
directory so they do not create duplicate frontmatter names. Reopening the skills
selector or starting a new session can refresh discovery when needed.

The deterministic research scripts use the Python standard library and POSIX
process/file-lock APIs. Run them on Linux/macOS or Windows through WSL. Python
3.10+ is required for research scripts and recording callbacks; enabling the
recorder requires Python 3.11+ to safely parse existing TOML configuration.
Validate the actual host. Model, benchmark, rendering and service dependencies
are task-specific and are not installed by this skill.

## Enable automatic local recording

From the actual scientific project's directory, after installing the skill:

```bash
python3 "$HOME/.agents/skills/research-autopilot/scripts/session_records.py" enable --project .
```

For a repository-scoped installation, use that project's actual installed script
path. The worker performs this setup on first use in a write-authorized local
project with native hook support. `enable` writes project `.codex/hooks.json`
and enables `features.hooks` in `.codex/config.toml`, preserving other handlers
and settings. Changed existing files are backed up under
`.research-autopilot/records/setup-backups/`. Repeating setup replaces only this
recorder's definitions without adding duplicate callbacks.

Trust the project in Codex and open `/hooks` to review/trust the new definitions.
This is the native client's trust requirement. Setup does not mark them trusted
or prove that capture is active. Confirm the recorder in the client's hook list,
start a new supported local session and check for newly written `events.jsonl`.
Changed callback paths or definitions may require another client review.
CLI/IDE/desktop support and project configuration loading depend on the actual
client; if the client lacks these hooks, use the explicit CLI capture recipe below
and report that automatic native capture is unavailable.

Each installed hook saves its complete host-provided JSON input and a UTC
observation timestamp to:

```text
.research-autopilot/records/sessions/<hashed-session-id>/events.jsonl
```

The original session ID remains in the record; hashing only makes its directory
name safe. Missing IDs use `unidentified` and stay null. The `session-record`
schema distinguishes `codex_hook` input from `worker_decision_note` explanations.
Callbacks observe session start/end, prompts, tool pre/post activity, permission
requests, compaction, subagent start/stop, turn stop and interruption. They emit
no permission decisions, replacement tool input or stop instructions. Logging
errors produce a client message and return success, leaving a known recording
gap. Brief synchronous file writes and lock waits can add latency; capture is
best effort and cannot guarantee every event after cancellation or disk failure.
The client permits at most three seconds for session-end and interruption hooks;
those callbacks use that limit. Other recorder callbacks use thirty seconds.
If an interrupted append leaves an incomplete final JSON line, the next writer
retains those exact bytes in `interrupted-events/` before resuming parseable JSONL;
the new record links the retained tail. A complete final object missing only its
newline is kept in place. A malformed transcript cursor marks capture unavailable
while still retaining the host event; existing transcript segments remain intact.

At session start/end, compaction, turn stop and subagent stop, the recorder also
copies new bytes from the host-provided native `.jsonl` transcript under the
configured Codex home's `sessions/` or `archived_sessions/`. It retains opaque
segments under that session's `transcripts/`, with source path, byte offsets,
generation and SHA-256 in the event record. Segments can end inside a JSON line;
reconstruct a generation by stream ID and offsets before interpreting its bytes.
Truncation or a changed captured prefix starts a new generation and preserves
older segments. Missing or unsupported transcript paths are marked `unavailable`.
An unchanged source is marked `unchanged` rather than copied repeatedly.

Native transcript formats are not a stable API. The recorder copies bytes without
interpreting or decrypting private reasoning. It records only what the host
provides. Hosted search and unsupported execution paths may lack tool hooks;
`write_stdin` does not start another tool pre-hook. Hook time is when this callback
observed an event, not a proven causal ordering, GPU duration or model thinking
duration. It covers this configured project after activation, not past chats,
every other project or another machine. Inspect actual event/transcript coverage
before analyzing it.

To locate records or remove this recorder while retaining existing files:

```bash
python3 "$HOME/.agents/skills/research-autopilot/scripts/session_records.py" where --project .
python3 "$HOME/.agents/skills/research-autopilot/scripts/session_records.py" disable --project .
```

`disable` removes only this recorder's callbacks and keeps other hooks, the feature
setting and all recorded files. There is no background recording service to stop.

## Separate four kinds of records

| Record | Producer | What it establishes |
| --- | --- | --- |
| Session transcript/events | Native hooks plus the bundled recorder, explicit CLI JSONL or supported host export | Host-exposed prompts, messages, available reasoning summaries and tool activity |
| Research decision record | Worker after each material milestone | Observation, evidence references, competing explanations, route choice and next discriminating experiment |
| Experiment receipt and raw outputs | Existing bounded runner/native benchmark | Actual command, attempts, start/end times, elapsed execution time, status, logs and retained outputs |
| Shared route checkpoint | Existing route registry plus actual host write/readback | Current/next map node, source revision, owner, blockers and synchronization freshness |

A transcript alone is not a scientific ledger, and a summary score is not raw
evidence. Keep negative outcomes and failed attempts. A session's elapsed time is
not GPU-active time, billed cost or the duration of private model reasoning.
Report those measures only when the actual host/provider supplies them. Exposed
reasoning summaries may be captured; unexposed internal reasoning is unavailable.
Do not describe a generated decision note as a verbatim internal thought trace.

## Capture one explicit Codex CLI run

Run from the actual scientific project's working directory, not the skill source
repository. Use a unique directory per invocation and retain the exact prompt.
The command below runs only the stated read-only inspection; it supplies no GPU
budget and does not authorize experiments. This is an operational logging recipe,
not a research benchmark or a scientific test fixture.

```bash
mkdir -p .research-autopilot/sessions
session_dir=$(mktemp -d ".research-autopilot/sessions/$(date -u +%Y%m%dT%H%M%SZ)-XXXXXX")
cat > "$session_dir/prompt.txt" <<'PROMPT'
$research-autopilot Resume this worker from its actual project records. Inspect the current code, experiment evidence and route. Do not launch experiments or modify scientific results. At the end, report the observed milestone, evidence gaps and next discriminating experiment. Recommend a dated decision entry and route checkpoint without claiming that a remote write occurred.
PROMPT
date -u +%Y-%m-%dT%H:%M:%SZ > "$session_dir/started_at.txt"
codex_status=0
/usr/bin/time -p codex exec --json --sandbox read-only \
  -c hide_agent_reasoning=false \
  --output-last-message "$session_dir/final.md" - \
  < "$session_dir/prompt.txt" \
  > "$session_dir/events.jsonl" 2> "$session_dir/stderr-and-time.log" \
  || codex_status=$?
date -u +%Y-%m-%dT%H:%M:%SZ > "$session_dir/completed_at.txt"
printf '%s\n' "$codex_status" > "$session_dir/exit-code.txt"
printf '%s\n' "$session_dir"
```

Keep `events.jsonl` separate from stderr so it remains parseable. The initial
prompt is saved separately because a JSON event stream need not repeat it.
`/usr/bin/time -p` reports elapsed/user/system process time; preserve the Codex
exit code even when the invocation fails. Do not use `--ephemeral` if native
session persistence is wanted. Capture each subsequent `codex exec resume
ACTUAL_SESSION_ID` invocation in its own directory with its actual follow-up
prompt and timestamps. Obtain the real thread/session ID from saved host events;
do not select another project's session using an unscoped guess.

For an authorized implementation run, use the appropriate existing permission
profile and a concrete prompt with the already-agreed commands and GPU/time/round
limits. `workspace-write` permits workspace changes; it does not manufacture
dataset access, network permissions, credentials or a resource lease. Preserve
the existing host approval policy rather than disabling it to make logging work.
Non-interactive runs cannot resolve an interactive approval dialogue on their own.

This recipe captures the invocation it launches. It does not automatically capture
earlier IDE/desktop chats, future interactive replies, every open worker or another
machine. Use the actual client's supported transcript/export capability for those
sessions and label incomplete coverage. Native history retention is controlled by
the user's actual configuration; do not silently rewrite it or assume that a
history index is a complete event/evidence archive.

## Save decisions and map progress

Reuse the existing H03 navigation decision card and canonical project records.
Record an actual UTC timestamp, project/route/thread identities when exposed,
current evidence versions, observation, competing explanations, continue/switch/
combine/repair/stop choice, next discriminating experiment, resource limit and
development-versus-confirmation status. Missing identities and costs stay unknown.
Link a retained session event file when it supports a decision; do not copy
speculation into an evidence field. In a write-authorized worker, append the entry
and checkpoint at each material milestone and turn end. A read-only inspection
reports the proposed entry instead of pretending it wrote one.

Automatically append a concise operational decision note at each material
milestone and turn end, as well as maintaining the canonical ledger. The command
accepts an actual JSON note file, or `--note -` with JSON on stdin:

```bash
python3 "$HOME/.agents/skills/research-autopilot/scripts/session_records.py" decision \
  --project . --note ACTUAL_DECISION_NOTE.json
```

Required fields are nonempty `decision` and concise, evidence-based `rationale`.
Include `evidence_refs`, `alternatives`, `map_node`, `next_map_node`, `project_id`,
`route_id`, `resource_limits` and `next_action` when known. These are declared
worker explanations; the record does not verify their scientific truth or infer
causal responsibility. Add `--session-id ACTUAL_SESSION_ID` only when exposed by
the host. Without that ID, the note is explicitly unidentified; do not invent an
association with another session. Review its `recorded: true` result before
claiming a saved note. If writing fails, report the gap and continue the authorized
research work; do not turn recording into an approval or scientific gate.

Use `scripts/supervise_routes.py checkpoint` against the actual initialized
registry with its current expected revisions and inspected project ledger.
Read [multi-route-supervision.md](multi-route-supervision.md) before shared updates.
The supervisor reads actual saved records; chat memory is not a complete live feed.

## Reuse the existing experiment harness

Install/use Codex and the skill on the user's controller computer. In the owner's
SSH workflow, the remote GPU machine needs only the pinned project and Python/
Conda harness runtime, not another Codex/GPT installation. Start remote tests/jobs
over SSH and collect their separate logs/receipts under local-execution-harness.md.
Native session hooks record the local control session and visible SSH tool calls;
remote process logs are execution evidence, not remote GPT chat records.

Codex already supplies the agent tool/command loop. An additional general-purpose
agent framework is unnecessary for a worker that uses local files and tools.
The skill already supplies `scripts/run_experiments.py` for reviewed finite
experiment plans, attempts, timeouts, retries and collection; see
[native-runner.md](native-runner.md). It stores `attempt.json`, `stdout.log`,
`stderr.log`, declared output references and a run `receipt.json`, including
`started_at`, `completed_at`, elapsed seconds and exit status. These records are
produced only when that runner actually executes the reviewed plan.
For actual independent-task concurrency and soft reports across up-to-24-hour
Local cycles, use
`scripts/run_harness.py` and [local-execution-harness.md](local-execution-harness.md)
on the Linux execution host. It retains native run receipts and separate driver/
worker/context records, and makes no LLM calls or automatic cloud uploads.

Distinguish this runner from the benchmark's native evaluation harness. Every
research eval, including Gate A, must use an existing benchmark's original data,
tests, labels, metric and official or verified faithful evaluator. No operational
logging, software fixture or transcript summary substitutes for benchmark eval.

An additional host/provider adapter is needed for behavior outside that harness
such as unattended restart after reboot, multiple-machine dispatch, continuous
cloud uploads, physical GPU fencing or round-by-round daemon scheduling. Keep
those as actual deployment tasks. This package does not install or claim such a
service. Do not turn `while true` or automatic retries into an unbounded research
loop; reuse the finite budgets, stop conditions and confirmation separation.

## Retention and delivery

Keep actual conversation logs, prompts, canonical ledgers, credentials, raw
experiment files and checkpoints in the scientific project's authorized private
destination, separate from this reusable skill-source repository. Publish only
the requested source package and engineering checks here. Add runtime records to
the actual project's ignore policy when they must not enter its source history.
An ignore file is not an access-control or redaction mechanism. Inspect the
selected contents and actual destination before a requested result upload.

For cloud review, use the existing authorized GitHub/HF/Page/Drive handoff. Fetch
the current version, reconcile updates and retain the real write/readback receipt.
Saving local events does not synchronize them. Preserve an explicit blocked or
unsynced status until an actual host operation succeeds.

## Official host references

Checked 2026-10-03:
- [Build skills](https://learn.chatgpt.com/docs/build-skills)
- [Hooks](https://learn.chatgpt.com/docs/hooks)
- [Non-interactive mode](https://learn.chatgpt.com/docs/non-interactive-mode)
- [Developer commands](https://learn.chatgpt.com/docs/developer-commands)
- [Configuration reference](https://learn.chatgpt.com/docs/config-file/config-reference)

These references describe host features, not evidence that a particular user's
Codex version, account, GPU or remote record has been connected and tested.
