"""Reference/fixture integration only, not agent-compliance or novelty tests."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
class PolicyTests(unittest.TestCase):
    def test_entry_points_to_shared_object_first_contract(self):
        s=(ROOT/'SKILL.md').read_text()
        self.assertIn('## Frame the question before selecting mathematics',s)
        self.assertIn('references/inquiry-generation.md',s)
        self.assertIn('v4',s)
    def test_early_probe_contract_is_explicit_and_not_a_scientific_pass(self):
        s=(ROOT/'references/inquiry-generation.md').read_text().lower()
        for phrase in ('phenomenon-first','unknown prior','claim_kind=investigation','semantic','development','not a replacement research benchmark'):
            self.assertIn(phrase,s)
    def test_template_is_draft_not_manufactured_evidence(self):
        d=json.loads((ROOT/'assets/templates/research-decision.json').read_text())
        self.assertEqual(d['schema_version'],4);self.assertIsNone(d['inquiry']['goal_ref'])
        self.assertEqual(d['inquiry']['observations'],[])
    def test_behavior_cases_have_no_fabricated_agent_results(self):
        c=json.loads((ROOT/'tests/inquiry-development-scenarios.json').read_text())
        self.assertIn('not_run',c['classification']);self.assertNotIn('results',c)
        self.assertEqual(len(c['cases']),8)
    def test_example_creates_valid_early_decision_and_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as d:
            work=Path(d)/'new'
            cp=subprocess.run([sys.executable,str(ROOT/'assets/examples/object-first/setup.py'),str(work)],capture_output=True,text=True,timeout=8)
            self.assertEqual(cp.returncode,0,cp.stderr)
            checked=subprocess.run([sys.executable,str(ROOT/'scripts/research_reasoning.py'),'--root',str(work),'--task','task.json'],capture_output=True,text=True,timeout=8)
            self.assertEqual(checked.returncode,0,checked.stdout+checked.stderr)
            self.assertFalse(json.loads(checked.stdout)['scientific_certification'])
            executed=subprocess.run([sys.executable,'probe.py'],cwd=work,capture_output=True,text=True,timeout=8)
            self.assertEqual(executed.returncode,0,executed.stderr)
            result=json.loads((work/'probe.json').read_text())
            self.assertEqual(result['rows'][1]['disagreement'],'4')
            repeated=subprocess.run([sys.executable,str(ROOT/'assets/examples/object-first/setup.py'),str(work)],capture_output=True,text=True,timeout=8)
            self.assertNotEqual(repeated.returncode,0)
if __name__=='__main__':unittest.main()
