# Local execution harness for rolling research windows

Use [single-experiment batching](single-experiment-batching.md): one active
experiment program, sequential descending batch calibration (for example
64 → 32 → 16 → 8 → 4 → 2), preserved scientific semantics and measured useful
throughput/headroom. Queue other experiments; keep Chat within CPU/4 GB.

Before blocking a stage on scorer availability/isolation, apply
[native-scoring-stages.md](native-scoring-stages.md). Restore real deferred scoring
support from the project. Independent training/export may proceed with saved
unscored artifacts; final metric claims wait for actual native scoring. No Docker
on any host. Requirements for a scorer that executes generated programs belong
to that operation, not automatically to training or prediction generation.


Use `scripts/run_harness.py` on the actual Linux execution host. A local Codex
agent can prepare/validate it and start it through an already authorized SSH
connection. Python 3.11+ and the standard library are sufficient for CPU tasks;
GPU admission additionally requires working NVIDIA `nvidia-smi` telemetry. No
Ray/Orca install, continuously active chat worker, API call or paid service is
needed by the scheduler. The existing native runner remains the per-task executor.

## Controller, SSH transport and GPU execution host

For the owner's workflow, the Local Codex/GPT session runs on the user's computer
and operates the remote GPU machine over SSH. Do not require or assume a Codex
installation, remote GPT session or LLM agent service on that machine. The harness
and inner runner are ordinary Python processes on the Linux execution host.

| Location | Responsibility and identity |
|---|---|
| User's computer | Local control session, supported subagents, source/design review, SSH/file-transfer tools, local session recording and selected GitHub delivery checkout |
| SSH connection | Existing authorized target/alias and transport; explicit remote working directory/interpreter, actual acknowledgments and reconnect handling |
| Remote GPU machine | Pinned project files and runtime scripts/schemas, native Conda environment, CPU/GPU admission, harness/inner-runner processes, tests/experiments, logs/checkpoints/receipts |

1. Restore the actual SSH alias/host, remote project and runtime-script roots,
   scheduler Python, model/scorer Conda prefix, local delivery root and finite
   budgets from the existing brief. Check remote access/inventory with read-only
   commands. Missing access or paths block this deployment, not scientific
   generation; do not guess a host or ask for already known credentials again.
2. Stage the exact approved source/design and required harness runtime files on
   the remote machine through the existing authorized Git or file-transfer path.
   Compare source identities and retain the local-to-remote path map. Copying
   Python runtime files is not installing/activating a remote Codex skill. Preserve
   running workspaces, checksummed inputs and the three required distinctions:
   planned/accepted scientific work, deployed runtime and observed execution.
3. Run bounded remote environment/software/semantic/native-interface acceptance
   and diagnosis for each affected task before its full execution, through this
   harness via SSH. Use actual remote absolute paths and the reviewed interpreter/
   Conda environment, not a laptop path or local interpreter forwarded by accident.
   Runtime, telemetry, GPU UUIDs, process IDs/boot identity, pool locks and budgets
   belong to the remote host. Reuse current qualified unchanged shared checks;
   admit each scientific task only after its own actual prerequisites and existing
   gates hold. A failed first candidate does not gate unrelated ready candidates.
4. Keep one execution owner/host pool. Run its driver on the remote machine in an
   existing permitted tmux session or authorized nohup launch when persistence
   across SSH disconnects is needed; model/scorer children remain foreground jobs
   inside that harness. Do not use raw SSH training/eval as a second driver.
   Observing a driver launch is not observing a completed task or passed test.
5. On disconnect, timeout or lost acknowledgment, reconnect to the same host and
   inspect retained driver/task/receipt state before retrying. An SSH connection
   failure does not prove a remote job stopped. Resume stable IDs and cumulative
   limits; do not start a duplicate queue, reset budgets or treat local PIDs as
   remote process evidence. Host changes follow the existing reconciliation rules.
6. Read and retrieve remote logs, outputs, checkpoints and receipts via the
   authorized transport. Verify transferred file identities and preserve their
   project-relative provenance; record remote and local paths separately rather
   than rewriting evidence. The Local controller assembles the review packet and
   normally pushes from its selected authenticated delivery checkout, then reads
   back the exact GitHub commit. A remote Git writer is optional only with actual
   scoped access and one integration owner; remote GitHub credentials are not a
   prerequisite for SSH execution. File retrieval alone is not GitHub delivery.

Codex session hooks record controller-visible SSH calls/results on the user's
computer. Remote native/harness logs separately record task execution. Collect
and link both as authorized; do not describe remote process logs as a second
GPT conversation or a hidden-thought transcript. This contract describes the
required topology; it does not claim a live SSH connection or remote deployment.
All shell examples below target the remote execution host. The Local controller
issues them through the authorized SSH/remote shell with its actual path map.

## Preparation and frozen scope

Follow [local-code-handoff.md](local-code-handoff.md): read the applicable project
AGENTS instructions, linked Local runbook and round handoff at the delivered
commit before setup/tests/repair. Restore the guide's real host/path/command/log
map; missing or stale pointers are acceptance gaps, not permission to guess a
training/eval command. Link new remote receipts and debug rechecks back to it.

Read [workflow-harness.md](workflow-harness.md). Generation boundaries apply
before code/experiment artifacts are written, not only when a GPU job starts.
Use this harness for all executable project jobs, including CPU-only setup,
software checks, scoring, E04 helper commands and collection. Schedule official
scorer replay inside a reviewed admitted job; a raw terminal/scorer invocation
must not silently escape the resource, process, evidence and budget contract.
The native runner remains the inner executor; separate standalone drivers must
not compete for the same host. Reading/connector calls retain their actual host
receipts and workflow checkpoints rather than being called scheduled GPU jobs.

The agent first joins the current papers, actual implementation and official
benchmark/scorer with G01 design. In the web/local workflow, reuse the approved
web-prepared linked reading/design record and inspect affected new dependencies;
local execution does not require regenerating the whole candidate investigation.
Confirm/reuse the current host/GPU inventory,
GitHub/HF destinations, soft reporting cadence and the up-to-24-hour Local cycle
under rolling-research-batches.md, with finite cumulative bounds. An eight-hour review
request alone is not an unlimited compute grant. Keep at most 20 active ideas
per navigation goal. New/reopened discovery derives consequential mathematical
constructions and verifies readiness-based selection before code design under
method-verification.md; resume reuses that pool and later convergence keeps fewer.
Plan full controls/scoring/E04/export obligations; do not replace them with quick
tests, more seeds or arbitrary new ideas to occupy a GPU.

Use [development-and-execution.md](development-and-execution.md)'s G02/E04
contract to declare finite per-task diagnosis/repair time, attempts, compute/spend
and stop conditions within the cumulative development envelope. Local may choose
evidence-driven checks and repairs within it without asking about each adjustment.
Small diagnostics precede the affected full run where informative; their success
does not satisfy the complete scientific queue. Retain blocked benchmarks and
their missing comparisons in the final coverage/continuation record.

Apply [gpu-host-runtime.md](gpu-host-runtime.md): use native Conda commands for
setup/train/inference/eval/replay and retain a pinned runtime profile. On a
confirmed single-GPU host, admit CPU tasks with `gpu_count: 0` and GPU tasks with
`gpu_count: 1`; do not invent another UUID or a multi-GPU launch. Keep one
experiment program at a time with sharing disabled under single-experiment-batching.md.
Independent reading/code/CPU preparation may overlap within its actual envelope. Docker-only or isolation-dependent blocked tasks
never become ready merely because GPU time is available.

Read the host without launching a workload:

```bash
python3 "$SKILL_DIR/scripts/run_harness.py" --inspect-host
```

Prepare real reviewed `experiment-run-plan` files using native-runner.md. Each
harness task binds one such file by path and SHA256, with stable `task_id`,
`idea_id`, prerequisite task IDs, integer priority and a resource envelope.
Use one atomic foreground workload per native plan when task-level concurrency
is needed: jobs inside a native plan still run serially. Existing frozen train/
inference/evaluation entry points can perform several approved stages internally.
Keep one integration writer; pinned inputs are staged into isolated attempts.
Declare mutable caches/export targets as `exclusive_keys` when they may conflict.

`make_plan(root, *, batch_id, tasks, pool_dir=None, limits, gpus=None,
output_root='runs/harness')` validates and returns a digested `harness-plan`.
`window_seconds` defaults to 28800 only for progress reports. New Local cycles
may use `total_wall_seconds: 86400` when the remaining actual allowance permits;
use a smaller remaining bound if required. Specify the other limits from actual
authorization, cost and resources. `schemas/harness-plan.schema.json` is the
exact strict file contract. A task resource envelope contains:

| Field | Meaning |
|---|---|
| `cpu_cores`, `ram_mib` | Conservative host reservations, including command descendants |
| `gpu_count` | 0 for CPU; otherwise actual UUID-based device count |
| `gpu_peak_mib` | Qualified conservative peak; null means unknown/exclusive |
| `allow_gpu_share` | Set false under the current single-experiment policy |
| `memory_profile_ref` | Pinned `gpu-memory-profile`, or null |
| `exclusive_keys` | Shared mutable assets that cannot have simultaneous writers |

`limits` includes finite `total_wall_seconds`, `max_parallel_tasks`, `cpu_cores`,
`ram_mib`, and `max_gpu_task_seconds`. The last is a conservative planned native
task-time bound: the sum of each GPU task's native wall limit times GPU count
must fit. Reserve overhead in the external compute/spending budget. It is not
an invoice cap or measured physical GPU utilization. Retries stay inside each
native plan's attempt/development/time limits; confirmation never retries. Native
`max_retries_per_trial` repeats the same pinned job, not a repaired version chosen
by Local. Use short developmental tasks and no automatic retry when agent diagnosis
must intervene between failures; bind each supported repair in a future frozen
plan within the remaining allowance.

`gpus` freezes actual `uuids`, positive `safety_margin_mib`, and
`max_tasks_per_gpu`. Use a single common `pool_dir` for all cooperating workers
on a host (default `~/.local/state/research-autopilot`). One driver manages that
host pool; other agents submit approved work to it rather than launching their
own GPU processes. This layer operates under one execution-owner route's valid
whole-GPU lease; the existing supervisor registry has no VRAM sublease schema.
External provider budgets/lease expiry must already bound any paid infrastructure.

### Dependency scope

The DAG orders execution-ready, already pinned native plans. All input/code/
protocol files must exist and validate before execution. It does not invent the
future hash of a not-yet-produced checkpoint, prediction or native evaluation
record. A task's successful exit/declared files establish execution completion;
they do not qualify a scientific upstream result.

When a downstream plan needs newly generated artifacts or a scientific decision,
the agent must first collect/qualify those actual outputs, run E04/native checks
and bind them in a new ready frozen plan under existing authorized conditions.
Keep that item as a documented blocked obligation until then. Do not insert
placeholder hashes, auto-promote a scientific gate, or mutate the running batch.
An independently ready task can proceed during this wait. Automatically generated
artifact-to-input DAG binding is not implemented by this version.

## Dispatch and GPU admission

The scheduler considers completed prerequisites, descending frozen priority,
available task slots and CPU/RAM reservations. Independent tasks can overlap
regardless of idea numbering. Failed dependencies block their descendants and
leave other tasks eligible. RAM admission checks the aggregate conservative
reservations against both the declared envelope and live MemAvailable; this is
deliberately conservative under memory pressure. Reservations are admission
accounting, not cgroups or an OS memory partition. Commands/frameworks must honor
the active reviewed envelope. Within a declared adaptive development envelope,
Local may version permitted pending configuration changes (including justified
batch-size/dtype/resource tuning), record effective settings and measured costs,
and requalify affected semantics without per-change user approval. Bind those
changes to future plans within remaining bounds; never silently change an active
command, digest or frozen confirmation setting. New scope or result-affecting
confirmation changes retain human/child-protocol and fresh-confirmation obligations.

GPU placement uses stable device UUIDs. CPU workers receive an empty
`CUDA_VISIBLE_DEVICES`; GPU workers receive only their admitted UUIDs. Retain the
actual allocation and declared envelope in `execution-context.json`. NVIDIA
query failure, unsupported/ambiguous memory values or unaccounted foreign GPU
processes block new GPU admissions. CPU tasks may still proceed.

Keep `limits.max_parallel_tasks: 1`, `gpus.max_tasks_per_gpu: 1` and
`resources.allow_gpu_share: false` in new plans; also serialize across project
plans/hosts. The following describes generic backend capability, not permission
to enable sharing under this policy. Unknown peaks and multi-GPU workloads get
exclusive devices. Backend same-card sharing
requires actual memory and useful-throughput qualification, pinned measurement/
throughput refs and `gpu-memory-profile` workload/device/concurrency bindings.
The profile also freezes allowed `co_location_workload_digests`: both profiles
must permit each other. Reuse a profile only for its exact workload/environment/
input/protocol identity. A JSON profile and hash do not themselves establish that
the measurements are scientifically valid; the agent retains that qualification.
Prefer exclusive runs for resource/efficiency claims or unqualified confirmation.

Admission accounts for the larger of conservative reserved peaks and observed
own allocation, plus foreign memory and operating headroom. An observed own
allocation above its reserved envelope prevents additional sharing. It does not
infer free capacity from a training job's small instantaneous allocation. No
memory partition/fractional accelerator token is claimed. Review real throughput:
co-location that fits VRAM can still be slower or change a timing comparison.

The exclusive driver lock serializes admission. Shared execution/device ownership
locks are bound to the current batch digest, inherited by its worker/watchdog/
command and retained while they run. A restarted driver can rejoin its own batch;
another batch must obtain exclusivity before changing the owner. Locks are
cooperative among users of the same host pool, not physical fencing of unrelated
accounts or programs. NVIDIA telemetry detects foreign GPU use before admission.

### Known task failure and bounded controller repair

The current runtime already continues independent ready tasks after a known
failure. A failed native receipt or missing required output makes that outer task
`failed`; terminal unsuccessful prerequisites make only their descendants
`blocked` with `HARNESS_DEPENDENCY_FAILED`. Other pending tasks with completed
prerequisites remain eligible for normal resource admission. A final batch status
of `failed` reports unfinished execution obligations, not scientific refutation
of every candidate or removal of their benchmarks from coverage. Qualification
and shared-fault scope remain the agent's scientific responsibility.

Jobs and retries inside a native plan run serially. Exhausted ordinary failure
retries leave that trial failed; the native runner may then run its next pinned
job, while interruption or exhausted overall wall/attempt allowance ends that
native run. The outer scheduler sees the task's terminal receipt after the native
plan returns; it does not yield the task after each inner failure. Keep diagnosis
plans and their retry/time limits suitably small before freezing so one broken
task cannot consume the whole repair budget ahead of independent work.

When repeated diagnosis/repair reaches the declared per-task allowance or stops
adding useful evidence, the Local controller pauses that effort and skips it for
current dispatch, records the blocker/resume condition and continues actual
authorized independent work under G02/E04. This is workflow prose: the harness
has no pause/skip/requeue field or retry/skip CLI control. Failed and blocked task
IDs are terminal on resume. `--stop-after-report` is a driver handoff, not a
per-task skip mechanism. Do not edit task state to make it retryable, add repaired
tasks to an active plan or bypass missing inputs/native scoring. Validation also
requires every included plan/ref to exist before launch; unresolved future plans
remain documented obligations outside the current ready frozen batch.

After actual failure and process/receipt reconciliation, Local may prepare a
versioned future native/harness plan for a supported repair or pending operational
resource replan within the same authorized development envelope and remaining
cumulative limits. Preserve failed identities/evidence, carry forward completed
work, bind real new inputs and reconcile host ownership before launching the new
batch. A new run ID never substitutes for reconciliation of an unknown launch.
No parallel second driver, active-plan mutation, budget reset or implicit expansion
of scientific scope is allowed. Frozen result-affecting confirmation repairs
still require the existing child protocol and fresh eligible confirmation.

Continue only tasks independent of the actual fault. A shared environment, input
or scorer failure blocks its affected dependents; unrelated qualified work may
proceed. Missing isolation, access or scorer capability does not become ready
through resource replanning. If all actual eligible execution work is blocked,
continue already authorized scientific reading/code work only when it has its
own satisfied prerequisites. Otherwise retain the concrete blockers and ask for
human intervention. The driver has no automatic human-escalation or repair loop:
pending resource-admission waits can last until its hard deadline, so the Local
controller must inspect them rather than promise automatic parking. Do not invent
new experiments or weaken benchmark coverage to occupy idle hardware.

## Eight-hour reports and recovery

Eight hours is a soft report cadence, not a task or batch execution limit. The
owner allows approved Local work to run continuously for up to 24 elapsed hours
per cycle on existing resources; a healthy job can span several reports. Keep
all comparisons and report actual partial/running work rather than cut the run. The separate native job/attempt and
harness total deadlines still apply, using the host monotonic clock. Reboot,
host changes and uncertain process identity require reconciliation, rather than
resetting the clock or consuming a fresh budget. A batch that completed before
its deadline stays completed when inspected later.

Keep the driver on the execution host in an existing `tmux` session or an authorized
`nohup` invocation if SSH disconnects are expected. No background service is
installed by reading the skill. The Linux watchdog has its own deadline, responds
to worker death, kills the native process group, retains its receipt when possible
and holds ownership locks until cleanup. A command that leaves background
children after its foreground launcher exits is interrupted and cannot qualify;
scorer replay also rejects that result despite a zero launcher exit code.
Commands must remain in their foreground process group. Deliberately detached
sessions/daemons, privileged adversarial jobs and multi-host physical fencing
need an actually authorized native cgroup/OS/provider mechanism outside this
lightweight harness. Docker/container execution is excluded; missing support
holds only operations that require that capability.

Validate a draft and print its canonical digest without starting jobs:

```bash
python3 "$SKILL_DIR/scripts/run_harness.py" draft-harness.json \
  --root "$PROJECT_DIR" --freeze > reviewed-harness.json
python3 "$SKILL_DIR/scripts/run_harness.py" reviewed-harness.json \
  --root "$PROJECT_DIR"
```

Execute only the already authorized exact finite scope, on the GPU host:

```bash
python3 "$SKILL_DIR/scripts/run_harness.py" reviewed-harness.json \
  --root "$PROJECT_DIR" --execute --approved-plan-digest REVIEWED_SHA256
```

The same command resumes the same batch. It verifies retained receipts and output
hashes, reconciles `/proc` PID/start-time/boot identities, reuses completed tasks
and keeps live jobs. A persisted dispatch intent with no provable process/result
stays `reconciliation_required`; it is never an automatic retry. Lost workers can
leave partial outputs; retain and investigate them. Do not delete state/locks or
invent a new run ID as a recovery shortcut. Apply existing confirmation policy.

`--stop-after-report` hands off the driver at the next boundary while existing
workers retain their deadlines/locks; restart with the same command to admit
further ready work. Do not add this flag for ordinary continuous execution: leave
the driver running to admit ready tasks across report boundaries.

Before freezing, inspect both outer `total_wall_seconds` and inner native
`wall_time_seconds`/`attempt_timeout_seconds`. Reporting 28800 must not become an
implicit eight-hour timeout in either layer. Choose measured/estimated task bounds
and overhead within the remaining up-to-86400-second cycle; retain actual GPU/task
time, spend, attempts and lease bounds. Do not guess those from 24 wall hours.
For old eight-hour plans record the owner policy update, reconcile live jobs and
prepare any required pending operational plan without modifying active digests,
watchdogs, receipts or cumulative counters.
`--status` reads the last retained state and launches nothing; it labels that
observation rather than claiming newly checked liveness.

### Retained artifacts and cost controls

Under `runs/harness/<batch_id>/`, retain `plan.json`, atomically replaced
`state.json`, `events.jsonl`, final/current `report.json`, `reports/window-*.json`
and each task's actual process/context/result/worker logs. Native attempt/run
receipts remain at their own frozen paths, with complete stdout/stderr, output
refs, failed attempts and watchdog refs. The scheduler verifies the canonical
run/attempt identities, actual declared outputs and receipt hashes. Reports
always retain `gate_advanced: false` and `scientific_result_verified: false`;
the agent must perform G01/E04/native scientific acceptance and human handoff.

The scheduler makes zero LLM calls. Reuse a small number of coding/reading agents
and let the process pool wait/dispatch. Completed task IDs do not repeat on
resume; share already qualified immutable baselines under their actual contracts.
Hash large files in bounded 1 MiB buffers, once per unique output per verification
boundary. Staging tries an isolated filesystem reflink, falling back to a normal
copy; it never uses writable hard links into pinned sources. This can reduce
checkpoint/data copying when the host filesystem supports copy-on-write.

Reports give elapsed/remaining wall time and the union of per-device task
ownership intervals (`gpu_device_occupied_seconds`), so overlapping jobs do not
double-count that duration. This measures reservation time, including staging,
not GPU utilization or paid billing. The planned native task-time bound is shown
separately. No price, total cost saving or GPU speedup is invented. Actual
GitHub/HF pushes remain the agent's authorized delivery work with readback,
not an automatic upload performed by this executor.
At each boundary and finite-queue completion, the local agent follows
[repository-round-trips.md](repository-round-trips.md)'s result-packet contract:
collect a coherent snapshot, record E04 status and unfinished work/budgets, push
to the saved project target, verify remote content and give the human a pinned
repo/commit/path for web analysis. A report with running jobs is a window handoff,
not a finished queue. Web-proposed code never mutates those active attempts.

## Engineering verification boundary

Use short CPU-only engineering commands to verify real overlap, dependency wait,
window continuation, stable IDs, hard deadlines, missing-output/failed dependency
handling, worker-death cleanup, mutable-asset locks, bounded-memory hashing and
CLI validation. Hardware doubles test resource admission and profile bindings;
they are not proof of live GPU throughput or SSH deployment. Running these tests
does not run research, qualify a method, create a benchmark or satisfy E04.

Primary interfaces checked 2026-10-04: [Python subprocess](https://docs.python.org/3/library/subprocess.html),
[Python fcntl](https://docs.python.org/3/library/fcntl.html),
[NVIDIA SMI](https://docs.nvidia.com/deploy/nvidia-smi/index.html).
