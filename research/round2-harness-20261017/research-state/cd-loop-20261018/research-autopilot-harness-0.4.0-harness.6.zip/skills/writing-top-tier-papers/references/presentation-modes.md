# Paper presentation modes

Treat presentation as a choice about emphasis and wording. Keep the operation, venue profile, evidence eligibility and completion state independent of that choice.

## Select and record

| Mode | Reader and output | Shared evidence rule |
|---|---|---|
| `formal-paper` — 正式论文版 | Venue-aware manuscript, organized around the contribution and its evidence | State supported claims directly; retain facts that determine their interpretation |
| `internal-strengths-review` — 内部优点呈现版 | Separate internal copy for reviewing how the strongest supported story reads | Foreground strengths and remove defensive rhetoric; retain the same material facts and claim boundaries |

At the first writing intake, offer these two choices once if the user has not chosen. A suitable question is “这篇用正式论文版，还是内部优点呈现版？” Continue evidence inventory and blueprint work while awaiting a preference. If no answer is available, use `formal-paper` and state the default. An explicit request for “内部审核版”, “内部优点呈现版”, or an internal version removing negative writing selects `internal-strengths-review`. A request for both creates two outputs. Reuse prior choices for this paper until the user changes them.

Record the following in the existing paper brief or writing contract, outside manuscript prose:

- `presentation_mode`, or `presentation_modes` when both are requested;
- source manuscript revision and shared evidence snapshot;
- output artifact for each selected mode and the active artifact;
- intended review purpose and unresolved evidence gaps.

These are writing-brief fields, not new experiment states or harness configuration. Keep a missing venue provisional. If the user only asks to add or explain this mode, update or explain the workflow without inventing a paper. If a manuscript is needed but not identified, resolve that input before rewriting.

## Internal strengths pass

1. Identify the strongest thesis already supported by the claim–evidence matrix. Lead with the problem, contribution and measured or derived outcome.
2. Order sections and paragraphs by the argument. Compress repeated caveats, apologetic self-assessment and speculative reviewer objections. Remove abandoned draft history and irrelevant debugging chronology from article prose.
3. Replace defensive framing with concrete descriptions of what the method does and what the evidence establishes. Keep qualifications that change scope next to the claim they qualify.
4. Report material null, negative and contradictory findings in neutral factual language. Keep relevant comparison conditions, unfavorable rows, uncertainty and denominators. A material boundary can be stated concisely without self-deprecation.
5. Place secondary detail according to the verified venue contract. Preserve the full underlying result matrix and leave evidence that changes the headline interpretation in the main text.
6. Check every edited claim against the unchanged evidence snapshot. Apply the safe prose revision invariants in [evidence-citations-prose.md](evidence-citations-prose.md): factual polarity, numbers, units, mathematical meaning, causal strength, population, assumptions, citations and anonymity.

| Requested change | Apply this transformation |
|---|---|
| Remove apologetic or repetitive negative wording | State the supported result directly; remove the rhetorical self-assessment |
| Emphasize the strongest contribution | Move its supported claim and evidence earlier; retain its scope |
| Remove a poor result that changes the main claim | Retain the result, use neutral wording and narrow the claim to the supported conclusion |
| Turn an unfavorable outcome into a “trade-off” | Use that description only when comparable evidence establishes both opposing quantities |

Do not increase claim strength by changing selection, deleting contrary measurements, presenting a chosen seed as the full result, or turning an uncertain effect into a demonstrated improvement. A request to remove negative writing authorizes a presentation pass, not changes to the scientific record.

## Separate copies and comparison

Retain the source manuscript as an unchanged artifact or recoverable revision. Write the internal copy to a distinct path such as `paper.internal-strengths-review.tex`, `.docx` or `.md`. Label it “Internal review — strengths presentation” in its artifact metadata and handoff. Keep workflow labels and editing instructions outside article prose. Do not overwrite the formal artifact with this copy.

When both are requested, create `paper.formal.<ext>` and `paper.internal-strengths-review.<ext>` from the same retained source revision, claim IDs and evidence snapshot. Use the actual authoring format and requested scope; do not fabricate absent sections, figures or results. A diagnosis or planning-only request still produces no manuscript edits.

Deliver the selected artifact or artifacts plus a compact comparison record:

| Source location / claim ID | Original framing | Revised framing | Reason | Material facts and scope check |
|---|---|---|---|---|

Show the significant presentation changes, retained material findings and unresolved gaps. Keep this record outside the manuscript. For a single-mode request, compare its changes with the retained source; for both modes, align the two versions by section and claim ID. Complete the relevant citation, consistency and render checks for each generated artifact. Finishing an internal review copy means finishing that requested presentation task, not scientific validation or submission clearance.

Switching modes changes the selected output in the brief. It does not change evidence eligibility, promote the internal copy to a formal submission, publish it, or trigger experiments. On new evidence, refresh every affected version and its dependent figures or captions; label stale artifacts and preserve their lineage. Use a separately authorized formal revision before any external release.
