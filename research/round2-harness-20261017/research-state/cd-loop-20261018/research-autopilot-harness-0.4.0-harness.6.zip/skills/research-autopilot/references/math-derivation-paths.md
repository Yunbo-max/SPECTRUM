# Reusable derivation paths

These paths reconstruct mathematical dependencies from papers; they are not
claims about the authors' private discovery chronology. They illustrate how to
compose operations in [math-operation-graph.md](math-operation-graph.md), not recipes that
establish novelty. Source IDs and reading scope are in [math-paper-atlas.md](math-paper-atlas.md).

## P01. A constraint produces a distribution and an algorithm

**Entry:** an update budget is meaningful, but a mixing coefficient is arbitrary.
**Path:** B01 → D01 → D02 → D03 → C04. Examples: S02, S03, S20.

For a fixed reference `q`, maximize `E_p[r]` with `KL(p||q)<=epsilon`
and normalization. Interior stationarity yields
`p_lambda(a)=q(a) exp(r(a)/lambda)/Z(lambda)` for `lambda>0`.
The budget chooses the multiplier only when the constraint is active; an
unconstrained optimum, zero budget or degenerate reward requires endpoint logic.
For finite support and fixed rewards, differentiating the partition function
gives `d KL(p_lambda||q)/d lambda = -Var_p(r)/lambda^3`.
This supplies a search direction, not permission to drop `Z`.

**Branch:** if moments are estimated, audit finite-data error and support. If the
policy family cannot represent this distribution, analyze projection error.
**Prediction:** reward rescaling `r→c r`, `lambda→c lambda` preserves this
distribution at the same budget. A finite neural update need not preserve it.

## P02. Eliminate a nuisance normalizer only where it cancels

**Entry:** a latent reward and a policy seem to require separate fitting.
**Path:** D02 → B01 → B02 → H01 → H03. Example: S02.

Invert the Gibbs relation to get `r(x,y)=beta log(p(y|x)/q(y|x))
+ beta log Z(x)`. In a same-prompt Bradley–Terry preference difference,
the two `log Z(x)` terms cancel. Substitute the remaining log-ratios into
the preference likelihood to obtain a directly trainable policy objective.

**Branch:** cancellation fails across different prompts or a feedback model
that depends on absolute reward offsets. The reduction requires the preference
model, support and representability assumptions; it does not equate training
trajectories. **Prediction:** adding a shared prompt-dependent reward offset
leaves these pairwise preference probabilities unchanged.

## P03. A tighter bound sends you back to the estimator

**Entry:** increasing importance samples tightens a variational bound.
**Path:** C01 → E01 → E06 → C05 → C06; then E03 or B03 if justified.
Example: S04; estimator alternatives are illustrated by S05/S06, not proved by S04.

Let the gradient estimator's mean be `m_K` and standard deviation `s_K`.
Compare their orders separately: `m_K=O(K^-1)` and `s_K=O(K^-1/2)`
would give a shrinking `O(K^-1/2)` SNR despite decreasing variance.
Rainforth et al. derive the relevant generative/inference-block asymptotics
under moment and nondegeneracy assumptions. Account for the replication count
and total budget, not only `K`.

**Branch:** if the target gradient itself is correct but noisy, redesign the
estimator. If the surrogate favors an unwanted solution, return to C01/B01.
**Prediction:** the two parameter blocks can respond differently to increasing
`K`. This is not a universal statement that tighter bounds perform worse.

## P04. Decompose a gradient before removing a term

**Entry:** a pathwise Monte Carlo gradient has persistent noise near a solution.
**Path:** E01 → E02 → E03 → E06, or B05 → E04. Examples: S05, S06.

For `z=T_phi(epsilon)`, the derivative of `log p(x,z)-log q_phi(z)`
splits into a path term and an explicit score term. The latter has zero mean
under `q_phi` with the usual support/integrability conditions. Removal can
preserve the expected gradient. But if `g=u+v`, then
`Var(g)=Var(u)+Var(v)+2 Cov(u,v)`; deleting a zero-mean `v` is not
universally beneficial. In contrast, `E[g|F]` conditions the whole estimator
and satisfies the total-covariance inequality.

**Branch:** for discrete `z`, a differentiable relaxation alone changes the
estimator's expectation. REBAR adds conditional control-variate corrections.
**Prediction:** compare bias and covariance as well as variance; test the
posterior-matching limit separately from far-from-optimum behavior.

## P05. Separate output coordinates from objective weighting

**Entry:** two denoising parameterizations give different training behavior.
**Path:** A01 → A05 → A06 → A03 → A04/H05 if adaptive. Examples: S13, S15.

Write `D(x,sigma)=a(sigma)x+b(sigma)F(c(sigma)x,sigma)`. Then
`lambda ||D-y||^2 = lambda b^2 ||F-(y-a x)/b||^2` when `b!=0`.
Derive input/target variances to choose scaling; derive the effective weight
`lambda b^2` separately. In DDPM, rewriting a Gaussian KL as noise-prediction
MSE retains timestep weights; dropping those weights changes the objective.

**Branch:** equalized magnitudes but unequal directional progress suggests D05,
not more scalar normalization. Adaptive trainable scales require A04.
**Prediction:** holding the effective weighting fixed separates representation
effects from a change of which noise levels dominate training.

## P06. Move compute without silently changing the objective

**Entry:** a sum `L=sum_t E[L_t]` has expensive or uneven contributions.
**Path:** A03 → B03 → E06 → B03. Example: S14.

With `t~p`, use `L_t/p_t` to preserve the sum. Minimizing its scalar second
moment gives `p_t proportional to sqrt(E[L_t^2])` when costs are equal and
the relevant moments exist. Minimizing gradient variance instead uses
`sqrt(E[||g_t||^2])`; this is a different allocation problem. Nonuniform costs
require a new budget derivation.

**Branch:** if some `p_t=0` where contributions are nonzero, restore support.
If sampling is changed without the compensating weight, return to A03 and
analyze the new objective. **Prediction:** unbiasedness of the estimator can
coexist with substantially different optimization variance and compute cost.

## P07. Derive a tractable metric from tensor structure

**Entry:** curvature helps conceptually but the full matrix is too costly.
**Path:** D04 → D05 → D06 → H05. Examples: S07, S08.

A layer gradient has an outer-product structure, so vectorization gives
Kronecker structure inside its second moment. Distinguish the exact identity
from the approximation `E[A tensor B] approximately E[A] tensor E[B]`.
Use a factored operator only after specifying the approximation and damping.
Shampoo supplies another tensor-based route with mode-wise accumulated metrics;
it is not simply the same Fisher approximation under another name.

**Branch:** if a factor is singular, analyze regularization and inverse roots.
**Prediction:** directional conditioning and compute/storage change; matched
scalar learning-rate controls help separate these effects. Convex regret bounds
do not prove global convergence of a nonconvex neural training run.

## P08. Turn a kernel computation into recurrent state

**Entry:** pairwise sequence interactions dominate cost.
**Path:** F01 → F02 → F03; include C04 for finite feature approximations.
Examples: S10, S11.

For `k(q,k)=phi(q)^T phi(k)`, accumulate
`S_t=sum_{i<=t} phi(k_i) v_i^T` and `z_t=sum_{i<=t} phi(k_i)`.
Then `y_t=phi(q_t)^T S_t / (phi(q_t)^T z_t)` where the denominator is
positive. Associativity is exact for that kernel and feature map. Approximating
a kernel with random features is a separate error; selecting a different kernel
is a change of model.

**Branch:** a nonseparable mask or query-dependent historical update may prevent
this sufficient statistic. **Prediction:** fixed feature dimension gives bounded
state size in sequence length, but feature capacity and accumulated numerical
error remain meaningful axes.

## P09. Parallelize a recurrence through ordered low-rank products

**Entry:** a useful sequential update appears difficult to batch.
**Path:** F03 → F04 → C04. Example: S18.

Write the DeltaNet state update as
`S_t=S_{t-1}(I-beta_t k_t k_t^T)+beta_t v_t k_t^T`.
Expand a block as ordered products of identity-plus-rank-one factors. A compact
WY-like representation and triangular computation can evaluate the block.
Order must be retained; these factors are not generally orthogonal reflectors.

**Branch:** an additional nonlinear state dependence may destroy the factor
structure. **Prediction:** compare against the same sequential recurrence for
numerical agreement before claiming a speed benefit. Algebraic equivalence,
hardware efficiency and a new model family are separate claims.

## P10. Replace unrolled differentiation with a root sensitivity solve

**Entry:** many repeated layers approach an equilibrium.
**Path:** G01 → G02 → C04, with G03 for solver stability. Example: S12.

From `z*=f(z*,theta)`, obtain
`(I-J_z f) dz*/dtheta = partial_theta f` when the implicit-function
conditions hold. Backpropagation becomes an adjoint linear solve instead of
storing an arbitrarily deep unroll. Inspect forward residual, backward residual
and conditioning of `I-J_z f`.

**Branch:** a root may exist while naive iteration diverges, and a near-singular
Jacobian may amplify tiny residuals. Change the solver or problem accordingly.
**Prediction:** saved activation memory does not imply low total compute;
gradient error should depend on residuals and conditioning.

## P11. Solve the easy dynamics exactly, approximate the residual

**Entry:** a generic ODE solver ignores known linear structure.
**Path:** G04 → G05 → C05 → C06. Example: S16.

For `dx/dt=a(t)x+b(t)epsilon_theta(x,t)`, apply variation of constants.
In the diffusion setting, a monotone `lambda=log(alpha/sigma)` transforms
the solution to a known linear term plus an exponentially weighted residual
integral. Approximate that residual with a controlled expansion in `lambda`.

**Branch:** a time map that is not invertible or a nonsmooth residual invalidates
the corresponding order argument. **Prediction:** compare error at matched
function evaluations and check observed order in its asymptotic regime. Higher
formal order alone does not guarantee better few-step samples.

## P12. Learn an invariant map instead of repeatedly solving the flow

**Entry:** the desired output is a trajectory endpoint.
**Path:** G05 → G06 → H02 → H05, with C04 for pair-generation error.
Example: S17.

Define a map constant along a trajectory, `f(x_t,t)=x_epsilon`, and impose
`f(x,epsilon)=x`. A skip parameterization can enforce the boundary exactly.
Neighboring trajectory pairs provide a consistency relation; approximate
solvers/scores and moving targets add distinct errors and derivative choices.

**Branch:** consistency without anchoring admits uninformative constant maps.
Estimated pairwise consistency does not automatically identify the correct
global flow. **Prediction:** boundary behavior and solver-pair error provide
tests beyond a final generation score.

## P13. A population decomposition reveals what finite data removes

**Entry:** a likelihood-based loss constrains observed relative scores but
leaves surprising changes in absolute probability.
**Path:** B01 → H03 → H02 → B06 → H04 → D01. Example: S19.

Separate the population preference objective into evidence-dependent and
regularizing parts. Inspect which terms survive empirical restriction. If the
unobserved complement matters, retain its aggregate probability
`p(H)=1-sum_{y not in H}p(y)` rather than treating it as absent. Analyze what
the resulting coarse-grained optimum preserves and which internal probabilities
remain unconstrained. Then compare optimizer/regularizer growth near zero
probabilities to determine whether an optimum can exist.

**Branch:** a result over unrestricted probability vectors does not directly
prove the same result for a shared neural parameterization. **Prediction:**
aggregate mass and within-group mass can behave differently even when pairwise
observed losses match.

## P14. Use a counterexample to refine the mechanism, then construct a method

**Entry:** a plausible universal explanation predicts the wrong response to an
intervention. **Path:** H06 → C04 → A05/D05 → H05. Example: S09.

Change the allegedly causal quantity while preserving the proposed benefit as
far as the setup permits, or construct a case satisfying the claim's premises.
If the explanation fails, isolate the missing mathematical object: an activation
Jacobian, its projection components, a scale factor or a curvature direction.
Derive a narrower account and use it to design an alternative normalization or
update, then predict a contrast against the original explanation.

**Branch:** a counterexample to one explanation is not proof of its replacement.
**Prediction:** demand an intervention that separates the accounts, not merely
another benchmark improvement. This path explicitly couples mathematical and
empirical discovery; either side can initiate the next round.

## Choosing and extending paths

These 14 paths are starting points. Choose from the unresolved object, not the
prestige of the example paper. A genuine new path might connect a support defect
to a constraint, a symmetry to an information acquisition rule, or an implicit
gradient to a structured solve. Supply the connecting derivation and conditions.
Do not advertise a concatenation of known operations as novel without identifying
the new mathematical consequence or algorithmic capability and checking prior art.
