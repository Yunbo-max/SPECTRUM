"""Synthetic control-flow fixtures, not scientific or model-compliance evidence."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'

class ReasoningTests(unittest.TestCase):
    def setUp(self):
        path = SCRIPTS / 'research_reasoning.py'
        self.assertTrue(path.is_file(), 'new-method trace and decision checker is missing')
        spec = importlib.util.spec_from_file_location('reasoning_under_test', path)
        self.m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.m)
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.n = 0
        self.raw = self.ref('fixture observation; not an experiment receipt')

    def ref(self, value):
        self.n += 1
        p = self.root / ('artifact-%d.json' % self.n)
        p.write_text(value if isinstance(value, str) else json.dumps(value, sort_keys=True))
        return {'path': p.name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}

    def trace(self):
        return dict(kind='mathematical_trace', schema_version=1, trace_id='trace',
            candidate_id='candidate', revision=1,
            objects=[dict(id='loss', definition='L(theta) is differentiable')],
            assumptions=[dict(id='positive', statement='c>0 is fixed', status='established', evidence_refs=[self.raw])],
            obligations=[], steps=[
                dict(id='scale', operation='A02', inputs=['loss'], assumptions=['positive'],
                     transition='Multiply the specified objective by the fixed scalar c',
                     derivation='grad(c L)=c grad L because c does not depend on theta',
                     output='scaled gradient = c grad L', validity='exact', obligations=[]),
                dict(id='update', operation='H05', inputs=['scale'], assumptions=['positive'],
                     transition='Insert the scaled gradient into the actual SGD update',
                     derivation='theta_next=theta-(eta/c)c grad L=theta-eta grad L',
                     output='SGD iterates agree after learning-rate compensation', validity='exact', obligations=[])],
            branches=[], frontier=[], method=dict(rule='Use eta/c for the scaled SGD objective', from_steps=['update']),
            prediction=dict(ours='Compensated SGD iterates agree in exact arithmetic',
                rival='Keeping eta unchanged generally changes iterates',
                distinguishing_test='Compare compensated and uncompensated updates from the same state',
                falsifier='An admissible exact-arithmetic compensated SGD counterexample refutes equivalence'))

    def decision(self, previous=None, **changes):
        d=dict(kind='research_decision', schema_version=1, decision_id='decision-%d' % self.n,
            goal_id='goal', candidate_id='candidate', family_id='scaling', mechanism='fixed rescaling and actual updates',
            previous_ref=previous, review_after_rounds=3, evidence_change='engineering_only',
            evidence_refs=[self.raw], objective_change='No new task-quality evidence',
            if_repairs_free='Compare the corrected update against the optimized exact baseline',
            options=[dict(id='repair', action='repair', value_if_success='Unlock the baseline comparison',
                          cost='measured in the separate execution receipt', unlocks=['compare']),
                     dict(id='compare', action='compare', value_if_success='Resolve trajectory equivalence', cost='bounded diagnostic')],
            selected_option='repair', selected_task_ids=['task'],
            why_selected='The baseline comparison still depends on the broken update',
            stop_or_pivot='Retire if an exact optimized baseline removes the proposed advantage',
            facts=[], math_trace_ref=self.ref(self.trace()))
        d.update(changes)
        return d

    def adaptive_decision(self):
        d=self.decision(selected_option='compare');d['schema_version']=2
        trajectory=dict(kind='adaptive_trajectory',schema_version=1,trajectory_id='t',goal_id='goal',revision=1,
            previous_ref=None,routes=[dict(id='r',candidate_id='candidate',trace_ref=d['math_trace_ref'],
            prior=dict(priority='medium',basis='Sourced local equivalence',uncertainty='Empirical benefit unknown',evidence_refs=[self.raw]),
            decision_value='high',cost='one bounded CPU check',availability='ready',
            experiments=[dict(id='e',question='Does invariance hold?',target_step_ids=['update'],contrast='same-state controls',
                analysis_plan='Exact arithmetic comparison',scope='development',independent_unit='problem',sampling_plan='fixed common inputs',
                budget='one task',outcome_actions=dict(supports='confirm',refutes='backtrack',inconclusive='repeat',invalid='repair'))])],
            observations=[],selection=dict(route_id='r',action='experiment',experiment_id='e',task_ids=['task'],
                reason='Test prediction',alternative='Only this bounded hypothesis selected; rival control shares task',based_on_observation_ids=[]))
        d['trajectory_ref']=self.ref(trajectory)
        return d

    def test_new_method_requires_adaptive_binding(self):
        d=self.decision();t=dict(task_id='task',research_scope='method',reasoning_ref=self.ref(d))
        self.assertIn('adaptive_trajectory_required',self.codes(self.m.check_task(self.root,t)))

    def test_adaptive_decision_cannot_execute_different_tasks(self):
        d=self.adaptive_decision();d['selected_task_ids']=['different']
        self.assertIn('trajectory_task_mismatch',self.codes(self.m.check_decision(self.root,d)))

    def test_adaptive_decision_cannot_borrow_other_trace(self):
        d=self.adaptive_decision();d['math_trace_ref']=self.ref(dict(self.trace(),revision=2))
        self.assertIn('trajectory_trace_mismatch',self.codes(self.m.check_decision(self.root,d)))

    def codes(self, report):
        return {g['code'] for g in report['gaps']}

    def test_complete_trace_never_certifies_mathematics(self):
        r=self.m.check_trace(self.root,self.trace())
        self.assertEqual(r['status'],'record_complete');self.assertFalse(r['mathematical_truth_verified'])
        self.assertEqual(r['operations_used'],['A02','H05'])

    def test_single_relevant_operation_not_48_is_enough(self):
        t=self.trace();t['steps']=t['steps'][:1];t['method']['from_steps']=['scale']
        self.assertEqual(self.m.check_trace(self.root,t)['status'],'record_complete')

    def test_boolean_math_verified_does_not_replace_trace(self):
        r=self.m.check_trace(self.root,{'math_verified':True})
        self.assertEqual(r['status'],'record_incomplete');self.assertFalse(r['mathematical_truth_verified'])

    def test_undefined_input_is_a_gap(self):
        t=self.trace();t['steps'][1]['inputs']=['unknown']
        self.assertIn('unknown_input',self.codes(self.m.check_trace(self.root,t)))

    def test_forward_edge_or_cycle_is_not_a_derivation(self):
        t=self.trace();t['steps'][0]['inputs']=['update']
        self.assertIn('unknown_input',self.codes(self.m.check_trace(self.root,t)))

    def test_duplicate_step_identity_rejected(self):
        t=self.trace();t['steps'][1]['id']='scale'
        self.assertIn('duplicate_identity',self.codes(self.m.check_trace(self.root,t)))

    def test_missing_intermediate_algebra_rejected(self):
        t=self.trace();t['steps'][0]['derivation']=''
        self.assertIn('missing_derivation',self.codes(self.m.check_trace(self.root,t)))

    def test_unknown_operation_requires_justified_custom_move(self):
        t=self.trace();t['steps'][0]['operation']='Z99'
        self.assertIn('unknown_operation',self.codes(self.m.check_trace(self.root,t)))
        t['steps'][0].update(operation='custom:rescale',operation_justification='This local identity extends the catalog with the displayed derivation')
        self.assertEqual(self.m.check_trace(self.root,t)['status'],'record_complete')

    def test_false_assumption_cannot_support_selected_method(self):
        t=self.trace();t['assumptions'][0]['status']='false'
        self.assertIn('false_condition_on_method_path',self.codes(self.m.check_trace(self.root,t)))

    def test_conditional_assumptions_stay_conditional(self):
        t=self.trace();t['assumptions'][0]['status']='conditional'
        r=self.m.check_trace(self.root,t);self.assertTrue(r['conditional']);self.assertFalse(r['mathematical_truth_verified'])

    def test_inherited_assumption_cannot_disappear(self):
        t=self.trace();t['steps'][1]['assumptions']=[]
        self.assertIn('dropped_assumption',self.codes(self.m.check_trace(self.root,t)))

    def test_approximation_requires_error_obligation(self):
        t=self.trace();t['steps'][0]['validity']='approximation'
        self.assertIn('approximation_without_error',self.codes(self.m.check_trace(self.root,t)))

    def test_error_is_carried_through_exact_downstream_algebra(self):
        t=self.trace();t['obligations']=[dict(id='remainder',statement='Taylor remainder bound',status='open',evidence_refs=[])]
        t['steps'][0].update(validity='approximation',obligations=['remainder'])
        self.assertIn('dropped_obligation',self.codes(self.m.check_trace(self.root,t)))
        t['steps'][1]['obligations']=['remainder'];r=self.m.check_trace(self.root,t)
        self.assertEqual(r['status'],'record_complete');self.assertTrue(r['conditional'])

    def test_discharge_requires_real_referenced_evidence(self):
        t=self.trace();t['obligations']=[dict(id='remainder',statement='Bound remainder',status='discharged',evidence_refs=[])]
        self.assertIn('missing_evidence',self.codes(self.m.check_trace(self.root,t)))

    def test_method_must_link_to_actual_steps(self):
        t=self.trace();t['method']['from_steps']=['not-computed']
        self.assertIn('unknown_method_step',self.codes(self.m.check_trace(self.root,t)))

    def test_rival_prediction_and_falsifier_required(self):
        for key in ['rival','distinguishing_test','falsifier']:
            t=self.trace();t['prediction'][key]=''
            self.assertEqual(self.m.check_trace(self.root,t)['status'],'record_incomplete')
        t=self.trace();t['prediction']['rival']=t['prediction']['ours']
        self.assertIn('identical_predictions',self.codes(self.m.check_trace(self.root,t)))

    def test_branch_backtrack_and_frontier_are_bound(self):
        t=self.trace();t['branches']=[dict(at='update',choice='backtrack',targets=['scale'],reason='Revisit scale after a counterexample')]
        t['frontier']=[dict(step_id='update',question='Does clipping preserve equivalence?',next_action='Derive the clipped update')]
        self.assertEqual(self.m.check_trace(self.root,t)['status'],'record_complete')
        t['branches'][0]['targets']=['missing'];self.assertIn('unknown_branch_target',self.codes(self.m.check_trace(self.root,t)))

    def test_unchanged_prefix_can_be_reused(self):
        old=self.trace();t=copy.deepcopy(old);t.update(revision=2,parent_ref=self.ref(old),reused_steps=['scale','update'])
        self.assertEqual(self.m.check_trace(self.root,t)['status'],'record_complete')

    def test_changed_prefix_cannot_borrow_old_review(self):
        old=self.trace();t=copy.deepcopy(old);t.update(revision=2,parent_ref=self.ref(old),reused_steps=['scale'])
        t['steps'][0]['derivation']='different construction'
        r=self.m.check_trace(self.root,t);self.assertIn('changed_reused_prefix',self.codes(r));self.assertIn('update',r['invalidated_step_ids'])

    def test_changed_assumption_invalidates_descendants(self):
        old=self.trace();t=copy.deepcopy(old);t.update(revision=2,parent_ref=self.ref(old),reused_steps=['update'])
        t['assumptions'][0]['statement']='c may depend on theta'
        r=self.m.check_trace(self.root,t);self.assertIn('update',r['invalidated_step_ids']);self.assertIn('changed_reused_prefix',self.codes(r))

    def test_trace_candidate_binding(self):
        self.assertIn('candidate_mismatch',self.codes(self.m.check_trace(self.root,self.trace(),candidate_id='other')))

    def test_reference_tamper_and_symlink_are_rejected(self):
        r=self.ref(self.trace());(self.root/r['path']).write_text('{}')
        with self.assertRaises(ValueError):self.m.read_ref(self.root,r)
        target=self.root/'target';target.write_text('abc');(self.root/'link').symlink_to(target)
        with self.assertRaises(ValueError):self.m.read_ref(self.root,dict(path='link',sha256=hashlib.sha256(b'abc').hexdigest()))

    def test_decision_requires_alternative_and_parent_value(self):
        d=self.decision();d['options']=d['options'][:1]
        self.assertIn('missing_alternative',self.codes(self.m.check_decision(self.root,d)))
        d=self.decision();d['if_repairs_free']=''
        self.assertIn('missing_parent_value',self.codes(self.m.check_decision(self.root,d)))

    def test_repair_requires_concrete_unlock(self):
        d=self.decision();d['options'][0]['unlocks']=[]
        self.assertIn('repair_without_unlock',self.codes(self.m.check_decision(self.root,d)))

    def test_selected_task_is_bound_not_just_a_next_action_sentence(self):
        self.assertIn('task_not_selected',self.codes(self.m.check_decision(self.root,self.decision(),task_id='other-task')))

    def test_new_hashes_and_issue_names_do_not_reset_family_effort(self):
        prev=None
        for i in range(4):
            self.raw=self.ref('new repair evidence %d'%i)
            d=self.decision(prev,decision_id='r%d'%i,issue='different-%d'%i);prev=self.ref(d)
        r=self.m.check_decision(self.root,d)
        self.assertEqual(r['family_rounds'],4);self.assertEqual(r['rounds_without_goal_evidence'],4)
        self.assertIn('strategy_reassessment_due',self.codes(r));self.assertEqual(r['route'],'analysis')

    def test_reassessment_does_not_erase_total_or_original_evidence(self):
        prev=None
        for i in range(4):
            d=self.decision(prev,decision_id='r%d'%i,strategy_reassessment='The remaining one repair unlocks the frozen comparison; compare next, not another repair grid')
            prev=self.ref(d)
        r=self.m.check_decision(self.root,d);self.assertEqual(r['family_rounds'],4)
        self.assertEqual(r['rounds_without_goal_evidence'],4);self.assertEqual(r['status'],'record_complete')

    def test_meaningful_negative_is_progress_not_automatic_project_stop(self):
        p=self.decision(decision_id='old');d=self.decision(self.ref(p),decision_id='new',evidence_change='prediction_refuted',
            evidence_refs=[self.ref('new independently checked counterexample')],objective_change='The universal mechanism is refuted',selected_option='compare')
        r=self.m.check_decision(self.root,d);self.assertEqual(r['family_rounds'],2);self.assertEqual(r['rounds_without_goal_evidence'],0)
        self.assertEqual(r['route'],'compare');self.assertFalse(r['scientific_certification'])

    def test_relabeling_reused_evidence_is_not_new_progress(self):
        p=self.decision(decision_id='p',evidence_change='boundary',objective_change='Boundary characterized')
        d=self.decision(self.ref(p),decision_id='d',evidence_change='boundary',objective_change='Same observation renamed')
        self.assertEqual(self.m.check_decision(self.root,d)['rounds_without_goal_evidence'],1)

    def test_refuted_mechanism_cannot_continue_by_renaming_issue(self):
        d=self.decision(facts=[dict(name='mechanism_refuted',value=True,evidence_refs=[self.raw])])
        self.assertIn('retire_or_reframe',self.codes(self.m.check_decision(self.root,d)))
        d['options'].append(dict(id='retire',action='retire',value_if_success='Retain refutation; free effort for next hypothesis',cost='no experiment'))
        d['selected_option']='retire';self.assertEqual(self.m.check_decision(self.root,d)['route'],'retire')

    def test_parking_is_not_scientific_refutation(self):
        d=self.decision();d['options'].append(dict(id='park',action='park',value_if_success='Preserve unresolved lead',cost='none'))
        d['selected_option']='park';r=self.m.check_decision(self.root,d);self.assertEqual(r['route'],'park');self.assertFalse(r['scientific_certification'])

    def test_pause_cannot_be_overridden(self):
        r=self.m.check_decision(self.root,self.decision(),paused=True);self.assertEqual(r['route'],'preserve_pause')

    def test_same_mechanism_cannot_reset_family_via_new_id(self):
        p=self.decision(decision_id='old');d=self.decision(self.ref(p),family_id='renamed',decision_id='new')
        self.assertIn('renamed_family',self.codes(self.m.check_decision(self.root,d)))

    def test_changed_threshold_cannot_silently_hide_stagnation(self):
        p=self.decision(decision_id='old');d=self.decision(self.ref(p),review_after_rounds=99,decision_id='new')
        self.assertIn('changed_review_policy',self.codes(self.m.check_decision(self.root,d)))

    def test_task_check_requires_trace_only_for_method_scope(self):
        task=dict(task_id='task',research_scope='method',reasoning_ref=self.ref(self.adaptive_decision()))
        self.assertEqual(self.m.check_task(self.root,task,candidate_id='candidate',goal_id='goal')['status'],'record_complete')
        d=self.decision();d.pop('math_trace_ref');task['reasoning_ref']=self.ref(d)
        self.assertEqual(self.m.check_task(self.root,task)['status'],'record_incomplete')
        task['research_scope']='diagnostic';self.assertEqual(self.m.check_task(self.root,task)['status'],'record_complete')
        self.assertEqual(self.m.check_task(self.root,{'task_id':'legacy'})['status'],'legacy_unreviewed')

    def test_actual_method_task_rejects_missing_decision(self):
        self.assertEqual(self.m.check_task(self.root,dict(task_id='task',research_scope='method'))['status'],'record_incomplete')

    def test_legacy_history_not_rewritten(self):
        d=self.decision();before=copy.deepcopy(d);self.m.check_decision(self.root,d);self.assertEqual(d,before)

    def test_method_dispatch_not_allowed_after_park(self):
        d=self.decision();d['options'].append(dict(id='park',action='park',value_if_success='Preserve lead',cost='none'));d['selected_option']='park'
        task=dict(task_id='task',research_scope='method',reasoning_ref=self.ref(d))
        self.assertIn('method_after_closure',self.codes(self.m.check_task(self.root,task)))

    def test_binary_evidence_is_hashed_without_decoding_or_loading_entire_file(self):
        p=self.root/'binary.dat';p.write_bytes(b'\x00\xff'*1024)
        ref=dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
        t=self.trace();t['assumptions'][0]['evidence_refs']=[ref]
        self.assertEqual(self.m.check_trace(self.root,t)['status'],'record_complete')

    def test_transitive_trace_refs_are_returned_for_execution_pinning(self):
        d=self.adaptive_decision();ref=self.ref(d);task=dict(task_id='task',research_scope='method',reasoning_ref=ref)
        r=self.m.check_task(self.root,task)
        self.assertIn(d['math_trace_ref'],r['required_input_refs']);self.assertIn(self.raw,r['required_input_refs'])

if __name__=='__main__':unittest.main()
