# Mathematical work products and consequential research choices

Use this contract for every substantive method construction or revision, at each meaningful
research-batch decision, and before expanding a repair family. It complements the
edition's existing experiment, review and state contracts; it does not replace them.
One active expensive candidate is an execution constraint, not a restriction on
cheap reading, derivation or counterexamples about competing explanations.

## Before selecting the mathematical object

[inquiry-generation.md](inquiry-generation.md) defines the v4 framing/competition
entry. Keep leads and hypotheses distinct from constructions; early probes use
explicit diagnostic decisions rather than invented completed mathematics. Ordinary
repairs and prespecified seeds reuse the same frame. Construction work retains the
trace, trajectory and quality requirements below. The inquiry object is embedded in
the existing research_decision, not a second project state.

## Mathematical trajectory, not a checklist

Read math-handoff.md and the relevant part of math-operation-graph.md when proposing
or materially revising a method. The 48 operations are a navigation vocabulary,
not a quota: one relevant operation may suffice and a justified custom operation is
allowed. Operation IDs A01-H06 are mathematical moves, not full-workflow gate IDs.

Save a public, inspectable mathematical work product, not private model scratchpad
or a claim to capture hidden internal reasoning. A concise reconstruction can be
useful if labeled retrospective; never fabricate a contemporaneous history.
Retain objects/domains, assumptions and their evidence/status, selected operations,
input/output links, consequential equations/intermediate steps, exact versus
conditional/approximate/conjectural status, inherited errors, and the resulting
executable rule. Give the nearest rival's prediction, a discriminating experiment
or proof check, and a falsifier. A list of tool names or math_verified=true is not
this artifact. An empirical lead remains a legitimate investigation before its
mathematical explanation exists; do not invent mathematics to fill a template.

Use assets/templates/mathematical-trace.json for machine-checkable bindings, with
long algebra/proofs in referenced project files. Each step explains its transition
and derivation; referencing an appendix is allowed, but the actual appendix must
also be a pinned evidence input. Empty branches/frontier arrays honestly mean none.
Branch, merge, rejected and backtracked paths keep their reasons and conditions.
Only the selected path supports the method. A false condition cannot support that
path; a conditional premise or unresolved approximation keeps the result conditional.
Exact downstream algebra does not erase an earlier approximation obligation.

For revisions, pin parent_ref and identify reused_steps. Retain unchanged prefixes;
changed inputs, assumptions, error obligations or steps invalidate affected
successors, reviews and dependent method/code/evaluation bindings. The helper
reports structural invalidation, not a proof of semantic equivalence or inequivalence.
Resume the unresolved frontier rather than replaying a valid whole derivation.
Do not discard a failed branch to make the final story look inevitable.

## Select work, not just the next repair

At each meaningful batch boundary record a research_decision in the current project
checkpoint/journal's evidence, using assets/templates/research-decision.json. Reuse
unchanged source notes, but update what the new evidence changed. Retain the original
goal, candidate, stable mechanism-family ID, all earlier decisions and actual costs.
Compare the current choice with a real alternative, or explain concretely why no
independent alternative is available. No mandatory candidate pool or numeric
probability of discovery is required.

Answer: if all current engineering problems were repaired for free, what important
result could follow? What exact task/result does this repair unlock? Why is the
chosen action better now than a simpler baseline, another mechanism, source
acquisition, scoped delivery or parking? What would make us stop/pivot? Bind the
selected option to concrete selected_task_ids; a free-text next_action is not an
execution receipt. A missing prerequisite creates an acquisition task, not a
reason to relabel a weak comparator as strong or to manufacture a method PASS.

Track meaningful goal-evidence changes separately from engineering-only progress,
new filenames, new hashes, successful commands and more seeds of the same question.
A supported prediction, valid refutation, useful boundary or now-unlocked decisive
dependency can change the research decision. New positive scores are not required.
Include actual model/reviewer/engineering effort when exposed; unknown is not zero.
A bug can deserve repair without deserving indefinite occupation of the main line.

Set a prospective review_after_rounds cadence for the family. This is a trigger
for a strategy reassessment, not a project time/attempt cap or automatic rejection.
Keep previous_ref tied to the last accepted decision; renamed issues, sessions,
files or hypotheses do not reset cumulative family effort. A reassessment permits
a justified continuation but does not erase spent effort. Reusing the same evidence
under a new filename is not a new goal-evidence change. Preserve meaningful negative
findings. Park means deferred investment; retire means the specified mechanism is
refuted/redundant or explicitly ended. They are not interchangeable scientific claims.

Reviews have separate questions: mathematical validity, empirical validity, and
whether another batch is worth doing for the parent goal. Ask an available reviewer
the investment question explicitly; reviewing serialization or algebra alone does
not answer it. If no independent reviewer is available, mark that limitation and
perform explicit self-analysis without inventing a second actor.

## Bind to the actual task

The shared scripts/research_reasoning.py is read-only and stdlib-only. It checks
identity, selected-step links, inherited conditions/error obligations, prefix reuse,
decision ancestry and action-to-task linkage. It returns record_complete or
record_incomplete with scoped next actions and required_input_refs. Neither outcome
proves mathematical truth, originality, authentic independent review, statistical
validity or that an agent followed the policy. Those need substantive evidence and
review. Do not turn structural success into a scientific PASS.

For new method construction/implementation/comparison tasks set research_scope to
method, reasoning_ref to the actual research_decision, and pin it in input_refs.
The selected decision pins math_trace_ref. Host adapters add all checked transitive
references to immutable task inputs and recheck before new dispatch. They reject a
task not selected by the decision, changed source bytes, another candidate's trace,
or a method investment after park/retire/close_scoped. Changing a plan creates a
versioned task; it never mutates an already running contract.

Use diagnostic for source acquisition, native baseline qualification, unresolved
mathematical leads and evaluator checks; use maintenance for storage/environment
repair. These can proceed without a complete new-method trace. Scope describes the
actual purpose: running a candidate comparison as diagnostic does not waive the
method obligation or create a supported method claim. Evidence repairs may be
necessary; no unrelated work is blocked because one trace is incomplete.

Simple: record research_review with decision_ref in the existing simple_loop
journal, then submit tagged tasks through simple_runner. The event must extend the
last accepted decision and bind the active candidate. Tag repair feedback with the
same family_id. The additive family counter cannot be reset by a new change hash
or issue name; the legacy consecutive counter still has its original local meaning.
An overdue family routes to analysis, not project stop. New snapshots include the
math and decision guidance; old 7/12/14-file source snapshots remain exact and
settleable, never retroactively upgraded.

Chat: record strategy_reasoning with decision_ref in the existing strategy ledger;
new tagged method tasks consume the current accepted selection. The selection can
prioritize a decisive ready comparison ahead of another generic repair, while
existing dependencies, pauses, resource controls, strategy limits and canonical
claim checks still apply. Existing family/usage/diagnostic records remain in force;
this is not a second scheduler or a reset of the strategy ledger. Continue using
the current GitHub-only project cooperation protocol and pinned project registry.

Untagged legacy tasks remain legacy_unreviewed, not retrospectively certified.
Settle running/unknown attempts first. Adopt this policy and its source snapshot at
a quiet boundary with a versioned project migration; keep old pauses, evidence,
exposure, cumulative usage and failed outcomes. Upgrading repository/package bytes
does not update an installed plugin, activate a host, migrate a project or resume it.


## Prior-guided routes and experiment feedback

The library still has 48 reusable operations, 14 composed derivation paths and 20
paper cases; none is a mandatory traversal list, and custom justified operations
remain possible. The reusable operation graph may have cycles. A concrete
mathematical_trace is a topologically ordered DAG of intermediate results, not a
DAG with only 48 vertices: repeat an operation under a fresh step ID as needed.
A backtrack chooses an earlier valid result as the parent of a new branch. It
never creates a backwards proof dependency or rewrites an earlier calculation.
The research loop can repeat; its immutable, versioned work-product dependencies
remain acyclic. Experimental feedback can invalidate an assumption and its
successors; it is not by itself a proof of the theorem's truth or falsehood.

Use an adaptive_trajectory record (assets/templates/adaptive-trajectory.json) for
new method selection. Each route pins its candidate/trace, a sourced initial
prior, an uncertainty statement, expected decision value, cost and availability.
Prior sources can be relevant published paths, checked mathematics, known
counterexamples or native pilot evidence. Analogies are uncertain priors, not
universal laws. Default priorities are ordinal (high/medium/low/unknown): the
helper does NOT compute posterior probabilities, Bayes factors or calibrated
expected information gain. A quantitative Bayesian controller needs a separately
justified likelihood, dependence model and calibration; do not turn pass/fail
counts into such probabilities. For v4, rank eligible routes by expected decision value without using prior
familiarity to break ties. Keep priors visible as evidence, not a penalty on unknown
routes. Explain overrides when cost or a decisive control justifies another route. This is a transparent heuristic, not an optimal policy.

An experiment belongs to a specific route, intermediate step and immutable
contrast/analysis/sampling contract. Before execution state what support,
refutation, inconclusive evidence and invalid execution would change. After each
bounded experimental task, append its attempt identity, exact contract/trace,
terminal outcome, raw evidence and scoped interpretation. Use trajectory_outcome
(assets/templates/trajectory-outcome.json). Include the real host execution receipt
in raw_refs. Account for every earlier observation in the next selection,
including failures. Select the next operation, alternative route, diagnostic,
repeat or confirmation based on that evidence. Park/retire are different from a
technical failure. A failed universal claim is not rescued by averaging in later
successes. Conflicting evidence calls for diagnosis and a versioned question.

Multiple trials may answer one prediction: repetitions/seed batches refine its
precision and do not automatically add hypotheses, independent units or research
cycles. The helper reports attempts, tested questions and unique declared units
separately, without claiming independence or statistical confidence. Inconclusive
results may justify further data or a more discriminating comparison. Invalid
runs justify repair, not scientific refutation. Predeclare precision/futility and
sampling rules appropriate to the question; there is no fixed count of experiments.
Keep development distinct from confirmation, including selection bias from adaptive
path choice. A new seed on an exposed case is not a new untouched condition.

Construction decisions use research_decision schema_version 4 with inquiry and pin trajectory_ref and quality_ref;
math_trace_ref and selected_task_ids must match its selected route. A selected
repair/derivation cannot be dispatched as a new-method empirical comparison. Before
another tagged experiment, the host checks that the new decision consumes its
previous terminal tagged experimental receipts. One task may contain a prespecified
multi-seed batch; running jobs retain their original input pins. Untagged legacy
records remain explicitly unreviewed, not implicitly compliant. New method work
must not be mislabeled diagnostic to bypass these obligations. Missing derivation
is an investigation task, not a global reason to stop other useful work.

Trajectory revisions retain old routes, original priors and every observation as
an immutable prefix. Add a new route for changed mathematics and a new experiment
ID for a changed protocol. Link its trace parent and explicitly reuse valid steps;
never overwrite a failed branch or retune the old confirmation. Entry/adoption
checks enforce record linkage and actual task selection, not honest scope labels,
mathematical truth, authentic independent review or universal agent compliance.

## Checks and limitations

Run the helper with --root PROJECT and one of --trace, --decision, --task or --trajectory followed
by the metadata path. Exit 2 means record_incomplete for this artifact; schedule the
specific missing analysis/acquisition instead of blocking the whole research goal.
Tests must include broken trajectories, dropped errors, renamed repair families,
real task linkage, preservation of negative evidence and legacy migration.
Software tests are not fresh-model behavioral tests: use held-out decision scenarios
with actual independent agents when available, record their choices and reasons,
and do not claim improved long-horizon behavior merely from passing unit tests.

## Goal-linked quality extension

Read [goal-linked-quality.md](goal-linked-quality.md). Version 3 added primary-metric/protocol/obligation binding; v4 constructions preserve it. Early inquiry does not discharge old obligations. Once adopted, do not omit quality history or downgrade the accepted policy. Legacy histories stay unreviewed rather than retroactively certified.
