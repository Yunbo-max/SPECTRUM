"""Bounded runner engineering tests. Only existing Python/fixture tools run."""
import copy
import pathlib
import sys
import tempfile
import time
import unittest
from unittest import mock
from fixtures import C, DIGEST, PACKAGE, ProjectFixture, digest, env, write

try:
    import run_experiments as R
except ModuleNotFoundError:
    R = None


def engineering_plan_fixture(root, *, evidence_mode="developmental", run_id="engineering-run", command=None):
    """Plan a non-evaluation invocation of the existing artifact validator CLI."""
    input_ref = write(root, "engineering/validator-input.json", env("evidence-snapshot", snapshot_id="engineering",
        created_at="2026-09-01T00:00:00Z", cutoff="2026-09-01", artifact_refs=[write(root,"engineering/source.json",{"fixture":True})],
        claim_ids=["engineering-contract"], negative_result_refs=[]))
    entrypoint = root / "engineering/validate_artifact.py"
    entrypoint.write_bytes((PACKAGE / "scripts/validate_artifact.py").read_bytes())
    # Use the real existing CLI from the installed package, with pinned code refs.
    command = command or [sys.executable, str(PACKAGE / "scripts/validate_artifact.py"), str(root / input_ref["path"])]
    plan = env("experiment-run-plan", run_id=run_id, purpose="engineering", evidence_mode=evidence_mode,
        protocol_ref=None, protocol_digest=None, output_root="engineering/attempts",
        provenance={"git_revision":"engineering-fixture-v1","model_revision":"none","data_revision":"existing-fixtures",
                    "environment_digest":DIGEST}, limits={"max_attempts":2,"max_development_trials":1,
                    "max_confirmation_trials":1,"max_retries_per_trial":1,"wall_time_seconds":10,"attempt_timeout_seconds":5},
        jobs=[{"trial_id":"existing-validator","command":command,"cwd":".","input_refs":[input_ref],
               "code_refs":[],"output_paths":[],"seed":1,"group":"engineering","arm_role":"engineering"}])
    plan["plan_digest"] = digest(plan)
    return plan


def schema_contract_examples():
    fixture = ProjectFixture()
    try:
        plan = engineering_plan_fixture(fixture.root)
        receipt = env("experiment-run-receipt",run_id=plan["run_id"],plan_digest=plan["plan_digest"],purpose="engineering",
            evidence_mode="developmental",status="failed",attempts=[],started_at="2026-09-01T00:00:00Z",
            completed_at="2026-09-01T00:00:01Z",resources={"seconds":1},provenance=plan["provenance"],gate_advanced=False)
        return {"experiment-run-plan":(copy.deepcopy(plan),"limits"),"experiment-run-receipt":(receipt,"gate_advanced")}
    finally: fixture.close()


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(R, "bounded runner is missing")
        self.f = ProjectFixture(); self.addCleanup(self.f.close)

    def reject(self, code, action):
        with self.assertRaises(C.Failure) as raised: action()
        self.assertEqual(raised.exception.code, code)

    def test_execution_requires_live_exact_scope_authorization(self):
        plan = engineering_plan_fixture(self.f.root)
        self.reject("RUN_EXECUTION_AUTHORIZATION_REQUIRED", lambda: R.run_plan(self.f.root, plan))
        self.reject("RUN_EXECUTION_NOT_AUTHORIZED", lambda: R.run_plan(self.f.root, plan, authorizer=lambda scope: False))
        self.assertFalse((self.f.root / "engineering/attempts/engineering-run").exists())

    def test_real_engineering_command_retains_logs_and_isolated_attempt_identity(self):
        plan = engineering_plan_fixture(self.f.root)
        result = R.run_plan(self.f.root, plan, authorizer=lambda scope: True)
        self.assertEqual(result["status"], "completed")
        self.assertEqual(len(result["attempts"]), 1)
        attempt = result["attempts"][0]
        self.assertEqual(attempt["exit_code"], 0)
        self.assertIn("engineering/attempts/engineering-run/", attempt["stdout_ref"]["path"])
        self.assertTrue(C.verify_ref(self.f.root, attempt["stdout_ref"]).exists())
        self.assertEqual(attempt["provenance"], plan["provenance"])
        self.assertEqual(result["gate_advanced"], False)

    def test_failed_command_retries_only_within_budget_and_retains_every_failure(self):
        plan = engineering_plan_fixture(self.f.root, command=[sys.executable, str(PACKAGE / "scripts/validate_artifact.py"),
                                                             str(self.f.root / "missing-engineering-input.json")])
        result = R.run_plan(self.f.root, plan, authorizer=lambda scope: True)
        self.assertEqual(result["status"], "failed")
        self.assertEqual(len(result["attempts"]), 2)
        self.assertEqual([attempt["exit_code"] for attempt in result["attempts"]], [2, 2])
        self.assertNotEqual(result["attempts"][0]["attempt_path"], result["attempts"][1]["attempt_path"])
        for attempt in result["attempts"]: C.verify_ref(self.f.root, attempt["stderr_ref"])

    def test_confirmation_cannot_retry_or_reuse_old_run_directory(self):
        plan = engineering_plan_fixture(self.f.root, evidence_mode="prospective_confirmatory")
        plan["limits"]["max_retries_per_trial"] = 0; plan["plan_digest"] = digest({k:v for k,v in plan.items() if k!="plan_digest"})
        R.run_plan(self.f.root, plan, authorizer=lambda scope: True)
        self.reject("RUN_ID_ALREADY_USED", lambda: R.run_plan(self.f.root, plan, authorizer=lambda scope: True))
        retry = engineering_plan_fixture(self.f.root, evidence_mode="prospective_confirmatory", run_id="other")
        self.reject("CONFIRMATION_RETRIES_FORBIDDEN", lambda: R.validate_plan(self.f.root, retry))

    def test_infinite_or_zero_attempt_budgets_are_rejected_before_authorization(self):
        for key, value in (("max_attempts",0),("max_development_trials",0),("wall_time_seconds",float("inf"))):
            plan = engineering_plan_fixture(self.f.root); plan["limits"][key] = value
            # finite values get their canonical hash; infinity fails first by design.
            if value != float("inf"): plan["plan_digest"] = digest({k:v for k,v in plan.items() if k!="plan_digest"})
            with self.assertRaises(C.Failure): R.validate_plan(self.f.root, plan)

    def test_trial_inventory_cannot_exceed_declared_development_budget(self):
        plan = engineering_plan_fixture(self.f.root)
        second = copy.deepcopy(plan["jobs"][0]); second["trial_id"] = "unauthorized-extra-trial"; plan["jobs"].append(second)
        plan["plan_digest"] = digest({k:v for k,v in plan.items() if k!="plan_digest"})
        self.reject("RUN_TRIAL_BUDGET_EXCEEDED", lambda: R.validate_plan(self.f.root, plan))

    def test_scorer_builder_cannot_be_constructed_from_stored_authorization_flag(self):
        self.reject("RUN_EXECUTION_AUTHORIZATION_REQUIRED", lambda: R.build_official_replay_context(self.f.root, {"approved": True}))

    def test_authorizer_sees_resolved_command_and_finite_scope(self):
        plan = engineering_plan_fixture(self.f.root); scopes = []
        def allow(scope): scopes.append(scope); return True
        R.run_plan(self.f.root, plan, authorizer=allow)
        self.assertEqual(scopes[0]["command"], plan["jobs"][0]["command"])
        self.assertEqual(scopes[0]["cwd"], str(self.f.root))
        self.assertEqual(scopes[0]["budget"]["wall_time_seconds"], 10)

    def test_short_wall_time_stops_existing_engineering_command_and_retains_timeout(self):
        plan = engineering_plan_fixture(self.f.root)
        plan["limits"].update(wall_time_seconds=0.001,attempt_timeout_seconds=0.001,max_retries_per_trial=0)
        plan["plan_digest"] = digest({k:v for k,v in plan.items() if k!="plan_digest"})
        started = time.monotonic(); result = R.run_plan(self.f.root,plan,authorizer=lambda scope:True)
        self.assertLess(time.monotonic()-started,2)
        self.assertEqual(result["status"],"budget_exhausted")
        self.assertFalse(result["gate_advanced"])

    def test_budget_expiring_during_real_input_staging_is_retained_as_timeout_without_execution(self):
        plan = engineering_plan_fixture(self.f.root)
        plan["limits"].update(wall_time_seconds=1,attempt_timeout_seconds=1,max_retries_per_trial=0)
        plan["plan_digest"] = R.plan_digest(plan)
        clock = [0.0]
        stage = R._stage
        def elapsed_after_staging(*args):
            result = stage(*args)
            clock[0] = 2.0
            return result
        with mock.patch.object(R.time, "monotonic", lambda: clock[0]), \
             mock.patch.object(R, "_stage", elapsed_after_staging), \
             mock.patch.object(R, "_execute", side_effect=AssertionError("Expired plan must not launch")):
            result = R.run_plan(self.f.root, plan, authorizer=lambda scope: True)
        self.assertEqual(result["status"], "budget_exhausted")
        self.assertEqual(result["attempts"][0]["status"], "timeout")
        self.assertEqual(result["attempts"][0]["reason_code"], "RUN_WALL_TIME_BUDGET_EXHAUSTED")
        C.verify_ref(self.f.root, result["attempts"][0]["stdout_ref"])
        self.assertFalse(result["gate_advanced"])

    def test_stale_input_cannot_be_collected_as_new_attempt_output(self):
        plan = engineering_plan_fixture(self.f.root)
        plan["jobs"][0]["output_paths"] = [plan["jobs"][0]["input_refs"][0]["path"]]
        plan["plan_digest"] = digest({k:v for k,v in plan.items() if k!="plan_digest"})
        self.reject("RUN_OUTPUT_OVERLAPS_INPUT",lambda:R.validate_plan(self.f.root,plan))

    def test_live_scorer_callback_executes_existing_non_evaluation_validator_and_retains_output(self):
        # This tests process collection only; the output has no scientific metric.
        plan = engineering_plan_fixture(self.f.root); job = plan["jobs"][0]
        scorer = {"kind":"official","identity":"engineering-validator","revision":"installed-fixture-v1",
            "source_refs":job["input_refs"],"code_refs":job["input_refs"],"command":job["command"],"cwd":".",
            "output":{"format":"json","source":"stdout"},"denominator_path":["unused-engineering-field"]}
        request = {"nonce":"engineering-nonce","arm_role":"engineering","receipt":{
            "predictions_ref":job["input_refs"][0],"sample_manifest_ref":job["input_refs"][0],
            "labels_or_tests_ref":job["input_refs"][0],"seed":1},"scorer":scorer,"command":job["command"],
            "cwd":str(self.f.root),"budget":{"seconds":5},"input_refs":job["input_refs"]}
        request["request_digest"] = digest(request)
        replay = R.build_official_replay_context(self.f.root,lambda scope:True,timeout_seconds=5)
        result = replay(request)
        self.assertEqual(result["exit_code"],0)
        self.assertEqual(result["nonce"],"engineering-nonce")
        self.assertTrue(C.load_file(C.verify_ref(self.f.root,result["native_output_ref"]))["valid"])

    def test_resource_lease_wraps_attempt_execution(self):
        plan = engineering_plan_fixture(self.f.root); active = []
        class Lease:
            def __enter__(self): active.append("leased")
            def __exit__(self,*args): active.append("released")
        result = R.run_plan(self.f.root,plan,authorizer=lambda scope:True,lease_factory=lambda scope:Lease())
        self.assertEqual(result["status"],"completed")
        self.assertEqual(active,["leased","released"])

    def test_resource_lease_failure_is_retained_without_retry(self):
        plan = engineering_plan_fixture(self.f.root)
        def unavailable(scope): C.fail("RESOURCE_LEASE_UNAVAILABLE")
        result=R.run_plan(self.f.root,plan,authorizer=lambda scope:True,lease_factory=unavailable)
        self.assertEqual(result["status"],"interrupted")
        self.assertEqual(len(result["attempts"]),1)
        self.assertEqual(result["attempts"][0]["reason_code"],"RESOURCE_LEASE_UNAVAILABLE")
        C.verify_ref(self.f.root,result["attempts"][0]["stderr_ref"])

    def test_missing_native_output_retains_failed_execution_metadata(self):
        plan=engineering_plan_fixture(self.f.root);job=plan["jobs"][0];scopes=[]
        scorer={"kind":"official","identity":"engineering-validator","revision":"installed-fixture-v1",
            "source_refs":job["input_refs"],"code_refs":job["input_refs"],"command":job["command"]+["{output}"],"cwd":".",
            "output":{"format":"json","source":"file","path":"engineering/missing-native-output.json"},
            "denominator_path":["unused-engineering-field"]}
        request={"nonce":"engineering-missing-output","arm_role":"engineering","receipt":{
            "predictions_ref":job["input_refs"][0],"sample_manifest_ref":job["input_refs"][0],"labels_or_tests_ref":job["input_refs"][0],"seed":1},
            "scorer":scorer,"command":job["command"]+["{output}"],"cwd":str(self.f.root),"budget":{"seconds":5},"input_refs":job["input_refs"]}
        request["request_digest"]=digest(request)
        def allow(scope):scopes.append(scope);return True
        replay=R.build_official_replay_context(self.f.root,allow,timeout_seconds=5)
        self.reject("NATIVE_REPLAY_OUTPUT_REQUIRED",lambda:replay(request))
        attempt=pathlib.Path(scopes[0]["output_root"])
        self.assertTrue((attempt/"stderr.log").is_file())
        recorded=C.load_file(attempt/"execution.json")
        self.assertEqual(recorded["exit_code"],2)
        self.assertIsNone(recorded["native_output_ref"])

    def test_interrupted_scorer_cannot_qualify_from_a_zero_leader_exit(self):
        plan = engineering_plan_fixture(self.f.root); job = plan["jobs"][0]; scopes = []
        command = [sys.executable,"-c","import subprocess,sys;subprocess.Popen([sys.executable,'-c','import time;time.sleep(.3)']);import json;print(json.dumps(dict(engineering=True)))"]
        scorer = {"kind":"official","identity":"engineering-validator","revision":"fixture-v1",
            "source_refs":job["input_refs"],"code_refs":job["input_refs"],"command":command,"cwd":".",
            "output":{"format":"json","source":"stdout"},"denominator_path":["unused-engineering-field"]}
        request = {"nonce":"engineering-interrupted","arm_role":"engineering","receipt":{
            "predictions_ref":job["input_refs"][0],"sample_manifest_ref":job["input_refs"][0],"labels_or_tests_ref":job["input_refs"][0],"seed":1},
            "scorer":scorer,"command":command,"cwd":str(self.f.root),"budget":{"seconds":5},"input_refs":job["input_refs"]}
        request["request_digest"] = digest(request)
        def allow(scope): scopes.append(scope); return True
        replay = R.build_official_replay_context(self.f.root,allow)
        self.reject("NATIVE_SCORER_REPLAY_FAILED",lambda:replay(request))
        record = C.load_file(pathlib.Path(scopes[0]["output_root"])/"execution.json")
        self.assertEqual(record["exit_code"],0)
        self.assertEqual(record["execution_status"],"interrupted")

    def test_staged_file_write_never_modifies_pinned_source(self):
        plan = engineering_plan_fixture(self.f.root)
        input_ref = plan["jobs"][0]["input_refs"][0]
        job = plan["jobs"][0]
        job["command"] = [sys.executable,"-c","import pathlib,sys;pathlib.Path(sys.argv[1]).write_text('attempt edit')",str(self.f.root/input_ref["path"])]
        plan["plan_digest"] = R.plan_digest(plan)
        result = R.run_plan(self.f.root,plan,authorizer=lambda scope:True)
        self.assertEqual(result["status"],"completed")
        C.verify_ref(self.f.root,input_ref)
        staged = self.f.root/result["attempts"][0]["attempt_path"]/"workspace"/input_ref["path"]
        self.assertEqual(staged.read_text(),"attempt edit")


if __name__ == "__main__": unittest.main()
