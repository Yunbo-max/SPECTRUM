"""Pinned checks for Work Harness C/D development; never a scientific verdict.

Controller-owned sequence bindings select this policy. Development retains native
scoring/provenance checks while avoiding prerequisites whose evidence it produces.
"""
from pathlib import Path
import hashlib
import json
import _autoresearch as C

PROFILE = 'work-harness-cd-v1'
CATALOG = 'assets/skill-sequence-cd-v1.json'
C_STEPS = {'B01', 'S01', 'E01', 'B02', 'B03', 'B04', 'B05'}
B_STEPS = {'L01', 'L02', 'L03', 'X02', 'L04', 'X03', 'L05'}
D_STEPS = {'H01', 'H02', 'H03', 'H04', 'H05', 'M01', 'M02', 'M03', 'M04', 'M05'}


def need(value, message):
    if not value:
        raise ValueError(message)


def text(value, label):
    need(isinstance(value, str) and bool(value.strip()), label + ' requires text')


def unique(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def document(root, ref):
    path = C.verify_ref(C.root_path(root), ref)
    raw = path.read_bytes()
    need(len(raw) <= 2 * 1024 * 1024, 'C/D metadata exceeds byte bound')
    value = json.loads(raw, object_pairs_hook=unique,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))
    need(isinstance(value, dict), 'C/D document must be an object')
    return value


def refs(root, values, label, *, nonempty=False):
    need(isinstance(values, list) and (values or not nonempty), label + ' requires references')
    seen = {}
    for ref in values:
        C.verify_ref(C.root_path(root), ref)
        need(ref['path'] not in seen or seen[ref['path']] == ref['sha256'], 'conflicting reference pins')
        seen[ref['path']] = ref['sha256']
    return values


def code_identity(root, values):
    refs(root, values, 'complete method code identity', nonempty=True)
    identity = {(ref['path'], ref['sha256']) for ref in values}
    need(len(identity) == len(values), 'method code identity contains duplicate references')
    return identity


def binding(project, task):
    selected = task.get('parameters', {}).get('sequence_binding', {})
    need(selected.get('flow_profile') == PROFILE, 'C/D requires adopted flow profile')
    need(type(selected.get('epoch')) is int and selected['epoch'] >= 1, 'C/D requires adopted epoch')
    source = Path(project['skill_root']) / CATALOG
    need(source.is_file() and hashlib.sha256(source.read_bytes()).hexdigest() == selected.get('catalog_sha256'),
         'C/D catalog pin mismatch')
    marker = Path(project['skill_root']) / 'assets/harness-policy.json'
    need(marker.is_file() and json.loads(marker.read_text()).get('edition') == 'autonomous-rsi-harness',
         'C/D policy belongs to Work Harness')
    need(project.get('workflow_class') == 'scientific_method', 'C/D requires scientific project')
    return selected


def decision_refs(root, reference, goal_id, previous_ref=None, receipt_refs=None):
    """Validate append-only selections and input pins, without accepting science."""
    result, visited, current, newest = [], set(), reference, None
    while current is not None:
        identity = (current['path'], current['sha256'])
        need(identity not in visited, 'C/D decision chain cycle')
        visited.add(identity)
        d = document(root, current)
        need(d.get('kind') == 'research-cd-decision' and type(d.get('schema_version')) is int
             and d['schema_version'] == 1, 'C/D decision schema required')
        need(d.get('goal_id') == goal_id, 'C/D decision goal mismatch')
        need(d.get('stage') in {'diagnosis', 'development', 'scaleup'}, 'invalid C/D decision stage')
        text(d.get('rationale'), 'decision rationale')
        ids = d.get('selected_task_ids')
        need(isinstance(ids, list) and len(ids) == len(set(ids)), 'unique selected task IDs required')
        for item in ids: text(item, 'selected task')
        evidence = refs(root, d.get('evidence_refs'), 'decision evidence')
        observed = refs(root, d.get('observed_receipt_refs'), 'observed receipt refs')
        for key in ('problem_ref', 'mechanism_ref', 'verified_ref', 'previous_ref'):
            need(key in d, 'decision requires explicit ' + key)
            if d[key] is not None:
                refs(root, [d[key]], key)
                result.append(d[key])
        if d['stage'] in {'development', 'scaleup'}:
            need(d['problem_ref'] is not None and d['mechanism_ref'] is not None,
                 'development requires problem and mechanism records')
        if d['stage'] == 'scaleup': need(d['verified_ref'] is not None, 'scaleup requires verified evidence')
        if newest is None:
            newest = d
            if previous_ref is not None and reference != previous_ref:
                need(d['previous_ref'] == previous_ref, 'C/D decision must extend accepted decision')
            for ref in receipt_refs or []:
                need(ref in observed, 'C/D decision did not consume actual host receipt')
        else:
            for ref in observed:
                need(ref in newest['observed_receipt_refs'], 'C/D decision erased observed receipts')
        result.extend([current, *evidence, *observed])
        current = d['previous_ref']
        # Adoption can extend one legacy v4 decision without reinterpreting it.
        if current is not None:
            prior = document(root, current)
            if prior.get('kind') == 'research_decision':
                need(prior.get('schema_version') == 4 and prior.get('goal_id') == goal_id,
                     'invalid legacy adoption predecessor')
                result.append(current)
                break
    return list({(r['path'], r['sha256']): r for r in result}.values())


def check_task(project, task, *, accepted_ref=None, goal_id=None, expand=False):
    selected = binding(project, task)
    q = task['parameters']; root = project['root']; reference = q.get('reasoning_ref')
    need(reference is not None and reference == accepted_ref, 'C/D requires current accepted decision')
    need(q.get('goal_id') == goal_id, 'C/D task goal mismatch')
    required = decision_refs(root, reference, goal_id)
    d = document(root, reference)
    need(task['task_id'] in d['selected_task_ids'], 'C/D task was not selected')
    stage = ('diagnosis' if selected['step_id'] in C_STEPS | B_STEPS else
             'development' if selected['step_id'] in D_STEPS else 'scaleup')
    investment = task['action'] in {'candidate_code', 'experiment_design', 'native_harness', 'result_verify'}
    if investment: need(d['stage'] == stage, 'C/D decision differs from adopted stage')
    if not investment:
        need(task['action'] in {'source_read', 'math_review', 'writing'}, 'unsupported acquisition action')
    elif stage == 'scaleup':
        need(selected.get('verified_ref') is not None and d['verified_ref'] == selected['verified_ref'],
             'scaleup requires controller-owned verified handoff')
        handoff = {'flow_profile': PROFILE, 'verified_ref': selected['verified_ref'],
                   'acceptance_ref': selected.get('scaleup_acceptance_ref')}
        report = require_scaleup(root, handoff)
        need(report['goal_id'] == goal_id and report['problem_ref'] == d['problem_ref']
             and report['mechanism_ref'] == d['mechanism_ref'], 'scaleup decision differs from accepted method')
        required.extend([handoff['verified_ref'], handoff['acceptance_ref']])
        if task['action'] == 'native_harness':
            need(q.get('native_purpose', 'comparison') == 'comparison', 'E must use formal comparison purpose')
            plan = document(root, q.get('harness_plan_ref'))
            found_treatment = False
            for item in plan['tasks']:
                native = document(root, item['plan_ref'])
                protocol = document(root, native['protocol_ref'])
                need(protocol.get('cd_scaleup') == handoff, 'E protocol lacks current accepted scaleup handoff')
                need(protocol.get('cd_problem_ref') == report['problem_ref'], 'E protocol problem mismatch')
                need(not protocol.get('cd_development') and native['evidence_mode'] != 'developmental',
                     'E cannot reuse development evidence as confirmation')
                treatments = [job for job in native['jobs'] if job['arm_role'] == 'treatment']
                found_treatment = found_treatment or bool(treatments)
                need(all(code_identity(root, job['code_refs']) == code_identity(root, report['method_code_refs'])
                         for job in treatments),
                     'E treatment code changed; reopen D and obtain a new verified report')
            need(found_treatment, 'E comparison must execute the verified treatment')
        # Official E method checks continue in admission.CHECK.
    elif investment:
        need(q.get('research_scope') == ('diagnostic' if stage == 'diagnosis' else 'method'),
             'C/D research scope mismatch')
        if stage == 'development':
            need(selected.get('problem_ref') is not None and d['problem_ref'] == selected['problem_ref'],
                 'D requires controller-owned accepted problem')
        eref = q.get('cd_evidence_ref'); e = document(root, eref)
        need(e.get('kind') == 'research-cd-experiment' and type(e.get('schema_version')) is int
             and e['schema_version'] == 1 and e.get('flow_profile') == PROFILE, 'C/D experiment schema required')
        need(e.get('stage') == stage and e.get('goal_id') == goal_id
             and e.get('candidate_id') == q.get('candidate_id'), 'C/D experiment identity mismatch')
        text(e.get('candidate_id'), 'candidate identity')
        for key in ('question', 'mathematical_object', 'prediction', 'falsifier', 'code_plan', 'uncertainty_plan'):
            text(e.get(key), key)
        need(isinstance(e.get('assumptions'), list) and e['assumptions'], 'explicit assumptions required')
        for assumption in e['assumptions']: text(assumption, 'assumption')
        for key in ('problem_ref', 'mechanism_ref'):
            need(key in e and e[key] == d[key], 'experiment ' + key + ' differs from decision')
        required.append(eref)
        for key in ('benchmark_ref', 'model_ref', 'dataset_ref', 'evaluation_ref', 'exposure_log_ref'):
            required.extend(refs(root, [e.get(key)], key, nonempty=True))
        required.extend(refs(root, e.get('condition_source_refs'), 'condition sources', nonempty=True))
        mappings = e.get('code_bindings')
        need(isinstance(mappings, list), 'code bindings required')
        if task['action'] != 'candidate_code': need(mappings, 'concrete math-code bindings required')
        code_refs = []
        for item in mappings:
            for key in ('mathematical_object', 'location'): text(item.get(key), 'code binding ' + key)
            code_refs.extend(refs(root, [item.get('code_ref')], 'mapped code'))
        required.extend(code_refs)
        controls = e.get('controls')
        need(isinstance(controls, list) and controls, 'C/D controls required')
        for control in controls:
            text(control.get('name'), 'control name'); text(control.get('rationale'), 'control rationale')
            required.extend(refs(root, control.get('implementation_refs'), 'control implementation',
                                 nonempty=task['action'] == 'native_harness'))
        if task['action'] == 'native_harness':
            qualification = q.get('native_purpose') == 'qualification'
            if qualification:
                need(selected['step_id'] == 'B01' and stage == 'diagnosis', 'qualification exception belongs to B01 diagnosis')
                aref = q.get('qualification_authorization_ref'); authorization = document(root, aref)
                need(authorization.get('kind') == 'research-b01-qualification-authorization'
                     and authorization.get('schema_version') == 1 and authorization.get('step_id') == 'B01'
                     and authorization.get('native_purpose') == 'qualification'
                     and authorization.get('project_id') == project.get('project_id')
                     and authorization.get('goal_id') == goal_id, 'B01 owner authorization identity mismatch')
                need(type(authorization.get('max_task_seconds')) in (int, float)
                     and 0 < task['max_seconds'] <= authorization['max_task_seconds'], 'B01 qualification exceeds owner scope')
                if q.get('native_target_ref') is not None:
                    need(q['native_target_ref'] == authorization.get('native_target_ref'), 'B01 qualification target mismatch')
                required.extend(refs(root, [aref, authorization.get('instruction_ref'),
                                           authorization.get('native_target_ref')], 'B01 owner authorization'))
            else:
                need(q.get('native_purpose') == 'development', 'C/D native purpose must be development')
            import run_harness as H
            href = q.get('harness_plan_ref'); plan = document(root, href)
            H.validate_plan(root, plan)
            required.append(href)
            need(plan['limits']['max_parallel_tasks'] == 1 and plan['gpus']['max_tasks_per_gpu'] == 1,
                 'one development experiment at a time required')
            need(plan['limits']['total_wall_seconds'] <= task['max_seconds'], 'native time exceeds reservation')
            actual_code = []; actual_roles = set()
            for item in plan['tasks']:
                need(item['resources']['allow_gpu_share'] is False, 'GPU sharing not allowed')
                native = document(root, item['plan_ref']); required.append(item['plan_ref'])
                need(native['purpose'] == 'scientific' and native['evidence_mode'] == 'developmental',
                     'C/D runs must retain scientific development identity')
                need(native['provenance'].get('cd_evidence_ref') == eref, 'native development evidence mismatch')
                protocol = document(root, native['protocol_ref']); required.append(native['protocol_ref'])
                need(not protocol.get('method_discovery'), 'development cannot mix legacy discovery contracts')
                need(protocol.get('cd_development') == {'flow_profile': PROFILE, 'stage': stage, 'cd_evidence_ref': eref},
                     'protocol development evidence mismatch')
                for job in native['jobs']:
                    actual_code.extend(job['code_refs']); actual_roles.add(job['arm_role'])
            need(all(ref in actual_code for ref in code_refs), 'mapped code is absent from native jobs')
            need(all(ref in actual_code for control in controls for ref in control['implementation_refs']),
                 'declared control implementation is absent from native jobs')
            if qualification:
                need('baseline' in actual_roles and 'treatment' not in actual_roles,
                     'B01 qualification permits baseline and controls, never treatment')
            else:
                need('baseline' in actual_roles and len(actual_roles) >= 2, 'development requires actual control comparison')
    inventory = task['inputs'] + task['instructions']
    for ref in required:
        if ref not in inventory:
            need(expand, 'C/D transitive evidence was not pinned at intake')
            need(not any(r['path'] == ref['path'] for r in inventory), 'C/D conflicting immutable input pin')
            inventory.append(ref)
    return inventory


def response(root, ref):
    value = document(root, ref)
    if set(value) == {'response'}:
        value = json.loads(value['response'], object_pairs_hook=unique)
    need(isinstance(value, dict), 'agent response must be an object')
    return value


def check_scored_lineage(root, gate):
    """Join scored predictions to actual retained run outputs, not nearby runs.

    This checks provenance only. Scorer execution and scientific interpretation
    remain separate program-owned verification and independent-review duties.
    """
    proofs = []; runs = refs(root, gate.get('run_receipt_refs'), 'cited native runs', nonempty=True)
    candidates = []
    for run_ref in runs:
        saved = document(root, run_ref); item = saved.get('controller', {}); task = item.get('task', {})
        need(item.get('state') == 'completed' and task.get('action') == 'native_harness', 'lineage requires completed native run')
        output_refs = refs(root, item.get('outputs'), 'actual task outputs', nonempty=True)
        declared = task.get('outputs')
        need(isinstance(declared, list), 'native task declared outputs required')
        retained = saved.get('retained_files')
        need(isinstance(retained, list) and retained, 'native run retained files required')
        archives = []
        for row in retained:
            original, archive = row.get('original_ref'), row.get('archive_ref')
            refs(root, [original, archive], 'retained prediction identity')
            need(original['sha256'] == archive['sha256'], 'retained archive bytes differ from actual output')
            archives.append(original); proofs.extend([original, archive])
        href = task.get('parameters', {}).get('harness_plan_ref'); harness = document(root, href)
        proofs.extend([run_ref, href, *output_refs])
        for htask in harness.get('tasks', []):
            nref = htask.get('plan_ref'); native = document(root, nref); proofs.append(nref)
            for job in native.get('jobs', []):
                candidates.append((native.get('protocol_ref'), job, output_refs, declared, archives))
    scored = gate.get('scored_runs')
    need(isinstance(scored, list) and scored, 'scored run inventory required')
    for row in scored:
        protocol = document(root, row.get('protocol_ref')); manifest = document(root, row.get('manifest_ref'))
        proofs.extend([row['protocol_ref'], row['manifest_ref']])
        for key in ('protocol_id', 'protocol_digest', 'run_id', 'group'):
            text(manifest.get(key), 'scored manifest ' + key)
        need(type(manifest.get('seed')) is int and manifest['seed'] >= 0, 'scored manifest seed required')
        need(manifest.get('protocol_id') == protocol.get('protocol_id')
             and manifest.get('protocol_digest') == protocol.get('protocol_digest'), 'scored manifest protocol mismatch')
        arms = manifest.get('native_eval_receipts')
        need(isinstance(arms, dict) and arms, 'scored manifest needs native arm receipts')
        for role, receipt_ref in arms.items():
            receipt = document(root, receipt_ref); pred = receipt.get('predictions_ref')
            refs(root, [pred], 'scored predictions'); proofs.extend([receipt_ref, pred])
            need(receipt.get('arm_role') == role and receipt.get('group') == manifest.get('group')
                 and receipt.get('seed') == manifest.get('seed') and receipt.get('run_id') == manifest.get('run_id')
                 and receipt.get('protocol_id') == manifest.get('protocol_id')
                 and receipt.get('protocol_digest') == manifest.get('protocol_digest'), 'scored arm identity mismatch')
            matched = any(protocol_ref == row['protocol_ref']
                          and job.get('arm_role') == role and job.get('group') == manifest.get('group')
                          and job.get('seed') == manifest.get('seed')
                          and pred['path'] in job.get('output_paths', []) and pred['path'] in declared
                          and pred in outputs and pred in retained
                          for protocol_ref, job, outputs, declared, retained in candidates)
            need(matched, 'scored predictions do not match cited native output/protocol/arm/group/seed')
    return list({(ref['path'], ref['sha256']): ref for ref in proofs}.values())


def require_scaleup(root, handoff):
    """Replay a pinned M05 handoff; runtime additionally binds its trusted pin.

    CLI freezing checks this artifact lineage. It cannot authorize dispatch; the
    program/controller separately requires its own accepted verified_ref.
    """
    need(isinstance(handoff, dict) and set(handoff) == {'flow_profile', 'verified_ref', 'acceptance_ref'}
         and handoff['flow_profile'] == PROFILE, 'typed C/D scaleup handoff required')
    report = document(root, handoff['verified_ref'])
    need(report.get('kind') == 'research-cd-scaleup' and report.get('schema_version') == 1,
         'scaleup report schema required')
    acceptance = document(root, handoff['acceptance_ref'])
    seq = acceptance.get('sequence', {})
    need(acceptance.get('kind') == 'research-skill-step-acceptance' and acceptance.get('schema_version') == 1
         and acceptance.get('disposition') == 'accepted' and seq.get('flow_profile') == PROFILE
         and seq.get('step_id') == 'M05' and acceptance.get('cd_gate_ref') == handoff['verified_ref']
         and acceptance.get('goal_id') == report.get('goal_id'), 'scaleup lacks accepted M05 lineage')
    text(acceptance.get('review_run_id'), 'actual review run')
    need(acceptance.get('planner_task_id') != acceptance.get('reviewer_task_id'), 'independent review required')
    result = response(root, acceptance['result_ref']); review = response(root, acceptance['review_ref'])
    proposal = document(root, acceptance['proposal_ref'])
    need(result.get('kind') == 'research-skill-step-result' and result.get('sequence') == seq
         and result.get('goal_id') == report['goal_id'] and result.get('tasks') == [], 'M05 result mismatch')
    need(review.get('kind') == 'research-skill-step-review' and review.get('approved') is True
         and review.get('sequence') == seq and review.get('result_ref') == acceptance['result_ref']
         and review.get('proposal_ref') == acceptance['proposal_ref']
         and review.get('goal_id') == report['goal_id'], 'M05 independent review mismatch')
    need(proposal.get('goal_id') == report['goal_id'] and proposal.get('tasks') == []
         and proposal.get('decision_ref') == result.get('decision_ref'), 'M05 proposal mismatch')
    findings = result.get('findings'); requirements = review.get('requirements')
    need(isinstance(findings, list) and findings and isinstance(requirements, list) and requirements,
         'M05 findings and reviews required')
    ids = {row['requirement_id'] for row in findings}
    need(len(ids) == len(findings) == len(requirements)
         and {row['requirement_id'] for row in requirements} == ids
         and all(row.get('satisfied') is True for row in requirements), 'M05 requirements incomplete')
    need(any(handoff['verified_ref'] in row.get('evidence_refs', []) for row in findings)
         and any(handoff['verified_ref'] in row.get('evidence_refs', []) for row in requirements),
         'M05 review did not examine scaleup report')
    verification = document(root, acceptance.get('cd_verification_ref'))
    scored = verification.get('report', {})
    need(verification.get('kind') == 'research-cd-scientific-verification'
         and verification.get('schema_version') == 1 and verification.get('goal_id') == report['goal_id']
         and verification.get('proposal_ref') == acceptance['proposal_ref']
         and verification.get('cd_gate_ref') == handoff['verified_ref'], 'M05 scorer receipt identity mismatch')
    need(scored.get('ready') is True and scored.get('native_replay_executed') is True
         and scored.get('goal_id') == report['goal_id'] and scored.get('proposal_ref') == acceptance['proposal_ref']
         and scored.get('cd_gate_ref') == handoff['verified_ref'], 'M05 requires actual ready native scoring')
    measured = scored.get('scored_runs')
    need(isinstance(measured, list) and measured, 'M05 needs scored development runs')
    need(verification.get('scored_runs') == report.get('scored_runs'), 'M05 scoring differs from accepted report')
    need(verification.get('scored_runs') == [{'protocol_ref': row['protocol_ref'], 'manifest_ref': row['manifest_ref']}
                                           for row in measured], 'M05 scorer run inventory mismatch')
    for row in measured:
        need(row.get('baseline_qualified') is True and row.get('positive_control_passed') is True,
             'M05 baseline and controls must qualify')
        refs(root, [row['protocol_ref'], row['manifest_ref']], 'scored native inputs')
        refs(root, row.get('proof_refs'), 'native scorer proofs', nonempty=True)
    replays = scored.get('native_replays')
    need(isinstance(replays, list) and replays and type(scored.get('native_replay_count')) is int
         and scored['native_replay_count'] == len(replays), 'M05 requires retained native scorer executions')
    for replay in replays: refs(root, [replay.get('execution_ref')], 'native scorer execution')
    refs(root, [verification.get('identity_ref'), verification.get('native_receipt_ref')], 'scorer provenance')
    text(verification.get('run_id'), 'scorer actual run'); text(verification.get('task_id'), 'scorer task')
    for row in findings + requirements: refs(root, row.get('evidence_refs'), 'M05 evidence', nonempty=True)
    for key in ('problem_ref', 'mechanism_ref', 'code_ref', 'protocol_ref', 'exposure_ref'):
        refs(root, [report.get(key)], key)
    expected_code = code_identity(root, report.get('method_code_refs'))
    need(report['code_ref'] in report['method_code_refs'], 'primary code reference is outside complete method identity')
    refs(root, report.get('analysis_refs'), 'actual analysis', nonempty=True)
    runs = refs(root, report.get('run_receipt_refs'), 'actual local runs', nonempty=True)
    check_scored_lineage(root, report)
    matched_method = False
    for ref in runs:
        receipt = document(root, ref); controller = receipt.get('controller', {})
        need(controller.get('state') == 'completed' and controller.get('task', {}).get('action') == 'native_harness'
             and controller.get('attempt', {}).get('run_id'), 'scaleup requires actual completed native receipts')
        harness = document(root, controller['task'].get('parameters', {}).get('harness_plan_ref'))
        for item in harness.get('tasks', []):
            native = document(root, item.get('plan_ref'))
            if native.get('protocol_ref') != report['protocol_ref']:
                continue
            treatments = [job for job in native.get('jobs', []) if job.get('arm_role') == 'treatment']
            for job in treatments:
                need(code_identity(root, job.get('code_refs')) == expected_code,
                     'D treatment run differs from complete verified method identity')
                matched_method = True
    need(matched_method, 'scaleup lacks a treatment run with its exact protocol and full code identity')
    need(isinstance(report.get('e_obligations'), list) and report['e_obligations'], 'formal E obligations required')
    obligations = report.get('obligations')
    need(isinstance(obligations, list) and obligations, 'scaleup evidence obligations required')
    for row in obligations:
        text(row.get('id'), 'obligation'); text(row.get('finding'), 'finding')
        refs(root, row.get('evidence_refs'), 'obligation evidence', nonempty=True)
    return report
