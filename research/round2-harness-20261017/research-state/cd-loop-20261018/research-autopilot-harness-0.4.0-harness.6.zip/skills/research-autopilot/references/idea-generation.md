## 9. Entry-specific idea generation

Before substantial method investment or a changed-condition experiment, read
[benchmark-discovery.md](benchmark-discovery.md). Prefer the original native
benchmark when it can test the prediction; otherwise actively search suitable
existing protocols/data using primary sources, Web and accessible discussion leads.
Record condition fit, strong baselines and a credible validation path before
comparative outcomes. Missing evaluation coverage is a research task, not a reason
to build the method first or silently substitute favorable datasets.


At entry, restore the selected field and cumulative paper/code/reproduction record.
Use [research-cycle.md](research-cycle.md) to choose the next unresolved question.
Reading, reproduction and diagnosis are legitimate selected actions before a new
method; mathematical procedures apply to consequential modeling/construction rather
than forcing equations for every source read. Reuse mature evidence; do not restart
completed reading or qualified baselines to satisfy a quota.

## Optional model-design and training discussions

If the retained project choice enables Xiaohongshu, follow
[xiaohongshu-idea-discovery.md](xiaohongshu-idea-discovery.md) for bounded public
note/comment sampling and technical lead extraction. Reuse saved evidence if live
access is unavailable; continue paper/code investigation. Trace “already done”
claims to primary papers and code before judging overlap or a remaining gap.
Feed leads into the inquiry below; popularity and missing search hits establish
neither effectiveness nor novelty. Current edition policy overrides inherited
candidate quotas and direction-selection defaults.

## Simple/Chat v4 entry

For these editions, [inquiry-generation.md](inquiry-generation.md) governs problem
framing, competing accounts and empirical-first leads. Reuse the techniques below
when relevant, not inherited candidate quotas or completed-theory prerequisites.
Extract a paper's challenged default, changed object, decisive contrast and limits;
search for close collisions and disconfirming evidence, not only supporting analogies.
A changed method name is not a different explanation. No paper-count or path-count quota.


Every generated outcome is immutable and uses a discriminated schema:

- `research_candidate`: full `IdeaAtom` requirements apply;
- `no_new_idea_needed`: references the already adequate method/claim and next route;
- `stop`: states the blocking evidence and reusable assets;
- `evidence_repair`: states which invalid or missing evidence must be repaired before ideation;
- `retarget_writing`: identifies a writing/positioning/venue-only change and the evidence snapshot that must remain unchanged or be revalidated.

Evidence and judgments are separate envelopes.

### Start from the task, benchmark and simple baselines

Use [mathematical-empirical-inquiry.md](mathematical-empirical-inquiry.md) to join
empirical observations and mathematical exploration. Either can initiate a
question; connect derivations to observations and let observations revise the
derivation. The heading names empirical evidence obligations, not a mandatory
order for all thinking. Read-only conceptual work can produce conditional
identities, bounds, counterexamples and predictions without a benchmark or new
project intake. The candidate-investment requirements below apply when
recommending empirical method development or an experiment batch.
Every research candidate must complete the internal [mathematical procedure](math-analysis.md),
regardless of its entry route or empirical readiness. Return a mathematical
discovery card with the actual derivation and assumptions, justified operation
path, executable construction, what changes, closest-work relation, distinguishing
prediction and falsifier. Raw observations and unanalyzed combinations remain
leads. Shared derivations require candidate-specific consequences. The initial
candidate target never permits padding with configurations or superficial formulas.

Use [literature-evidence.md](literature-evidence.md)'s joined reading/design contract
in every round. Read relevant primary papers, actual author/baseline GitHub files
and the contents/config/scorer of each considered benchmark; map their evidence
and limits to each hypothesis's experiment, rather than handing off a standalone
idea list. Reuse current pinned readings and inspect changed dependencies. Pair
the hypothesis with controls, fair budgets, possible outcome interpretations and
next actions; missing evidence remains a bounded investigation, not method approval.

At batch-end human review, apply [state-and-routing.md](state-and-routing.md)'s
branches. Valid direction failure is recorded during the batch; renewed contextual
paper/code/benchmark discovery and ideas/design follow the human's review decision.
Changed human goals/resources return to discussion; qualified success follows
full-validation/writing prerequisites. Use [rolling-research-batches.md](rolling-research-batches.md)
at idea generation and design for finite dispatch, complete comparisons across
soft progress reports, up-to-24-hour Local execution, unfinished approved
carryover and consolidated human review. Web authoring has separate completion criteria.
Use its evidence-driven convergence: deepen/confirm useful positive candidates,
stop/park validly refuted ones and group mixed cases into discriminating diagnoses.
Later rounds normally focus on 2–5, then 1–2 ideas when supported; no minimum.
Expansion needs a material named uncertainty or changed human requirements.

Apply this contract before the first empirical candidate recommendation, including
an initial brainstorming reply or a time-budgeted candidate/experiment request.
For new/reopened method discovery, use the relevant portions of
[method-verification.md](method-verification.md) after establishing the problem,
conditions and closest alternatives. No fixed 20-to-15 candidate pool is required.
Work/Chat select the next justified in-field question; Simple keeps one active idea;
main retains the human's consequential direction choice. A source-learning round can
end in improved understanding or a bounded diagnostic with no new architecture.
For an executable proposal retain the mathematical account, simple counterfactual,
falsifier, full cost and claim-scoped evidence requirements. Unknown premises remain
unknown; an attractive module or a provisional label does not supply that evidence.

Apply the standing importance/originality and benchmark-feasibility review in
[research-quality-bar.md](research-quality-bar.md) before recommending method
development. Carry its unresolved obligations in the H03 card. Never handcraft
eval cases or benchmark data for discovery measurements, eval debugging or
mechanism evaluation; reuse existing benchmark cases and native scoring. Keep
exposition and non-evaluation software checks separate. A reproducible gap is a discovery
entry, not by itself a strongly original contribution.

Inspect the user's benchmark specifications, repository, evaluator, existing runs
and task logs before recommending empirical investment in a mechanism. Read the task, version, split, input
and output, primary task metric, and resource constraints. If those assets are
absent, retrieve primary benchmark documentation or ask the one essential task
question. Do not invent a benchmark or silently select an easier subset. Explain
how the evaluation represents the intended natural failure; benchmark popularity
alone does not establish importance. Keep discovery data separate from the final
confirmation split. A benchmark deficiency may justify an audit or measurement
contribution about the existing instrument, supported by natural evidence and
its native evaluation. It does not authorize creating a dataset, benchmark,
test suite or scorer. Locate a suitable established evaluation or retain the
measurement gap as a blocker; a changed scope must be explicit.

Fulfil the empirical evidence obligations below when advancing an empirical
candidate. Select, revisit or combine H01 thinking routes from observations,
mathematical structure and literature using
[method-development-tree.md](method-development-tree.md). A real-condition
baseline gap is one entry; it is not the universal default. These obligations
do not require trying all eight routes in order.

1. Map SOTA and qualified simple baselines to the actual task and metric. Read
   failure examples and retained runs; separate observations from explanations.
2. Build a natural failure census with a denominator and downstream task harm.
   Identify which failures remain after the strongest simple alternative.
3. Check inexpensive remedies first: prompt changes, direct rereading, retrieval,
   recency rules, a planner/checker/solver, or a simple statistical baseline when
   applicable. Qualify their implementation, tuning and information access fairly.
4. Draft a small set of structurally different hypotheses connecting the
   mathematical account with observed success/failure regimes. A derivation may
   expose a limitation before it has been measured; retain that evidential status.
   Include simplification or no new method as a serious possible outcome.
   After material new evidence, return the H03 navigation decision card explaining
   continue/switch/combine, competing explanations, the next discriminating check,
   value, resource cost, scope and confirmation status. Repair invalid runs first.
   Use the entry-specific lenses below to explain observations or derive
   consequential predictions; do not invent a use for an attractive module.
5. For each candidate, derive why its construction might address the identified
   structure or consequential limitation, give the strongest counterargument, and one comparison
   that could disprove this necessity. Reject candidates justified only by being
   different. Rank by consequential task value, baseline gap, evidence quality,
   falsifiability and total cost; unknown evidence stays unknown.
6. Retain each mathematical card and its semantic verification review. Rank the
   relevant alternatives, recording the evidence for the chosen action and
   unresolved questions. Require verified selection before new code design. Retrieve closest
   work from each admitted hypothesis, complete collision/IPCG, then approve its
   Idea Atom and freeze its decisive Gate A comparison. Selection alone passes
   none of these scientific gates. Reuse the current pool/ranking on resume.

Constructions can change objectives, distributions, representations, estimators,
constraints or the organization of an algorithm. “Minimal intervention” in the
candidate schema means the decisive comparison avoids unnecessary confounding;
it neither requires a one-line method nor reduces evidence needed for a claim.

For a memory representation change, include a qualified `plain_text_memory`
baseline: faithful text storage plus a reasonable prompt/retrieval policy, under
the same task, available information and resource limits. Also test the relevant
simple selector, such as recency, retrieval or a lightweight filter. A latent
representation must predict a specific task-success or resource benefit that
survives these comparisons and an ablation replacing it with text. A storage name,
compression ratio or selection score alone is insufficient. This does not presume
that latent representations are always useless: their advantage is a hypothesis
to test. If text is adequate under the declared constraints, prefer simplification
or `no_new_idea_needed`. Do not redesign the benchmark merely to favor the proposal.

Every candidate contains a `necessity_case`: `simple_alternatives_compared`,
`unresolved_task_failure`, `expected_advantage` (explicitly a hypothesis),
`decisive_comparison`, `memory_representation_change`, and captured
`baseline_evidence_refs`. The comparison list includes every frozen parent
`simple_alternatives` entry; memory representation changes additionally include
the canonical `plain_text_memory` entry. The refs support the observed baseline
gap or primary evidence; they do not assert an unrun candidate has already won.
Record what would kill the proposal, not just how to support it. Give a candid
verdict with uncertainty; enthusiasm or agreement with the user supplies no evidence.

Before method design, freeze the six-field Parent Problem and require Natural
Gate 0 PASS. Bind every candidate to `parent_problem_ref`. Draft only the atomic
hypothesis needed for collision retrieval; approve the complete Idea Atom after
the importance-preserving review. Reframes that change the natural failure,
population or consequence return to I-style exploration and a fresh parent/Gate 0.
See [importance-preserving-gate.md](importance-preserving-gate.md).

### `I`

Apply lenses such as phenomenon/measurement, scaling/bounds, decomposition,
assumption-breaking, mechanism transfer, interface mismatch, metric blind spot
and regime boundary to the observations and mathematical objects. Connect the
two accounts and distinguish reported from measured patterns. Generate structurally different atoms,
not stylistic variants. Isolate lenses only when the host supports the context
isolation; never claim independent generation when one context supplied all atoms.

### `M`

Audit assets and the actual benchmark before generation. An existing latent
module is an asset to evaluate, not a requirement to preserve. Valid outputs
include mechanism diagnosis, simplification, boundary law, measurement paper,
constrained reframe, or no new idea. Mature experiments with unverified provenance
do not skip evidence review.

### `R`

Create one issue card per reviewer proposition. Writing-only objections route to writing. Missing evidence routes to an evidence sprint. Novelty or mechanism failures may generate a constrained reframe. Leakage or invalid evaluation quarantines affected evidence before any new narrative is generated.

Required `research_candidate` records include the mathematical discovery card above,
plus question, importance, literature tension, bottleneck, minimal intervention,
causal chain, dominant claim, unique prediction, falsifier, simplest alternative,
provisional closest-work delta, decisive test, compute estimate, risks, and source
evidence IDs. Preserve machine-schema compatibility by linking the card through
the existing research record/evidence references rather than silently adding
unsupported serialized fields. The generator labels its closest-work delta as a
hypothesis for the later collision audit, never as a novelty verdict.

The generator never judges its own novelty. `stop`, `no_new_idea_needed`, `evidence_repair`, and `retarget_writing` are valid outcomes and do not fabricate mechanism, falsifier, or novelty fields.
