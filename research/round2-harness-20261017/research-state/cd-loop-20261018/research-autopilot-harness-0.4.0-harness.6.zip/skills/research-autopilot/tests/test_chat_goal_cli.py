"""Real CLI/CPU engineering fixture; it asserts no research or benchmark gain.

Review fixtures are authored separately from the comparison program and inspect
its actual output. Distinct reviewer IDs are structural bindings only: this test
does not establish real-world reviewer independence or scientific acceptance.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from chat_control_fixtures import ChatControlFixture


SCRIPT = Path(__file__).resolve().parents[1] / 'scripts/chat_cycle.py'

COMPARISON = '''import json, math, sys
from decimal import Decimal
from pathlib import Path
values = [1e16, 1.0, -1e16]
naive = 0.0
for value in values:
    naive += value
compensated = math.fsum(values)
exact = float(sum((Decimal(str(v)) for v in values), Decimal(0)))
Path(sys.argv[1]).write_text(json.dumps({
    'scope': 'engineering fixture only', 'values': values,
    'naive_sum': naive, 'compensated_sum': compensated, 'exact_sum': exact,
    'naive_error': abs(naive-exact), 'compensated_error': abs(compensated-exact)
}, sort_keys=True))
'''

REVIEW = '''import json, sys
from pathlib import Path
observation = json.loads(Path(sys.argv[1]).read_text())
assert observation['scope'] == 'engineering fixture only'
assert observation['exact_sum'] == 1.0
assert observation['naive_error'] == 1.0
assert observation['compensated_error'] == 0.0
review = json.loads(Path(sys.argv[2]).read_text())
review.update(verdict='supported',
    limitation='Structural test review; no scientific gain or reviewer independence claim',
    next_action='Repeat the fixed comparison and write the reproducibility report')
Path(sys.argv[3]).write_text(json.dumps(review, sort_keys=True))
'''


class ChatGoalCLIIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.state = self.root / 'state.json'
        self.sequence = 0
        self.controls = ChatControlFixture(self.root)

    def ref(self, name):
        return {'path': name, 'sha256': hashlib.sha256((self.root / name).read_bytes()).hexdigest()}

    def write(self, name, value):
        text = value if isinstance(value, str) else json.dumps(value, sort_keys=True)
        (self.root / name).write_text(text, encoding='utf-8')
        return self.ref(name)

    def cli(self, command, **options):
        args = [sys.executable, str(SCRIPT), command, '--state', str(self.state),
                '--host-invocation-id', self.controls.invocation_id]
        for name, value in options.items():
            args.extend(['--' + name.replace('_', '-'), str(value)])
        result = subprocess.run(args, cwd=self.root, capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def record(self, op, **values):
        if op == 'add_task':
            values['task'] = self.controls.task(values['task'])
            state = self.cli('status')
            for reference in self.controls.qualifications.values():
                if reference not in state['strategy']['qualifications']:
                    self.record('strategy_qualify', qualification_ref=reference)
        if op == 'result':
            values.setdefault('strategy_usage', self.controls.usage(values['attempt_id']))
        revision = self.cli('status')['revision']
        self.sequence += 1
        filename = 'event-' + str(self.sequence) + '.json'
        self.write(filename, dict(op=op, **values))
        return self.cli('record', expected_revision=revision, event=self.root / filename)

    def advance(self):
        return self.cli('advance', expected_revision=self.cli('status')['revision'])

    def execute(self, filename, *args):
        result = subprocess.run([sys.executable, str(self.root / filename), *args],
                                cwd=self.root, capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)

    def settle(self, attempt, raw, criteria=()):
        evidence = self.write(attempt['id'] + '-evidence.json', {
            'attempt_id': attempt['id'], 'task_id': attempt['task_id'],
            'candidate_id': attempt['candidate_id'], 'procedure_id': attempt['procedure']['id'],
            'outcome': 'completed', 'raw_evidence': raw, 'criteria_met': list(criteria),
            'delivery_receipts': {}})
        self.record('result', attempt_id=attempt['id'], outcome='completed', evidence_ref=evidence)
        return evidence

    def test_preflight_then_diagnostic_comparison_continues_without_scientific_closure(self):
        request = self.write('request.txt',
            'Test-only authorized goal: investigate the fixed numerical fixture, '
            'review the comparison, and produce a reproducibility report. '
            'Feasibility alone does not complete this goal.')
        procedure = {'id': 'fixture-v1', 'ref': self.write('procedure.txt',
            'Execute the fixed comparison, review its actual output, and finish remaining obligations.')}
        config = {
            'goal_id': 'cpu-fixture-goal', 'goal': 'Complete the reviewed engineering fixture',
            'goal_contract': {'mode': 'research', 'request_ref': request,
                'continuation_action': 'Prepare the fixed hypothesis and numerical comparison'},
            'criteria': ['comparison_checked', 'reproducibility_report'], 'deliveries': [],
            'budget': {'max_attempts': 6}, 'procedure': procedure,
            'tasks': [{'id': 'preflight', 'candidate_id': 'fixture-candidate', 'kind': 'preflight',
                'action': 'Check the required standard library on this CPU',
                'dependencies': [], 'input_refs': []}]}
        self.write('config.json', self.controls.configure(config))
        self.cli('init', config=self.root / 'config.json')
        bootstrap = self.controls.bootstrap_event(self.cli('status'))
        self.record(**bootstrap)
        for reference in self.controls.qualifications.values():
            self.record('strategy_qualify', qualification_ref=reference)
        preflight = self.advance()
        self.assertEqual(preflight['kind'], 'execute')
        self.write('preflight.py', "import json, math\nfrom pathlib import Path\n"
                   "Path('preflight.json').write_text(json.dumps({'fsum_available': callable(math.fsum)}))\n")
        self.execute('preflight.py')
        self.settle(preflight['attempt'], [self.ref('preflight.json')])
        after_preflight = self.advance()
        self.assertEqual(after_preflight['kind'], 'replan')
        self.assertEqual(after_preflight['scientific_cycle_count'], 0)

        # These documents exist and are pinned before the comparison is begun.
        hypothesis = self.write('hypothesis.json', {
            'kind': 'research_hypothesis', 'candidate_id': 'fixture-candidate',
            'proposal_task_id': 'fixture-proposal',
            'hypothesis': 'math.fsum preserves the unit term in this fixed cancellation fixture',
            'derivation': 'Exact decimal addition of 1e16, 1, and -1e16 equals 1',
            'prediction': 'Compensated error is zero and naive left-to-right error is one',
            'falsifier': 'Any different observed pair of errors refutes the fixture prediction'})
        design = self.write('design.json', {
            'kind': 'research_design', 'candidate_id': 'fixture-candidate',
            'hypothesis_ref': hypothesis, 'mode': 'empirical',
            'comparison': 'Naive left-to-right summation versus math.fsum',
            'protocol': 'Use exactly [1e16, 1, -1e16]; compare both against Decimal addition'})
        source = self.write('comparison.py', COMPARISON)
        self.record('add_task', task={
            'id': 'compare', 'candidate_id': 'fixture-candidate', 'kind': 'research_experiment',
            'experiment_phase': 'diagnostic',
            'action': 'Run the fixed numerical comparison', 'dependencies': ['preflight'],
            'input_refs': [hypothesis, design, source]})
        comparison = self.advance()
        self.assertEqual(comparison['kind'], 'execute')
        self.assertIn(hypothesis, comparison['attempt']['input_refs'])
        self.assertIn(design, comparison['attempt']['input_refs'])
        self.assertEqual(comparison['procedure_text'], (self.root / 'procedure.txt').read_text())
        self.execute('comparison.py', 'comparison-raw.json')
        comparison_evidence = self.settle(comparison['attempt'],
            [self.ref('comparison-raw.json')], ['comparison_checked'])

        cycle = {'cycle_id': 'fixture-cycle-1', 'candidate_id': 'fixture-candidate',
            'attempt_ids': [comparison['attempt']['id']], 'hypothesis_ref': hypothesis, 'design_ref': design}
        self.write('review-input.json', dict(cycle, kind='research_cycle_review',
            proposal_task_id='fixture-proposal', review_task_id='separate-fixture-review',
            raw_evidence=[comparison_evidence]))
        self.write('review.py', REVIEW)
        self.execute('review.py', 'comparison-raw.json', 'review-input.json', 'cycle-review.json')
        cycle['review_ref'] = self.ref('cycle-review.json')
        self.record('research_cycle', cycle=cycle)
        after_cycle = self.advance()
        self.assertEqual(after_cycle['kind'], 'replan')
        self.assertEqual(after_cycle['scientific_cycle_count'], 1)
        self.assertEqual(after_cycle['missing_criteria'], ['reproducibility_report'])
        self.assertIn('Repeat', after_cycle['action'])

        # Execute a real next task. A repeated run is not another research cycle.
        self.record('add_task', task={
            'id': 'reproduce-and-report', 'candidate_id': 'fixture-candidate', 'kind': 'action',
            'action': 'Re-execute the comparison and record reproducibility and limitations',
            'dependencies': ['compare'], 'input_refs': [source, comparison_evidence, cycle['review_ref']]})
        confirmation = self.advance()
        self.assertEqual(confirmation['kind'], 'execute')
        self.execute('comparison.py', 'confirmation-raw.json')
        first = json.loads((self.root / 'comparison-raw.json').read_text())
        repeated = json.loads((self.root / 'confirmation-raw.json').read_text())
        self.assertEqual(repeated, first)
        report = self.write('reproducibility-report.json', {
            'comparison_ref': self.ref('comparison-raw.json'),
            'confirmation_ref': self.ref('confirmation-raw.json'), 'identical': repeated == first,
            'scope': 'Deterministic engineering fixture; no benchmark or research gain claim'})
        self.settle(confirmation['attempt'], [self.ref('confirmation-raw.json'), report],
                    ['reproducibility_report'])
        before_review = self.advance()
        self.assertIn(before_review['kind'], {'replan', 'needs_goal_review'})
        self.assertEqual(before_review['scientific_cycle_count'], 1)
        self.assertEqual(before_review['missing_criteria'], [])

        state = self.cli('status')
        self.assertEqual(state['started_attempts'], 3)
        self.assertEqual(len(state['attempts']), 3)
        self.assertEqual(state['goal_contract']['request_ref'], request)
        goal_review = self.write('goal-review.json', {
            'kind': 'goal_review', 'goal_id': state['goal_id'], 'goal': state['goal'],
            'goal_revision': state['goal_revision'], 'state_revision': state['revision'],
            'goal_contract': state['goal_contract'], 'criteria': state['criteria'],
            'deliveries': state['deliveries'], 'attempt_ids': [a['id'] for a in state['attempts']],
            'cycle_ids': [cycle['cycle_id']], 'proposal_task_id': 'goal-proposal-fixture',
            'review_task_id': 'goal-review-fixture', 'outcome': 'complete',
            'limitation': 'Structural review fixture only; does not establish reviewer independence',
            'raw_evidence': [a['evidence_ref'] for a in state['attempts']] + [cycle['review_ref']]})
        # A real CPU diagnostic plus correct hashes still cannot close research.
        self.write('close-event.json', dict(op='goal_review', review_ref=goal_review))
        result = subprocess.run([sys.executable, str(SCRIPT), 'record', '--state', str(self.state),
            '--expected-revision', str(state['revision']), '--event', str(self.root / 'close-event.json')],
            cwd=self.root, capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 2)
        self.assertIn('scientific_evidence', result.stdout + result.stderr)
        done = self.cli('next')
        self.assertEqual(done['kind'], 'replan')
        self.assertEqual(done['scientific_cycle_count'], 1)
        self.assertEqual(self.cli('status')['authority'], 'operational_bookkeeping_only')


if __name__ == '__main__':
    unittest.main()
