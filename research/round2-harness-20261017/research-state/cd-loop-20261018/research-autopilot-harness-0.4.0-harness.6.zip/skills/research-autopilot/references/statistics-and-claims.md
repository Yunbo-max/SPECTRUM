# Statistical decisions and supported claims

Apply after native benchmark scoring, from Gate A to full validation and downstream
writing. Statistical analysis does not replace a task's native metric, denominator,
sampling or evaluator. Freeze the scientific estimand and a suitable design before
examining confirmation. A numerical method alone cannot establish independence,
causality, originality or top-conference acceptance.

## Frozen analysis and eligibility

New executable protocols require `method_version`, `project_version`,
`statistical_design`, explicit `eligibility` and the native evaluation contract.
`method_version` equals the frozen `provenance_constraints.git_tree_digest`.
The primary contract retains the Parent Problem's benchmark/revision/primary
endpoint. It uses the parent's `evaluation_split` or a previously declared
`allowed_eval_splits` list containing that split. Every selected split must also
exist in the retained published native definition. Additional full-validation
benchmarks use explicit group contracts and bounded claim scopes.

Supported eligibility is exactly `complete_inventory: true` and `unblinding`:
`after_freeze` for prospective confirmation, `registered_before_audit` for an
existing full-validation retrospective audit. Unknown policies block rather than
silently filtering runs. Keep the actual source chronology/exposure record; a
timestamp does not establish that results were unseen. Frozen seed/group policies
and full-validation `inventory_run_ids` must be complete; preserve failed,
unselected, negative and developmental attempts in the separate execution ledger.
Gate A cannot be retrospective. Its PASS only permits the bounded next stage.

`statistical_design` records `unit`, `independence_justification`, and optionally
`clustered` and `bootstrap`. Seed units use the run seed; another unit requires
`analysis_unit_id`. Duplicate units cannot count as independent repetitions.
The built-in design is `design: paired`, `aggregation: mean`, with one signed
treatment-minus-baseline native scalar per independent run unit, separately for
each frozen criterion/group. Choose uncertainty explicitly:

| `uncertainty` | Actual implementation and constraints |
| --- | --- |
| `none` | Point screen only; cannot be described as a confidence interval. |
| `normal` | Normal approximation, only when justified for the units/sample. |
| `paired_t` | Student-t interval for the independent paired differences; SciPy required. |
| `bootstrap` | SciPy bootstrap over paired differences; freeze `method` (`BCa`, `basic`, `percentile`), integer `resamples` and `seed`; degenerate/invalid outputs block. |
| `external` | Trusted live project analysis under a pinned `analysis_plan_ref`; stored outputs cannot authorize a new decision. |

`multiple_comparison_policy` is `single_claim` only for a one-test family,
`bonferroni` for an explicitly adjusted family of all frozen criterion/group tests,
or `external` with project analysis. A result-selected family is invalid.
Clustered/dependent designs require project analysis. Avoid universal seed counts
or a normal interval chosen merely because it is convenient.

Distinguish diagnostic point screens, deterministic finite-scope statements,
stochastic effects and generalization claims in the experiment contract. The
existence of `uncertainty: none` in a legacy numeric protocol is not permission
to close stochastic/generalization claims without appropriate uncertainty and
precision. Bind the declared independent unit, planned units, variability and
precision rationale to the actual claim; justify exact deterministic results
separately. A statistically narrow interval does not establish broad external
validity or remove dependence between evaluation units.

Freeze the exact contrast for each claim, including necessary treatment-versus-
ablation, simpler-replacement or interaction comparisons. A treatment-baseline
PASS and separate acceptable ablation scores do not test the difference between
them. Bind each obligation to its own canonical criterion/group and recomputed
estimand. Use reviewed project analysis for contrasts the selected evaluator
cannot represent; retain unsupported analysis as pending, not a surrogate PASS.

Track adaptive exposure across research rounds, including failed candidates and
data inspected during idea selection. Reusing a public test set for repeated
selection creates development evidence, even when each protocol has a new hash.
Use fresh appropriate confirmation or a justified analysis accounting for the
selection process; record limitations where fresh evaluation is unavailable.
Within-protocol multiplicity correction alone does not remove cross-round
selection bias. Never relabel already observed results as unseen confirmation.

For `design: external`, `aggregation: project`, every criterion uses `external`.
Install the actual reviewed analysis callback through
`_autoresearch.evaluation_runtime(analysis_context=callable)` or
`evaluate(..., analysis_context=callable)`. It receives exact values/units,
unit policy, criterion, family policy, and frozen scope containing protocol,
criterion/group, run-manifest refs and the analysis-plan hash. It returns matching
input/scope digests, `n`, `effect`, `lower`, `upper`, actual method/software version.
It must actually recompute the frozen estimand from retained native evidence and
apply the declared dependence/multiplicity handling. An adapter that simply echoes
saved numbers violates the host contract. Missing/unavailable adapters block.
The generic CLI supplies native scorer execution when explicitly authorized;
it does not automatically install a project-specific statistical or formal adapter.

Primary implementation references:
[SciPy bootstrap](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.bootstrap.html),
[SciPy paired t-test](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.ttest_rel.html).
Pin the actual local software version; documentation retrieval is not installation.

## Evidence changes and validation binding

Full-validation PASS anchors its exact decision, protocol, closure snapshot and
validated method/project versions. Every claim marked closed, including optional
claims, belongs to the frozen claim set and binds its own passed criteria.
Each criterion retains the actual eligible `run_ids` and native `proof_refs`;
claim evidence includes those run-manifest refs. A generic source file, a closed
boolean, another claim's criterion, or a run omitted from eligibility is insufficient.

Replacing the evidence snapshot revokes old validation/writing eligibility,
marks dependent assets stale, and returns writing/retarget work to full validation.
Updating the exact same snapshot does not revoke a valid binding. Re-enter writing
only after the changed evidence is checked and a new canonical decision/closure is
anchored. Neither a copied PASS nor a routine supervisor checkpoint can do this.
On every writing advance and handoff, verify the current state against the anchored
decision, protocol, closure and method/project versions. Historical immutable
binding checks do not rerun a GPU experiment merely to read a verified record.

## Frozen claim wording and scope

Full-validation protocols freeze `claim_cards` for exactly every `claim_set` ID.
Each card retains `supported_wording`, nonempty `forbidden_wording` and `limitations`,
`method_version`, `project_version`, and `scope`. A flat scope binds benchmark ID,
revision (`version`), native split, effective `sample_manifest_ref`, exact subset
`selection` when present, metrics, selected groups, and native budget.
For multiple benchmark contracts, `scope.evaluation_scopes` is keyed by exactly
the claim's groups and binds those same evaluation fields independently per group.
The top-level groups/metrics must match the frozen claim criteria. One group's
receipt or scope cannot certify a different benchmark.

Handoffs retain the exact cards for allowed closed claims and the current writing
stage. Same claim ID does not authorize broader language or a newer implementation.
The helper enforces IDs/versions/scope/proofs; a writer or human reviewer still
checks whether actual prose entails only the supported wording and limitations.
It is not a semantic theorem prover for free-form text.

## Editable asset propagation

Keep an asset manifest for motivation, methods, results, appendix, figures, title/
abstract/conclusion, project website and promotion drafts. Each entry records
`asset_id`, `kind`, actual `asset_ref`, `claim_ids`, `rendered_from` claim-card
digests and method/project versions. Retain editable SVG/plot/LaTeX/Markdown/web
source. Human edits are allowed and remain inspectable.

`_writing.refresh_assets` and `scripts/writing_assets.py` compare actual file
hashes, current claim cards and validated versions. Output is `current`, `stale`
or `blocked` plus explicit `rewrite_actions`. Changed wording/scope, version or
manual file edits trigger review; unknown claims block. The tracker reports an
update obligation, not a completed rewrite. Read current evidence, rewrite the
actual asset at its requested scope, review it, then retain its new refs/digests.
Never refresh a digest alone to conceal unsupported text. Public release remains
the user's separately authorized delivery task.

## Compatibility and actual capabilities

Artifact envelopes remain `1.0.0` with additive fields; the map registry has its
own revision. Legacy ledgers/captures remain readable. Legacy scalar summaries and
flags are insufficient for a new native-scored decision or writing certification:
retain the real scorer inputs/outputs, pinned native contract, analysis policy,
bounded claim cards and an anchored validation binding first. Do not forge a
conversion or rewrite historical evidence. Missing assets produce explicit blockers.
Contribution-specific Gate 0 supports formal evidence review, but the empirical
paired-scalar Gate A/full-validation helper cannot certify pure-theory claims.
They require a supported formal evaluator; never invent an empirical benchmark.
