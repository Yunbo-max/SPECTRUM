"""Retain the Chat scope/continuation contract; not an agent-compliance test."""
from pathlib import Path
import unittest


SKILL = Path(__file__).resolve().parents[1]


def read(relative):
    return ' '.join((SKILL / relative).read_text(encoding='utf-8').split())


class ChatGoalPolicyTests(unittest.TestCase):
    def test_entry_preserves_request_and_separates_goal_from_milestone(self):
        text = read('SKILL.md')
        for term in ('original user request', 'project goal', 'current milestone',
                     'bounded_task', 'research'):
            self.assertIn(term, text)

    def test_preflight_cannot_close_authorized_research(self):
        text = read('references/chat-execution.md')
        for term in ('CPU feasibility is a milestone', 'goal_contract', 'request_ref',
                     'continuation_action', 'goal_review'):
            self.assertIn(term, text)

    def test_explicit_selection_only_scope_remains_valid(self):
        text = read('references/chat-execution.md')
        self.assertIn('only choose a runnable paper', text)
        self.assertIn('bounded_task', text)
        self.assertIn('Do not expand that request into autonomous research', text)

    def test_cycle_counts_require_research_evidence_not_seed_counts(self):
        text = read('references/autonomous-rsi.md')
        for term in ('hypothesis', 'executed comparison', 'review', 'next decision',
                     'Three methods by three seeds are nine runs'):
            self.assertIn(term, text)

    def test_resume_does_not_reset_or_invent_round_bound(self):
        text = read('references/chat-execution.md')
        self.assertIn('Do not reset or invent a one-round budget on resume', text)
        self.assertIn('revise_goal', text)
        self.assertIn('preserve the old goal', text)

    def test_current_chat_starter_is_first_and_preserves_scope(self):
        text = (SKILL / 'references/project-chat-instructions.md').read_text(encoding='utf-8')
        first_block = text.split('```text', 1)[1].split('```', 1)[0]
        for term in ('original user request', 'CPU feasibility', 'current host',
                     'cumulative', 'scientific cycles'):
            self.assertIn(term, first_block)
        self.assertNotIn('Local must pass', first_block)

    def test_web_contract_keeps_host_boundary_and_goal_review(self):
        text = read('references/web-background-work.md')
        self.assertIn('goal_review', text)
        self.assertIn('preflight', text)
        self.assertIn('Do not claim work continues between turns', text)


if __name__ == '__main__':
    unittest.main()
