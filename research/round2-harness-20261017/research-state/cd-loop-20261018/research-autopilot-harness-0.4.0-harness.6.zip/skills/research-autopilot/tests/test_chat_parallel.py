"""Behavioral bookkeeping tests with explicit simulated host observations.

No real models, agents, GPUs, paid calls, or scientific verdicts are exercised.
"""
import hashlib
import copy
import importlib.util
import json
import math
from datetime import datetime, timedelta, timezone
from pathlib import Path
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts/chat_cycle.py'
SPEC = importlib.util.spec_from_file_location('chat_parallel_cycle', SCRIPT)
C = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(C)


class ChatParallelTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.path = self.root / 'cycle.json'
        self.serial = 0
        self.input_ref = self.write('input.txt', 'Pinned source material')
        self.procedure = dict(id='p1', ref=self.write('procedure.md', 'Actual parent procedure'))
        self.limits = dict(wall_seconds=1000, gpu_seconds=100, cost=50)
        C.initialize(self.path, dict(goal_id='g', goal='Review one candidate',
            goal_contract=dict(mode='bounded_task', request_ref=self.write('request.txt', 'Review one candidate'),
                               continuation_action='Continue current candidate'),
            criteria=['reviewed'], deliveries=[], budget=dict(max_attempts=5, limits=self.limits),
            procedure=self.procedure,
            tasks=[dict(id='t1', action='Review sources and code', candidate_id='c1',
                        dependencies=[], input_refs=[self.input_ref], experiment_job_ids=['job1', 'job2'])]))
        self.event('usage', totals={k: 0 for k in self.limits}, receipt_ref=self.write('initial-usage.txt', 'Observed zeros'))
        self.attempt = self.event('begin', task_id='t1')['current_attempt']

    def write(self, name, content):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        data = content if isinstance(content, str) else json.dumps(content, sort_keys=True)
        path.write_text(data, encoding='utf-8')
        return dict(path=name, sha256=hashlib.sha256(path.read_bytes()).hexdigest())

    def unique(self, label, value):
        self.serial += 1
        return self.write(str(self.serial) + '-' + label, value)

    def event(self, op, **values):
        if op.startswith('team_') and op != 'team_capability':
            values.setdefault('attempt_id', self.attempt['id'])
        return C.record(self.path, C.status(self.path)['revision'], dict(op=op, **values))

    def state(self):
        return C.status(self.path)

    def team(self):
        return self.state()['current_attempt']['team']

    def child(self, ident):
        return next(c for c in self.team()['children'] if c['id'] == ident)

    def capability(self, *, spawn=True, observe=True, continuation=True, capacity=4, active=None, stale=False):
        now = datetime.now(timezone.utc)
        evidence = dict(kind='chat-team-capability', session_id='host-session', parent_agent_id='parent',
            capabilities=dict(spawn=spawn, observe=observe, **{'continue': continuation}),
            max_active_agents=capacity, active_agent_ids=active or ['parent'],
            observed_at=(now - timedelta(seconds=120 if stale else 1)).isoformat(),
            expires_at=(now + timedelta(seconds=-1 if stale else 600)).isoformat(),
            source_ref=self.unique('host-capability.txt', 'Simulated actual host inventory'))
        ref = self.unique('capability.json', evidence)
        self.event('team_capability', observation_ref=ref)
        return ref

    def start(self, *, max_children=8, reserve=None, capability=True):
        if capability:
            self.capability()
        return self.event('team_start', config=dict(source_ref=self.unique('team-plan.txt', 'Authorized finite action plan'),
            max_children=max_children, deadline_seconds=900,
            parent_reserve=reserve or dict(wall_seconds=100, gpu_seconds=5, cost=1),
            parent_output_paths=['parent-result.txt'], parent_resource_ids=[]))

    def prepare(self, ident, **patch):
        packet = dict(id=ident, role='source', action='Inspect independent source ' + ident,
            acceptance='Return cited exact observations', input_refs=[self.input_ref],
            output_paths=[ident + '/result.txt'], reserve=dict(wall_seconds=60, gpu_seconds=10, cost=2),
            deadline_seconds=50, max_continuations=1, resource_ids=[], job_ids=[])
        packet.update(patch)
        self.event('team_prepare', packet=packet)
        return self.child(ident)

    def operation(self, ident, state='running', *, agent_id=None, **patch):
        child = self.child(ident)
        receipt = dict(kind='chat-team-operation', attempt_id=self.attempt['id'], child_id=ident,
            dispatch_token=child['dispatch_token'], session_id='host-session',
            agent_id=None if state == 'not_started' else (agent_id or child.get('agent_id') or 'agent-' + ident),
            state=state, observed_at=datetime.now(timezone.utc).isoformat(),
            source_ref=self.unique('host-operation.txt', 'Simulated actual host operation ' + state))
        receipt.update(patch)
        return self.unique('operation.json', receipt)

    def bind(self, ident, agent_id=None):
        self.event('team_bind', child_id=ident, dispatch_token=self.child(ident)['dispatch_token'],
                   receipt_ref=self.operation(ident, agent_id=agent_id))
        return self.child(ident)

    def observe(self, ident, status, **patch):
        self.event('team_observe', child_id=ident, receipt_ref=self.operation(ident, status, **patch))
        return self.child(ident)

    def result_ref(self, ident, outcome='completed', actual=None, **patch):
        child = self.child(ident)
        output = self.write(child['output_paths'][0], 'New result for ' + ident)
        result = dict(kind='chat-child-result', attempt_id=self.attempt['id'], child_id=ident,
            candidate_id='c1', procedure=self.procedure, input_refs=child['input_refs'],
            dispatch_token=child['dispatch_token'], agent_id=child.get('agent_id'), outcome=outcome,
            operation_ref=self.operation(ident, outcome), raw_evidence=[output], output_refs=[output],
            actual_usage=actual or dict(wall_seconds=20, gpu_seconds=3, cost=0.5),
            usage_ref=self.unique('usage-source.txt', 'Observed actual engineering test usage'))
        result.update(patch)
        return self.unique('child-result.json', result)

    def finish(self, ident, outcome='completed', **patch):
        reference = self.result_ref(ident, outcome, **patch)
        self.event('team_result', child_id=ident, result_ref=reference)
        return reference

    def usage(self, ids=None, totals=None):
        children = [c for c in self.team()['children'] if c['status'] in {'completed', 'failed', 'cancelled'}]
        ids = ids if ids is not None else [c['id'] for c in children]
        children = [c for c in children if c['id'] in ids]
        if totals is None:
            totals = {unit: (max((c['actual_usage'][unit] for c in children), default=0)
                            if unit == 'wall_seconds' else sum(c['actual_usage'][unit] for c in children))
                      for unit in self.limits}
            totals['wall_seconds'] = math.ceil(max([totals['wall_seconds'],
                (datetime.now(timezone.utc) - datetime.fromisoformat(self.team()['started_at'])).total_seconds()]
                + [c['wall_usage_baseline'] + c['actual_usage']['wall_seconds'] for c in children]))
        ref = self.unique('team-usage.json', dict(kind='chat-team-usage', attempt_id=self.attempt['id'],
            totals=totals, accounted_child_ids=ids, observed_at=datetime.now(timezone.utc).isoformat(),
            source_ref=self.unique('cumulative.txt', 'Observed whole-project cumulative totals')))
        return self.event('team_usage', totals=totals, accounted_child_ids=ids, receipt_ref=ref)

    def parent_result(self, outcome='completed', include_children=True):
        raw = self.write('parent-result.txt', 'Integrated parent result')
        refs = [c['result_ref'] for c in self.team()['children'] if 'result_ref' in c] if include_children else []
        evidence = self.unique('parent-envelope.json', dict(attempt_id=self.attempt['id'], task_id='t1',
            candidate_id='c1', procedure_id='p1', outcome=outcome, raw_evidence=[raw] + refs,
            criteria_met=['reviewed'], delivery_receipts={}))
        return self.event('result', attempt_id=self.attempt['id'], outcome=outcome, evidence_ref=evidence,
                          reason='Observed parent outcome', next_action='Continue goal')

    def test_two_children_out_of_order_failed_sibling_does_not_erase_live_sibling(self):
        self.start()
        self.prepare('a'); self.bind('a')
        self.prepare('b'); self.bind('b')
        self.finish('b', 'failed')
        self.assertEqual(self.child('a')['status'], 'running')
        self.assertEqual(C.next_action(self.path)['children'][0]['child_id'], 'a')
        self.finish('a')
        self.usage()
        self.parent_result()
        state = self.state()
        self.assertEqual(state['attempts'][0]['team']['children'][1]['status'], 'failed')
        self.assertEqual(state['started_attempts'], 1)
        self.assertEqual(state['research_cycles'], [])
        self.assertEqual(C.next_action(self.path)['kind'], 'bookkeeping_complete')

    def test_no_tools_means_serial_fallback_without_new_attempt(self):
        self.capability(spawn=False)
        with self.assertRaisesRegex(ValueError, 'serially'):
            self.start(capability=False)
        self.assertNotIn('team', self.state()['current_attempt'])
        self.assertEqual(C.next_action(self.path)['kind'], 'continuation')
        self.assertEqual(self.state()['started_attempts'], 1)

    def test_dynamic_external_occupancy_and_unknown_dispatch_take_slots(self):
        self.capability(capacity=3, active=['parent', 'external'])
        self.start(capability=False)
        self.prepare('a')
        with self.assertRaisesRegex(ValueError, 'slot'):
            self.prepare('b')
        self.observe('a', 'unknown', agent_id=None)
        self.capability(capacity=3, active=['parent', 'external'])
        with self.assertRaisesRegex(ValueError, 'slot'):
            self.prepare('b')

    def test_stale_capability_rejected_without_rewriting_state(self):
        before = self.path.read_bytes()
        with self.assertRaisesRegex(ValueError, 'stale'):
            self.capability(stale=True)
        self.assertEqual(self.path.read_bytes(), before)

    def test_changed_input_pins_block_child_prepare_and_settlement(self):
        self.start(); self.prepare('a'); self.bind('a')
        self.write('input.txt', 'Changed pinned source')
        with self.assertRaisesRegex(ValueError, 'hash'):
            self.prepare('b')
        with self.assertRaisesRegex(ValueError, 'hash'):
            self.finish('a')

    def test_overlap_parent_children_input_and_checkpoint_outputs_rejected(self):
        self.start(); self.prepare('a')
        for path in ['parent-result.txt', 'a/result.txt', 'a', 'input.txt', 'procedure.md', 'cycle.json', 'cycle.json.lock', 'cycle.json.tmp', '../outside']:
            with self.subTest(path=path), self.assertRaises(ValueError):
                self.prepare('b', output_paths=[path])

    def test_symlink_output_alias_rejected(self):
        self.start()
        (self.root / 'alias').symlink_to(self.root / 'input.txt')
        with self.assertRaisesRegex(ValueError, 'symlink'):
            self.prepare('a', output_paths=['alias'])

    def test_shared_additive_budget_includes_parent_and_all_children(self):
        self.start(reserve=dict(wall_seconds=100, gpu_seconds=75, cost=1))
        self.prepare('a')
        self.prepare('b')
        with self.assertRaisesRegex(ValueError, 'budget'):
            self.prepare('c')

    def test_unknown_child_cannot_release_budget_or_repeat_dispatch(self):
        self.start(); self.prepare('a'); self.observe('a', 'unknown', agent_id=None)
        with self.assertRaisesRegex(ValueError, 'duplicate'):
            self.prepare('a')
        with self.assertRaisesRegex(ValueError, 'acknowledged partial'):
            self.event('team_continue', child_id='a')
        with self.assertRaisesRegex(ValueError, 'live child'):
            self.usage(ids=['a'])
        with self.assertRaisesRegex(ValueError, 'team_usage'):
            self.event('usage', totals={k: 0 for k in self.limits}, receipt_ref=self.unique('wrong-usage.txt', 'Not release authority'))

    def test_rejected_spawn_needs_no_effect_terminal_receipt(self):
        self.start(); self.prepare('a')
        bad = self.result_ref('a', 'cancelled', operation_ref=self.operation('a', 'unknown', agent_id=None))
        with self.assertRaisesRegex(ValueError, 'terminal'):
            self.event('team_result', child_id='a', result_ref=bad)
        ref = self.result_ref('a', 'cancelled', operation_ref=self.operation('a', 'not_started', agent_id=None),
                              actual=dict(wall_seconds=0.01, gpu_seconds=0, cost=0), output_refs=[])
        self.event('team_result', child_id='a', result_ref=ref)
        self.usage()
        self.assertEqual(self.child('a')['status'], 'cancelled')

    def test_parent_all_outcomes_and_resume_block_with_unresolved_children(self):
        self.start(); self.prepare('a'); self.bind('a')
        for outcome in ['completed', 'failed', 'blocked', 'refuted']:
            with self.subTest(outcome=outcome), self.assertRaisesRegex(ValueError, 'unresolved'):
                self.parent_result(outcome)
        self.event('checkpoint', attempt_id=self.attempt['id'], reason='Turn boundary', next_action='Reconcile children')
        with self.assertRaisesRegex(ValueError, 'unresolved'):
            C.resume(self.path, self.state()['revision'])
        self.assertEqual(C.advance(self.path, self.state()['revision'])['kind'], 'parallel')
        self.assertEqual(self.state()['started_attempts'], 1)

    def test_partial_continuation_keeps_identity_pins_and_is_finite(self):
        self.start(); self.prepare('a', output_paths=['a/result.txt', 'a/partial.txt']); original = self.bind('a')
        partial = self.write('a/partial.txt', 'Acknowledged partial draft')
        self.observe('a', 'partial', partial_refs=[partial], next_action='Finish specific missing paragraph')
        self.event('team_continue', child_id='a')
        continued = self.child('a')
        self.assertEqual(continued['agent_id'], original['agent_id'])
        self.assertEqual(continued['procedure'], original['procedure'])
        self.assertNotEqual(continued['dispatch_token'], original['dispatch_token'])
        with self.assertRaisesRegex(ValueError, 'acknowledged partial'):
            self.event('team_continue', child_id='a')
        self.bind('a')
        self.observe('a', 'partial', partial_refs=[partial], next_action='Still missing one part')
        with self.assertRaisesRegex(ValueError, 'allowance'):
            self.event('team_continue', child_id='a')

    def test_wrong_agent_old_token_and_duplicate_settlement_rejected(self):
        self.start(); saved = self.prepare('a'); self.bind('a')
        for patch in [dict(agent_id='foreign'), dict(dispatch_token='stale-token'), dict(candidate_id='foreign')]:
            with self.subTest(patch=patch), self.assertRaises(ValueError):
                self.event('team_result', child_id='a', result_ref=self.result_ref('a', **patch))
        self.finish('a')
        with self.assertRaisesRegex(ValueError, 'terminal'):
            self.event('team_result', child_id='a', result_ref=self.child('a')['result_ref'])
        with self.assertRaisesRegex(ValueError, 'terminal'):
            self.event('team_bind', child_id='a', dispatch_token=saved['dispatch_token'], receipt_ref=self.operation('a'))

    def test_review_waits_for_artifact_then_requires_other_host_agent(self):
        self.start(); self.prepare('a'); self.bind('a')
        with self.assertRaisesRegex(ValueError, 'completed pinned'):
            self.prepare('review', role='review', review_of=['a'])
        self.finish('a')
        result = json.loads((self.root / self.child('a')['result_ref']['path']).read_text())
        inputs = [self.input_ref] + result['output_refs']
        self.prepare('review', role='review', review_of=['a'], input_refs=inputs)
        with self.assertRaisesRegex(ValueError, 'distinct'):
            self.bind('review', agent_id='agent-a')
        self.bind('review', agent_id='independent-reviewer')
        self.assertEqual(self.child('review')['producer_agent_ids'], ['agent-a'])

    def test_arbitrary_action_cannot_dispatch_experiment_children(self):
        self.start()
        for patch in [dict(job_ids=['job1']), dict(job_ids=['job2'], resource_ids=['gpu:allocation0']), dict(job_ids=['unplanned'])]:
            with self.subTest(patch=patch), self.assertRaises(ValueError):
                self.prepare('b', role='experiment', **patch)
        self.assertEqual(self.state()['research_cycles'], [])

    def test_walltime_is_max_not_sum_and_additive_usage_is_sum(self):
        self.start(); self.prepare('a'); self.bind('a'); self.prepare('b'); self.bind('b')
        self.finish('a', actual=dict(wall_seconds=20, gpu_seconds=3, cost=0.5))
        self.finish('b', actual=dict(wall_seconds=25, gpu_seconds=4, cost=0.8))
        with self.assertRaisesRegex(ValueError, 'omits'):
            self.usage(totals=dict(wall_seconds=25, gpu_seconds=4, cost=0.8))
        self.usage(totals=dict(wall_seconds=26, gpu_seconds=7, cost=1.3))
        self.assertEqual(self.state()['usage']['totals']['wall_seconds'], 26)
        self.parent_result()

    def test_result_can_record_overrun_and_reconcile_after_budget_exhaustion(self):
        self.start(); self.prepare('a'); self.bind('a')
        self.finish('a', actual=dict(wall_seconds=10, gpu_seconds=101, cost=2))
        with self.assertRaisesRegex(ValueError, 'cumulative usage'):
            self.parent_result()
        self.usage()
        with self.assertRaisesRegex(ValueError, 'budget'):
            self.prepare('b')
        self.parent_result('failed')
        self.assertEqual(self.state()['usage']['totals']['gpu_seconds'], 101)

    def test_parent_evidence_keeps_child_receipts_and_changed_child_bytes_invalidate(self):
        self.start(); self.prepare('a'); self.bind('a'); self.finish('a'); self.usage()
        with self.assertRaisesRegex(ValueError, 'every settled child'):
            self.parent_result(include_children=False)
        self.parent_result()
        self.write('a/result.txt', 'Late overwritten child artifact')
        status = C.next_action(self.path)
        self.assertNotEqual(status['kind'], 'bookkeeping_complete')
        self.assertTrue(status['invalid_evidence'])

    def test_team_bounds_cannot_reset_and_child_count_is_finite(self):
        self.start(max_children=1)
        with self.assertRaisesRegex(ValueError, 'cannot reset'):
            self.start(capability=False)
        self.prepare('a'); self.bind('a'); self.finish('a'); self.usage()
        with self.assertRaisesRegex(ValueError, 'allowance'):
            self.prepare('b')

    def test_same_live_agent_cannot_own_two_packets(self):
        self.start(); self.prepare('a'); self.bind('a'); self.prepare('b')
        with self.assertRaisesRegex(ValueError, 'already owns'):
            self.bind('b', agent_id='agent-a')

    def test_capability_change_cannot_rebind_existing_team_host(self):
        self.start(); self.prepare('a')
        cap = json.loads((self.root / self.state()['team_capability_ref']['path']).read_text())
        cap['session_id'] = 'new-session'
        with self.assertRaisesRegex(ValueError, 'original host'):
            self.event('team_capability', observation_ref=self.unique('newhost.json', cap))

    def test_internal_packet_fields_cannot_replace_reserved_budget(self):
        self.start(reserve=dict(wall_seconds=100, gpu_seconds=75, cost=1))
        with self.assertRaisesRegex(ValueError, 'internal'):
            self.prepare('a', actual_usage={k: 0 for k in self.limits})
        self.assertEqual(self.team()['children'], [])

    def test_anonymous_partial_cannot_become_a_fresh_agent_continuation(self):
        self.start(); self.prepare('a', output_paths=['a/result.txt', 'a/partial.txt'])
        partial = self.write('a/partial.txt', 'Partial with no verifiable agent identity')
        receipt = json.loads((self.root / self.operation('a', 'partial', partial_refs=[partial], next_action='Continue')['path']).read_text())
        receipt['agent_id'] = None
        with self.assertRaisesRegex(ValueError, 'anonymous'):
            self.event('team_observe', child_id='a', receipt_ref=self.unique('anonymous.json', receipt))
        with self.assertRaisesRegex(ValueError, 'acknowledged partial'):
            self.event('team_continue', child_id='a')

    def test_changed_pins_do_not_lock_observation_and_failed_reconciliation(self):
        self.start(); self.prepare('a'); self.bind('a')
        self.write('input.txt', 'External input change')
        self.observe('a', 'failed')
        self.finish('a', 'failed')
        self.usage()
        self.parent_result('failed')
        attempt = self.state()['attempts'][0]
        self.assertTrue(attempt['invalidated_parent_pins'])
        self.assertTrue(attempt['team']['children'][0]['invalidated_parent_pins'])
        self.assertEqual(attempt['outcome'], 'failed')

    def test_missing_completed_child_artifact_does_not_lock_failed_parent(self):
        self.start(); self.prepare('a'); self.bind('a'); self.finish('a'); self.usage()
        (self.root / 'a/result.txt').unlink()
        with self.assertRaises(OSError):
            self.parent_result()
        self.parent_result('failed')
        self.assertTrue(self.state()['attempts'][0]['team']['invalidated_child_evidence'])

    def test_missing_child_result_receipt_is_preserved_as_invalidated_history(self):
        self.start(); self.prepare('a'); self.bind('a'); self.finish('a'); self.usage()
        reference = self.child('a')['result_ref']
        (self.root / reference['path']).unlink()
        self.parent_result('failed', include_children=False)
        attempt = self.state()['attempts'][0]
        self.assertEqual(attempt['team']['children'][0]['result_ref'], reference)
        self.assertEqual(attempt['team']['invalidated_child_evidence'][0]['result_ref'], reference)

    def test_control_receipts_are_not_available_as_child_outputs(self):
        self.start(); self.prepare('a'); self.bind('a')
        operation_ref = self.child('a')['operation_ref']
        operation = json.loads((self.root / operation_ref['path']).read_text())
        for path in [operation_ref['path'], operation['source_ref']['path'], self.state()['team_capability_ref']['path']]:
            with self.subTest(path=path), self.assertRaisesRegex(ValueError, 'overlap'):
                self.prepare('b', output_paths=[path])

    def test_sequential_waves_preserve_elapsed_walltime_baseline(self):
        self.start(); self.prepare('a'); self.bind('a')
        self.finish('a', actual=dict(wall_seconds=20, gpu_seconds=1, cost=0.1))
        self.prepare('b'); self.bind('b')
        self.finish('b', actual=dict(wall_seconds=25, gpu_seconds=1, cost=0.1))
        with self.assertRaisesRegex(ValueError, 'omits'):
            self.usage(totals=dict(wall_seconds=26, gpu_seconds=2, cost=0.2))
        self.usage(totals=dict(wall_seconds=46, gpu_seconds=2, cost=0.2))

    def test_usage_accepts_exact_observed_elapsed_without_write_latency_padding(self):
        self.start()
        observed_at = datetime.now(timezone.utc)
        elapsed = (observed_at - datetime.fromisoformat(self.team()['started_at'])).total_seconds()
        totals = dict(wall_seconds=elapsed, gpu_seconds=0, cost=0)
        receipt = self.unique('exact-usage.json', dict(kind='chat-team-usage', attempt_id=self.attempt['id'],
            totals=totals, accounted_child_ids=[], observed_at=observed_at.isoformat(),
            source_ref=self.unique('exact-source.txt', 'Actual observation taken before saving the receipt')))
        self.event('team_usage', totals=totals, accounted_child_ids=[], receipt_ref=receipt)
        self.assertEqual(self.state()['usage']['totals']['wall_seconds'], elapsed)

    def test_real_confirmation_admission_derives_host_lock_and_requires_job_terminal_receipt(self):
        # Reuse the actual canonical CPU fixture; no mock of Chat/science admission.
        from test_chat_science_bridge import ChatScienceBridgeTests
        fixture = ChatScienceBridgeTests()
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        extra = copy.deepcopy(fixture.f.contract['jobs'][0])
        extra['id'] = 'second'
        fixture.f.contract['jobs'].append(extra)
        for obligation in fixture.f.contract['obligations']:
            if obligation['applicability'] == 'required':
                obligation['job_ids'].append('second')
        fixture.prepare()
        config = C.status(fixture.path)
        # A new independent fixture project gets a fresh checkpoint lineage.
        config.pop('lineage')
        config['tasks'][0]['experiment_job_ids'] = ['compare', 'second']
        self.root = fixture.root
        self.path = self.root / 'team-confirmation.json'
        self.procedure = config['procedure']
        self.limits = config['budget']['limits']
        self.input_ref = config['tasks'][0]['input_refs'][0]
        C.initialize(self.path, config)
        fixture.controls.activate(self.path)
        self.event('usage', totals=dict(wall_seconds=2, gpu_seconds=0, cost=0), receipt_ref=fixture.f.raw)
        self.attempt = C.advance(self.path, self.state()['revision'])['attempt']
        self.start(reserve=dict(wall_seconds=10, gpu_seconds=0, cost=0))
        options = dict(role='experiment', reserve=dict(wall_seconds=2, gpu_seconds=0, cost=0), deadline_seconds=1)
        self.prepare('a', job_ids=['compare'], resource_ids=[], **options)
        self.assertIn('experiment-host:cpu', self.child('a')['resource_ids'])
        self.bind('a')
        self.observe('a', 'completed')
        for resources in [[], ['pretend-different-device']]:
            with self.assertRaisesRegex(ValueError, 'already owned'):
                self.prepare('b', job_ids=['second'], resource_ids=resources, **options)
        with self.assertRaisesRegex(ValueError, 'evidence refs'):
            self.finish('a', actual=dict(wall_seconds=0.1, gpu_seconds=0, cost=0))
        child = self.child('a')
        job = dict(kind='chat-team-job-receipt', attempt_id=self.attempt['id'], child_id='a',
            contract_ref=self.attempt['experiment_contract_ref'], dispatch_token=child['dispatch_token'],
            job_id='compare', host_id='cpu', execution_id='actual-fixture-run', state='completed',
            observed_at=datetime.now(timezone.utc).isoformat(), source_ref=fixture.f.raw)
        self.finish('a', actual=dict(wall_seconds=0.1, gpu_seconds=0, cost=0),
                    job_receipts=[self.unique('job-terminal.json', job)])
        self.prepare('b', job_ids=['second'], resource_ids=[], **options)


if __name__ == '__main__':
    unittest.main()
