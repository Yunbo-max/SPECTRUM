# Consequential, original and benchmark-grounded research

Apply the owner's standing high bar across direction selection, idea generation,
method design, experimental expansion and final claims. Reuse the goal/resource
brief, Parent Problem, natural evidence, collision report and H03 decision card.
Respect current explicit user scope; a reproduction, repair or website request
does not require inventing a contribution. This is a research review contract,
not a new ledger schema, authorization, scientific gate or automatic score.

## Select evaluation from the scientific prediction

Apply [research-cycle.md](research-cycle.md) to benchmark choice, justified condition
studies, limited mathematical/engineering diagnostics and exceptional new-benchmark
research. It clarifies the blanket wording below at those scopes. Prefer existing
evaluations that discriminate the claim under feasible complete costs. Keep altered
protocols separate from standard scores; never fabricate native provenance.


## Benchmark evaluation integrity

Apply the owner's rule to research and benchmark evaluation at every stage,
including discovery measurements, Gate A, mechanism evaluation, full validation
and debugging or qualifying the eval path. Use existing published benchmarks,
their released data/splits, reference labels/test suites and native evaluation
protocol. Use official evaluation code or a verified faithful harness. Never
handcraft evaluation cases or create a replacement benchmark, test suite, label
set or ad hoc scoring rule. Calling an eval case "debug-only" or "diagnostic-only"
does not permit this substitution. Official benchmark cases remain usable even
when their original authors constructed them; the restriction is on creating our
own eval materials or replacing the established evaluation.

Preserve dataset/task revisions, split and sample IDs, preprocessing, evaluator
revision, extraction, metric, denominator, aggregation and effective settings.
Retain sampling count, selection/retries, seeds, information access and compute
budget: pass@1, best-of-k and pass@k are distinct evaluation contracts. Actual
outputs and run/error records diagnose the existing eval path; they do not by
themselves define a new benchmark or qualify a substitute scoring protocol.

A minimum experiment prospectively selects a manageable native development
subset or fewer models/runs while preserving the task and scoring contract.
There is no lower scientific-standard "quick test" mode. Short time, early
exploration, debug or tuning cannot waive qualified baselines, essential controls,
matched information/budget, uncertainty appropriate to the decision, raw evidence
or independent confirmation requirements. Reduce scope to a defensible comparison
or retain an inconclusive/blocked design when these cannot fit. A small experiment
can be rigorous; its evidential scope remains bounded. Do not turn software smoke
checks, a few convenient successes or hand-picked best settings into efficacy proof.
Label subset/pilot results with their scope; they are not full-benchmark results.
Tune on development data and reserve fresh confirmation. Mechanism ablations
change the method applied to the same benchmark inputs, not inputs, reference
labels or native scoring to manufacture a favorable comparison. Faithful format
or environment adapters are implementation work; verify equivalence and record
their version. A materially changed eval is not a standard benchmark result.

When suitable evaluation assets or native known-outcome cases are absent, retrieve
an existing source or report that the eval check is blocked. Never invent a
substitute or mark qualification passed without an observed check. Retain prior
records for audit, but exclude self-made eval cases from benchmark scores and
scientific performance judgments.

Keep this scope explicit: mathematical exposition, teaching illustrations,
method-generated training data and isolated non-evaluation engineering fixtures
are not categorically forbidden by this rule. Label them accurately; they cannot
replace benchmark eval, qualify its scoring path or establish method efficacy.

## Importance and originality review

Before recommending a direction or candidate for method development, answer the
following with actual evidence references. Unavailable evidence remains unknown.

| Required question | Evidence or decision to retain |
|---|---|
| Why does this problem deserve solving? | Natural task/population, consequential endpoint, prevalence/uncertainty and the gap remaining after qualified strong simple alternatives. A convenient proxy or an unusual niche alone is insufficient. |
| What substantively changes relative to closest work? | Function-level comparison of the essential claim, assumptions, objective/computation and predicted behavior against the closest primary full texts; distinguish a new capability, explanation, principle or consequential tradeoff from a cosmetic variation. |
| Why is the advance nontrivial? | The failed assumption or limitation, competing explanations and a prediction existing mechanisms or a budget-matched simple substitute do not already imply. State what evidence would refute this difference. |
| Is this target already crowded and covered? | Map relevant work families and which cover the actual failure, mechanism and endpoint, using a dated search/citation-expansion snapshot. Publication counts, fashion and names are weak proxies; assess substantive coverage. |
| Can the central claim be tested credibly? | Link to the benchmark-first feasibility review below, with actual data/evaluator/baseline identities, access status, official metric and affordable decisive comparison. |

Reject a new-method recommendation supported only by combining popular modules,
renaming computation, changing a backbone/dataset/language, being the first in a
small subset or obtaining a small score gain. Record borrowed ideas and sources;
functional equivalence requires accurate attribution. Field density alone is
neither a plagiarism judgment nor evidence that every important problem is solved.

For a crowded target, require a supported consequential residual problem and a
defensible substantive departure before recommending entry. When closest work
already covers the core, prefer another problem or an honest scoped contribution;
do not keep shrinking the claim to preserve a nominal first. Apply IPCG and its
existing restart/stop rules. An empty literature niche earns no originality
preference without importance, an explanatory advance and credible measurement.

For composition, specify why the functions must interact, the information each
uses, their compatibility and a distinguishing interaction prediction. Plan
A, B, A+B and a budget/information-matched replacement where relevant. A gain
caused by extra parameters, samples, labels, retrieval or tuning cannot establish
the claimed new mechanism. Reusing components is legitimate when the interaction
is substantively new and necessary; reject arbitrary assembly and packaging.

Keep the generator's novelty hypothesis separate from collision adjudication.
Report exactly what the dated search supports; never promise absolute originality
or acceptance. A positive result does not raise the novelty verdict automatically;
a null result does not rule out an important original finding or boundary law.

## Benchmark-first feasibility

For empirical method research, locate an existing benchmark that measures the
central claim before selecting an intervention. Consult actual primary benchmark
documentation, author repositories/task configs and released evaluation code.
Reuse the user's suitable benchmark. Do not choose an unsuitable popular task
merely to have a standard score or silently change the original scientific goal.

Return a compact readiness record for each proposed benchmark:

| Required item | What to verify |
|---|---|
| Scientific fit | Task, input/output, eligible population, endpoint and exactly which claim the benchmark can and cannot test. |
| Usable data | Actual dataset ID/location, version/config/splits, natural sample source, size, permitted access and material preprocessing; distinguish located metadata from verified access. |
| Reproducible evaluator | Official or faithful validated harness/task/scorer version, runnable interface and dependencies; use benchmark-supplied test cases or traceable actual correct/incorrect/error outputs for checks, never manufactured fixtures; distinguish availability from an observed run. |
| Comparable baselines | Strong published and simple baselines, actual compatible code/models/settings and reproduction status; no invented runnable command or result. |
| Exact scoring and budget | Metric, denominator, extraction, aggregation, generations/selection/retries, information access, tuning and total compute; pass@1, best-of-k and pass@k remain different contracts. |
| Decisive affordable test | Frozen development sampling rule and IDs, effect/uncertainty and stopping rules, required controls, available fresh confirmation and P04 resource bound. |

Use a manageable, prospectively selected official development subset for the
smallest diagnostic when justified; retain its sampling rule and denominator.
Use appropriate independent confirmation for claims chosen after inspection.
Freeze the native task contract and compare under matched information/budget.
Repair an unofficial incompatible scorer or unfair baseline before interpreting
an apparent method gain or expanding the experiment matrix.

Never create hand-constructed eval cases for implementation checks, hypothesis
evaluation or mechanism diagnostics. Use the benchmark's sourced existing cases
and actual run records; keep non-evaluation engineering checks separate.
A diagnostic control on the standard task cannot turn its score into evidence
for a capability it does not measure.

If a task's established evaluation genuinely requires human judgment, use its
validated protocol, representative data, blinded independent assessment and
reliability audit on existing sourced cases. Do not invent convenient examples. Prefer an
appropriate reproducible automatic evaluator where the task provides one.

When no usable dataset or credible evaluation is found, report the search scope
and specific missing resource. Do not assert that none exists beyond that scope,
invent an official dataset or quietly replace the research with a homemade task.
Continue bounded source/access feasibility work, propose another evidenced
benchmark-grounded direction, or pause that method investment. Do not rescue the
method by constructing a new dataset, task or benchmark.

## Decision and progression

Add the review to the H03 card: importance evidence, substantive closest-work
delta, coverage/crowding rationale, benchmark readiness, unresolved obligations
and next action. Give a candid recommendation: investigate missing evidence,
prepare the eligible smallest test, reroute, simplify/no-new-method or stop the
candidate. Reuse the existing state/routing vocabulary for actual transitions.

Baseline reproduction, evaluator qualification and natural failure census are
problem-discovery work. They can proceed within authorized resources when method
novelty is still unknown. Do not implement, train or run the proposed method merely
because a conditional idea sounds plausible: complete current Parent Problem,
Natural Gate 0 and collision/IPCG obligations before the existing Gate A freeze
and method implementation. Missing full text or unresolved coverage stays pending;
read-only investigation can continue. Final project abandonment follows the user
direction contract. Budget pressure, a drafted diagram or sunk effort do not
lower the research bar.

Refresh this review when the core claim, mechanism, benchmark contract or closest
work changes. Writing, figures and promotion use only the scope the evidence
supports; a polished story cannot fill an unresolved scientific obligation.
