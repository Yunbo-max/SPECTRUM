# Reuse evidence and resolve dependencies at the consuming stage

Apply this policy to both the current-step worker and independent reviewer at
S01, E01 and B02, including new projects and later research cycles. Read existing
accepted artifacts and actual results before requesting more preparation. Evidence
is reusable when its source/configuration, task population, claim scope and target
remain applicable. Cite the real artifacts; a prior acceptance is not a substitute
for examining evidence relevant to a changed claim.

## S01: select a sufficient evaluation plan

Start with the project's existing benchmark, metric, split and baseline records.
When they cover the current prediction and strongest alternative, record the fit
and proceed to review. Search additional benchmarks only for an identified coverage
gap. Reuse unchanged source/configuration inspection; do not reopen exhaustive
literature discovery or require new baseline scores merely to accept a plan.
Pin the comparison, denominator, protocol, provenance and prospective resource cost.
Separate known future scoring/qualification work from dependencies required to
choose a credible plan. An unavailable resource that makes the plan infeasible
still needs a concrete resolution; do not declare it available or switch to an
easier test after seeing outcomes.

## E01: reuse a working execution environment

Define the execution target and GPU at intake, using already supplied authority.
Reuse the confirmed target, interpreter, dependency versions, source revision,
model/data caches and successful startup receipts for the same configuration.
Do not recreate environments, reinstall packages, download the same assets or
repeat identical smoke checks solely because the program entered a new node.
Recheck affected components when versions/configuration change, access/allocation
is lost or stale, or an actual failure occurs. Reconcile jobs before dispatch;
lightweight job/allocation checks do not require repeating environment qualification.
A routine machine-migration procedure is not part of every run.
Apply native-scoring-stages.md: a missing scorer blocks work that actually consumes
scores. Supported independent training/export can retain unscored outputs for
later scoring. Startup evidence alone does not certify scoring or experiment fit.

## B02: analyze existing results before collecting more

Use traceable historical results, per-example artifacts and accepted audits first.
Extract supported failures/tradeoffs with their population, denominator and scope.
Do not rerun a complete historical matrix merely to enter the second research round.
Aggregate summaries cannot supply absent paired examples, failure frequencies or
semantic labels. Where such missing evidence is essential, name the exact artifact
and request the smallest relevant diagnostic on existing natural benchmark inputs,
with fixed inclusion IDs, outputs, scoring dependencies and explicit limited scope.
Retain stronger comparisons and confirmation obligations for their proper stage.
Once archive recovery is exhausted, repeat it only when a new concrete source lead
appears; otherwise collect the missing evidence through an admitted task.

## Common worker and reviewer criterion

For each current requirement, identify sufficient existing evidence or the exact
missing artifact, why this stage needs it, and a concrete action to obtain it.
Do not repeatedly reject unchanged sufficient evidence for future-stage proof.
Do not submit the same insufficient summary for acceptance without addressing the
reviewed gap. Evidence sufficiency, independent review, native-task admission and
coverage contracts remain mandatory. Missing essential evidence is not a PASS;
keep it explicit and perform the targeted work. Do not invent retry quotas or
aggregate budgets, bypass the program cursor, manufacture scientific evidence,
or relabel third-party executors as official. Preserve failed and negative results.
