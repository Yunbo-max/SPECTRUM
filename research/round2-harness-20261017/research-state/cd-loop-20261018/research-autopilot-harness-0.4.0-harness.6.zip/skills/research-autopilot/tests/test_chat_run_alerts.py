"""Real finite CPU failures create incidents, never scientific or delivery passes."""
import contextlib
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from fixtures import C, write
import chat_alerts as A
import chat_run as R


class ChatRunAlertTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.procedure = write(self.root, "procedure.json", {"version": "engineering-alert-fixture"})

    def plan(self, **updates):
        value = dict(attempt_id="attempt-alert", procedure_ref=self.procedure,
                     input_refs=[], code_refs=[], command=[sys.executable, "-c", "pass"],
                     cwd=".", output_paths=[], timeout_seconds=2, max_log_bytes=4096)
        value.update(updates)
        return value

    def run_plan(self, **updates):
        prepared = R.prepare(self.root, self.plan(**updates))
        receipt = R.execute(self.root, prepared["execution_id"], prepared["plan_digest"],
                            authorizer=lambda scope: True)
        return prepared, receipt

    def incidents(self):
        return list(A.read(self.root)["incidents"].values())

    def test_missing_executable_has_startup_incident_not_blanket_cpu_claim(self):
        prepared, receipt = self.run_plan(command=["/no/such/engineering-alert-command"])
        self.assertEqual(receipt["reason"], "command_startup_failed")
        incident, = self.incidents()
        self.assertEqual(incident["category"], "startup")
        self.assertEqual(incident["scope"], prepared["execution_id"])
        self.assertEqual(incident["notification_status"], "pending")
        self.assertIn("does not establish", incident["next_action"])
        evidence = C.load_file(C.verify_ref(self.root, incident["evidence_refs"][0]))
        self.assertEqual(evidence, receipt)
        self.assertEqual(receipt["cpu_seconds"], 0)

    def test_configuration_rejection_reports_before_any_dispatch(self):
        prepared = R.prepare(self.root, self.plan(command="invalid argv"))
        incident, = self.incidents()
        self.assertEqual(incident["category"], "configuration")
        receipt = R.read_receipt(self.root, prepared["execution_id"])
        self.assertEqual(receipt["status"], "configuration_failed")
        self.assertEqual(receipt["cpu_scope"], "no_command_dispatched")
        self.assertFalse((self.root / R.BASE / prepared["execution_id"] / "workspace").exists())

    def test_timeout_is_reported_after_cleanup_and_preserves_actual_usage(self):
        _, receipt = self.run_plan(command=[sys.executable, "-c", "import time; time.sleep(5)"],
                                   timeout_seconds=.15)
        self.assertEqual(receipt["status"], "timeout")
        incident, = self.incidents()
        self.assertEqual(incident["category"], "timeout")
        self.assertFalse(receipt["cleanup"]["foreground_group_alive"])
        self.assertGreater(receipt["wall_seconds"], 0)
        self.assertIsNotNone(receipt["cpu_seconds"])
        self.assertFalse(receipt["scientific_accepted"])

    def test_numeric_invalid_and_partial_are_distinct_reportable_outcomes(self):
        for value, status in [("invalid", "numeric_invalid"), ("partial", "partial")]:
            code = "from pathlib import Path; Path('status.json').write_text(%r)" % json.dumps({"status": value})
            prepared, receipt = self.run_plan(command=[sys.executable, "-c", code],
                output_paths=["status.json"], numeric_status_path="status.json")
            self.assertEqual(receipt["exit_code"], 0)
            incident, = [item for item in self.incidents() if item["scope"] == prepared["execution_id"]]
            self.assertEqual(incident["category"], status)
            self.assertEqual(incident["notification_status"], "pending")
            self.assertEqual(receipt["status"], status)

    def test_success_prepared_and_observed_running_do_not_raise_incidents(self):
        prepared = R.prepare(self.root, self.plan())
        self.assertEqual(R.reconcile(self.root, prepared["execution_id"])["status"], "prepared")
        directory = self.root / R.BASE / prepared["execution_id"]
        state = C.load_file(directory / "state.json")
        state.update(status="launching", worker=R.H._self_identity())
        R._save(directory / "state.json", state)
        self.assertEqual(R.reconcile(self.root, prepared["execution_id"])["status"], "running")
        _, receipt = self.run_plan()
        self.assertEqual(receipt["status"], "completed")
        self.assertEqual(self.incidents(), [])

    def test_repeated_uncertain_observation_is_one_incident_without_terminal_commit(self):
        prepared = R.prepare(self.root, self.plan())
        directory = self.root / R.BASE / prepared["execution_id"]
        state = C.load_file(directory / "state.json"); state["status"] = "launching"
        R._save(directory / "state.json", state)
        first = R.reconcile(self.root, prepared["execution_id"])
        second = R.reconcile(self.root, prepared["execution_id"])
        incident, = self.incidents()
        self.assertEqual(incident["category"], "reconcile_required")
        self.assertEqual(incident["version"], 1)
        self.assertEqual(incident["occurrences"], 1)
        self.assertEqual(first, second)
        self.assertIsNone(second["cpu_seconds"])
        self.assertFalse(second["terminal"])
        self.assertFalse((directory / "commit.json").exists())
        self.assertEqual(C.load_file(C.verify_ref(self.root, incident["evidence_refs"][0])), second)

    def test_terminal_readback_deduplicates_without_mutating_receipt(self):
        prepared, receipt = self.run_plan(command=[sys.executable, "-c", "raise SystemExit(3)"])
        path = self.root / R.BASE / prepared["execution_id"] / "receipt.json"
        before = path.read_bytes()
        self.assertEqual(R.read_receipt(self.root, prepared["execution_id"]), receipt)
        self.assertEqual(R.reconcile(self.root, prepared["execution_id"]), receipt)
        incident, = self.incidents()
        self.assertEqual(incident["category"], "execution")
        self.assertEqual(incident["version"], 1)
        self.assertEqual(path.read_bytes(), before)

    def test_read_receipt_is_read_only_for_existing_outbox(self):
        prepared, receipt = self.run_plan(command=[sys.executable, "-c", "raise SystemExit(3)"])
        outbox = self.root / "runs/chat-alerts/outbox.json"
        original = outbox.read_bytes()
        for _ in range(2):
            self.assertEqual(R.read_receipt(self.root, prepared["execution_id"]), receipt)
        self.assertEqual(outbox.read_bytes(), original)

    def test_reconcile_retries_unsaved_notice_but_read_receipt_does_not_write(self):
        folder = self.root / "runs/chat-alerts"; folder.parent.mkdir(parents=True)
        folder.write_text("file blocks outbox directory")
        with contextlib.redirect_stderr(io.StringIO()):
            prepared = R.prepare(self.root, self.plan(command="invalid argv"))
        folder.unlink()
        receipt = R.read_receipt(self.root, prepared["execution_id"])
        self.assertFalse(folder.exists())
        self.assertEqual(R.reconcile(self.root, prepared["execution_id"]), receipt)
        incident, = self.incidents()
        self.assertEqual(incident["category"], "configuration")
        self.assertEqual(incident["notification_status"], "pending")

    def test_old_terminal_read_after_delivered_recovery_does_not_reopen_incident(self):
        prepared, receipt = self.run_plan(command=[sys.executable, "-c", "raise SystemExit(3)"])
        incident, = self.incidents()
        recovery = write(self.root, "recovery.json", {"kind": "engineering-fixture-recovery", "checked": True})
        resolved = A.resolve(self.root, incident["incident_id"], summary="Engineering fixture recovery verified",
                             next_action="Continue other authorized engineering work", evidence_refs=[recovery])
        execution = write(self.root, "delivery-operation.json", {"kind": "engineering-fixture-delivery", "success": True})
        delivery = write(self.root, "delivery.json", {
            "kind": "chat-alert-delivery", "status": "delivered", "incident_id": resolved["incident_id"],
            "version": resolved["version"], "channel": "test-adapter", "destination": "fixture-only",
            "provider_operation_id": "simulated-engineering-delivery", "execution_ref": execution})
        A.delivery(self.root, resolved["incident_id"], resolved["version"], "delivered", receipt_ref=delivery)
        self.assertEqual(R.read_receipt(self.root, prepared["execution_id"]), receipt)
        self.assertEqual(R.reconcile(self.root, prepared["execution_id"]), receipt)
        after, = self.incidents()
        self.assertEqual(after["lifecycle"], "resolved")
        self.assertEqual(after["notification_status"], "delivered")
        self.assertEqual(after["version"], resolved["version"])

    def test_unwritable_outbox_does_not_mask_configuration_receipt(self):
        folder = self.root / "runs/chat-alerts"; folder.parent.mkdir(parents=True)
        folder.write_text("file blocks outbox directory")
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            prepared = R.prepare(self.root, self.plan(command="invalid argv"))
            receipt = R.read_receipt(self.root, prepared["execution_id"])
        self.assertEqual(receipt["status"], "configuration_failed")
        self.assertEqual(receipt["cpu_seconds"], 0)
        self.assertIn('"notification_status": "unsaved"', stderr.getvalue())
        self.assertTrue((self.root / R.BASE / prepared["execution_id"] / "commit.json").is_file())

    def test_broken_reporter_never_replaces_original_result(self):
        with patch.object(A, "safe_report", side_effect=RuntimeError("broken reporting adapter")):
            with contextlib.redirect_stderr(io.StringIO()) as output:
                prepared = R.prepare(self.root, self.plan(command="invalid argv"))
                receipt = R.read_receipt(self.root, prepared["execution_id"])
        self.assertEqual(receipt["status"], "configuration_failed")
        self.assertIn("CHAT_RUN_INCIDENT_NOT_SAVED", output.getvalue())

    def test_postdispatch_incident_survives_failed_final_state_save(self):
        plan = self.plan(command=[sys.executable, "-c", "import time; time.sleep(5)"], timeout_seconds=.5)
        prepared = R.prepare(self.root, plan)
        directory = self.root / R.BASE / prepared["execution_id"]
        command, cwd, _ = R.R._stage(self.root, plan, directory)
        state = C.load_file(directory / "state.json")
        state.update(status="launching", command=command, cwd=str(cwd), owner=R.H._self_identity())
        R._save(directory / "state.json", state)
        original_save = R._save; identities = []
        def fail_state_save(path, value, **kwargs):
            if path.name == "state.json" and value.get("status") in {"running", "reconcile_required"}:
                if value.get("command_process"): identities.append(value["command_process"])
                raise OSError("engineering fixture state write failure")
            return original_save(path, value, **kwargs)
        previous = {s: signal.getsignal(s) for s in (signal.SIGTERM, signal.SIGINT)}
        libc = R.ctypes.CDLL(None, use_errno=True); old_subreaper = R.ctypes.c_int()
        self.assertEqual(libc.prctl(37, R.ctypes.byref(old_subreaper), 0, 0, 0), 0)
        try:
            with patch.object(R, "_save", side_effect=fail_state_save), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaisesRegex(OSError, "fixture state write failure"):
                    R._worker(self.root, prepared["execution_id"])
            self.assertTrue(identities)
            self.assertTrue(all(not R.H._alive(identity) for identity in identities))
            self.assertFalse((directory / "commit.json").exists())
            incident, = self.incidents()
            self.assertEqual(incident["category"], "reconcile_required")
            observation = C.load_file(C.verify_ref(self.root, incident["evidence_refs"][0]))
            self.assertEqual(observation["reason"], "collector_failed_after_dispatch")
            self.assertIsNone(observation["cpu_seconds"])
            self.assertFalse(observation["terminal"])
        finally:
            for signum, handler in previous.items(): signal.signal(signum, handler)
            libc.prctl(36, old_subreaper.value, 0, 0, 0)
            for identity in identities:
                local_pid = R._local_pid(identity)
                if local_pid:
                    try: os.kill(local_pid, signal.SIGKILL)
                    except ProcessLookupError: pass

    def test_raw_command_secrets_stay_out_of_notice_summary(self):
        secret = "engineering-fixture-secret-12345"
        _, receipt = self.run_plan(command=[sys.executable, "-c", "import sys; print(%r, file=sys.stderr); sys.exit(1)" % secret])
        self.assertIn(secret, C.verify_ref(self.root, receipt["stderr_ref"]).read_text())
        self.assertNotIn(secret, json.dumps(self.incidents()))

    def test_cli_unexpected_failure_reports_and_retains_nonzero_exit(self):
        result = subprocess.run([sys.executable, str(Path(R.__file__)), "read", str(self.root), "bad-id"],
                                capture_output=True, text=True, timeout=5)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("CHAT_RUN_INVALID_EXECUTION_ID", result.stderr)
        self.assertEqual(result.stdout, "")
        incident, = self.incidents()
        self.assertEqual(incident["category"], "host_tool")
        self.assertEqual(incident["notification_status"], "pending")


if __name__ == "__main__": unittest.main()
