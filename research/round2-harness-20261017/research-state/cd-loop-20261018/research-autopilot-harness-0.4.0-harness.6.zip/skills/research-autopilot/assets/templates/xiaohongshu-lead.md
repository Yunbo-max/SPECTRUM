# Public technical discussion → research lead

Optional planning/evidence note. Leave missing facts unknown; do not fabricate examples.

- Project / existing inquiry or idea ID:
- Source preference + user choice reference / observed access state + time:
- Research question / query groups / sort / date window / retrieval cutoff:
- Sampling budget and stop reason / unique notes / comments / replies read:
- Original token-free source URLs and identifiers / dates / minimal attribution:
- Deduplication / inaccessible or truncated portions / coverage limits:
- Author claim or reported observation / speculation / our inference (separate):
- Supported model, data, training, hardware and evaluation conditions / unknowns:
- Phenomenon / mechanism hypothesis / rival account / conflicting evidence:
- Closest primary papers + inspected code/config revision / unresolved access:
- Relation: verified match | partial/related | contradicted | unverified |
  no match found within stated search scope:
- Exact overlap / conditional remaining gap / originality uncertainty:
- Falsifiable prediction / strongest fair baseline / next check + resource cost:
- Decision under this edition / evidence that would change it:

No cookies, xsec tokens, login/QR data or raw secret-bearing MCP responses here.
An observed post is not an experiment receipt; a completed card is not scientific approval.
