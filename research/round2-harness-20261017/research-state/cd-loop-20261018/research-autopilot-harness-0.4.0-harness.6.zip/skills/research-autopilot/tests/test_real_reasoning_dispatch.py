"""Real short CPU command and existing scheduler tests, not model-compliance trials."""
import copy
import importlib
import json
from pathlib import Path
import sys
import time
import unittest
import test_research_reasoning as fixtures

S=Path(__file__).resolve().parents[1]/'scripts'
sys.path.insert(0,str(S))
class ActualReasoningDispatch(unittest.TestCase):
    def setUp(self):
        self.f=fixtures.ReasoningTests();self.f.setUp();self.addCleanup(self.f.doCleanups);self.root=self.f.root
    def simple(self, tasks=('task',)):
        if not (S/'simple_runner.py').exists():self.skipTest('Other edition: no Simple command executor')
        m=importlib.import_module('simple_runner');r=m.SimpleRunner(self.root)
        r.initialize(dict(idea='candidate',goal='goal',goal_contract=dict(mode='bounded_task',completion_criteria=[dict(id='c',description='CPU fixture only')]),
            limits=dict(max_attempts=10,max_command_seconds=100,deadline_seconds=40,max_concurrency=1)))
        self.addCleanup(lambda:r.stop('test cleanup'))
        d=self.f.adaptive_decision();d['selected_task_ids']=list(tasks)
        t=json.loads((self.root/d['trajectory_ref']['path']).read_text());t['selection']['task_ids']=list(tasks);d['trajectory_ref']=self.f.ref(t)
        ref=self.f.ref(d);r.loop.record(dict(event_id='review',kind='research_review',reason='Read the scoped fixture',decision_ref=ref,evidence=[ref]),r.loop.status()['version'])
        return r,d,ref
    def task(self,name,ref,dependencies=()):
        return dict(task_id=name,argv=[sys.executable,'-c',f"from pathlib import Path; Path('{name}.txt').write_text(str(2+2))"],
            phase='experiment',purpose='CPU control-flow fixture',timeout_seconds=8,outputs=[name+'.txt'],
            research_scope='method',reasoning_ref=ref,input_refs=[ref],depends_on=list(dependencies))
    def until(self,r,predicate):
        end=time.monotonic()+24
        while time.monotonic()<end:
            r.tick();state=r.status()
            if predicate(state):return state
            time.sleep(.03)
        self.fail('No terminal observation for actual short CPU task')
    def test_selected_method_runs_actual_cpu_and_pins_dag(self):
        r,d,ref=self.simple();r.submit(dict(submission_id='p',idea='candidate',revision=1,tasks=[self.task('task',ref)]))
        st=self.until(r,lambda s:s['tasks'][0]['state']=='succeeded')
        self.assertEqual((self.root/'task.txt').read_text(),'4')
        inputs=st['attempts'][0]['contract']['input_refs'];self.assertIn(d['trajectory_ref'],inputs);self.assertIn(d['math_trace_ref'],inputs)
        self.assertFalse(st['journal']['scientific_certification'])
    def test_changed_math_after_intake_never_runs(self):
        r,d,ref=self.simple();r.submit(dict(submission_id='p',idea='candidate',revision=1,tasks=[self.task('task',ref)]))
        (self.root/d['math_trace_ref']['path']).write_text('{}')
        st=self.until(r,lambda s:s['tasks'][0]['state']=='blocked')
        self.assertEqual(st['attempts'],[]);self.assertFalse((self.root/'task.txt').exists())
    def test_new_experiment_result_requires_new_route_decision(self):
        r,d,ref=self.simple(('task','again'));r.submit(dict(submission_id='p',idea='candidate',revision=1,
            tasks=[self.task('task',ref),self.task('again',ref,['task'])]))
        st=self.until(r,lambda s: any(t['task_id']=='again' and t['state'] in {'blocked','succeeded'} for t in s['tasks']))
        self.assertEqual(next(t for t in st['tasks'] if t['task_id']=='task')['state'],'succeeded')
        self.assertEqual(next(t for t in st['tasks'] if t['task_id']=='again')['state'],'blocked')
        self.assertIn('new reasoning',next(t for t in st['tasks'] if t['task_id']=='again')['reason'])
        self.assertFalse((self.root/'again.txt').exists())
    def test_chat_selected_comparison_can_outrank_generic_repair(self):
        if not (S/'chat_strategy.py').exists():self.skipTest('Other edition: no Chat strategy adapter')
        from test_chat_strategy import StrategyTests,S as strategy
        f=StrategyTests();f.setUp();self.addCleanup(f.doCleanups)
        self.f.root=f.root
        self.f.raw=self.f.ref("scoped fixture note, not scientific evidence")
        a=f.task('repair',purpose='unblock');b=f.task('task',purpose='analysis')
        d=self.f.adaptive_decision();ref=self.f.ref(d)
        strategy.apply(f.root,f.state,dict(op='strategy_reasoning',decision_ref=ref),f.read)
        order=strategy.order_tasks(f.root,f.state,[a,b],f.read)
        self.assertEqual(order[0]['id'],'task')

    def test_feedback_decision_allows_the_next_real_experiment(self):
        r,d,ref=self.simple();r.submit(dict(submission_id='p',idea='candidate',revision=1,tasks=[self.task('task',ref)]))
        st=self.until(r,lambda s:s['tasks'][0]['state']=='succeeded')
        attempt=st['attempts'][0]
        t=json.loads((self.root/d['trajectory_ref']['path']).read_text())
        old_t_ref=d['trajectory_ref'];exp_ref=self.f.ref(t['routes'][0]['experiments'][0])
        outcome=dict(kind='trajectory_outcome',attempt_id=attempt['attempt_id'],route_id='r',experiment_id='e',
            trace_ref=d['math_trace_ref'],experiment_ref=exp_ref,outcome='inconclusive',terminal=True,
            raw_refs=[attempt['receipt_ref']],interpretation='Execution fixture only; no mathematical inference',independent_unit_ids=['fixture'])
        o=dict(id='o',route_id='r',experiment_id='e',attempt_id=attempt['attempt_id'],trace_ref=d['math_trace_ref'],
               experiment_ref=exp_ref,outcome='inconclusive',result_ref=self.f.ref(outcome))
        t.update(revision=2,previous_ref=old_t_ref,observations=[o]);t['selection'].update(action='repeat',task_ids=['next'],based_on_observation_ids=['o'])
        d.update(decision_id='after-observation',previous_ref=ref,selected_task_ids=['next'],trajectory_ref=self.f.ref(t))
        next_ref=self.f.ref(d);r.loop.record(dict(event_id='review-next',kind='research_review',reason='Consume result before selecting repeat',
            decision_ref=next_ref,evidence=[next_ref]),r.loop.status()['version'])
        r.submit(dict(submission_id='p-next',idea='candidate',revision=1,tasks=[self.task('next',next_ref)]))
        st=self.until(r,lambda s:any(x['task_id']=='next' and x['state']=='succeeded' for x in s['tasks']))
        self.assertEqual((self.root/'next.txt').read_text(),'4');self.assertEqual(len(st['attempts']),2)

if __name__=='__main__':unittest.main()
