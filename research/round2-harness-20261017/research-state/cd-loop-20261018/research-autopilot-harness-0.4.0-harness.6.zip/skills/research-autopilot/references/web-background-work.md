# Web reasoning and local execution

Local means the control agent on the user's computer. Before execution restore
the authorized SSH GPU route and choose the workload target under local-execution.md;
sync the pinned code there and monitor/collect its real results. No Docker anywhere.


Read edition-policy.md, research-cycle.md and local-execution.md first.

Work and Simple use the local agent for research and execution. Web authoring or
ChatGPT Work is optional and is not the default route. Use the actual local tools
to complete the next authorized in-field action and inspect its results.
Save source pins, raw outputs, cumulative knowledge, budgets and next actions.
Use a supported local continuation mechanism; a detached experiment is not a
decision consumer. No automatic cloud service or human Web handoff is required.

## Define the authoring goal

Restore the selected field, goal, paper/code/reproduction knowledge, current
question, source pins and cumulative limits. Select a concrete next action
within the field; use the local agent's tools to execute authorized work.

## Completion and handoff

Inspect actual results, retain negative findings, save artifacts and costs,
and choose the next unresolved question. Use supported local continuation when
available; no separate Web or Work handoff is required. Completion follows the
user's actual scoped goal and evidence requirements, not one positive comparison.
