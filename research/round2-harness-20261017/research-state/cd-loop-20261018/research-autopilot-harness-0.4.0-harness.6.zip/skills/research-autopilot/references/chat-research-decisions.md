# Choose research that changes the next decision

Read at research startup, a batch boundary, a new candidate investment or a
stagnation review. Use this with the sourced goal and existing scientific gates;
it adds no prerequisite to reading sources, repairing setup or obtaining the
missing baseline evidence. A bounded audit, reproduction or engineering request
keeps its own scope and need not invent an original method.

Read in order: [progress](#track-goal-progress), [selection](#choose-the-next-action),
[investment](#invest-in-a-hypothesis), [diagnostics](#bound-diagnostics-and-respond-to-stagnation),
[decisions](#learn-from-results), [continuity](#keep-decisions-durable).

## Track goal progress

Maintain the original acceptance obligations and their evidence, separately from
the current milestone, queue, run count and stage labels. At meaningful batch
boundaries retain what changed in:

- Required claim/task coverage, including named missing comparisons.
- Qualified source implementations, scorers and strongest relevant baselines.
- Critical dependencies: access, data, compute, missing review and their next action.
- Hypotheses/families: unresolved prediction, valid refutation or scoped support.
- Independent scientific review, frozen confirmation and requested deliveries.

Count runs, seeds, timing repeats, engineering repairs and scientific cycles
separately. Reusing one generated problem with several settings does not create
several independent problems. A valid falsification, an informative boundary
result or a resolved dependency is progress even when a result table is unchanged.
More logs, renamed stages or another run of an unchanged check are not evidence
of scientific progress. Do not turn this record into a self-awarded quality score.

Maintain both coverage and contribution. Completing the original experiment
matrix cannot itself establish originality; adding a different task cannot
silently satisfy a missing original task. Change the goal or protocol only with
its actual authority, explicit revision and preserved remaining obligations.

## Choose the next action

Before dispatch, compare the ready actions against the outstanding goal. Record
the affected obligation, uncertainty or dependency, why the action matters now,
what each plausible result would change, and its bounded cost. Use evidence-based
ordinal priorities; do not fabricate numerical probabilities of discovery.

Prefer consequential dependency recovery, decisive tests that separate remaining
explanations, qualified strong controls, and required confirmation over another
convenient nearby experiment. A prerequisite may deserve priority before its
downstream experiment. The first task in a list need not be the best next task.
While access is blocked, use genuinely independent mathematics, source review or
feasible checks; retain the unresolved critical path visibly.

Balance exploration and completion for the sourced goal. Cheap parallel readers
may investigate several causal explanations or prior-art conflicts while one
candidate receives expensive implementation and verification. Do not require a
fixed candidate pool, paper count or agent count. If all remaining actions have
low decision value, revisit the problem or contribution route within scope.
Do not keep an unpromising method alive solely to maintain continuous activity.

## Invest in a hypothesis

Before substantial candidate implementation or an expanded empirical campaign,
retain a short evidence-bound investment decision covering:

1. The consequential unresolved question and native population/quality target.
2. The closest primary methods and the strongest simple alternative; explain
   their actual unresolved limitation without asserting novelty from a search gap.
3. The proposed mechanism, assumptions, mathematical construction and substantive
   difference from its parent and known alternatives.
4. A falsifiable prediction, decisive comparison, failure regime and decision
   after support, refutation or inconclusive evidence.
5. Qualified baseline/scorer/defaults and currently available calibrated resources,
   or a concrete bounded acquisition/qualification action for what is missing.

Use the existing Parent/Gate 0/IPCG and method records rather than copying them
into another gate. A source lookup, baseline qualification, derivation or bounded
diagnostic may establish a missing item. It cannot claim final method acceptance.
If an existing simple method already resolves the proposed limitation, retire
the redundant construction or state a genuinely different remaining question.

Freeze source code, configuration, initialization/update semantics, precision,
stopping criteria and implementation status before large comparisons. Distinguish
official unmodified code, a qualified faithful port and an experimental repair.
Do not attribute a port's performance or defect to the official implementation.
A discovered mismatch triggers scoped invalidation/review of affected evidence;
do not automatically discard unrelated results or silently rewrite old settings.

## Bound diagnostics and respond to stagnation

Give a diagnostic a specific question, family/failure signature, finite allowance,
required output and exit decision before running it. Reuse the same checked runner
and analysis for comparable experiments. A new seed, stage ID, child agent, batch
or renamed task does not renew its allowance. Account actual unsuccessful usage.
Technical records and cumulative bounds constrain work; they do not judge value.

At the project-declared stagnation threshold, and after a family is refuted or its
diagnostic allowance is used, review strategy before admitting more work of that
family. Compare the progress record and evidence with the preceding boundaries.
Choose an evidence-bound action: resolve a critical blocker, run a decisive missing
control, revise a materially different hypothesis, retire the family, complete a
supported scoped result, or retain a real blocker/limit. Specify the next evidence
that could change the decision. A threshold is a planning bound, not a universal
number of rounds after which scientific work is worthless.

Do not evade review by declaring every experiment diagnostic or changing a label.
Do not let one stalled family block unrelated authorized work. If new evidence
justifies further diagnostics within the remaining allowance, append a reviewed
changed plan; preserve the old spent allowance. The helper keeps adopted
cumulative diagnostic limits immutable rather than treating review as new budget.
Unresolved receipts or unknown operations still require reconciliation first.

## Learn from results

Separate environment, implementation, evaluator and scientific failures. A failed
process cannot falsify the hypothesis. A numerically valid negative comparison
can, at its actual scope. Translate each scientific result into a retained
prediction update, eliminated explanation, boundary or next discriminating test.

Retire a hypothesis family when its defining mechanism is refuted or its value
is removed by a qualified existing alternative. Preserve the failed prediction,
conditions, controls and related candidates. A renamed parameter, another seed
or a cosmetic equation change is not a successor. Reopen only for an explicit
substantive change or new evidence addressing the failed predicate, with lineage
and independent review appropriate to the claim.

Do not overextend a local counterexample to the entire algorithm or generalize
from one reused problem family. Separate engineering cost improvements from
algorithmic improvements, fixed-iteration timings from time to matched quality,
and stationarity from useful task performance. Use exploratory data to formulate
the next hypothesis; freeze it before untouched confirmation. Never silently
change an audit implementation, metric or holdout to fit a deadline.

Independent reviewers should challenge value, prior-art overlap, mechanism,
baseline fairness, inference scope and the proposed next investment. A second
implementation validates some numerical properties, not all these judgments.
Different role names do not establish independence, and same-model agents may
share blind spots. Preserve genuine reviewer identities, dissent and unresolved
questions; their agreement is evidence to assess, not a novelty certificate.

## Keep decisions durable

Keep one authoritative project checkpoint with revision ancestry, stable project,
hypothesis/family, task, attempt and experiment identities, artifact digests,
accepted procedure/version, pending decisions and cumulative usage. Link batch
labels as display names; they are not globally unique identities. Use actual
save/readback receipts from the authorized durable destination. A sandbox hash
checks bytes; it does not prove persistence elsewhere or resolve conflicting heads.

Use a short resume instruction pointing to the checkpoint and expected revision,
not an ever-growing copied research contract. At each actual invocation, restore
the sourced request and stop status, reconcile effects, and read the adopted
procedure. Record the loaded plugin/source version separately from the adopted
project procedure and any scheduled instruction version. A missing or older
plugin must not be reported as the latest. An authorized pinned procedure may
be read directly if accessible; otherwise record the affected capability gap.

Keep running attempts on their frozen versions. Adopt reviewed changes at a
recorded boundary and retain rollback. A source push does not update an installed
plugin, existing automation instructions or model weights. Report each observed
activation separately. Preserve user pause through maintenance, migration,
version updates and recurring invocations; only actual user authorization resumes
that research. Helpers organize and constrain records; the host still executes,
the agent still judges science, and an ended Chat still needs a real invocation.

## Prospective trace and investment binding

At substantive method intake/revision and meaningful batch decisions, apply
[research-reasoning.md](research-reasoning.md). Preserve the public mathematical
work product from selected operations to the executable rule, its rival prediction
and falsifier. Conditional premises and accumulated error do not disappear at a
handoff. Check the selected action against the parent goal and a real alternative;
new repair hashes or issue names do not reset mechanism-family effort. Record the
current accepted decision and tag actual method tasks with research_scope=method
and reasoning_ref; keep source/baseline/evaluator acquisition scoped as diagnostic.
Use quiet-boundary adoption for old tasks and never overwrite their evidence or
resume a pause. Structural checks are not mathematical or scientific acceptance.
