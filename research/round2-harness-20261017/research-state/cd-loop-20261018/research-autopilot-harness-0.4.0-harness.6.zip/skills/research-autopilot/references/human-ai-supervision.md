# Human–AI research supervision

**Autonomous branch:** read [autonomous-rsi](autonomous-rsi.md) with this module. Its finite delegated machine supervisor replaces routine human step-7 selection and selects the startup-authorized delivery branch; scientific evidence, existing goals, budgets and same-attempt recovery remain binding. Older human-at-every-batch/main-only wording below describes the baseline and is superseded only within that explicit delegation.

Use for P/I and for a changed goal, priority, resource constraint or preference.
The human defines value and acceptable tradeoffs; evidence defines what can be
claimed. This is a shared supervisor across projects. The bundled registry implements
local route/resource coordination. A shared deployment, chat access, connected
accounts and available compute require actual host connections and receipts.

## P01 Goals and portfolio

At a new project's start, host the goal discussion through I01 and record its
resource envelope through P04. Keep project purpose, core problem and minimum
useful success distinct from a single session deliverable. Use human-stated goals;
show suggested goals as provisional rather than treating them as agreed values.
The startup brief is used for one project even when no portfolio scheduler exists.

Maintain a project register with stable project ID, human goal, current decision,
origin, milestone, assets, obligations, next action and dependencies. Separate
scientific outcome, publication outcome, learning and public communication. A
negative finding, useful dataset, replication or stopped project can meet a goal.
Record each preference with verbatim/source locator, scope, explicit/provisional
status, date, review trigger and superseded version. Do not promote a temporary
choice into a durable personal preference. Do not infer ambitions from affiliation.

Discuss tradeoffs using two or three concrete alternatives, their evidence,
human time, compute, expected information and opportunity cost. Respect existing
authorization; continue routine work instead of requesting the same decision again.
For multiple chats/agents, declare supervisor and worker roles using
[project-chat-instructions.md](project-chat-instructions.md). One ChatGPT Project
can hold several scientific projects; each project keeps its own ledger and each
worker its own route. Use [multi-route-supervision.md](multi-route-supervision.md)
to register real routes and reuse this goal/preference brief in every worker.

## P02 Assets and current position

Read the actual manuscript, repository, run records and reviews. Record immutable
versions, missing files, inspected scope, last credible milestone and unresolved
obligations. Distinguish author's report, observed output and inference. Resume
from these assets rather than resetting to a topic interview. Return completed
node outputs to the project register with evidence identity and next action.
Checkpoint actual milestones/end of turn to the shared registry with expected
registry/route revisions. The supervisor imports inspected canonical files;
oral/copied reports remain unverified. Fetch the actual latest host source on
resume. Missing or old checkpoints are unknown/stale, never assumed progress.

## P03 Priorities and work in progress

Ask how the human values deadline, scientific importance, uncertainty reduction,
learning, collaboration and visibility. Present a transparent priority rationale;
never silently optimize publication count. Track active, waiting, paused and
completed work separately. Set a human-agreed WIP limit and revisit it on a real
conflict. Give each active project one decision-driving next action. Do not count
GPU waiting as human work. New priorities version the plan rather than erase it.

Use rolling-research-batches.md's evidence-driven convergence per scientific
project/navigation goal: initially derive about 20 justified candidates through
mathematical reasoning, verify the pool and select the ranked top 15 before code
design under method-verification.md; at most 20 active
including carryover/reserve, with no minimum in later rounds. Deepen/independently
confirm positive candidates, stop/park validly refuted ones and prioritize mixed
cases by causal question; unresolved bugs remain pending. Do not refill the slate
each round or count controls/configurations/seeds as ideas. Propose new scientific
slates for consolidated human review while eligible unfinished approved work
continues unchanged within existing scope and cumulative bounds.

## P04 Resources and people

Include a visible resource summary at project startup, before proposing a definitive
method or experiment scale. Record current device model/count/per-device VRAM,
human hours per week, elapsed-time limit, GPU-hours, monetary amount/currency and
API access. Keep missing facts unknown and past availability provisional. Inspect
available inventories before asking; resolve remaining facts in rounds of at most
three independent questions. A zero additional budget and CPU-only work are valid.

Reuse the owner's soft progress cadence (nominally eight hours) and up-to-24-hour
continuous Local execution allowance, preserving shorter explicit limits and
actual remaining capacity/budgets. Web hosted authoring is completion-driven,
without inheriting either Local clock; use web-background-work.md. Record actual dates/timezone, full
comparison obligations, dispatch/carryover and cumulative use; a new window does
not reset budgets, release unknown costs or require repeating unchanged intake.

For independent work within a window, use dependency-resource-scheduling.md's
actual task DAG and resource admission. Follow single-experiment-batching.md:
one experimental program across the project, sharing disabled, supported batches
calibrated from large to small. Separate agent/API limits from execution; readers
and code workers may overlap within actual resources.

Maintain availability/reservations for human time, GPU memory and device IDs,
CPU/RAM, storage, wall time, API budget and collaborator responsibilities. A
planned reservation is not a running job. Resolve clashes using alternatives:
queue, reduce the pilot, switch qualified assets, or reprioritize with the human.
Map S choices and E jobs back to the project goal and resource envelope. Record
actual job IDs and costs; cannot promise availability from a model's memory.
Discuss scope/credit/responsibility changes with affected humans before committing.
Reserve resources and budget using real inventory and fenced expiring leases
before authorized execution. Reject overlapping active writer branches/workspaces
and resource conflicts. Host adapters enforce the lease token at the resource;
local coordination alone cannot stop a GPU process. Expiry frees capacity while
unknown spend remains held until an actual usage/final receipt is inspected.

## P05 Growth and retrospectives

After a meaningful decision, record what was learned, surprising failures,
transferable knowledge, a skill gap and one practical next learning task. Track
understanding and independent verification rather than number of papers/posts.
Offer doing, explaining and reviewing modes according to the human's preferences.
Keep researcher's private reflections separate from publicly released project data.

## I01 Progressive goal interview

Start by summarizing known goals/assets and the next decision. Use the following
question bank to check completeness, not to ask everything in one turn. Ask at
most three material questions per round; use concise choices and optional free
text. Explain which downstream choice an answer changes. Unknown answers may
remain unknown while independent work continues. Preserve answers across sessions.

On a new scientific project, the first card contains purpose, core problem and
minimum useful success, known/unknown resources and project delivery targets.
Confirm the GitHub output repo and Hugging Face output destination (or explicit
non-use) at startup, before the first idea/work batch. Reuse explicit selections;
the two missing destination decisions take the first question slots, with at most
three independent questions in the turn. For empirical/GPU planning, unknown
current usable GPU count takes the next available startup slot; inspect current
inventory first and do not substitute historical hardware or one suggested worker.
Use remaining slots for missing goals,
then resolve resources in later short rounds. Follow [initial-intake.md](initial-intake.md)
and preserve the sourced per-project target map across workers and rounds.
"Find an idea" identifies this round's
output and cannot fill all goal fields. When the user has already stated a field,
reuse it with its source. Apply this to new I/M/R projects; existing code or a
rejection does not reveal why the human wants to pursue the project. For a bounded
requested continuation, preserve its scope and ask only changed dependencies.

| Dimension | Questions to resolve when material |
|---|---|
| Purpose | What should become possible? Who benefits? Is the goal discovery, an application, replication, publication or learning? What would change a decision? |
| Problem | What fails naturally? Under which conditions? How often and with what consequence? What strongest simple solution already works? |
| Starting point | Topic, existing method/results, or rejected manuscript? Which artifacts are authoritative? What has been read, run and independently verified? |
| Project destinations | Which GitHub delivery repo and which Hugging Face output destination, or explicit HF non-use? Reuse selected targets; keep input/download repos separate. |
| Contribution | Method, empirical phenomenon, theory, benchmark/data or system? Is a new component necessary? What remains valuable if the method fails? |
| Evidence | Which atomic claim must be established? Which observation would contradict it? What is the task endpoint, unit and evaluator? What confirmation data remain unseen? |
| Feasibility | Available models, data, code and licenses? Human time, GPU/API and storage limits? Existing collaborators and constraints? Minimum decisive affordable test? |
| Delivery | Desired audience/venue/year/track/stage and deadline? Public/private materials? Paper, artifact, website, demo or teaching output? |
| Interaction | Prefer options with recommendations or exploration? How much explanation/learning? Which decisions belong to the human? When should goals be reconsidered? |
| Exit | Minimum success? A reason to stop or pause? A resource ceiling? Which question would remain unresolved if we stop? |

The [question bank](human-question-bank.md) supplies startup goal/resource slots
and independent trigger-based slots across methods, experiments and review.

Return a sourced goal brief, chosen current decision, remaining unknowns and a
small actionable next step. Correct it when the human supplies new information.

## I02 Contribution types

Select a track from available evidence, not a universal method-paper template.
Method: mechanism and fair comparisons; phenomenon: definition, prevalence and
competing explanations; theory: explicit assumptions/proofs/counterexamples;
dataset/benchmark: provenance, validity and coverage; system: end-to-end utility,
cost and failure/recovery. Mixed tracks state which evidence supports each claim.
Freeze `contribution_type` and apply the corresponding value gate from
[contribution-value-gates.md](contribution-value-gates.md), rather than requiring
every theory/system/phenomenon contribution to invent a failed-agent census.

## I03 Venue and stage

Resolve venue/year/track/article type/stage using current official instructions.
Record template, limits, anonymity, artifact, ethics and discussion-window rules
only when applicable. Explain fit and tradeoffs. Existing rules are not current
merely because they are familiar. A target venue is a goal, not a quality verdict.

## I04 Success and exit

Agree on minimum informative outcome, milestones, budget ceiling and stop/pause
criteria. Distinguish scientific falsification from implementation invalidity.
Review goals on new evidence or changed human circumstances. Publication is not
the sole completion criterion. Goal changes propagate through P, S, G/V and W/C.
