# Deep research within one field

## Work Harness C/D profile

Restore `sequence.flow_profile` before applying inherited workflow rules. For
`work-harness-cd-v1`, read [C/D mathematical diagnosis and executable idea development](cd-math-code-loop.md).
The versioned catalog `assets/skill-sequence-cd-v1.json` and its overriding node
guides govern C's condition/failure/dependency diagnosis, D's mechanism construction
and real local experiments, reviewed B/C/D revisits and M05 `VERIFIED_FOR_SCALEUP`.
B05 validates a supported problem contract; old Natural Gate 0/IPCG prerequisites
do not apply to this profile's local diagnostic/development work. Independent
verified review plus program checks advances automatically into E, which retains
full settings, freezing, fair comparisons, scale and confirmation.

The worker proposes typed revisits and code applies approved transitions; no raw
skip/jump is allowed. Preserve source/evidence lineage, failed findings, external
jobs, cumulative usage and pause state. Omitted `flow_profile` retains legacy
catalog/transition behavior. Profile-specific rules override conflicting inherited
C/D ordering/admission text below only when the profile is actually adopted.
Installation alone does not migrate a running project or change another edition.

Read this when entering a field, forming an idea, changing a consequential assumption,
designing a comparison or interpreting results. It governs research selection across
editions; edition-policy.md governs host and human/machine decision ownership.

For Work Harness and DSH Harness, [skill-sequence.md](skill-sequence.md) fixes
execution order and acceptance. The scientific choices described here are made
inside the program-assigned node; they do not authorize selecting, skipping or
ending Skill steps. Preserve this existing research method.

## Keep the field stable and deepen the evidence

The long-term object is the user's selected field. A model family, question or idea
is a revisable working object inside it. Retiring one hypothesis does not abandon
the field or reset its knowledge, failed findings, source pins or cumulative budget.
Changing the field requires the user's direction; choosing the next in-field question
follows the edition's decision ownership. For a bounded reproduction or artifact
request, retain that endpoint instead of imposing open-ended research.

Build understanding through relevant primary papers, actual code, technical discussions
and purposeful reproductions. Read original computation rules and why they were chosen;
compare the strongest relevant method families, conditions, implementations and known
limits. When Xiaohongshu is enabled and accessible, use text/image discussion threads
and comments about real difficulties; skip videos and promotion. Social reports are
leads, with prevalence and proposed explanations still to be checked.

Maintain cumulative field knowledge in existing project notes/evidence indexes:
method relationships, paper/code versions and read depth, reproduction outcomes,
implementation discrepancies, observed failure conditions, rejected explanations and
unresolved questions. Keep discussion claims, paper claims and our measured findings
distinct. Do not introduce a second database or unsupported runtime JSON fields.

Use this loop repeatedly within the field:
1. Find the next consequential knowledge gap. Deep reading, code tracing and baseline
   reproduction are substantive research actions; a round need not invent a method.
2. Reproduce representative strong alternatives where their behavior matters to the
   question. Choose coverage for understanding, not a fixed paper/run quota. Preserve
   exact conditions and failed reproductions; check implementation and evaluation
   mismatches before interpreting them as scientific limitations.
3. Identify a concrete defect, unexplained behavior or meaningful changed condition.
   State what the original method assumes and why that assumption is now questionable.
   An interesting formula or available compute alone does not establish problem value.
4. Choose a focused source check, proof, counterexample or causal intervention that
   distinguishes explanations. Name the question and possible result interpretations
   before running it. Avoid broad experiment sweeps whose only goal is finding a win.
5. Propose a new mechanism when evidence or a justified theoretical argument warrants
   it. Compare strong and simpler alternatives, with matched information and resources,
   a falsifier and the relevant failure boundary. Reuse already qualified knowledge;
   mature evidence should proceed to its decisive comparison without another reading quota.
6. Interpret the result, update field knowledge and record unresolved in-field
   questions. Work Harness/DSH Harness retain the program-assigned node until
   acceptance; code schedules subsequent nodes. A failed new module may require
   reading or diagnosing the baseline before further construction. Account for prior exposure and retain negative findings through revisions.

## Use mathematics to express and solve the concrete problem

Mathematical modeling, derivation and optimization are tools for the question. Under
a new information or operating condition, specify observed and latent variables,
available information, assumptions, objectives, constraints and their relation to the
actual task. Identify which part of the old formulation or solver no longer applies.
Derive an appropriate representation, state transition, objective or solver from that
structure; examine tractability, identifiability, stability and full cost where relevant.
Optimizing the chosen objective better does not prove that it represents the task well.
Check modeling adequacy and solution quality separately, against plausible rivals.

Mathematical observations may initiate an in-field question and yield conditional
predictions before experiments. Do not require a measured defect for a purely
theoretical claim, a finished proof for a useful diagnostic, or decorative equations
for source reading. Apply formal derivation/code/evidence obligations when advancing
an executable construction. Correct theory can show that no new architecture is needed.

For architecture work, track six questions as current evidence and unresolved work:
the exact existing method; a measurable or provable limitation; the questionable
dependency; a derived mechanism; a simpler strong counterfactual; and a falsifier or
failure boundary. These are not an admission score or a requirement to know every
answer at intake. If claiming capability innovation, identify what information can
be represented, retained or updated differently and test that claimed capability.

A small state change does not establish dispensability. Skipping an update in a frozen
trained model and training a selective-update architecture test different hypotheses.
An adverse frozen-model intervention refutes that intervention under its conditions;
it does not alone refute every retrained architecture. A positive result likewise
needs controls for task difficulty, measurement sensitivity and alternative explanations.

One command or seed is not one research cycle. A cycle links a question, prediction
or diagnostic purpose, actual evidence, interpretation and next decision. Reading and
reproduction can resolve a knowledge question without producing a new architecture.

## Select evidence for the actual claim

| Claim from analysis | Prioritize existing evidence that can test it |
| --- | --- |
| Better performance under the original conditions | The task's native benchmark and strongest compatible baselines. |
| Advantage depends on a condition | Tasks with that measurable condition and variation sufficient to distinguish the prediction. |
| A crossover or useful operating range | Relevant tasks around the predicted threshold and on either side where feasible. |
| A previously unsupported task becomes feasible | Authentic tasks with that limitation, suitable feasible comparators and the complete quality/cost tradeoff. |

Choose coverage to support the claimed scope. A conditional claim need not win on every
benchmark; broad superiority requires broader evidence. Conventional-condition controls
are useful when they answer a rival explanation or scope question, not a compulsory
extra suite for every idea. Each benchmark may require a different strong baseline.
Separate measured task properties from assumed ones; record unknown conditions.

Before examining comparative outcomes, retain the selection rationale, data/version,
split, relevant condition, prediction/falsifier, metrics, baseline and protocol. If an
unexpected result motivates a different benchmark or subgroup, retain the original
result, label the new hypothesis exploratory and seek independent confirmation with
frozen choices. Fresh seeds on data used to select the method are not fresh task evidence.
Never silently discard unfavorable benchmarks or search for wins and report only those.

## Prefer existing benchmarks; justify genuine evaluation gaps

Read [benchmark-discovery.md](benchmark-discovery.md) before substantial method
investment and whenever a changed condition affects validation. First check whether
the original native dataset/protocol can genuinely expose the condition and test
the prediction. Preserve it when suitable. Search published variants next; if the
new condition needs different information, labels or tasks, search for new existing
datasets and benchmarks. Do not force reuse or design the whole method before
establishing a plausible validation path.

Compare multiple plausible options through primary papers, official datasets and
evaluators, Web search and enabled/accessible Xiaohongshu discussions. Record source,
condition/claim fit, rival predictions, strong/simple baselines, protocol changes,
full resource costs and reasons for selection/rejection. Search depth follows the
unresolved question, with no fixed quota. Discussion leads require primary-source
checks; unavailable access does not become an invented search result.

Keep native and adapted protocols distinct. A new benchmark is an exceptional
research contribution requiring substantial value, a documented existing-evaluation
gap, justified data/labels/scoring, strong baselines and independent protocol review.
If no suitable validation path exists, retain the empirical evidence gap and work
on search, acquisition or theory. Correct theoretical claims retain their own proof
requirements. Changing conditions after outcomes is exploratory and needs fresh
confirmation; do not drop unfavorable datasets or select only wins.

Small synthetic/algebraic checks may diagnose a formula, implementation or mechanism;
label their limited diagnostic scope and retain construction choices. They cannot
replace empirical effectiveness evidence, qualify a native scorer, or become a hidden
homemade benchmark. Existing formal native-evaluation validators still require their
published contracts. Neither adapted studies nor new benchmarks automatically satisfy
those gates: use a valid supported contract or report the missing separately reviewed
evaluation integration. Never forge upstream provenance or loosen a verifier to pass.

## Include resources in every consequential selection

Restore the project's actual authorized host/allocation and remaining cumulative limits.
Measure present availability separately. Apply the selected edition profile first: Chat has a CPU-only 4 GB planning
ceiling; local-control editions use measured resources on each authorized execution target. Actual lower
capacity remains binding. A host label alone establishes no usable allocation.
At selection time estimate a credible path through the decisive comparison and final
claim-relevant evaluation, not only whether the proposed method's first run fits.

Account for data acquisition/preprocessing, loading/copies, initialization, baseline
qualification and tuning, method runs, updates/fallbacks, scoring, repetitions and
independent confirmation. Estimate peak RAM/VRAM, CPU/threads or GPU allocation,
disk/checkpoints, wall time and authorized API/cost usage. Include simultaneous workers
and other known reservations in the same actual resource domain. Record estimates,
measurements and uncertainty separately. A bounded pilot may calibrate an unknown
profile without claiming the full workload has run or will certainly fit.

Prefer a cheaper decisive comparison when it preserves the scientific question.
Use verified equivalent chunking/streaming or supported prospective native subsets;
scope pilot conclusions accordingly. Preserve the complete required evaluation plan.
If final evidence is presently infeasible, record the gap and an authorized execution
path, a justified narrower claim, an alternative in-scope problem, or a parked task.
Do not delete a strong comparator, change the user's goal or substitute convenient
synthetic data merely to fit the current machine.

Use resource-queue.md for actual admission. Temporary contention keeps the same work
queued for real rechecks; a requirement above hard capacity needs replanning. Resource
waits, OOM and infrastructure repair are not scientific refutations or discoveries.
For efficiency claims, compare complete cost at matched quality. For example, reuse
with setup S, per-use costs c_new < c_base and K uses saves total work only if
K > S / (c_base - c_new), with quality validity and all updates/fallbacks accounted for.
Seek workloads that naturally supply those uses; artificial repetition cannot establish
practical value. A better local proxy or isolated kernel timing is not an end-to-end win.

## Preserve one decision history and edition boundaries

Use the existing inquiry/decision, math trace, quality record, experiment plan and
receipts. Link the derivation and predicted conditions to benchmark selection, resource
basis, observed outcome and successor task in their existing narrative/reference fields.
Do not invent unsupported schema keys, a mandatory second ledger or a fixed candidate
quota. Keep unresolved evaluation obligations and original goal criteria visible.

Human–AI presents a concrete evidence/cost/alternatives packet at a consequential new
direction; reuse sourced human choices and continue approved work. Auto Work and Auto
Chat select in-scope successors on their specified host. Simple keeps one active idea
while supporting multiple cycles and evidence-led transfers. All retain pauses, scoped
authority, source pins and cumulative usage. Publication or a written next action alone
does not establish an installed policy or a live unattended research service.
