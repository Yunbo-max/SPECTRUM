"""Goal provenance, quantitative resource bounds and lossless startup intake."""
import copy
from pathlib import Path
import tempfile
import types
import unittest

from fixtures import C, DATE, sample_artifacts


def record(value=None, status="unknown", source="Not supplied"):
    return {"value": value, "status": status, "source": source, "updated_at": DATE}


def startup_intake():
    value = copy.deepcopy(sample_artifacts()["research-intake"])
    value["goal_alignment"] = {
        "purpose": record("Establish a useful empirical finding", "user_stated", "User request"),
        "core_problem": record("Agents retrieve correct memory but execute a wrong action", "user_stated", "User request"),
        "minimum_success": record(),
    }
    value["resource_envelope"] = {
        "accelerators": record([{"model": "RTX 4090", "count": 1, "vram_gb_each": 24}], "user_stated", "Current user device inventory"),
        "human_hours_per_week": record(),
        "wall_clock_hours": record(48, "user_stated", "User request"),
        "gpu_hours": record(),
        "spend_budget": record({"amount": 0, "currency": "GBP"}, "user_stated", "User request"),
        "api_access": record([], "user_stated", "User request"),
    }
    return value


class StartupIntakeTests(unittest.TestCase):
    def test_unknowns_and_zero_additional_budget_are_valid(self):
        C.validate(startup_intake())

    def test_resource_counts_and_limits_are_quantitative(self):
        changes = [
            ("accelerators", [{"model": "RTX 4090", "count": -1, "vram_gb_each": 24}]),
            ("accelerators", [{"model": "RTX 4090", "count": 1.5, "vram_gb_each": 24}]),
            ("accelerators", [{"model": "RTX 4090", "count": 1, "vram_gb_each": -24}]),
            ("wall_clock_hours", -1),
            ("spend_budget", {"amount": -1, "currency": "GBP"}),
            ("spend_budget", {"amount": 10}),
        ]
        for key, bad in changes:
            value = startup_intake()
            value["resource_envelope"][key]["value"] = bad
            with self.subTest(key=key, value=bad), self.assertRaises(C.Failure):
                C.validate(value)

    def test_an_unknown_field_cannot_silently_contain_an_assumed_answer(self):
        value = startup_intake()
        value["goal_alignment"]["minimum_success"]["value"] = "An accepted top conference paper"
        with self.assertRaisesRegex(C.Failure, "INTAKE_STATUS_VALUE_MISMATCH"):
            C.validate(value)

    def test_a_user_stated_field_needs_an_answer_and_source(self):
        for replacement in [record(None, "user_stated", "User request"), record("Publish a paper", "user_stated", "")]:
            value = startup_intake()
            value["goal_alignment"]["purpose"] = replacement
            with self.subTest(replacement=replacement), self.assertRaises(C.Failure):
                C.validate(value)

    def test_legacy_intake_is_still_readable(self):
        C.validate(sample_artifacts()["research-intake"])

    def test_initialization_preserves_the_supplied_goal_and_resource_records(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder) / "project"
            root.mkdir()
            source = Path(folder) / "intake.json"
            source.write_text(C.canonical(startup_intake()))
            args = types.SimpleNamespace(name="Fixture", goal="test", entry="M", mode="audit", intake=str(source))
            C.init_project(args, root)
            stored = C.load_file(root / "research-intake.yaml")
            self.assertEqual(stored["goal_alignment"], startup_intake()["goal_alignment"])
            self.assertEqual(stored["resource_envelope"], startup_intake()["resource_envelope"])
            before = (root / "research-intake.yaml").read_bytes()
            source.write_text("invalid replacement")
            self.assertEqual(C.init_project(args, root)["status"], "resumed")
            self.assertEqual((root / "research-intake.yaml").read_bytes(), before)

    def test_supplied_intake_cannot_initialize_another_project_or_origin(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder) / "project"
            root.mkdir()
            source = Path(folder) / "intake.json"
            source.write_text(C.canonical(startup_intake()))
            args = types.SimpleNamespace(name="Other project", goal="test", entry="I", mode="audit", intake=str(source))
            with self.assertRaisesRegex(C.Failure, "INTAKE_INITIALIZATION_MISMATCH"):
                C.init_project(args, root)
            self.assertFalse((root / "event-ledger.jsonl").exists())


if __name__ == "__main__":
    unittest.main()
