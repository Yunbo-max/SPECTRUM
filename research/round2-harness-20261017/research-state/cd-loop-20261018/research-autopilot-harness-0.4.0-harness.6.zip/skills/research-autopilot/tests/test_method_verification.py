"""Engineering evidence-contract tests, never scientific method evaluations."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

from fixtures import C, DATE, DIGEST, PACKAGE, ProjectFixture, digest, ref, sample_artifacts, write

try:
    import verify_methods as V
except ModuleNotFoundError:
    V = None


MATH_CHECKS = ("formal_object", "operations_and_conditions", "derivation", "assumptions",
               "method_expression", "prediction_and_falsifier", "closest_alternative")
RANK_CHECKS = ("structural_distinctness", "all_candidates_compared", "ranking_basis", "top_selection")
CODE_CHECKS = ("math_to_code", "software_checks", "actual_code_identity")
DESIGN_CHECKS = ("native_benchmark", "strong_simple_baseline", "distinguishing_controls",
                 "fair_information_and_cost", "splits_seeds_uncertainty", "outcome_rules", "bounded_schedule")
RESULT_CHECKS = ("execution_and_parameters", "implementation_semantics", "native_measurement_and_baseline",
                 "optimization_validity", "confirmation_and_scope", "complete_inventory")


class BatchFixture:
    """Twenty differently labelled engineering derivations; never a research slate."""
    def __init__(self, root):
        self.root = root
        self.batch = {"kind": "method-verification-batch", "version": "1.0.0", "batch_id": "engineering-batch",
                      "candidates": []}
        for i in range(20):
            cid = "c" + str(i + 1)
            card = {"kind": "math-card", "version": "1.0.0", "candidate_id": cid,
                    "formal_object": "Scalar engineering identity with coefficient " + str(i + 1),
                    "operations": [{"id": "A02", "input": "L(x)=x^2/2", "condition": "constant c>0",
                                    "condition_status": "established", "output": "c L(x)"}],
                    "derivation_steps": [{"id": "s1", "statement": "d(c*x^2/2)/dx=c*x, c=" + str(i + 1),
                                          "justification": "Differentiate with c independent of x"}],
                    "assumptions": ["c is a positive constant; this is a contract fixture"],
                    "method_expression": "x_next=x-eta*" + str(i + 1) + "*x",
                    "distinguishing_prediction": "At fixed eta, update magnitude scales by " + str(i + 1),
                    "falsifier": "With fixed eta the update does not have the derived scale",
                    "closest_alternative": "Unscaled derivative; this is an equivalence, not novelty",
                    "decisive_comparison": "Check the exact scalar update, not scientific efficacy",
                    "source_refs": []}
            card_ref = write(root, "math/" + cid + ".json", card)
            review_ref = self.review(cid, "math", card_ref, MATH_CHECKS)
            self.batch["candidates"].append({"candidate_id": cid, "math_card_ref": card_ref,
                                              "math_review_ref": review_ref})
        self.selection()

    def review(self, cid, scope, artifact_ref, checks, **fields):
        value = {"kind": "method-review", "version": "1.0.0", "subject_id": cid,
                 "scope": scope, "artifact_ref": artifact_ref, "reviewer": "engineering-review-fixture",
                 "reviewed_at": DATE, "outcome": "verified",
                 "checks": {key: {"status": "verified", "rationale": "Checked the engineering fixture's " + key,
                                   "evidence_refs": [artifact_ref]} for key in checks}, **fields}
        return write(self.root, "reviews/" + cid + "-" + scope + ".json", value)

    def selection(self):
        entries = self.batch["candidates"]
        selection = {"kind": "method-selection", "version": "1.0.0", "batch_id": self.batch["batch_id"],
                     "pool_target": 20, "selection_target": 15,
                     "math_bindings": [{"candidate_id": e["candidate_id"], "math_card_ref": e["math_card_ref"],
                                        "math_review_ref": e["math_review_ref"]} for e in entries],
                     "ranking": [{"candidate_id": e["candidate_id"],
                                  "rationale": {key: "Engineering comparison for " + e["candidate_id"]
                                                for key in ("problem_value", "mathematical_consequence", "closest_work_delta",
                                                            "distinguishing_prediction", "feasibility_and_cost")}}
                                 for e in entries],
                     "selected_ids": [e["candidate_id"] for e in entries[:15]]}
        self.batch["selection_ref"] = write(self.root, "selection.json", selection)
        self.batch["selection_review_ref"] = self.review(self.batch["batch_id"], "selection",
                                                          self.batch["selection_ref"], RANK_CHECKS)

    def implementation(self, index=0):
        entry = self.batch["candidates"][index]
        cid = entry["candidate_id"]
        path = self.root / (cid + ".py")
        path.write_text("def update(x, eta):\n    return x - eta * " + str(index + 1) + " * x\n")
        code_ref = ref(self.root, path.name)
        log_ref = write(self.root, "logs/" + cid + ".json", {"purpose": "engineering software check", "exit_code": 0})
        identity_ref = write(self.root, "code/" + cid + "-source-identity.json", {
            "purpose": "non-evaluation engineering source fixture", "git_tree_digest": DIGEST,
            "method_code_refs": [code_ref]})
        packet = {"kind": "implementation-card", "version": "1.0.0", "candidate_id": cid,
                  "math_card_ref": entry["math_card_ref"], "selection_ref": self.batch["selection_ref"],
                  "code_refs": [code_ref], "code_version": digest([code_ref]),
                  "method_version": DIGEST, "source_identity_ref": identity_ref,
                  "mapping": [{"derivation_step": "s1", "code_ref": code_ref, "location": "update:2",
                               "rationale": "Exact scalar derivative in update"}],
                  "software_checks": [{"status": "passed", "command": ["python3", "scalar_check.py"],
                                       "tested_code_refs": [code_ref], "log_refs": [log_ref]}]}
        entry["implementation_ref"] = write(self.root, "code/" + cid + ".json", packet)
        entry["code_review_ref"] = self.review(cid, "code", entry["implementation_ref"], CODE_CHECKS)
        return packet

    def design(self, protocol_ref, index=0):
        entry = self.batch["candidates"][index]
        packet = {"kind": "experiment-design", "version": "1.0.0", "candidate_id": entry["candidate_id"],
                  "math_card_ref": entry["math_card_ref"], "selection_ref": self.batch["selection_ref"],
                  "implementation_ref": entry["implementation_ref"], "protocol_ref": protocol_ref}
        entry["design_ref"] = write(self.root, "design/" + entry["candidate_id"] + ".json", packet)
        entry["design_review_ref"] = self.review(entry["candidate_id"], "design", entry["design_ref"], DESIGN_CHECKS)

    def result(self, decision_ref, index=0):
        entry = self.batch["candidates"][index]
        design = C.load_file(C.verify_ref(self.root, entry["design_ref"]))
        packet = {"kind": "method-result", "version": "1.0.0", "candidate_id": entry["candidate_id"],
                  "design_ref": entry["design_ref"], "implementation_ref": entry["implementation_ref"],
                  "protocol_ref": design["protocol_ref"], "decision_ref": decision_ref}
        entry["result_ref"] = write(self.root, "results/" + entry["candidate_id"] + ".json", packet)
        entry["e04_review_ref"] = self.review(entry["candidate_id"], "e04", entry["result_ref"], RESULT_CHECKS)


class MethodVerificationTests(unittest.TestCase):
    def readiness_batch(self):
        self.f.batch['version'] = '1.1.0'
        self.f.batch['scope_rationale'] = 'One distinct ready construction; other families remain in history'
        self.f.batch['history_ref'] = write(self.root, 'search-history.json', {'retired': ['prior-family']})
        self.f.batch['candidates'] = self.f.batch['candidates'][:1]
        self.f.selection()
        selected = C.load_file(C.verify_ref(self.root, self.f.batch['selection_ref']))
        selected['pool_target'] = selected['selection_target'] = 1
        self.f.batch['selection_ref'] = write(self.root, 'selection.json', selected)
        self.f.batch['selection_review_ref'] = self.f.review(self.f.batch['batch_id'], 'selection',
                                                            self.f.batch['selection_ref'], RANK_CHECKS)

    def test_readiness_default_accepts_one_reviewed_candidate_without_quota_override(self):
        self.readiness_batch()
        report = self.report()
        self.assertTrue(report['selection_verified'])
        self.assertEqual(report['counts']['selected'], 1)
        self.assertEqual(report['counts']['code_verified'], 0)

    def test_readiness_never_waives_math_review_or_retained_search_history(self):
        self.readiness_batch()
        self.f.batch['candidates'][0].pop('math_review_ref')
        self.assertFalse(self.report()['selection_verified'])
        self.f.batch.pop('history_ref')
        with self.assertRaises(C.Failure):
            self.report()

    def test_readiness_declared_cohort_still_requires_complete_comparison(self):
        self.readiness_batch()
        self.f.batch['pool_target'] = 2
        self.assertFalse(self.report()['selection_verified'])


    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.f = BatchFixture(self.root)

    def report(self):
        return V.verify_batch(self.root, self.f.batch)

    def codes(self, report, index=0):
        return [item["code"] for item in report["candidates"][index]["blockers"]]

    def test_math_pool_and_ranked_top_fifteen_unlock_code_design_only(self):
        report = self.report()
        self.assertTrue(report["selection_verified"])
        self.assertEqual(report["counts"]["math_verified"], 20)
        self.assertEqual(report["counts"]["selected"], 15)
        self.assertEqual(report["counts"]["verdict_verified"], 0)
        self.assertEqual(report["counts"]["code_verified"], 0)

    def test_missing_math_blocks_selection_even_with_twenty_modules_and_a_rank_list(self):
        self.f.batch["candidates"][0].pop("math_card_ref")
        report = self.report()
        self.assertFalse(report["selection_verified"])
        self.assertEqual(report["counts"]["math_verified"], 19)
        self.assertIn("MATH_CARD_REF_REQUIRED", self.codes(report))

    def test_hash_bound_review_cannot_be_reused_for_a_different_derivation(self):
        entry = self.f.batch["candidates"][0]
        card = C.load_file(C.verify_ref(self.root, entry["math_card_ref"]))
        card["method_expression"] = "changed update with no review"
        entry["math_card_ref"] = write(self.root, entry["math_card_ref"]["path"], card)
        report = self.report()
        self.assertFalse(report["selection_verified"])
        self.assertIn("REVIEW_ARTIFACT_MISMATCH", self.codes(report))

    def test_review_checkbox_without_semantic_rationale_cannot_verify_math(self):
        entry = self.f.batch["candidates"][0]
        review = C.load_file(C.verify_ref(self.root, entry["math_review_ref"]))
        review["checks"]["derivation"]["rationale"] = " "
        entry["math_review_ref"] = write(self.root, entry["math_review_ref"]["path"], review)
        self.assertFalse(self.report()["candidates"][0]["math_verified"])

    def test_malformed_operation_condition_is_pending_instead_of_crashing_the_batch(self):
        entry = self.f.batch["candidates"][0]
        card = C.load_file(C.verify_ref(self.root, entry["math_card_ref"]))
        card["operations"][0]["condition_status"] = {}
        entry["math_card_ref"] = write(self.root, entry["math_card_ref"]["path"], card)
        entry["math_review_ref"] = self.f.review("c1", "math", entry["math_card_ref"], MATH_CHECKS)
        report = self.report()
        self.assertFalse(report["candidates"][0]["math_verified"])
        self.assertEqual(report["counts"]["math_verified"], 19)
        self.assertIn("OPERATION_CONDITION_NOT_SUPPORTED", self.codes(report))

    def test_relabelled_same_construction_cannot_pad_the_pool(self):
        entry = self.f.batch["candidates"][1]
        card = C.load_file(C.verify_ref(self.root, self.f.batch["candidates"][0]["math_card_ref"]))
        card["candidate_id"] = "c2"
        entry["math_card_ref"] = write(self.root, entry["math_card_ref"]["path"], card)
        entry["math_review_ref"] = self.f.review("c2", "math", entry["math_card_ref"], MATH_CHECKS)
        self.f.selection()
        report = self.report()
        self.assertFalse(report["selection_verified"])
        self.assertIn("DUPLICATE_CONSTRUCTION", self.codes(report, 1))

    def test_fewer_qualified_ideas_reports_deficit_instead_of_completing_quota(self):
        self.f.batch["candidates"] = self.f.batch["candidates"][:10]
        report = self.report()
        self.assertFalse(report["selection_verified"])
        self.assertEqual(report["pool_deficit"], 10)
        self.assertEqual(report["selection_deficit"], 5)

    def test_selected_ids_must_match_the_ranked_top_fifteen(self):
        selection = C.load_file(C.verify_ref(self.root, self.f.batch["selection_ref"]))
        selection["selected_ids"][0] = "c20"
        self.f.batch["selection_ref"] = write(self.root, "selection.json", selection)
        self.f.batch["selection_review_ref"] = self.f.review("engineering-batch", "selection",
                                                            self.f.batch["selection_ref"], RANK_CHECKS)
        report = self.report()
        self.assertFalse(report["selection_verified"])
        self.assertEqual(report["selection_blockers"][0]["code"], "TOP_SELECTION_MISMATCH")

    def test_real_code_receipt_is_scoped_to_software_and_changes_revoke_it(self):
        self.f.implementation()
        report = self.report()
        self.assertTrue(report["candidates"][0]["code_verified"])
        self.assertFalse(report["candidates"][0]["verdict_verified"])
        (self.root / "c1.py").write_text("def update(x, eta):\n    return x\n")
        changed = self.report()
        self.assertFalse(changed["candidates"][0]["code_verified"])
        self.assertIn("EVIDENCE_DIGEST_MISMATCH", self.codes(changed))

    def test_code_receipt_from_before_current_selection_cannot_certify_current_code(self):
        self.f.implementation()
        selection = C.load_file(C.verify_ref(self.root, self.f.batch["selection_ref"]))
        selection["ranking"][0]["rationale"]["problem_value"] = "Changed priority from new evidence"
        self.f.batch["selection_ref"] = write(self.root, "selection.json", selection)
        self.f.batch["selection_review_ref"] = self.f.review("engineering-batch", "selection",
                                                            self.f.batch["selection_ref"], RANK_CHECKS)
        report = self.report()
        self.assertTrue(report["selection_verified"])
        self.assertFalse(report["candidates"][0]["code_verified"])
        self.assertIn("SELECTION_BINDING_MISMATCH", self.codes(report))

    def test_duplicate_candidates_and_unexplained_target_changes_are_rejected(self):
        for change in ("duplicate", "target"):
            batch = copy.deepcopy(self.f.batch)
            if change == "duplicate":
                batch["candidates"][1]["candidate_id"] = "c1"
            else:
                batch["pool_target"] = 10
            with self.subTest(change=change), self.assertRaises(C.Failure):
                V.verify_batch(self.root, batch)

    def test_cli_returns_nonzero_when_selection_is_pending(self):
        self.f.batch["candidates"][0].pop("math_review_ref")
        write(self.root, "batch.json", self.f.batch)
        run = subprocess.run([sys.executable, str(PACKAGE / "scripts/verify_methods.py"), "--root", str(self.root),
                              "--batch", "batch.json", "--require", "selection_verified"], capture_output=True, text=True)
        self.assertEqual(run.returncode, 2)
        self.assertFalse(json.loads(run.stdout)["selection_verified"])


class NativeMethodVerificationTests(unittest.TestCase):
    def setUp(self):
        self.project = ProjectFixture()
        self.addCleanup(self.project.close)
        self.f = BatchFixture(self.project.root)
        self.code = self.f.implementation()

    def prepare(self, effects=(.25, .25), gate="full-validation"):
        protocol = self.project.protocol(gate)
        protocol["method_version"] = self.code["method_version"]
        protocol["native_eval_contract"]["arm_requirements"]["treatment"]["implementation_refs"] = self.code["code_refs"]
        if gate == "full-validation":
            protocol["claim_cards"][0]["method_version"] = self.code["method_version"]
        protocol["protocol_digest"] = C.protocol_hash(protocol)
        protocol_ref = write(self.project.root, "protocol.json", protocol)
        self.f.design(protocol_ref)
        runs, refs = self.project.runs(protocol, effects)
        decision = C.evaluate(self.project.root, protocol, runs, refs, gate)
        self.f.result(write(self.project.root, "decision.json", decision))
        return decision, runs, refs

    def test_complete_native_shaped_contract_uses_existing_rules_for_pass_and_kill(self):
        for effects, expected in (((.25, .25), "PASS"), ((0, 0), "KILL")):
            with self.subTest(outcome=expected):
                self.prepare(effects)
                row = V.verify_batch(self.project.root, self.f.batch)["candidates"][0]
                self.assertTrue(row["design_verified"], row["blockers"])
                self.assertTrue(row["verdict_verified"], row["blockers"])
                self.assertEqual(row["outcome"], expected)

    def test_baseline_or_different_method_code_cannot_be_counted_as_candidate_result(self):
        protocol = self.project.protocol("full-validation")
        protocol["method_version"] = self.code["method_version"]
        protocol["protocol_digest"] = C.protocol_hash(protocol)
        self.f.design(write(self.project.root, "protocol.json", protocol))
        row = V.verify_batch(self.project.root, self.f.batch)["candidates"][0]
        self.assertFalse(row["design_verified"])
        self.assertEqual(row["blockers"][0]["code"], "TREATMENT_CODE_BINDING_MISMATCH")

    def test_gate_a_pass_is_screening_not_full_method_verdict(self):
        self.prepare(gate="gate-a")
        row = V.verify_batch(self.project.root, self.f.batch)["candidates"][0]
        self.assertFalse(row["verdict_verified"])
        self.assertEqual(row["gate_a_outcome"], "PASS")
        self.assertIn("FULL_COMPARISON_REQUIRED", [b["code"] for b in row["blockers"]])

    def test_saved_native_receipts_without_live_replay_cannot_verify_a_method(self):
        self.prepare()
        self.project.runtime.__exit__(None, None, None)
        self.project.runtime = C.evaluation_runtime()
        self.project.runtime.__enter__()
        row = V.verify_batch(self.project.root, self.f.batch)["candidates"][0]
        self.assertFalse(row["verdict_verified"])
        self.assertIn("DECISION_RECOMPUTATION_MISMATCH", [b["code"] for b in row["blockers"]])

    def test_cli_installs_live_scorer_only_for_explicit_native_verification(self):
        # A real subprocess peer emits the existing contract fixture's values.
        # This tests callback installation/collection, not a scientific scorer.
        peer=self.project.root/'replay-peer.py'
        peer.write_text("import json,sys\nfrom pathlib import Path\nrole=Path(sys.argv[1]).parent.name\n"
                        "values={'treatment':(.75,.25),'baseline':(.5,.5),'positive':(1.,1.),'shuffled':(0.,0.)}[role]\n"
                        "print(json.dumps({'denominator':2,'native_metrics':dict(zip(['accuracy','scope'],values))}))\n")
        original_protocol=self.project.protocol
        def protocol_with_peer(*args,**kwargs):
            protocol=original_protocol(*args,**kwargs)
            contract=protocol['native_eval_contract']
            contract['scorer']['command']=[sys.executable,str(peer),'{predictions}']
            contract['scorer']['code_refs']=[ref(self.project.root,peer.name)]
            definition=C.load_file(C.verify_ref(self.project.root,contract['native_definition_ref']))
            definition['scorer']=copy.deepcopy(contract['scorer'])
            contract['native_definition_ref']=write(self.project.root,contract['native_definition_ref']['path'],definition)
            return protocol
        self.project.protocol=protocol_with_peer
        self.prepare()
        write(self.project.root,'verify-batch.json',self.f.batch)
        argv=[sys.executable,str(PACKAGE/'scripts/verify_methods.py'),
              '--root',str(self.project.root),'--batch','verify-batch.json','--before','verdict','--candidate','c1']
        denied=subprocess.run(argv,capture_output=True,text=True,timeout=10)
        self.assertNotEqual(denied.returncode,0)
        other=subprocess.run(argv[:-1]+['c2','--execute-native-scoring'],capture_output=True,text=True,timeout=15)
        self.assertNotEqual(other.returncode,0)
        self.assertFalse(list((self.project.root/'runs/native-replays').glob('*/execution.json')),
                         'requesting c2 must not execute c1 scoring')
        observed=subprocess.run(argv+['--execute-native-scoring','--native-timeout-seconds','10','--output','verified-report.json'],
                                capture_output=True,text=True,timeout=15)
        self.assertEqual(observed.returncode,0,observed.stdout+observed.stderr)
        report=json.loads((self.project.root/'verified-report.json').read_text())
        self.assertTrue(report['workflow_boundary']['ready'])
        self.assertEqual(report['candidates'][0]['outcome'],'PASS')
        self.assertTrue(list((self.project.root/'runs/native-replays').glob('*/execution.json')))

    def test_missing_raw_output_never_means_method_failed(self):
        _, runs, _ = self.prepare()
        C.verify_ref(self.project.root, runs[0]["raw_output_refs"][0]).unlink()
        row = V.verify_batch(self.project.root, self.f.batch)["candidates"][0]
        self.assertFalse(row["verdict_verified"])
        self.assertEqual(row["outcome"], "PENDING")
        self.assertNotEqual(row["outcome"], "KILL")

    def test_malformed_protocol_is_pending_and_never_a_method_failure(self):
        for protocol in ([], None, "not a protocol", {"schema_id": []}):
            with self.subTest(protocol=protocol):
                self.f.design(write(self.project.root, "malformed.json", protocol))
                row = V.verify_batch(self.project.root, self.f.batch)["candidates"][0]
                self.assertTrue(row["code_verified"])
                self.assertFalse(row["design_verified"])
                self.assertEqual(row["outcome"], "PENDING")
                self.assertTrue(row["blockers"])

    def test_native_protocol_admission_enforces_its_pinned_math_selection_and_code_prerequisites(self):
        import _native_eval as N
        protocol = self.project.protocol()
        protocol["method_version"] = self.code["method_version"]
        protocol["native_eval_contract"]["arm_requirements"]["treatment"]["implementation_refs"] = self.code["code_refs"]
        protocol["method_discovery"] = {"candidate_id": "c1", "batch_ref": write(self.project.root, "discovery.json", self.f.batch)}
        N.verify_protocol(self.project.root, protocol)
        self.f.batch["candidates"][0].pop("math_review_ref")
        protocol["method_discovery"]["batch_ref"] = write(self.project.root, "discovery.json", self.f.batch)
        with self.assertRaises(C.Failure) as error:
            N.verify_protocol(self.project.root, protocol)
        self.assertEqual(error.exception.code, "METHOD_DISCOVERY_NOT_VERIFIED")

    def test_method_code_digest_and_existing_git_tree_version_survive_real_protocol_freeze(self):
        from test_workflow import to_gate
        protocol, _ = to_gate(self.project)
        tree_version = protocol["method_version"]
        protocol["protocol_id"] = "verified-method-child"
        protocol["parent_protocol_digest"] = protocol.pop("protocol_digest")
        protocol.pop("frozen_at")
        protocol["native_eval_contract"]["arm_requirements"]["treatment"]["implementation_refs"] = self.code["code_refs"]
        protocol["method_discovery"] = {"candidate_id": "c1", "batch_ref": write(self.project.root, "discovery.json", self.f.batch)}
        source = write(self.project.root, "freeze-input.json", protocol)
        with C.locked(self.project.root):
            result = C.freeze_gate(types.SimpleNamespace(protocol=str(self.project.root / source["path"]), gate="gate-a"),
                                   self.project.root)
        frozen = C.verify_ref(self.project.root, result["protocol_ref"], "gate-a-protocol")
        self.assertEqual(frozen["method_version"], tree_version)
        self.assertEqual(frozen["provenance_constraints"]["git_tree_digest"], tree_version)
        self.assertNotEqual(tree_version, self.code["code_version"])
        self.f.design(result["protocol_ref"])
        row = V.verify_batch(self.project.root, self.f.batch, through="design")["candidates"][0]
        self.assertTrue(row["design_verified"], row["blockers"])

    def test_e04_is_required_after_scoring_before_a_verdict(self):
        self.prepare()
        self.f.batch["candidates"][0].pop("e04_review_ref")
        row = V.verify_batch(self.project.root, self.f.batch)["candidates"][0]
        self.assertFalse(row["verdict_verified"])
        self.assertIn("E04_REVIEW_REF_REQUIRED", [b["code"] for b in row["blockers"]])


class SelfDeclaredVerificationTests(unittest.TestCase):
    def test_candidate_cannot_self_certify_math_without_a_derivation_receipt(self):
        candidate = copy.deepcopy(sample_artifacts()["idea-atom"])
        candidate["math_verified"] = True
        with self.assertRaises(C.Failure) as error:
            C.validate(candidate, "idea-atom")
        self.assertEqual(error.exception.code, "DERIVED_VERIFICATION_REQUIRED")

    def test_archived_self_claims_replay_without_becoming_new_verification_or_new_admission(self):
        from ipcg_fixtures import candidate, importance, ready_problem
        project = ProjectFixture()
        self.addCleanup(project.close)
        # Recreate the observed earlier acceptance policy for this archived fixture.
        # All other validation stays real; the current replay below has no double.
        current_validate = C.validate
        def legacy_validate(value, expected=None, **kwargs):
            structural = copy.deepcopy(value)
            if structural.get("schema_id") == "idea-atom":
                structural.pop("math_verified", None)
            current_validate(structural, expected)
            return value
        with patch.object(C, "validate", legacy_validate):
            ready_problem(project)
            candidate_ref = candidate(project)
            value = C.load_file(C.verify_ref(project.root, candidate_ref))
            value["math_verified"] = True
            candidate_ref = write(project.root, "ideas/legacy.json", value)
            project.transition("research_candidate", {"candidate_ref": candidate_ref})
            project.transition("importance_decision", {"importance_decision_ref": importance(project)})
        state, _, _ = C.project(project.root)
        self.assertEqual(state["current_route"], "develop_candidate")
        self.assertNotIn("math_verified", state)
        batch = {"kind": "method-verification-batch", "version": "1.0.0", "batch_id": "legacy-audit",
                 "candidates": [{"candidate_id": value["candidate_id"], "math_verified": True}]}
        report = V.verify_batch(project.root, batch)
        self.assertEqual(report["counts"]["math_verified"], 0)
        self.assertFalse(report["selection_verified"])
        # Replay's compatibility scope must not leak into a new admission.
        with self.assertRaises(C.Failure) as error:
            project.transition("research_candidate", {"candidate_ref": candidate_ref})
        self.assertEqual(error.exception.code, "DERIVED_VERIFICATION_REQUIRED")


if __name__ == "__main__":
    unittest.main()
