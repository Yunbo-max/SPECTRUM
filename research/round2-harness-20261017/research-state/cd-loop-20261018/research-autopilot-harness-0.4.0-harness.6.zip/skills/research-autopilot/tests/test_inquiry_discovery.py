"""Object-first record/host regression fixtures; not live-agent discovery evidence."""
import copy
import json
from pathlib import Path
import sys
import unittest
import test_research_reasoning as rf
import test_goal_linked_quality as qf
S = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(S))
import research_reasoning as rr


class InquiryTests(unittest.TestCase):
    def setUp(self):
        self.f = rf.ReasoningTests(); self.f.setUp(); self.addCleanup(self.f.doCleanups)
        self.root = self.f.root; self.ref = self.f.ref
        self.goal = self.ref('User goal: compare valid outputs at fixed information and CPU budget. Fixture, not research evidence.')
        self.q = qf.QualityTests(); self.q.root = self.root; self.q.n = 1000; self.q.evidence = self.f.raw

    def inquiry(self, stage='hypothesis'):
        return dict(problem_id='p', frame_id='frame1', entry='phenomenon', stage=stage,
            goal_ref=self.goal, goal_preservation='Keep the requested output and information constraints.',
            question='Is the observed difference due to the objective or the update?',
            objects=dict(target='same final decision', information='observed history only',
                         objective='fixed primary error', representation='finite model', cost_model='complete CPU path'),
            defaults=[dict(id='a', statement='Equivalent objectives have equivalent updates.', status='open', evidence_refs=[])],
            explanations=[dict(id='h1', mechanism='The actual update is not invariant.', conditions='same initialization',
                    prediction='Learning-rate compensation removes the difference.',status='open',evidence_refs=[]),
                dict(id='h2', mechanism='The representable function class changes.', conditions='same initialization',
                    prediction='Compensation alone leaves the difference.',status='open',evidence_refs=[])],
            contrasts=[dict(id='c', explanation_ids=['h1','h2'], intervention='Compensate learning rate only.',
                    held_fixed='Inputs, initialization, model and objective.',
                    predictions={'h1':'Difference vanishes.','h2':'Difference remains.'})],
            selected_explanation_ids=['h1'], selected_contrast_id='c', no_alternative_reason=None,
            selection_reason='The paired check separates objective and update before a larger run.',
            priority=dict(basis='algebra and observed uncertainty', uncertainty='unknown',
                          decision_value='distinguish two mechanisms', cost='one paired check'),
            next_check=dict(action='compare' if stage=='construction' else 'probe',
                            question='Does compensated updating preserve the output?', task_ids=['task'],
                            outcome_actions=dict(supports='Bound the equivalence claim.',refutes='Revisit the update.',
                                                 inconclusive='Improve the discriminator.',invalid='Repair evaluation only.'),
                            input_refs=[self.f.raw]),
            observations=[], based_on_observation_ids=[])

    def decision(self, stage='hypothesis'):
        d = self.f.adaptive_decision() if stage=='construction' else self.f.decision(selected_option='compare')
        d['schema_version'] = 4; d['inquiry'] = self.inquiry(stage)
        if stage=='construction': d['quality_ref'] = self.ref(self.q.packet())
        else:
            d['math_trace_ref']=None;d['trajectory_ref']=None
            d['options'][1]['action']='explore'
        return d

    def codes(self, report): return {g['code'] for g in report['gaps']}
    def check(self, d): return rr.check_decision(self.root,d,candidate_id='candidate',goal_id='goal')
    def task(self,d,scope='diagnostic'):
        ref=self.ref(d)
        return dict(task_id='task',research_scope=scope,reasoning_ref=ref,input_refs=[ref],phase='diagnostic' if scope=='diagnostic' else 'experiment')
    def observation(self):
        return dict(id='o1',attempt_id='attempt1',task_id='prior-task',outcome='inconclusive',
                    affected_explanation_ids=['h1'],affected_layer='assumption',
                    interpretation='The fixture leaves the mechanism unresolved.',receipt_ref=self.ref('real-receipt-shaped unit fixture'))

    def test_early_hypothesis_runs_without_completed_math(self):
        d=self.decision();r=self.check(d)
        self.assertEqual(r['status'],'record_complete',r['gaps'])
        self.assertEqual(r['inquiry_stage'],'hypothesis');self.assertFalse(r['scientific_certification'])
        self.assertEqual(rr.check_task(self.root,self.task(d))['status'],'record_complete')
    def test_construction_keeps_dag_quality_and_frame(self):
        d=self.decision('construction');r=self.check(d)
        self.assertEqual(r['status'],'record_complete',r['gaps']);self.assertIn(self.goal,r['required_input_refs'])
        self.assertEqual(rr.check_task(self.root,self.task(d,'method'))['status'],'record_complete')
    def test_early_lead_cannot_be_method_investment(self):
        r=rr.check_task(self.root,self.task(self.decision(),'method'))
        self.assertIn('lead_not_method',self.codes(r))
    def test_missing_frame_does_not_silently_bypass_v4(self):
        d=self.decision();del d['inquiry'];self.assertIn('inquiry_required',self.codes(self.check(d)))
    def test_goal_source_must_be_pinned(self):
        d=self.decision();d['inquiry']['goal_ref']['sha256']='0'*64
        self.assertIn('invalid_reference',self.codes(self.check(d)))
    def test_objects_and_material_default_are_required_not_48_moves(self):
        d=self.decision();d['inquiry']['objects']['target']=''
        self.assertIn('missing_problem_object',self.codes(self.check(d)))
    def test_two_named_explanations_with_identical_predictions_are_not_distinct(self):
        d=self.decision();d['inquiry']['contrasts'][0]['predictions']['h2']=' DIFFERENCE   VANISHES. '
        self.assertIn('indistinguishable_contrast',self.codes(self.check(d)))
    def test_multiple_explanations_need_a_discriminator_not_a_quota(self):
        d=self.decision();d['inquiry']['contrasts']=[];d['inquiry']['selected_contrast_id']=None
        self.assertIn('missing_discriminator',self.codes(self.check(d)))
    def test_single_necessary_repair_is_allowed_with_reason(self):
        d=self.decision();i=d['inquiry'];i['explanations']=i['explanations'][:1];i['contrasts']=[]
        i['selected_contrast_id']=None;i['no_alternative_reason']='Only denominator provenance is unresolved; it blocks the fixed scorer.'
        i['next_check']['action']='repair';d['selected_option']='repair'
        r=self.check(d);self.assertEqual(r['status'],'record_complete',r['gaps'])
    def test_unknown_is_not_invalid_or_low_priority(self):
        d=self.decision();self.assertEqual(self.check(d)['status'],'record_complete')
    def test_refuted_explanation_cannot_remain_selected(self):
        d=self.decision();i=d['inquiry'];i['explanations'][0].update(status='refuted',evidence_refs=[self.f.raw])
        self.assertIn('refuted_explanation_selected',self.codes(self.check(d)))
    def test_object_change_requires_new_frame(self):
        old=self.decision();ref=self.ref(old);d=copy.deepcopy(old);d.update(previous_ref=ref,decision_id='new')
        d['inquiry']['objects']['objective']='a different objective'
        self.assertIn('frame_reused_after_object_change',self.codes(self.check(d)))
    def test_reframe_can_reuse_unchanged_objects_and_prior_results(self):
        old=self.decision();ref=self.ref(old);d=copy.deepcopy(old);d.update(previous_ref=ref,decision_id='new')
        d['inquiry']['objects']['objective']='a different optimization target serving same final goal'
        d['inquiry'].update(frame_id='frame2',change_reason='Compare the target under a separate protocol; no user goal change.')
        self.assertEqual(self.check(d)['status'],'record_complete',self.check(d)['gaps'])
    def test_goal_cannot_be_silently_replaced(self):
        old=self.decision();ref=self.ref(old);d=copy.deepcopy(old);d.update(previous_ref=ref,decision_id='new')
        d['inquiry']['goal_ref']=self.ref('Easier new goal')
        self.assertIn('inquiry_goal_changed',self.codes(self.check(d)))
    def test_changed_prediction_requires_new_explanation_identity(self):
        old=self.decision();ref=self.ref(old);d=copy.deepcopy(old);d.update(previous_ref=ref,decision_id='new')
        d['inquiry']['explanations'][0]['prediction']='Now the opposite outcome is predicted.'
        self.assertIn('explanation_rewritten',self.codes(self.check(d)))
    def test_observation_prefix_cannot_disappear(self):
        old=self.decision();old['inquiry']['observations']=[self.observation()];old['inquiry']['based_on_observation_ids']=['o1']
        ref=self.ref(old);d=copy.deepcopy(old);d.update(previous_ref=ref,decision_id='new');d['inquiry']['observations']=[]
        d['inquiry']['based_on_observation_ids']=[]
        self.assertIn('inquiry_history_lost',self.codes(self.check(d)))
    def test_invalid_execution_is_not_an_assumption_refutation(self):
        d=self.decision();o=self.observation();o.update(outcome='invalid',affected_layer='assumption')
        d['inquiry']['observations']=[o];d['inquiry']['based_on_observation_ids']=['o1']
        self.assertIn('invalid_run_is_not_refutation',self.codes(self.check(d)))
    def test_same_receipt_is_not_two_independent_observations(self):
        d=self.decision();o=self.observation();p=copy.deepcopy(o);p['id']='o2'
        d['inquiry'].update(observations=[o,p],based_on_observation_ids=['o1','o2'])
        self.assertIn('duplicate_inquiry_attempt',self.codes(self.check(d)))
    def test_framing_selected_tasks_match_dispatch(self):
        d=self.decision();d['inquiry']['next_check']['task_ids']=['other']
        self.assertIn('inquiry_task_mismatch',self.codes(self.check(d)))
    def test_probe_is_not_confirmed_method_or_expansion(self):
        d=self.decision();d['inquiry']['next_check']['action']='confirm'
        self.assertIn('early_claim_expansion',self.codes(self.check(d)))
    def test_v4_downgrade_is_rejected(self):
        old=self.decision();ref=self.ref(old);d=self.f.adaptive_decision()
        d.update(previous_ref=ref,decision_id='legacy');self.assertIn('inquiry_policy_downgrade',self.codes(self.check(d)))
    def test_actual_task_requires_accepted_v4_probe_decision(self):
        task=self.task(self.decision())
        with self.assertRaisesRegex(ValueError,'accepted'):
            rr.require_task(self.root,task,require_accepted=True,accepted_ref=None,expand=True)
    def test_probe_pins_are_rechecked_before_dispatch(self):
        d=self.decision();task=self.task(d);task['input_refs']=rr.require_task(self.root,task,expand=True)
        self.assertIn(self.goal,task['input_refs'])
        (self.root/self.goal['path']).write_text('changed goal')
        with self.assertRaises(ValueError):rr.require_task(self.root,task,expand=False)
    def test_actual_probe_receipt_must_be_read_before_successor(self):
        task=self.task(self.decision());r=dict(attempt_id='attempt1',task_id='prior-task',
            receipt_ref=self.ref('actual host unit fixture'),valid_execution=True,feedback_kind='inquiry')
        with self.assertRaisesRegex(ValueError,'consume'):
            rr.require_host_feedback(self.root,task,[r])
    def test_probe_receipt_consumption_does_not_require_invented_theory(self):
        d=self.decision();o=self.observation();d['inquiry'].update(observations=[o],based_on_observation_ids=['o1'])
        r=dict(attempt_id=o['attempt_id'],task_id=o['task_id'],receipt_ref=o['receipt_ref'],valid_execution=True,feedback_kind='inquiry')
        rr.require_host_feedback(self.root,self.task(d),[r])
    def test_construction_still_rejects_missing_math(self):
        d=self.decision('construction');d['math_trace_ref']=None
        self.assertNotEqual(rr.check_task(self.root,self.task(d,'method'))['status'],'record_complete')

    def test_unexplained_empirical_lead_is_legitimate(self):
        d=self.decision('lead');i=d['inquiry'];i.update(explanations=[],contrasts=[],selected_explanation_ids=[],selected_contrast_id=None,
            unexplained_lead='An observed effect deserves a controlled replication before its mechanism is known.')
        self.assertEqual(self.check(d)['status'],'record_complete',self.check(d)['gaps'])
    def test_unknown_prior_does_not_lose_to_familiar_route_at_equal_value(self):
        d=self.decision('construction');t=json.loads((self.root/d['trajectory_ref']['path']).read_text())
        familiar=copy.deepcopy(t['routes'][0]);familiar['id']='familiar';familiar['prior']['priority']='high'
        t['routes'][0]['prior']['priority']='unknown';t['routes'].append(familiar);d['trajectory_ref']=self.ref(t)
        self.assertEqual(self.check(d)['status'],'record_complete',self.check(d)['gaps'])
    def test_construction_comparison_cannot_use_early_diagnostic_label(self):
        d=self.decision('construction');r=rr.check_task(self.root,self.task(d,'diagnostic'))
        self.assertIn('construction_mislabeled',self.codes(r))
    def test_different_problem_preserves_history_without_recopying_all_explanations(self):
        old=self.decision();ref=self.ref(old);d=self.decision();d.update(previous_ref=ref,decision_id='other-problem')
        d['inquiry'].update(problem_id='other',frame_id='other-frame',problem_change_reason='The previous problem is parked; this independent question serves the same goal.')
        d['inquiry']['explanations'][0]['prediction']='Different question and different prediction.'
        self.assertEqual(self.check(d)['status'],'record_complete',self.check(d)['gaps'])
    def test_frame_change_cannot_silently_reuse_construction_math(self):
        old=self.decision('construction');ref=self.ref(old);d=copy.deepcopy(old);d.update(previous_ref=ref,decision_id='new')
        i=d['inquiry'];i.update(frame_id='frame2',change_reason='The information set changed.');i['objects']['information']='oracle'
        q=self.q.packet();q['previous_ref']=old['quality_ref'];d['quality_ref']=self.ref(q)
        self.assertIn('framing_math_revalidation_required',self.codes(self.check(d)))
    def test_invalid_host_probe_cannot_become_scientific_support(self):
        d=self.decision();o=self.observation();o['outcome']='supports';d['inquiry'].update(observations=[o],based_on_observation_ids=['o1'])
        receipt=dict(attempt_id=o['attempt_id'],task_id=o['task_id'],receipt_ref=o['receipt_ref'],valid_execution=False,feedback_kind='inquiry')
        with self.assertRaisesRegex(ValueError,'invalid host probe'):
            rr.require_host_feedback(self.root,self.task(d),[receipt])

    def test_reframe_after_method_experiment_must_read_its_receipt(self):
        task=self.task(self.decision())
        receipt=dict(attempt_id='method-attempt',task_id='method-task',receipt_ref=self.ref('host method receipt'),valid_execution=True,feedback_kind='method')
        with self.assertRaisesRegex(ValueError,'consume'):
            rr.require_host_feedback(self.root,task,[receipt])

if __name__=='__main__':unittest.main()
