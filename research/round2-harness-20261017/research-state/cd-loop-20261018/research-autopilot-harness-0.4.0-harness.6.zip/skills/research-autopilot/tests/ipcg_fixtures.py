"""Hand-derived synthetic observations; no real scientific finding is asserted."""
import copy
from fixtures import env, sample_artifacts, write


def parent_card(problem_id="problem-1"):
    return env("parent-problem-card", problem_id=problem_id,
        contribution_type="natural_failure",
        natural_failure="Useful memories conflict during real task execution",
        population_id="natural-failed-agent-episodes", population="Eligible failed multi-agent episodes",
        prevalence="Count affected episodes among all eligible failed episodes",
        consequence={"endpoint":"task_success_loss", "description":"Loss in final task success"},
        strong_simple_alternative="general constraint solver",
        simple_alternatives=["general constraint solver"],
        benchmark_contract={"benchmark_id":"engineering-contract-fixture","version":"fixture-v1",
            "task":"Complete multi-agent tasks","primary_metric":"accuracy",
            "evaluation_split":"main","resource_constraints":{"seconds":120},
            "relevance_to_natural_failure":"The same task population and final task endpoint",
            "source_evidence_refs":[]},
        falsifiable_prediction="Resolving this conflict recovers task success beyond the simple solver",
        gate_0_thresholds={"min_cases":20,"min_affected":3,"min_prevalence":0.1,
            "min_mean_loss":0.05,"min_unresolved_fraction":0.2})


def freeze_parent(f, card=None):
    card=copy.deepcopy(card or parent_card())
    card["benchmark_contract"]["source_evidence_refs"]=[f.source]
    r=write(f.root,"problems/"+card["problem_id"]+".json",card)
    f.transition("freeze_parent_problem",{"parent_problem_ref":r})
    return r


def census(f, pref, affected=6, sampling_kind="natural_failures", outcome="PASS", duplicate=False):
    card=__import__("json").loads((f.root/pref["path"]).read_text())
    rows=[]
    for i in range(20):
        row={"case_id":"episode-"+str(i),"population_id":card["population_id"],
            "natural_failure":card["natural_failure"],"endpoint":card["consequence"]["endpoint"],
            "strong_simple_alternative":card["strong_simple_alternative"],
            "natural":sampling_kind=="natural_failures","failed_episode":True,
            "affected":i<affected,"downstream_loss":0.2 if i<affected else 0.0,
            "alternative_solves":False}
        source=write(f.root,"evidence/episodes/"+str(i)+".json",row)
        rows.append({**row,"source_ref":source})
    if duplicate:rows[-1]=copy.deepcopy(rows[0])
    b=card["benchmark_contract"]
    raw=write(f.root,"evidence/census-"+str(f.counter)+".json",{"sampling_kind":sampling_kind,"cases":rows,
        "benchmark_id":b["benchmark_id"],"benchmark_version":b["version"],
        "evaluation_split":b["evaluation_split"],"primary_metric":b["primary_metric"]})
    report=env("natural-gate-0",census_id="census-"+str(f.counter),parent_problem_ref=pref,
        observations_ref=raw,outcome=outcome)
    return write(f.root,"audits/gate0-"+str(f.counter)+".json",report)


def ready_problem(f):
    pref=freeze_parent(f)
    gref=census(f,pref)
    f.transition("record_natural_gate_0",{"natural_gate_0_ref":gref})
    return pref,gref


def candidate(f,id="c1",parent=None):
    from fixtures import C
    idea=copy.deepcopy(sample_artifacts()["idea-atom"])
    idea.update(candidate_id=id,source_evidence_refs=[f.source],parent_problem_ref=C.project(f.root)[0]["parent_problem_ref"])
    idea["necessity_case"]["baseline_evidence_refs"]=[f.source]
    if parent:idea["parent_candidate_id"]=parent
    return write(f.root,"ideas/"+id+".json",idea)


def importance(f,outcome="CONCURRENT",work_refs=None,exclusion=None,scope_change=False,collision_ref=None):
    from fixtures import C
    s=C.project(f.root)[0]
    import json
    p=json.loads((f.root/s["parent_problem_ref"]["path"]).read_text())
    retained={"natural_failure":p["natural_failure"],"population_id":p["population_id"],
        "endpoint":p["consequence"]["endpoint"],"strong_simple_alternative":p["strong_simple_alternative"],
        "falsifiable_prediction":p["falsifiable_prediction"]}
    if scope_change:retained["population_id"]="hand-constructed-triples"
    d=env("importance-decision",decision_id="ipcg-"+str(f.counter),outcome=outcome,
        parent_problem_ref=s["parent_problem_ref"],natural_gate_0_ref=s["natural_gate_0_ref"],
        retained_problem=retained,reason="Synthetic packet retains the original natural task failure and consequence",
        functional_collision_work_refs=work_refs or [],exclusion_basis=exclusion or [],evidence_refs=[f.source])
    if s.get("candidate_ref"):d["candidate_ref"]=s["candidate_ref"]
    if collision_ref:d["collision_ref"]=collision_ref
    return write(f.root,"audits/"+d["decision_id"]+".json",d)


def functional_work(f,id):
    work=copy.deepcopy(sample_artifacts()["work-record"])
    work.update(work_id="doi:10.1/"+id,evidence_refs=[f.source])
    return write(f.root,"evidence/works/"+id+".json",work)
