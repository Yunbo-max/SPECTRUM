# Mathematical and empirical inquiry

Develop two mutually explanatory accounts of the same research question.
Observations identify what needs explaining; derivations identify what should
be observed. Either can initiate inquiry. A baseline gap, a success regime,
a surprising equivalence, a scale dependence or an invalid assumption can be
the starting point. Do not impose equal time, a fixed order or extra agents.

## Scope

Read-only mathematical and conceptual exploration can proceed without a selected
benchmark, compute allocation, delivery repository or natural failure census.
Do not apply empirical candidate-dispatch prerequisites to it or force a slate
of 10–20 methods. Keep conditional results, hypotheses and unknown evidence
explicit. The empirical investment, execution and performance-claim gates still
apply when recommending or running an empirical method. A formal contribution
follows the existing formal-obligation route.

Algebra checks, symbolic calculations and mathematical counterexamples are
legitimate tools for examining a claim. They do not create benchmark evidence,
qualify a scorer or establish task effectiveness. Missing experiments do not
invalidate a correct derivation; unexplained observations do not require
invented mathematics. Simple baselines test necessity and competing explanations;
they are not the sole source of research questions.

## Integrated mathematical procedure

For every proposed research idea and substantive revision, read the built-in
[mathematical discovery procedure](math-analysis.md). This applies to every H01
route, all I/M/R-generated candidates and every candidate in a batch. Use the
[conditional operation graph](math-operation-graph.md),
[derivation paths](math-derivation-paths.md), [paper atlas](math-paper-atlas.md)
and [discovery card](math-handoff.md) within the current H01/H03/M02 record.
These are internal parts of research-autopilot, with no separate skill dependency
or invocation. Resolve missing evidence within the same research workflow.

The agent performs this analysis; it is not user homework or a promised future
step. Every candidate needs an actual relevant mathematical basis. Shared valid
derivations can support several candidates, but each candidate must explain its
own construction and prediction. No theorem is required when an identity,
controlled approximation, counterexample or conditional derivation is the right
result. Do not fabricate mathematics to turn an unexplained observation into an
apparently completed idea. Follow this integrated procedure:

1. State the unresolved question and available observations, including successful
   regimes. Distinguish measured evidence from reports and conjectures.
2. Separate the objective, sampling distribution, estimator/gradient and actual
   update. Record support, parameterization, information access and assumptions.
3. Choose relevant mathematical operations and perform them: scaling and
   nondimensionalization; inequality bounds and tightness; change of variables;
   decomposition and conditioning; variational/dual reasoning; local expansions;
   spectrum and geometry; dynamics; limits and counterexamples.
   Compose them only when each output supplies the next input and its condition
   is established or explicitly conditional. Keep approximation errors and
   assumptions; branch or backtrack when an obligation fails. Do not impose a
   fixed path or exhaustive checklist.
4. State what the derivation preserves, changes or neglects, and predict a
   dependence, invariant, sign, order or regime boundary that separates competing
   explanations. Equations must affect the research decision.
5. Let observations test those predictions and revise assumptions or the account.
   Do not retrofit every result to protect the preferred mechanism.
6. Return the linked record: question/evidence, formal object, consequential
   derivation, competing explanation, discriminating prediction, falsifier,
   next decision and unresolved obligations. A decision can be a construction,
   measurement, boundary result, literature check or no new method.
   A method candidate also gives an executable rule/algorithm and identifies
   changes to objective, measure, estimator, representation or computation.

Scale changes deserve particular care: a global positive loss multiplier,
sample-dependent weighting and a coordinate transformation have different
consequences. Bounds require equality/tightness conditions and scale dependence.
Objective equivalence does not establish optimizer equivalence; dense token
feedback does not by itself settle temporal credit assignment.

Methods may be new objectives, representations, distributions, estimators,
constraints, solvers or multi-stage algorithms. A failed benchmark is not a
universal starting requirement. Minimal intervention means a decisive comparison
with unnecessary confounding removed; it does not restrict method complexity or
justify insufficient samples, repetitions or evaluation coverage. Baselines test
necessity and competing explanations after or alongside construction. Revisit
the affected mathematics after material successes, null results or failures.

The same research workflow retains project state, novelty review and empirical
gates. Reuse its idea records and evidence. Completing a mathematical derivation
does not approve an experiment or guarantee a publication. The internal operation
IDs are local to the mathematical graph; write `math:A01`, etc.
when mixing them with research-autopilot node IDs. They add no project state,
gate or edge to the existing 84-node research map.
