# Operational incident reporting in Chat

Read at every observed operational anomaly and when preparing an already
authorized background invocation. The owner requires failures to be reported,
including when CPU or Python cannot run. Reporting is a host responsibility
independent of the experiment process. The optional helper records an outbox;
it does not send a message, authenticate receipts or install a monitor.

## Report while the host is still available

1. Emit a concise user-facing incident report immediately upon observing a new
   failure. In an interactive invocation use the live response channel; in an
   actual scheduled/background invocation include it prominently in that task's
   result. Do not wait for retries, a batch report, Python recovery or checkpoint
   export. A successful retry does not erase the original incident.
2. Retain the report and sanitized source evidence in the project records. When
   local CPU/filesystem is unavailable, use an available authorized artifact or
   repository connector directly, then read back the stored content. If no save
   path works, include the complete report in the visible response and state
   `persistence_unavailable`; do not claim an outbox was durably saved.
3. Use the current supported host reporting/notification channel within the
   user's authorization. Record the actual channel, destination, operation and
   receipt when observable. Keep external notification delivery distinct from
   the visible task result, persistent record, and research execution state.
   Never report an email, push or notification as sent from an outbox write.
4. Continue eligible independent work or bounded repair within existing scope.
   Report material worsening, failed recovery, a changed next action and verified
   recovery. Before yielding, state unresolved incidents and unsent reports.

The report contains factual values or explicit `unknown`/`unavailable`:

| Field | Required meaning |
|---|---|
| Identity | Project, incident/version when available, task/attempt and actual job or child identity |
| Observation | Observed timestamp with timezone, observing host/tool, first or repeated occurrence |
| Failure | Category, sanitized original error excerpt and evidence locator; distinguish observation from suspected cause |
| Impact | Which goal obligation/action is blocked; which independent work remains feasible |
| Execution | Actual last-observed process state and timestamp: running, queued, terminal or unknown |
| Recovery state | Last verified checkpoint/revision and persistence status; missing bytes or uncertain operations |
| Response | What repair/reconciliation has actually been attempted, next action and its bound |
| User action | Exact required intervention, or explicitly none; no repeated approval for already authorized repair |
| Delivery | Actual reporting channel, acknowledgement if available, and pending/unknown/failed/unavailable external delivery |

Remove credentials, tokens, signed URLs, private unrelated content and sensitive
environment values from excerpts. Keep the useful error type and bounded relevant
context. Sanitization must happen before storage or notification; the helper is
not a secrets detector. Do not infer that a CPU failure means the process stopped,
or that a missing heartbeat proves failure. Observe/query the original operation
when possible; otherwise retain `last_run_unknown` and reconcile before retry.

## What requires a report

Report every newly observed operational fault, even if another path can continue:

- CPU/Python/kernel or execution tools unavailable; process launch rejected;
  memory, disk, quota, permission or resource access failures.
- Required skill or pinned procedure unavailable, version mismatch or stale
  scheduled contract; explicitly name any authorized source fallback adopted.
- Missing/invalid configuration, dependency, source, scorer or required input.
- Network, asset acquisition, remote operation or provider/API failure.
- Timeout, crash, nonzero exit, numerical invalidity, incomplete output or stale
  output incorrectly offered as current evidence; exit zero cannot dismiss these.
- Child/session dispatch uncertainty, lost acknowledgement, unconfirmed process
  termination, reconciliation failure or stale required observations.
- Checkpoint/artifact save or readback failure, conflicting heads, inaccessible
  historical evidence, or incident/report delivery failure.
- Repair failure, recurrence after verified recovery, repeated bounded retries,
  and unexplained stagnation needing a strategy review.

A valid negative hypothesis result, ordinary queue wait and an intentional user
pause are normal states, not operational errors. Resource/budget exhaustion still
requires an explicit status report with the exhausted limit, remaining work and
resumption conditions. Do not label a paused project as failed or resumed. If an
actual exception happens while observing a paused project, report that exception
without starting research. An expected missing optional capability may be a
warning, but must not be concealed when it changes the promised execution path.

## Deduplication and delivery evidence

Group repeated observations of the same underlying fault using a stable project,
source and affected scope. Retain first/last observation and occurrence count.
Identical repeats can share an incident version; a material change in severity,
impact, evidence, next action, escalation or recovery needs an updated version.
Deduplication suppresses repetitive copies, never the first report or a material
change. A recovered incident that recurs is reported as a recurrence.

Separate incident lifecycle from report delivery:

- `pending`: recorded, no confirmed delivery for this version.
- `unknown`: an attempted send has no reliable acknowledgement; reconcile the
  original provider operation before resending when identity is available.
- `failed`: an observed delivery error; retain that error and a bounded next step.
- `unavailable`: no authorized usable channel; say so in the live result.
- `delivered`: a real receipt binds this exact incident version to the actual
  channel/destination and execution evidence. This proves only the receipt's
  stated scope, not that the user opened or read the report.

A later version needs its own delivery state. Recovery of the research operation
does not deliver its warning or recovery report. Delivery failure must not cause
recursive alert generation; attach it to the same pending report and use any
independent authorized host output. Never fabricate an acknowledgement to clear
an outbox, and never silently drop the outbox when resuming.

## Optional local outbox

When Python and the project filesystem work, use `scripts/chat_alerts.py`:

```python
incident = report(root, category=category, source=source, scope=scope,
                  summary=summary, next_action=next_action,
                  evidence_refs=evidence_refs, severity="error",
                  observation_id=None)
pending_reports = pending(root)
```

`safe_report` has the same reporting arguments and preserves the original failure
when recording itself fails: its result has `stored:false` and it emits an unsaved
notice on stderr. Neither return value nor stderr establishes user notification;
the coordinator still follows the live-host reporting path above. Outbox lock
acquisition is bounded to one second; contention raises a recording failure
instead of hanging. `safe_report` turns this into the same visible unsaved
fallback, preserves the original error and makes no delivery claim. `read(root,
incident_id=None)` inspects saved incidents. `resolve(root,incident_id,
summary=summary,next_action=next_action,evidence_refs=evidence_refs)` records
recovery with actual nonempty evidence and leaves that version pending delivery.
The helper identity includes category, source, scope and summary: keep the concise
root-fault summary stable, and put evolving detail in evidence/next action. A
different fault summary creates a separate incident rather than overwriting one.

Both `report` and `safe_report` accept optional `observation_id=None`. Omit it
for a genuinely fresh observed error: a new occurrence after verified recovery
creates a pending incident version even when it has no evidence refs. When
re-reading an immutable command receipt or other already observed record, always
provide the same stable observation ID derived from that record's identity/digest.
The same ID and content preserve resolved state instead of falsely reopening an
old failure. Do not reuse an old observation ID for a fresh error. Controller
errors use fresh observations; runner receipt observations use stable digests.

Use `delivery(root,id,version,status,receipt_ref=None,detail=None)` after the
actual delivery attempt. Supported recorded outcomes are `delivered`, `failed`,
`unknown` and `unavailable`. For `delivered`, the hashed JSON receipt has
`kind=chat-alert-delivery`, `status=delivered`, the exact `incident_id` and `version`, actual `channel`,
`destination`, `provider_operation_id`, and `execution_ref` to real delivery
evidence. This validates record consistency; the host must actually perform and
inspect that operation. Do not invent a provider ID when it exposes none; keep
the externally unacknowledged delivery explicit instead.
Other delivery outcomes require factual `detail`; prior attempts remain in history.

Keep outbox files in the project evidence and persist/read them back through the
authorized destination. A locally coherent outbox is not a durable external copy.
Do not require this Python module as a gate for reporting when CPU is unavailable.
See [control records](chat-control-records.md) for checkpoint and runner integration.

## Background observation and limits

An already configured, authorized host scheduler can run a separate read-only
observation even when the experiment worker has failed. It reads the authoritative
checkpoint, last real process observations and pending incident versions using
available host tools, then reports missing/stale/unknown state honestly. Prefer a
reporting path outside the failed CPU process; a watcher inside that same failed
process provides no such independence. Record the actual schedule identity,
enabled state, last invocation and available delivery channel before claiming
background monitoring is active.

A skill, outbox, or scheduler prompt does not install this observer or guarantee
host wakeup, a complete failure log, immediate detection, email or push delivery.
When the host/model/scheduler itself cannot invoke, no agent can report from that
absent invocation. Describe this coverage gap when relevant; on the next actual
invocation reconcile and report the interruption instead of inventing continuous
monitoring. A missing observation proves uncertainty, not current activity.

Preserve existing disabled schedules and explicit user pauses. Updating reporting
instructions does not enable a schedule or authorize renewed research. An already
authorized observation-only task may inspect/report a paused project, but it must
not dispatch experiments, create a successor, clear pause, change budget, or treat
an incident as permission to acquire new infrastructure. Do not create duplicate
watchers or services merely because an execution capability failed.
