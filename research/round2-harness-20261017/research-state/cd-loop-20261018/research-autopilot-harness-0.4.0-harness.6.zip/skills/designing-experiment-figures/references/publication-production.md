# Reproducible publication plot production

Contents: [Route](#choose-and-retain-the-production-route),
[inputs and command](#input-and-execution-contract),
[inspection and handoff](#final-size-inspection-and-handoff).

## Choose and retain the production route

Use the selected scientific narrative and evidence inventory from this skill.
For grouped bars, ordered curves, scatter comparisons and complete heatmaps,
use the bundled local Matplotlib renderer when its contract fits. For paired
effects, distributions, fitted models, qualitative cases or other unsupported
data, write a project script with the same provenance and honesty requirements;
do not reshape evidence merely to use this renderer. Draw.io remains an optional
assembly layer. This production backend adds no lower-rigor experiment mode.

This reference independently implements general scientific plotting practices
after reviewing [figures4papers](https://github.com/ChenLiu-1996/figures4papers/tree/f0bb7559abe90f5e1828797126d4d133c1bd47d7).
Its actual `figure_*` scripts informed the comparison; its API reference describes
recommended interfaces, not a shipped shared helper module. Upstream is CC BY-NC
4.0. No upstream source, palette, image, data or text is bundled here. Do not
copy an upstream artifact without retaining its applicable license/attribution.

## Input and execution contract

Retain the exact source CSV, a selected-design JSON specification, source/evidence
references and the native result receipts that support the values. CSV columns:
`panel,series,x,y,value,lower,upper`. Supply already justified aggregates; the
renderer performs no aggregation, uncertainty estimation, significance testing,
benchmark scoring or normalization. Never reconstruct raw samples from means.

| Chart | CSV interpretation | Completeness |
|---|---|---|
| `bar` | `x` category, `series` method, `value` height; `y` empty | Every category × series cell present; zero baseline |
| `line` | Numeric `x`, `value` vertical coordinate; `y` empty | One supplied observation per series/x; ordered by numeric x |
| `scatter` | Numeric `x`, `value` vertical coordinate; `y` empty | Distinct series/x aggregates; raw repeated-x clouds need a custom script |
| `heatmap` | Category `x` and `y`, `value` cell; one `series` | Complete matrix; no invented or interpolated cells |

Use empty `lower,upper` only when the specification says `not reported` or
`not applicable`. Otherwise supply both interval endpoints for every row and
state whether they mean SD, SE, a particular CI, range or another reported quantity.
The renderer draws the supplied endpoints; it does not establish their validity.
An uncertainty gap stays a gap and may prevent a scientific claim.

Specification fields:

```json
{
  "source_status": "measured",
  "source_sha256": "ACTUAL_SHA256_OF_CSV_BYTES",
  "evidence_refs": ["ACTUAL_RETAINED_RESULT_RECEIPT"],
  "width_inches": 6.8,
  "height_inches": 3.2,
  "panels": [{
    "id": "comparison", "kind": "bar", "title": "SOURCE_SUPPORTED_TITLE",
    "xlabel": "ACTUAL_SETTING", "ylabel": "ACTUAL_METRIC_AND_UNITS",
    "metric": "ACTUAL_NATIVE_METRIC", "units": "ACTUAL_UNITS",
    "better": "higher", "aggregation": "ACTUAL_REPORTED_AGGREGATION",
    "sample_unit": "ACTUAL_INDEPENDENT_UNIT", "sample_count": 1,
    "uncertainty": "not reported", "selection_rule": "ACTUAL_SELECTION_RULE"
  }]
}
```

Replace every placeholder and the example count; this is a schema illustration,
not a measured result. `better` is `higher`, `lower` or `neither`. Optional numeric
`ylim` must include all values/intervals and, for bars, zero. For a close comparison
requiring a nonzero origin, use a clearly labeled point/interval plot. Preserve
adverse results and label scope; no clipping, favorable category removal or manual
quantitative geometry edits. Keep method identity stable across figures with the
same optional `series_order` list, including registered methods absent from a
particular figure. The receipt records actual visual identities; the default
uses first occurrence order. More than seven registered series needs a custom style.

```bash
python3 "$FIGURE_SKILL/scripts/publication_plot.py" \
  --data "$PROJECT_DIR/results/figure-data.csv" \
  --spec "$PROJECT_DIR/results/figure-spec.json" \
  --outdir "$PROJECT_DIR/figures/figure-1-v1"
```

Use actual paths and a new version directory. Runtime dependencies are Matplotlib
and NumPy; use the project's installed/locked environment or record the missing
dependency. Do not install packages or connect services just to match an example.
This command runs the local Agg backend and preserves SVG live text, embedded PDF
fonts and a 300-dpi PNG. It does not require LaTeX, an account or an online renderer.

## Final-size inspection and handoff

Keep the generated `source-data.csv`, `figure-spec.json`, `publication_plot.py`,
SVG/PDF/PNG, `caption-disclosures.md` and `figure-render.json`. The receipt records
exact input/output hashes, runtime versions, supplied values/intervals and method
identities. `source_status` is a declared label; a hash/reference cannot certify it.
Engineering fixture renders stay `engineering_fixture` and never become results.

Open the PNG/PDF/SVG and inspect at the target paper width. Verify text, panel
hierarchy, ticks, units, color plus marker/hatch distinction, grayscale readability,
legend obstruction, intervals, clipping and consistency with the manuscript.
Use actual venue dimensions and typography; do not copy an enormous demo canvas
and shrink its text into illegibility. Use a separate legend region or custom
layout when needed, and avoid decorative radar or dual-axis encodings without
an evidence-based reason. The bundled renderer's automatic layout is a starting
point, not proof that a dense figure is readable.

After inspection retain a separate review note with the files actually opened,
final width, observed fixes and unresolved issues. The renderer records export
success but deliberately reports visual and scientific verification as not
performed. Compare against native result evidence, statistical definitions and
frozen claim scope before manuscript acceptance. Carry changed evidence into the
figure, caption, manuscript and website rather than polishing a stale plot.
