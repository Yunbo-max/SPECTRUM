"""Real durable admission state; tiny fake capacity observations, no RAM filling."""
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import resource_queue as Q


class ResourceQueueTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.resources = dict(queue_dir=str(self.root / "queue"), cpu_slots=1,
                              peak_bytes=100, margin_bytes=20, min_disk_bytes=50)
        self.capacity = dict(domain="host-a", cpu_slots=1, memory_total=1000,
                             memory_available=1000, disk_available=1000, disk_total=1000, disk_domain=1)
        snapshot_patch = patch.object(Q, "snapshot", side_effect=lambda path: {**self.capacity, "observed_at": time.time()})
        self.real_snapshot = snapshot_patch.get_original()[0]
        snapshot_patch.start(); self.addCleanup(snapshot_patch.stop)
        self.patch = patch.object(Q, "RECHECK_SECONDS", 0)
        self.patch.start(); self.addCleanup(self.patch.stop)

    def poll(self, name, resources=None, **kwargs):
        return Q.poll(self.root, name, resources or self.resources, "contract-" + name,
                      snapshot_fn=lambda: {**self.capacity, "observed_at": time.time()}, **kwargs)

    def test_fifo_and_verified_release(self):
        a = self.poll("a")
        self.assertEqual(a["status"], "admitted")
        self.assertEqual(self.poll("b")["reason"], "waiting_for_cpu_slots")
        self.assertEqual(self.poll("c")["reason"], "waiting_for_turn")
        Q.transition(self.resources, a["key"], "dispatched", "fixture dispatch")
        Q.transition(self.resources, a["key"], "settled", "fixture terminal cleanup")
        self.assertEqual(self.poll("c")["reason"], "waiting_for_turn")
        self.assertEqual(self.poll("b")["status"], "admitted")

    def test_pressure_rechecks_reuse_ticket_and_sequence(self):
        self.capacity["memory_available"] = 30
        first = self.poll("a")
        for _ in range(5):
            current = self.poll("a")
            self.assertEqual((current["key"], current["sequence"]), (first["key"], first["sequence"]))
            self.assertEqual(current["reason"], "waiting_for_memory")
        self.capacity["memory_available"] = 1000
        self.assertEqual(self.poll("a")["status"], "admitted")
        self.assertEqual(len(json.loads((self.root / "queue/queue.json").read_text())["tickets"]), 1)

    def test_admission_survives_restart_without_new_grant(self):
        first = self.poll("a")
        self.assertEqual(self.poll("a"), first)
        Q.transition(self.resources, first["key"], "dispatched", "fixture dispatch")
        self.assertEqual(self.poll("a")["status"], "dispatched")
        self.assertEqual(self.poll("b")["status"], "queued")

    def test_unknown_running_never_expires_at_deadline(self):
        deadline = time.time() + 100
        first = self.poll("a", deadline_epoch=deadline)
        Q.transition(self.resources, first["key"], "dispatched", "fixture dispatch")
        with patch.object(Q.time, "time", return_value=deadline + 100):
            self.assertEqual(self.poll("a", deadline_epoch=deadline)["status"], "dispatched")
            self.assertEqual(self.poll("b")["status"], "queued")
        with self.assertRaises(ValueError):
            Q.transition(self.resources, first["key"], "cancelled", "not cleanup proof")

    def test_cancel_or_deadline_unblocks_only_waiting_tickets(self):
        self.capacity["memory_available"] = 0
        a = self.poll("a")
        self.poll("b", deadline_epoch=time.time() - 1)
        Q.transition(self.resources, a["key"], "cancelled", "explicit user stop")
        self.capacity["memory_available"] = 1000
        self.assertEqual(self.poll("c")["status"], "admitted")

    def test_impossible_request_does_not_starve_later_work(self):
        a = self.poll("a", {**self.resources, "peak_bytes": 2000})
        self.assertEqual(a["status"], "needs_replan")
        self.assertEqual(self.poll("b")["status"], "admitted")

    def test_disk_and_unknown_capacity_wait(self):
        self.capacity["disk_available"] = 1
        self.assertEqual(self.poll("a")["reason"], "waiting_for_disk")
        self.capacity["memory_available"] = None
        self.assertEqual(self.poll("a")["reason"], "resource_observation_unknown")

    def test_wrong_domain_and_changed_contract_never_admit(self):
        a = self.poll("a")
        with self.assertRaises(ValueError):
            self.poll("a", {**self.resources, "peak_bytes": 1})
        self.capacity["domain"] = "another-host"
        self.assertEqual(self.poll("b")["status"], "wrong_domain")

    def test_admitted_grant_rechecks_host_and_original_deadline(self):
        deadline = time.time() + 100
        a = self.poll("a", deadline_epoch=deadline)
        self.capacity["domain"] = "another-host"
        with self.assertRaisesRegex(ValueError, "another host"):
            self.poll("a", deadline_epoch=deadline)
        self.capacity["domain"] = "host-a"
        with patch.object(Q.time, "time", return_value=deadline + 1):
            self.assertEqual(self.poll("a", deadline_epoch=deadline)["status"], "expired")
        Q.transition(self.resources, a["key"], "settled", "verified no dispatch after expiry")
        self.assertEqual(self.poll("b")["status"], "admitted")

    def test_wrong_host_ticket_does_not_block_valid_waiter(self):
        a = self.poll("a")
        self.capacity["domain"] = "wrong"
        self.assertEqual(self.poll("wrong")["status"], "wrong_domain")
        self.capacity["domain"] = "host-a"
        Q.transition(self.resources, a["key"], "settled", "no command dispatched")
        self.assertEqual(self.poll("b")["status"], "admitted")

    def test_unknown_applicable_cpu_quota_waits_but_cpuset_only_does_not(self):
        cpu = {"cgroup": {"hierarchy_complete": True, "observations": [
            {"path": str(self.root), "quota_state": "unknown", "quota_applicable": True}]}, "capacity_upper_bound": 16}
        memory = {"cgroup_observations": [{"path": str(self.root), "limit_state": "observed", "current_bytes": 100}],
                  "effective_total_bytes_upper_bound": 1000, "observed_headroom_bytes": 900}
        with patch.object(Q.host_resources, "collect_cpu_memory", return_value=(cpu, memory, [])):
            self.assertIsNone(self.real_snapshot(self.root)["cpu_slots"])
            cpu["cgroup"]["observations"][0]["quota_applicable"] = False
            self.assertEqual(self.real_snapshot(self.root)["cpu_slots"], 16)

    def test_dispatch_replay_rechecks_host_and_deadline(self):
        deadline = time.time() + 100
        a = self.poll("a", deadline_epoch=deadline)
        Q.transition(self.resources, a["key"], "dispatched", "first dispatch intent")
        self.capacity["domain"] = "another-host"
        with self.assertRaisesRegex(ValueError, "domain changed"):
            Q.transition(self.resources, a["key"], "dispatched", "resume same dispatch intent")
        self.capacity["domain"] = "host-a"
        with patch.object(Q.time, "time", return_value=deadline + 1):
            with self.assertRaisesRegex(ValueError, "deadline"):
                Q.transition(self.resources, a["key"], "dispatched", "expired replay")

    def test_quarantined_unlaunched_ticket_can_be_cancelled(self):
        self.poll("a")
        self.capacity["domain"] = "another-host"
        wrong = self.poll("wrong")
        self.assertEqual(wrong["status"], "wrong_domain")
        self.assertEqual(Q.transition(self.resources, wrong["key"], "cancelled", "explicit stop")["status"], "cancelled")

    def test_failed_checkpoint_prevents_returning_grant(self):
        with patch.object(Q.O, "_atomic_json", side_effect=OSError(28, "No space")):
            with self.assertRaises(OSError):
                self.poll("a")
        self.assertFalse((self.root / "queue/queue.json").exists())

    def test_simultaneous_callers_cannot_overbook(self):
        with ThreadPoolExecutor(max_workers=2) as pool:
            rows = list(pool.map(self.poll, ["a", "b"]))
        self.assertEqual(sum(r["status"] == "admitted" for r in rows), 1)

    def test_snapshot_uses_cgroup_headroom_and_unknown_is_not_free(self):
        cpu = {"cgroup": {"hierarchy_complete": True, "observations": [{"path": str(self.root), "quota_state": "observed"}]}, "capacity_upper_bound": 2}
        memory = {"cgroup_observations": [{"path": str(self.root), "limit_state": "observed", "current_bytes": 900}],
                  "effective_total_bytes_upper_bound": 1000, "observed_headroom_bytes": 100}
        with patch.object(Q.host_resources, "collect_cpu_memory", return_value=(cpu, memory, [])):
            self.assertEqual(self.real_snapshot(self.root)["memory_available"], 100)
            memory["cgroup_observations"][0]["limit_state"] = "unknown"
            self.assertIsNone(self.real_snapshot(self.root)["memory_available"])


if __name__ == "__main__":
    unittest.main()
