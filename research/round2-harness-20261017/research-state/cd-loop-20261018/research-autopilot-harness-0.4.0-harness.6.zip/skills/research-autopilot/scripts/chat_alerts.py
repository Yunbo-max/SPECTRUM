#!/usr/bin/env python3
"""Incident outbox; never sends notifications or changes research/budget state.

An adapter must perform an authorized delivery and preserve the real receipt.
Receipt validation binds bytes and fields, not provider authenticity. This local
ledger needs the host's durable save mechanism just like other project files.
"""
import argparse
from contextlib import contextmanager
import copy
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import time


STATUSES = {'pending', 'delivered', 'failed', 'unknown', 'unavailable'}
LOCK_TIMEOUT_SECONDS = 1.0


def _now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def redact(value):
    """Remove common credential forms; do not pass arbitrary logs as summaries."""
    text = str(value)
    keys = r'(?:api[_-]?key|access[_-]?token|refresh[_-]?token|token|password|passwd|secret|authorization|(?:aws[_-]?)?secret[_-]?access[_-]?key|client[_-]?secret|cookie)'
    text = re.sub(r'(?i)\b(bearer|basic)\s+[A-Za-z0-9._~+/=-]+', r'\1 [REDACTED]', text)
    text = re.sub(r'(?i)(\b' + keys + r'\b[\"\x27]?\s*[:=]\s*)([\"\x27])(.*?)\2', r'\1\2[REDACTED]\2', text)
    text = re.sub(r'(?i)(\b' + keys + r'\b[\s\"\x27]*[:=][\s\"\x27]*)([^\s,;\"\x27}&]+)', r'\1[REDACTED]', text)
    text = re.sub(r'\b(?:sk-[A-Za-z0-9_-]{8,}|gh[pousr]_[A-Za-z0-9_]{8,}|github_pat_[A-Za-z0-9_]{8,}|hf_[A-Za-z0-9]{8,}|AKIA[A-Z0-9]{16})\b', '[REDACTED]', text)
    text = re.sub(r'(https?://)[^/@\s]+:[^/@\s]+@', r'\1[REDACTED]@', text)
    # Signed storage URLs can carry credentials under arbitrary query keys.
    text = re.sub(r'(https?://[^?\s\"\x27<>]+)\?[^\s\"\x27<>]*', r'\1?[REDACTED]', text)
    return text[:2000]


def _text(value, name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(name + ' must be nonempty text')
    return redact(value.strip())


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def _ref(root, reference, *, as_json=False):
    if not isinstance(reference, dict) or set(reference) != {'path', 'sha256'}:
        raise ValueError('evidence requires path and sha256')
    root = Path(root).resolve()
    path = (root / reference['path']).resolve()
    if not path.is_relative_to(root) or path == root:
        raise ValueError('evidence path must stay in project')
    if path.stat().st_size > 16 * 1024 * 1024:
        raise ValueError('evidence exceeds 16 MiB; reference a compact observation')
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != reference['sha256']:
        raise ValueError('evidence hash mismatch')
    return json.loads(data) if as_json else copy.deepcopy(reference)


def _refs(root, references):
    if not isinstance(references, list) or len(references) > 64:
        raise ValueError('evidence_refs must be a list of at most 64 references')
    return [_ref(root, value) for value in references]


def _directory(root):
    root = Path(root).resolve()
    folder = root / 'runs/chat-alerts'
    if not folder.resolve().is_relative_to(root):
        raise ValueError('outbox directory must stay in project')
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def _load(path):
    if not path.exists():
        return {'schema_version': 1, 'incidents': {}}
    if path.is_symlink():
        raise ValueError('outbox must not be a symlink')
    state = json.loads(path.read_text(encoding='utf-8'))
    if state.get('schema_version') != 1 or not isinstance(state.get('incidents'), dict):
        raise ValueError('invalid incident outbox')
    return state


@contextmanager
def _edit(root):
    folder = _directory(root)
    fd = os.open(folder / 'outbox.lock', os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'a') as lock:
        deadline = time.monotonic() + LOCK_TIMEOUT_SECONDS
        while True:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError('incident outbox lock unavailable; report in the active host response')
                time.sleep(min(0.01, remaining))
        path = folder / 'outbox.json'
        state = _load(path)
        yield state
        fd, name = tempfile.mkstemp(prefix='.outbox-', dir=folder)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                json.dump(state, handle, ensure_ascii=False, sort_keys=True, indent=2)
                handle.write('\n')
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(name, path)
            directory_fd = os.open(folder, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        finally:
            if os.path.exists(name):
                os.unlink(name)


def _new_version(incident):
    incident['history'].append({k: copy.deepcopy(v) for k, v in incident.items() if k != 'history'})
    incident['version'] += 1
    incident['notification_status'] = 'pending'
    incident['delivery'] = None
    incident['delivery_attempts'] = []


def report(root, *, category, source, scope, summary, next_action,
           evidence_refs=None, severity='error', observation_id=None):
    """Report a fresh observation; use stable observation_id only for receipt replays."""
    if severity not in {'warning', 'error', 'critical'}:
        raise ValueError('invalid incident severity')
    if observation_id is not None:
        observation_id = _text(observation_id, 'observation_id')
    identity = {k: _text(v, k) for k, v in dict(category=category, source=source, scope=scope, summary=summary).items()}
    material = dict(severity=severity, next_action=_text(next_action, 'next_action'),
                    evidence_refs=_refs(root, [] if evidence_refs is None else evidence_refs))
    incident_id = _hash(identity)[:24]
    with _edit(root) as state:
        incident = state['incidents'].get(incident_id)
        replay = (incident is not None and observation_id is not None and
                  incident.get('observation_id') == observation_id and
                  all(incident.get(k) == v for k, v in material.items()))
        if incident is None:
            incident = dict(identity, incident_id=incident_id, version=1, lifecycle='open',
                            occurrences=0, first_seen=_now(), history=[], delivery=None,
                            notification_status='pending', stored=True)
            state['incidents'][incident_id] = incident
        elif (any(incident.get(k) != v for k, v in material.items()) or
              (incident['lifecycle'] == 'resolved' and
               (observation_id is None or incident.get('observation_id') != observation_id))):
            _new_version(incident)
            incident['lifecycle'] = 'open'
            incident.pop('recovery', None)
        # Only explicitly identified old receipt reads are replay-idempotent.
        incident.update(material, observation_id=observation_id, last_seen=_now())
        if not replay:
            incident['occurrences'] += 1
        result = copy.deepcopy(incident)
    return result


def safe_report(root, **kwargs):
    """Best effort only: failures remain visible and cannot hide caller's error."""
    try:
        return report(root, **kwargs)
    except Exception as exc:
        result = {'stored': False, 'notification_status': 'unsaved',
                  'category': redact(kwargs.get('category', 'incident')),
                  'source': redact(kwargs.get('source', 'unknown')),
                  'scope': redact(kwargs.get('scope', 'unknown')),
                  'summary': redact(kwargs.get('summary', 'Incident could not be saved')),
                  'next_action': redact(kwargs.get('next_action', 'Report in the active host response')),
                  'storage_error': redact(type(exc).__name__ + ': ' + str(exc))}
        try:
            sys.stderr.write(json.dumps(result, ensure_ascii=False) + '\n')
            sys.stderr.flush()
        except Exception:
            pass
        return result


def read(root, incident_id=None):
    folder = _directory(root)
    # Atomic replace provides coherent readers; no write merely to view status.
    state = _load(folder / 'outbox.json')
    return copy.deepcopy(state['incidents'][incident_id] if incident_id else state)


def pending(root):
    """Undelivered observations, including unknown; reconcile unknown before retry."""
    return [item for item in read(root)['incidents'].values() if item['notification_status'] != 'delivered']


def delivery(root, incident_id, version, status, *, receipt_ref=None, detail=None):
    if isinstance(version, bool) or not isinstance(version, int) or version < 1:
        raise ValueError('positive integer incident version required')
    if status not in STATUSES - {'pending'}:
        raise ValueError('invalid delivery status')
    value = dict(status=status, version=version, observed_at=_now())
    if status == 'delivered':
        receipt = _ref(root, receipt_ref, as_json=True)
        if (not isinstance(receipt, dict) or receipt.get('kind') != 'chat-alert-delivery' or receipt.get('status') != 'delivered'
                or receipt.get('incident_id') != incident_id or receipt.get('version') != version):
            raise ValueError('delivery receipt must bind delivered incident and version')
        for key in ('channel', 'destination', 'provider_operation_id'):
            value[key] = _text(receipt.get(key), key)
        _ref(root, receipt.get('execution_ref'))
        value['receipt_ref'] = copy.deepcopy(receipt_ref)
    else:
        value['detail'] = _text(detail, 'delivery detail')
        if receipt_ref is not None:
            value['receipt_ref'] = _ref(root, receipt_ref)
    with _edit(root) as state:
        incident = state['incidents'][incident_id]
        if version != incident['version']:
            raise ValueError('stale incident version; reconcile current notification')
        if incident['notification_status'] == 'delivered':
            if incident['delivery'].get('receipt_ref') == receipt_ref and status == 'delivered':
                return copy.deepcopy(incident)
            raise ValueError('delivered version cannot be downgraded or delivered again')
        incident.setdefault('delivery_attempts', []).append(copy.deepcopy(value))
        incident.update(notification_status=status, delivery=value)
        result = copy.deepcopy(incident)
    return result


def resolve(root, incident_id, *, summary, next_action, evidence_refs):
    refs = _refs(root, evidence_refs)
    if not refs:
        raise ValueError('recovery requires observed evidence')
    recovery = dict(summary=_text(summary, 'recovery summary'),
                    next_action=_text(next_action, 'next_action'), evidence_refs=refs)
    with _edit(root) as state:
        incident = state['incidents'][incident_id]
        if incident['lifecycle'] != 'resolved' or incident.get('recovery') != recovery:
            _new_version(incident)
            incident.update(lifecycle='resolved', recovery=recovery, last_seen=_now())
        result = copy.deepcopy(incident)
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['report', 'pending', 'read', 'delivery', 'resolve'])
    parser.add_argument('root')
    parser.add_argument('--record', help='JSON arguments file for report/delivery/resolve')
    parser.add_argument('--incident-id')
    args = parser.parse_args(argv)
    if args.operation in {'report', 'delivery', 'resolve'}:
        if not args.record:
            parser.error('--record required')
        values = json.loads(Path(args.record).read_text(encoding='utf-8'))
        result = globals()[args.operation](args.root, **values)
    else:
        result = pending(args.root) if args.operation == 'pending' else read(args.root, args.incident_id)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


if __name__ == '__main__':
    main()
