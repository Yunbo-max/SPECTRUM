import copy
import json
import types
import unittest
from fixtures import C, ProjectFixture, canonical, digest, sample_artifacts, write
from ipcg_fixtures import candidate, census, freeze_parent, functional_work, importance, parent_card, ready_problem


class ImportanceTests(unittest.TestCase):
    def setUp(self):
        self.f=ProjectFixture();self.addCleanup(self.f.close)

    def apply(self,outcome,payload):
        try:return self.f.transition(outcome,payload)
        except C.Failure as error:self.fail("Required workflow rejected: "+error.code)

    def ready(self):
        try:return ready_problem(self.f)
        except C.Failure as error:self.fail("Required problem/Gate 0 workflow missing: "+error.code)

    def start_candidate(self):
        self.ready()
        self.apply("research_candidate",{"candidate_ref":candidate(self.f)})

    def test_candidate_cannot_start_without_frozen_parent_and_natural_gate(self):
        idea=copy.deepcopy(sample_artifacts()["idea-atom"]);idea["source_evidence_refs"]=[self.f.source]
        r=write(self.f.root,"ideas/no-parent.json",idea)
        with self.assertRaises(C.Failure):self.f.transition("research_candidate",{"candidate_ref":r})

    def test_parent_problem_cannot_be_silently_replaced(self):
        self.ready()
        changed=parent_card("problem-2");changed["population_id"]="hand-constructed-triples"
        r=write(self.f.root,"problems/changed.json",changed)
        with self.assertRaises(C.Failure):self.f.transition("freeze_parent_problem",{"parent_problem_ref":r})

    def test_natural_counts_and_downstream_loss_are_recomputed(self):
        self.ready()
        s=C.project(self.f.root)[0]
        self.assertEqual(s["natural_gate_0_outcome"],"PASS")
        self.assertEqual(s["natural_gate_0_metrics"]["cases"],20)
        self.assertAlmostEqual(s["natural_gate_0_metrics"]["prevalence"],0.3)
        self.assertAlmostEqual(s["natural_gate_0_metrics"]["mean_loss"],0.2)

    def test_constructed_existence_example_does_not_pass_natural_gate(self):
        try:p=freeze_parent(self.f)
        except C.Failure as e:self.fail(e.code)
        r=census(self.f,p,sampling_kind="constructed",outcome="INCONCLUSIVE")
        result=self.apply("record_natural_gate_0",{"natural_gate_0_ref":r})
        self.assertEqual(result["state"]["natural_gate_0_outcome"],"INCONCLUSIVE")
        with self.assertRaises(C.Failure):self.f.transition("research_candidate",{"candidate_ref":candidate(self.f)})

    def test_low_prevalence_kills_declared_problem_threshold(self):
        try:p=freeze_parent(self.f)
        except C.Failure as e:self.fail(e.code)
        r=census(self.f,p,affected=2,outcome="KILL")
        result=self.apply("record_natural_gate_0",{"natural_gate_0_ref":r})
        self.assertEqual(result["state"]["natural_gate_0_outcome"],"KILL")
        with self.assertRaises(C.Failure):self.f.transition("research_candidate",{"candidate_ref":candidate(self.f)})

    def test_duplicate_episode_cannot_inflate_natural_prevalence(self):
        try:p=freeze_parent(self.f)
        except C.Failure as e:self.fail(e.code)
        r=census(self.f,p,duplicate=True,outcome="INCONCLUSIVE")
        result=self.apply("record_natural_gate_0",{"natural_gate_0_ref":r})
        self.assertEqual(result["state"]["natural_gate_0_outcome"],"INCONCLUSIVE")

    def test_self_declared_gate0_pass_cannot_replace_raw_counts(self):
        try:p=freeze_parent(self.f)
        except C.Failure as e:self.fail(e.code)
        r=census(self.f,p,affected=2,outcome="PASS")
        with self.assertRaises(C.Failure):self.f.transition("record_natural_gate_0",{"natural_gate_0_ref":r})

    def test_same_problem_can_continue_after_importance_review(self):
        self.start_candidate()
        r=importance(self.f)
        result=self.apply("importance_decision",{"importance_decision_ref":r})
        self.assertEqual(result["state"]["importance_outcome"],"CONCURRENT")
        self.assertEqual(result["state"]["current_route"],"develop_candidate")

    def test_smaller_population_cannot_borrow_original_importance(self):
        self.start_candidate()
        r=importance(self.f,scope_change=True)
        with self.assertRaises(C.Failure):self.f.transition("importance_decision",{"importance_decision_ref":r})

    def test_exclusion_label_alone_cannot_authorize_concurrent(self):
        self.start_candidate()
        r=importance(self.f,exclusion=["higher_order_only"])
        with self.assertRaises(C.Failure):self.f.transition("importance_decision",{"importance_decision_ref":r})

    def test_two_distinct_functional_collisions_restart_exploration_even_with_new_sources(self):
        self.start_candidate()
        for id in ("problem-covered","mechanism-covered"):
            r=importance(self.f,work_refs=[functional_work(self.f,id)])
            result=self.apply("importance_decision",{"importance_decision_ref":r})
        s=result["state"]
        self.assertEqual(s["current_route"],"explore_problem")
        self.assertEqual(s["lifecycle_phase"],"landscape")
        self.assertEqual(s["entry_origin"],"M")
        self.assertEqual(s["importance_outcome"],"REROUTE")
        self.assertNotIn("candidate_ref",s)
        self.assertNotIn("parent_problem_ref",s)
        with self.assertRaises(C.Failure):self.f.transition("research_candidate",{"candidate_ref":write(self.f.root,"ideas/c3.json",sample_artifacts()["idea-atom"])})

    def test_same_work_cannot_count_as_two_functional_collisions(self):
        self.start_candidate();w=functional_work(self.f,"one-work")
        for _ in range(2):
            r=importance(self.f,work_refs=[w])
            result=self.apply("importance_decision",{"importance_decision_ref":r})
        self.assertEqual(result["state"]["current_route"],"develop_candidate")
        self.assertEqual(len(result["state"]["major_collision_work_ids"]),1)

    def test_reroute_archives_parent_and_requires_fresh_card(self):
        self.start_candidate();old=C.project(self.f.root)[0]["parent_problem_ref"]
        r=importance(self.f,outcome="REROUTE",scope_change=True)
        result=self.apply("importance_decision",{"importance_decision_ref":r})
        self.assertEqual(result["state"]["previous_parent_problem_ref"],old)
        with self.assertRaises(C.Failure):self.f.transition("freeze_parent_problem",{"parent_problem_ref":old})
        new=parent_card("problem-2");new["previous_parent_problem_ref"]=old
        new["benchmark_contract"]["source_evidence_refs"]=[self.f.source]
        nr=write(self.f.root,"problems/new.json",new)
        self.apply("freeze_parent_problem",{"parent_problem_ref":nr})
        with self.assertRaises(C.Failure):self.f.transition("research_candidate",{"candidate_ref":candidate(self.f,"new")})

    def test_legacy_refine_cannot_preserve_novelty_without_importance_decision(self):
        self.start_candidate()
        report=copy.deepcopy(sample_artifacts()["collision-decision"]);report.update(outcome="REFINE")
        r=write(self.f.root,"audits/refine.json",report)
        with self.assertRaises(C.Failure):self.f.transition("collision_REFINE",{"collision_ref":r,"candidate_ref":candidate(self.f,"c2","c1")})

    def test_candidate_revision_invalidates_prior_importance_decision(self):
        self.start_candidate()
        self.apply("importance_decision",{"importance_decision_ref":importance(self.f)})
        self.apply("research_candidate",{"candidate_ref":candidate(self.f,"c2","c1")})
        self.assertNotIn("importance_decision_ref",C.project(self.f.root)[0])

    def test_gate_freeze_requires_current_importance_decision(self):
        from test_workflow import primary_snapshot
        self.ready()
        sr=primary_snapshot(self.f)
        self.apply("update_evidence",{"claim_clarity":"C2_falsifiable","literature_state":"L2_primary_verified","evidence_snapshot_ref":sr})
        self.apply("no_new_idea_needed",{})
        p=self.f.protocol(frozen=False);p["evidence_snapshot_ref"]=sr
        r=write(self.f.root,"gate-input.json",p)
        with C.locked(self.f.root),self.assertRaises(C.Failure):
            C.freeze_gate(types.SimpleNamespace(protocol=str(self.f.root/r["path"]),gate="gate-a"),self.f.root)

    def test_zero_importance_thresholds_cannot_disable_the_screen(self):
        p=parent_card();p["gate_0_thresholds"].update(min_prevalence=0,min_mean_loss=0,min_unresolved_fraction=0)
        with self.assertRaises(C.Failure):C.validate(p,"parent-problem-card")

    def test_natural_source_changes_are_detected_by_project_replay(self):
        self.ready()
        write(self.f.root,"evidence/episodes/0.json",{"changed":True})
        with self.assertRaises(C.Failure):C.project(self.f.root)

    def test_recount_cannot_clear_a_pending_importance_kill(self):
        self.start_candidate()
        self.apply("importance_decision",{"importance_decision_ref":importance(self.f,outcome="KILL")})
        s=C.project(self.f.root)[0]
        self.apply("record_natural_gate_0",{"natural_gate_0_ref":census(self.f,s["parent_problem_ref"])})
        with self.assertRaises(C.Failure):self.f.transition("research_candidate",{"candidate_ref":candidate(self.f,"c2","c1")})

    def test_legacy_project_can_reenter_exploration_without_losing_origin(self):
        from test_workflow import primary_snapshot
        sr=primary_snapshot(self.f)
        self.apply("update_evidence",{"claim_clarity":"C2_falsifiable","literature_state":"L2_primary_verified","evidence_snapshot_ref":sr})
        self.apply("no_new_idea_needed",{})
        result=self.apply("restart_problem_exploration",{})
        self.assertEqual(result["state"]["current_route"],"explore_problem")
        self.assertEqual(result["state"]["entry_origin"],"M")
        self.assertEqual(result["state"]["gate_state"],"not_ready")
        try:freeze_parent(self.f)
        except C.Failure as e:self.fail(e.code)

    def test_general_solver_success_kills_room_for_a_new_method(self):
        try:p=freeze_parent(self.f)
        except C.Failure as e:self.fail(e.code)
        r=census(self.f,p,outcome="KILL")
        report=json.loads((self.f.root/r["path"]).read_text())
        raw=json.loads((self.f.root/report["observations_ref"]["path"]).read_text())
        for row in raw["cases"]:
            row["alternative_solves"]=True
            row["source_ref"]=write(self.f.root,row["source_ref"]["path"],{k:v for k,v in row.items() if k!="source_ref"})
        report["observations_ref"]=write(self.f.root,report["observations_ref"]["path"],raw)
        r=write(self.f.root,r["path"],report)
        result=self.apply("record_natural_gate_0",{"natural_gate_0_ref":r})
        self.assertEqual(result["state"]["natural_gate_0_outcome"],"KILL")

    def test_hash_consistent_state_cannot_forge_natural_metrics(self):
        self.ready()
        events=C.project(self.f.root)[1]
        events[-1]["next_state"]["natural_gate_0_metrics"]["cases"]=900
        events[-1]["event_digest"]=digest({k:v for k,v in events[-1].items() if k!="event_digest"})
        (self.f.root/"event-ledger.jsonl").write_text("".join(canonical(e)+"\n" for e in events))
        anchor=json.loads((self.f.root/"ledger-anchor.json").read_text());anchor["head_digest"]=events[-1]["event_digest"]
        write(self.f.root,"ledger-anchor.json",anchor);write(self.f.root,"research-state.json",events[-1]["next_state"])
        with self.assertRaises(C.Failure):C.project(self.f.root)

    def test_parent_freeze_requires_a_captured_benchmark_contract(self):
        p=parent_card();p.pop("benchmark_contract",None)
        r=write(self.f.root,"problems/no-benchmark.json",p)
        with self.assertRaises(C.Failure):self.f.transition("freeze_parent_problem",{"parent_problem_ref":r})

    def test_census_from_a_different_benchmark_cannot_pass(self):
        p=freeze_parent(self.f);r=census(self.f,p)
        report=json.loads((self.f.root/r["path"]).read_text())
        raw=json.loads((self.f.root/report["observations_ref"]["path"]).read_text())
        raw["benchmark_id"]="different-easier-benchmark"
        report["observations_ref"]=write(self.f.root,report["observations_ref"]["path"],raw)
        r=write(self.f.root,r["path"],report)
        with self.assertRaises(C.Failure):self.f.transition("record_natural_gate_0",{"natural_gate_0_ref":r})

    def test_candidate_requires_a_necessity_comparison(self):
        self.ready();r=candidate(self.f)
        idea=json.loads((self.f.root/r["path"]).read_text());idea.pop("necessity_case",None)
        r=write(self.f.root,r["path"],idea)
        with self.assertRaises(C.Failure):self.f.transition("research_candidate",{"candidate_ref":r})

    def test_candidate_cannot_omit_the_frozen_strong_simple_alternative(self):
        self.ready();r=candidate(self.f)
        idea=json.loads((self.f.root/r["path"]).read_text())
        idea["necessity_case"]={"simple_alternatives_compared":["weak straw baseline"],
            "unresolved_task_failure":"Wrong final answers","expected_advantage":"Hypothesis only",
            "decisive_comparison":"Paired task outcomes with matched resources",
            "memory_representation_change":False,"baseline_evidence_refs":[self.f.source]}
        r=write(self.f.root,r["path"],idea)
        with self.assertRaises(C.Failure):self.f.transition("research_candidate",{"candidate_ref":r})

    def test_memory_representation_change_requires_plain_text_comparison(self):
        self.ready();r=candidate(self.f)
        idea=json.loads((self.f.root/r["path"]).read_text())
        idea["necessity_case"]={"simple_alternatives_compared":["general constraint solver"],
            "unresolved_task_failure":"Wrong final answers","expected_advantage":"Hypothesis only",
            "decisive_comparison":"Paired task outcomes with matched resources",
            "memory_representation_change":True,"baseline_evidence_refs":[self.f.source]}
        r=write(self.f.root,r["path"],idea)
        with self.assertRaises(C.Failure):self.f.transition("research_candidate",{"candidate_ref":r})

    def test_memory_hypothesis_with_plain_text_control_can_be_reviewed(self):
        self.ready();r=candidate(self.f)
        idea=json.loads((self.f.root/r["path"]).read_text())
        idea["necessity_case"]={"simple_alternatives_compared":["general constraint solver","plain_text_memory"],
            "unresolved_task_failure":"Wrong final answers","expected_advantage":"Hypothesized efficiency at equal task success",
            "decisive_comparison":"Paired task success and measured latency under the same resource cap",
            "memory_representation_change":True,"baseline_evidence_refs":[self.f.source]}
        r=write(self.f.root,r["path"],idea)
        result=self.apply("research_candidate",{"candidate_ref":r})
        self.assertEqual(result["state"]["current_route"],"develop_candidate")
