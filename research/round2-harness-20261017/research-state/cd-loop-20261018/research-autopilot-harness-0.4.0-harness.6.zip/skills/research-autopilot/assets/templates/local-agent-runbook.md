# Local Codex: run, verify, debug and return this project

> Authoring template for Web. Instantiate as the project's
> `LOCAL_AGENT_RUNBOOK.md` (or mapped existing equivalent), linked directly by
> README and applicable AGENTS instructions. Replace every `REPLACE_*` field
> from actual project files/records; remove this authoring note after filling it.
> Missing sourced facts must have a named Local resolution step and pending
> launch status, not a guessed command or a fake passed test.

Contents: [read first](#read-first), [hosts](#hosts-and-paths),
[downloads](#download-datasets-and-models),
[commands](#ordered-command-cards), [development](#adaptive-development-allowance),
[placement and calibration](#task-placement-and-pre-run-calibration),
[coverage](#method-and-benchmark-coverage),
[debug](#debug-routing), [return](#report-and-return).

## Read first

| Item | Actual identity/path and status |
|---|---|
| Project / round / selected candidates | REPLACE_PROJECT_ROUND_AND_SELECTED_IDS |
| Delivered code | Resolve exact main commit from the Web delivery receipt; record it in Local's actual execution manifest. Do not insert this file's future commit. |
| Applicable agent instructions | REPLACE_LINK_TO_APPLICABLE_AGENTS_MD_AND_ANY_ADDITIONAL_INSTRUCTIONS |
| Current Web handoff | REPLACE_LINK_TO_ROUND_WEB_HANDOFF |
| Plan, mathematical selection and math-to-code mapping | REPLACE_EXACT_LINKS_TO_EXISTING_FILES_AND_SECTIONS |
| Complete G01/native design, protocol and method batch | REPLACE_EXACT_DESIGN_PROTOCOL_AND_BATCH_LINKS |
| Current ledger and total authorization/resources | REPLACE_ACTUAL_RECORD_LINKS |
| Implementation/design acceptance | `generated_unexecuted`; REPLACE_CURRENT_MATCHING_LOCAL_RECEIPTS_OR_PENDING_ITEMS |

Read these at the delivered commit before setup/acceptance/execution/repair.
Preserve running attempts at their pinned code; use an isolated compatible
checkout for changed source. Reuse current decisions and qualified evidence.

## Hosts and paths

| Responsibility | Actual sourced value |
|---|---|
| User computer: Local Codex, SSH control, authenticated GitHub integration | REPLACE_LOCAL_DELIVERY_ROOT |
| Existing authorized SSH target | REPLACE_SSH_ALIAS_FROM_SAVED_RECORD |
| GPU host: Linux project and harness runtime roots | REPLACE_REMOTE_PROJECT_AND_RUNTIME_ROOTS |
| Scheduler Python / model and scorer Conda prefixes | REPLACE_REMOTE_INTERPRETERS_ENVIRONMENT_AND_PIN_LINK |
| Data/model caches and native benchmark/scorer revisions | REPLACE_ACTUAL_PATHS_REVISIONS_AND_ACCESS_STATUS |
| Current GPU allocation, UUID/VRAM, CPU/RAM and sharing status | REPLACE_SOURCED_INVENTORY_OR_PENDING_INSPECTION |
| Single-/multi-device or multi-host topology, scheduler/allocation and placement | REPLACE_STEP_ONE_TOPOLOGY_ACCESS_AND_PER_HOST_OWNER |
| Reporting window / hard deadlines / cumulative GPU, wall, spend and attempts | REPLACE_CURRENT_BOUNDS_AND_RECORD_LINK |

The GPU host runs ordinary Python/Conda/harness processes, without a remote
Codex/GPT requirement. Setup, tests, inference/training, evaluation, replay,
diagnostics and collection use one remote harness owner. SSH transport, source
reading and Git delivery remain controller operations. Use native Conda, no Docker.

Time policy: eight hours is a soft report cadence; approved Local work may run
continuously for up to 24 elapsed hours per cycle on existing resources. Record
actual launch/remaining elapsed time and cumulative spend/attempt/GPU/lease limits.
Do not derive `total_wall_seconds`, native `wall_time_seconds` or
`attempt_timeout_seconds` from `window_seconds`; include realistic long-job and
scoring/export bounds. Ordinary continuous dispatch omits `--stop-after-report`.
Resolve old inferred eight-hour caps through recorded operational replanning,
preserving live plan digests, jobs and receipts. Progress reports do not pause
eligible work or truncate the frozen comparison; actual hard limits still bind.

## Download datasets and models

README/AGENTS and the round handoff must link directly to this section. Repeat
the card for every unique required input of methods, strongest baselines, controls
and scorers. Include all selected benchmarks/configs/splits and complete required
weight/tokenizer/processor/config/adapter/index/shard sets. Shared inputs may have
one card listing all consumers; bare repo names/URLs are not download commands.

| Field | Actual sourced value/command |
|---|---|
| Asset ID/type and consuming methods, arms, benchmarks or scorers | REPLACE_COMPLETE_REQUIRED_INPUT_INVENTORY_AND_CONSUMERS |
| Official URL/repo ID/type, full immutable revision, files/config/splits | REPLACE_ACTUAL_SOURCE_REVISION_AND_REQUIRED_COMPONENTS |
| Access/auth/license and official user-side action if needed | REPLACE_EXISTING_ACCESS_OR_NAMED_PENDING_STEP_WITHOUT_SECRETS |
| Host/cwd/Conda/tool version and exact download argv/official script | REPLACE_REAL_VERSION_MATCHED_DOWNLOAD_COMMAND |
| Cache/destination, extraction/native builder and actual config/loader keys | REPLACE_PATHS_PREPARATION_COMMAND_AND_LOADER_MAPPING |
| Size/disk/time and supported bounded cache/resume/retry | REPLACE_SOURCED_ESTIMATES_OR_PENDING_MEASUREMENTS_AND_LIMITS |
| Upstream manifest/checksum, required file/split checks and verification command | REPLACE_ACTUAL_SOURCE_CHECKS_OR_NAMED_GAP |
| Admitted preparation plan, logs and Local acquisition receipt/status | REPLACE_REAL_PLAN_EXPECTED_LOGS_AND_PENDING_ACQUISITION |

Derive commands from actual releases and pinned tooling: supported HF CLI/SDK
for HF inputs, or the official archive/script/native builder for other inputs.
Repo download alone may not prepare builder/external eval files; include those
steps. Web supplies source-inspected commands; Local acquires/extracts/verifies
through remote harness preparation before dependent checks, reusing complete
matching caches and preserving partial/live shared files. No untracked latest
version, omitted shard/split, invented upstream checksum or substitute asset.
Acquisition does not validate software, native scoring or empirical benefit.

## Ordered command cards

For each row provide the actual host, working directory/interpreter, command/argv
or existing pinned plan, required inputs, expected output paths, acceptance rule
and linked failure/debug row. Source-inspected commands are **pending Local
execution** until actual receipts exist. Do not write fictitious `train.py`,
`run_round`, `collect_results` or passing-log paths.

| Step | Exact command/plan and host/cwd/env | Outputs, acceptance and failure pointer |
|---|---|---|
| 1. Restore/stage exact source and runtime | REPLACE_REAL_CONTROLLER_GIT_SSH_TRANSFER_STEPS | REPLACE_VERSION_PATH_MAP_AND_FILE_IDENTITY_CHECKS |
| 2. Native environment preparation | REPLACE_ADMITTED_REMOTE_SETUP_TASK_PLAN | REPLACE_ENV_RECEIPT_PIN_AND_ENVIRONMENT_DEBUG_LINK |
| 3. Download/extract/verify all required datasets and models | REPLACE_COMPLETE_ASSET_CARDS_AND_ADMITTED_REMOTE_PREPARATION | REPLACE_FILES_REVISIONS_LOADER_PATHS_AND_DOWNLOAD_DEBUG_LINK |
| 4. Software/math-to-code semantic acceptance | REPLACE_ADMITTED_REMOTE_CHECK_TASKS_AND_SOURCE_LOCATIONS | REPLACE_ACTUAL_EXPECTED_LOGS_PROPERTIES_AND_IMPLEMENTATION_DEBUG_LINK |
| 5. Official native-interface/scorer qualification | REPLACE_NATIVE_CASE_OR_OUTPUT_IDS_AND_ADMITTED_TASK | REPLACE_NATIVE_SCORER_DENOMINATOR_OUTPUTS_AND_SCORER_DEBUG_LINK |
| 5a. Per-workload native development calibration and bounded pre-run debugging | REPLACE_REAL_CALIBRATION_DIAGNOSTIC_AND_RECHECK_PLAN_COMMANDS | REPLACE_NATIVE_INPUT_IDS_THROUGHPUT_PEAK_HEADROOM_AND_REPAIR_LIMITS |
| 6. Accept current code/design | REPLACE_REAL_BATCH_ID_METHOD_IDS_AND_BEFORE_EXPERIMENT_DESIGN_CHECK | REPLACE_REQUIRED_CODE_DESIGN_EVIDENCE_AND_PENDING_ACTION |
| 7. Scientific dispatch | REPLACE_BEFORE_DISPATCH_AND_ACTUAL_FROZEN_HARNESS_COMMAND_DIGEST | REPLACE_CURRENT_GATES_AUTHORITY_RESOURCE_ADMISSION_AND_EXPECTED_OUTPUTS |
| 8. Monitor/reconcile/resume | REPLACE_ACTUAL_HARNESS_PLAN_STATUS_AND_REMOTE_PROCESS_INSPECTION | REPLACE_LOG_CONTEXT_RECEIPT_REPORT_PATHS_AND_SSH_RESOURCE_DEBUG_LINKS |
| 9. E04/replay/collect/return | REPLACE_ADMITTED_REPLAY_COLLECTION_TASKS_AND_CONTROLLER_RETRIEVAL | REPLACE_VERIFICATION_RECORD_REVIEW_PACKET_AND_PUSH_READBACK_STEPS |

Keep the linked qualification tasks separate from the complete scientific queue.
Acceptance does not replace the benchmark comparisons below. Resolve dynamically
created attempt/stdout/stderr paths from actual receipts; keep exact log locators
in the result/debug packet rather than guessing an attempt ID.

If a step fails: retain its actual stderr/receipt and classify it using the debug
table. Repair supported causes within the finite per-task development allowance,
recheck affected properties and current design boundaries, then continue eligible
work. When justified attempts/time are exhausted, park the affected task with its
exact missing obligation and dispatch an independent ready task. Only actual
descendants wait; the first idea is not every idea's prerequisite. No failed
prerequisite becomes PASS or disappears from final coverage by skipping it.

## Adaptive development allowance

Fill this from the approved scope and inspected implementation. Local may choose
its next supported repair or informative development setting inside this envelope
without approval for each adjustment. Keep every attempt/version/cost; qualify
affected properties before continuing. Estimates may be revised from measured
costs within actual remaining limits; live plans and hard bounds stay intact.

| Allowed development action | Actual scope, bound, selection and escalation |
|---|---|
| Implementation/semantic repairs | REPLACE_PERMITTED_FIXES_CONSTRUCTION_BOUNDARY_AND_RECHECKS |
| Tunable parameters and adaptive search | REPLACE_REAL_CONFIG_KEYS_BOUNDS_OR_BOUNDED_RANGE_SELECTION_RULES |
| Development-only selection and fair baselines | REPLACE_NATIVE_DEV_SPLITS_OBJECTIVES_AND_MATCHED_TUNING_ALLOWANCES |
| Resource calibration and pending-queue replanning | REPLACE_ADMITTED_CALIBRATION_COST_UPDATE_AND_DISPATCH_RULES |
| Cumulative budget and escalation | REPLACE_TIME_COMPUTE_SPEND_ATTEMPT_CEILINGS_AND_HUMAN_DECISION_BOUNDARIES |
| Freeze and fresh confirmation | REPLACE_FINAL_CONFIG_PROTOCOL_REQUALIFICATION_AND_INDEPENDENT_CONFIRMATION |

Development settings are adjustable within this recorded allowance. Confirmation
is a separate frozen comparison; viewed outcomes cannot select its parameters.
Unknown allowance fields stay pending rather than granting unrestricted tuning.

## Task placement and pre-run calibration

Populate this before the full scientific queue. Use step 1's current sourced
allocation, then remote live inventory. Reuse existing actual values; resolve
changed/unknown capacity without assuming a cluster or repeating settled intake.
The bundled executor is single-host; multiple hosts need separate actual owners
and explicit coordinator/admission/artifact-transfer rules, not invented flags.

| Placement/calibration item | Actual project contract, command and record |
|---|---|
| CPU preparation/scoring/collection versus GPU inference/training/scoring | REPLACE_PER_TASK_CPU_RAM_IO_GPU_UUID_HOST_REQUESTS_AND_ACTUAL_DEPENDENCIES |
| Local coordinator and reusable bounded subagents | REPLACE_TASK_OWNERS_FILES_INPUTS_OUTPUTS_AGENT_LIMITS_AND_ONE_INTEGRATOR |
| Useful backfill and fair priority | REPLACE_READY_TASK_ORDER_CRITICAL_DEPENDENCIES_WAIT_AGE_AND_RESERVATIONS |
| Descending native batch calibration, one probe at a time (e.g. 64, 32, 16, 8, 4, 2) | REPLACE_SUPPORTED_CANDIDATES_CAPACITY_EXCLUSIONS_NATIVE_KEYS_DEV_INPUT_IDS_BUDGET_AND_STOP_RULE |
| Effective training batch, accumulation and RNG/sampling semantics | REPLACE_PRESERVED_SEMANTICS_OR_REVIEWED_DEVELOPMENT_CHANGES_AND_MATCHED_BASELINE_ALLOWANCE |
| Measured choice | REPLACE_ACTUAL_TRIAL_COMMANDS_LOGS_SYNCHRONIZED_THROUGHPUT_PEAK_RAM_VRAM_HEADROOM_STABILITY_AND_CHOSEN_CONFIG_OR_PENDING |
| One experimental program across project hosts; sharing disabled | REPLACE_SERIAL_COORDINATOR_RUNNER_LIMITS_ACTUAL_ALLOCATION_AND_JOB_IDENTITY |
| Per-task diagnosis, repair/recheck and park/next-task rule | REPLACE_REAL_COMMANDS_VERSIONED_PENDING_PLANS_ATTEMPT_TIME_CEILINGS_AND_INDEPENDENT_NEXT_TASK_IDS |
| Qualified final dispatch | REPLACE_ACTUAL_VALIDATED_HARNESS_PLAN_DIGEST_AUTHORITY_BEFORE_DISPATCH_AND_CURRENT_EVIDENCE |

Use single-experiment-batching.md: try supported native batches from large to
small and stop at a stable qualified setting unless measurements warrant a bounded
lower-batch comparison. Retain useful throughput, headroom and the selection reason.
One program owns the experiment slot; independent CPU preparation and its loader
workers may feed it within CPU/RAM/I/O limits. Queue other experiments/scoring. Short calibration qualifies only
resource/semantic properties, not benchmark benefit. Preserve complete comparisons.
Use the command shapes in the skill's local-code-handoff.md **Pre-run calibration
and debug entry**, replacing them with this project's real host/path/plan values.
No generic autotuner/retry/skip API is installed by the skill. Local executes all
trials via the admitted harness and freezes new pending plans/configs after changes;
never mutate a live digest or reset the cumulative budget.

## Method and benchmark coverage

Repeat the row for **every agreed benchmark and required method/baseline/control**.

| Candidate/arm | Existing benchmark, split/sample IDs, native metric | Source entry + config/effective keys | Plan/dependencies/resources | Native output, denominator, baseline/controls and remaining obligation |
|---|---|---|---|---|
| REPLACE_SELECTED_ID_OR_COMPARATOR | REPLACE_EXISTING_NATIVE_TASK_AND_VERSION | REPLACE_ADAPTER_SOURCE_AND_PINNED_CONFIG | REPLACE_ACTUAL_PLAN_AND_ENVELOPE | REPLACE_COMPLETE_COMPARISON_AND_OUTPUTS |

Use existing official benchmark data/scoring. Bind development choices to the
adaptive allowance and confirmation choices to the frozen design; retain actual
samples, masking, normalization, seeds/budgets, information and numerical/training
settings for each attempt. Software success is not empirical benefit or a scientific
verdict. Full comparisons remain required across reporting windows.

## Debug routing

Instantiate each applicable row with actual project source/config/log links and
an implemented diagnostic/recheck. Name a missing diagnostic as pending; do not
present a placeholder as a runnable tool. Record the diagnosis before tuning.

| Failure | Exact log/source/config to read | Hypothesis and real diagnostic | Scoped repair, required recheck and stop rule |
|---|---|---|---|
| Environment/import/path/CUDA | REPLACE_EXACT_ENV_POINTERS | REPLACE_SUPPORTED_ENV_DIAGNOSIS | REPLACE_NATIVE_SETUP_FIX_AND_ACCEPTANCE |
| Download/access/checksum/missing shard or native split | REPLACE_DOWNLOAD_RECEIPT_SOURCE_MANIFEST_LOADER_AND_CACHE | REPLACE_PERMISSION_VERSION_PARTIAL_CORRUPT_OR_PATH_DIAGNOSIS | REPLACE_BOUNDED_SAME_ASSET_RECOVERY_AND_RECHECK |
| OOM/resource contention | REPLACE_ATTEMPT_CONTEXT_DEVICE_PEAK_CONFIG | REPLACE_MEMORY_VS_CONTENTION_DIAGNOSIS | REPLACE_ADMISSION_OR_VERSIONED_CONFIG_ACTION |
| Shape/mask/gradient/NaN/semantic error | REPLACE_TRACE_INPUT_AND_MATH_TO_CODE_LINES | REPLACE_CAUSAL_DIAGNOSTIC | REPLACE_SOURCE_FIX_AND_MEANINGFUL_RECHECK |
| Native score/sample/denominator mismatch | REPLACE_ADAPTER_SCORER_RAW_OUTPUT_PROTOCOL | REPLACE_OFFICIAL_REPLAY_DIAGNOSTIC | REPLACE_NATIVE_REQUALIFICATION |
| Mixed scene/dataset performance | REPLACE_E04_BASELINES_PARAMETERS_AND_DEV_CASES | REPLACE_COMPETING_CAUSES_AND_DECISIVE_DEV_CONTRAST | REPLACE_FAIR_BOUNDED_TUNING_OR_SCOPE_CHECK_AND_FRESH_CONFIRMATION |
| Exhausted supported per-task debugging | REPLACE_ALL_ATTEMPTS_COSTS_MISSING_INPUT_OR_FAILED_PROPERTY | REPLACE_FINITE_REPAIR_EXHAUSTION_AND_AFFECTED_DESCENDANTS | REPLACE_PARKED_OBLIGATION_RECONCILED_RELEASE_AND_INDEPENDENT_READY_NEXT_TASK |
| SSH disconnect/lost launch acknowledgment | REPLACE_REMOTE_STATE_PROCESS_TUPLE_AND_RECEIPTS | REPLACE_REAL_RECONCILIATION_CHECK | REPLACE_SAME_ID_BUDGET_COMPATIBLE_RESUME |
| Eight-hour boundary/unfinished work | REPLACE_WINDOW_REPORT_TASKS_AND_TOTAL_DEADLINES | REPLACE_RUNNING_VS_COMPLETED_VS_BLOCKED_CHECK | REPLACE_UNCHANGED_CARRYOVER_AND_SNAPSHOT |
| GitHub push/readback failure | REPLACE_TARGET_PARENT_AND_OPERATION_RECEIPTS | REPLACE_REMOTE_HISTORY_CONTENT_CHECK | REPLACE_ONE_WRITER_RECONCILE_AND_DELIVERY_PENDING_RULE |

Retain a debug note with observation/versions, competing causes, inspected evidence,
source/config diff, all trials/costs, rechecks and next action. Parameter tuning is
development-only, fair to baselines and bounded; a mathematical derivation does
not prove that bad results are solely missing tuning. No held-out-label selection,
homemade evaluator or silent batch/dtype/model changes. Changes affecting predictions,
samples/scoring follow child-protocol and fresh-confirmation obligations.

Reconcile SSH process identities before retrying; retained `--status` is not live
process proof. Keep native workload children foreground inside the harness. An
eight-hour report does not kill healthy tasks or reset cumulative bounds. Hold
new directions/material designs for the existing consolidated human decision.

## Report and return

| Return item | Exact project path/operation |
|---|---|
| Coherent window/final review packet | REPLACE_ACTUAL_REVIEW_PACKET_PATH_AND_INDEX_LINK |
| Raw native scores/outputs, E04, all failed/adverse/mixed trials | REPLACE_PROJECT_RELATIVE_RECORD_LOCATORS |
| Execution version/config, remote-to-local transfer checks | REPLACE_REAL_MANIFEST_DIRTY_PATCH_AND_DIGEST_LOCATORS |
| Completed/running/blocked carryover and remaining total bounds | REPLACE_TASK_AND_BUDGET_RECORD_LINKS |
| Authorized GitHub/HF result targets and one writer | REPLACE_SAVED_DESTINATIONS_OR_EXPLICIT_HF_NON_USE |
| Scoped collection, push and exact-commit readback | REPLACE_ACTUAL_COLLECTOR_TRANSPORT_AND_DELIVERY_STEPS |

Do not rerun work because upload failed. Preserve other writers and live attempts.
Return actual repo/commit/review-packet path only after confirmed delivery; otherwise
retain concrete outputs and describe the observed pending transfer. All generated
Web code/config/design publication reaches the selected project's `main`.
