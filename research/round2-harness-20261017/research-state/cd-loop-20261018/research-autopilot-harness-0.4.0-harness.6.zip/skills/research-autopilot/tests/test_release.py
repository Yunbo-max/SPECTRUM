import copy
import json
import subprocess
import sys
import unittest
from fixtures import C, PACKAGE, ProjectFixture, canonical, digest, sample_artifacts, state, write
from test_boundaries import FakeHost, FakeProvider
from ipcg_fixtures import ready_problem,importance,functional_work,candidate

class ReleaseTests(unittest.TestCase):
    def setUp(self):
        self.f=ProjectFixture();self.addCleanup(self.f.close);ready_problem(self.f)
    def candidate(self,id="c1",parent=None):
        return candidate(self.f,id,parent)
    def collision(self,outcome,id="c1"):
        report=copy.deepcopy(sample_artifacts()["collision-decision"]);report.update(outcome=outcome,candidate_id=id)
        return write(self.f.root,"audits/"+id+"-"+outcome+".json",report)
    def test_second_major_collision_with_fresh_sources_requires_new_exploration(self):
        self.f.transition("research_candidate",{"candidate_ref":self.candidate()})
        for i in range(2):
            report=importance(self.f,work_refs=[functional_work(self.f,"distinct-work-"+str(i))])
            self.f.transition("importance_decision",{"importance_decision_ref":report})
        self.assertEqual(C.project(self.f.root)[0]["current_route"],"explore_problem")
    def test_within_route_phase_advance_cannot_skip_collision(self):
        result=self.f.transition("advance_phase",{"lifecycle_phase":"candidate_generation"})
        self.assertEqual(result["state"]["lifecycle_phase"],"candidate_generation")
        with self.assertRaises(C.Failure):self.f.transition("advance_phase",{"lifecycle_phase":"writing"})
    def test_provisional_collision_kill_does_not_abandon_project(self):
        self.f.transition("research_candidate",{"candidate_ref":self.candidate()})
        report=self.collision("KILL")
        result=self.f.transition("collision_KILL",{"collision_ref":report,"provisional":True})
        self.assertEqual(result["state"]["terminal_status"],"none")
        self.assertEqual(result["state"]["current_route"],"develop_candidate")
    def test_payload_cannot_replace_recorded_outcome(self):
        with self.assertRaises(C.Failure):self.f.transition("explicit_stop",{"outcome":"research_candidate"})
        self.assertFalse((self.f.root/".pending-commit.json").exists())
    def test_forged_same_route_history_cannot_promote_validation(self):
        event=C.project(self.f.root)[1][0];nextstate=copy.deepcopy(event["next_state"])
        nextstate.update(sequence=2,validation_state="pass")
        forged={**copy.deepcopy(event),"sequence":2,"transition_id":"forge","event_type":"transition",
            "previous_event_digest":event["event_digest"],"previous_state_digest":digest(event["next_state"]),
            "next_state":nextstate,"payload":{"outcome":"update_evidence"}}
        forged["event_digest"]=digest({k:v for k,v in forged.items() if k!="event_digest"})
        with self.assertRaises(C.Failure):C.verify_chain(canonical(event)+"\n"+canonical(forged)+"\n")
    def test_invalid_cli_argument_cannot_echo_secret(self):
        secret="hf_"+"W"*32
        result=subprocess.run([sys.executable,str(PACKAGE/"scripts/init_project.py"),"--root",str(self.f.root),"--name","f","--goal","f","--entry",secret],capture_output=True,text=True)
        self.assertEqual(result.returncode,2);self.assertNotIn(secret,result.stdout+result.stderr)
    def test_unnecessary_personal_identifiers_are_quarantined(self):
        for value in ({"contact_email":"person@example.org"},{"patient_id":"patient-123"},{"remote":"https://user:private-pass@example.org/repo"}):
            with self.subTest(value=value),self.assertRaises(C.Failure):C.scan(value)
    def test_owner_only_declassification_is_exactly_bound(self):
        import _safety as S
        host=FakeHost();assets=[{"asset_id":"a","digest":"1"*64,"classification":"private","owner":"alice"}]
        grant={"decision":"approved","approved_by":"bob","source_digests":["1"*64],"derived_digest":"2"*64,
            "new_classification":"public","destination":"fixture-search","purpose":"research","expires_at":"2026-11-01T00:00:00Z"}
        host.verified_declassification=lambda _:grant
        with self.assertRaises(C.Failure):S.declassify(assets,"2"*64,"public","fixture-search","research",host,"approval")
        grant["approved_by"]="alice"
        self.assertEqual(S.declassify(assets,"2"*64,"public","fixture-search","research",host,"approval"),"public")
        with self.assertRaises(C.Failure):S.declassify(assets,"3"*64,"public","fixture-search","research",host,"approval")
    def test_client_cannot_raise_trusted_cumulative_budget(self):
        import _safety as S
        from fixtures import request
        host=FakeHost();req=request();event=host.approve(req);provider=FakeProvider()
        with self.assertRaises(C.Failure):S.execute_operation(self.f.root,req,host,event,provider,{"cost":999,"seconds":100,"storage_bytes":1500,"egress_bytes":0})
        self.assertEqual(provider.submissions,0)
    def test_provider_receipt_cannot_erase_reservation_or_rebind_operation(self):
        import _safety as S
        from fixtures import request
        host=FakeHost();req=request();event=host.approve(req);provider=FakeProvider();real=provider.submit
        def malicious(req,idempotency_key):
            result=real(req,idempotency_key)
            return {**result,"reservation":{"cost":0,"seconds":0,"storage_bytes":0,"egress_bytes":0},"operation_id":"rebound"}
        provider.submit=malicious
        result=S.execute_operation(self.f.root,req,host,event,provider)
        self.assertEqual(result["reservation"]["cost"],2);self.assertEqual(result["operation_id"],"op-1")
        other=copy.deepcopy(req);other["operation_id"]="op-2";event=host.approve(other,event_id="approval-2")
        with self.assertRaises(C.Failure):S.execute_operation(self.f.root,other,host,event,provider)
        self.assertEqual(provider.submissions,1)
    def test_redaction_preserves_consumption_reservations_and_provider_identity(self):
        import _safety as S
        from fixtures import request
        host=FakeHost();req=request();event=host.approve(req);provider=FakeProvider(idempotency=False,lookup=False)
        first=S.execute_operation(self.f.root,req,host,event,provider)
        write(self.f.root,"evidence/private.json",{"remove":"private material"})
        redact=S.redaction_request(self.f.root,["evidence/private.json"],"user-requested",account_identity="fixture-user",expires_at="2026-11-01T00:00:00Z")
        approved=host.approve(redact,event_id="redaction-approval")
        S.redact_lineage(self.f.root,redact,host,approved)
        again=S.execute_operation(self.f.root,req,host,event,provider)
        self.assertEqual(first["provider_id"],again["provider_id"]);self.assertEqual(provider.submissions,1)
        other=copy.deepcopy(req);other["operation_id"]="op-2";approved=host.approve(other,event_id="approval-2")
        with self.assertRaises(C.Failure):S.execute_operation(self.f.root,other,host,approved,provider)
        self.assertEqual(provider.submissions,1)
    def test_redaction_purges_decoded_json_secret_copies(self):
        import _safety as S
        host=FakeHost();secret="hf_"+"X"*32
        write(self.f.root,"evidence/private.json",{"leak":secret})
        cache=self.f.root/"cache/escaped.json";cache.parent.mkdir(parents=True)
        escaped="".join("\\u%04x"%ord(c) for c in secret);cache.write_text('{"leak":"'+escaped+'"}')
        request=S.redaction_request(self.f.root,["evidence/private.json"],"user-requested",account_identity="fixture-user",expires_at="2026-11-01T00:00:00Z")
        event=host.approve(request);S.redact_lineage(self.f.root,request,host,event)
        self.assertFalse(cache.exists())

if __name__=="__main__":unittest.main()
