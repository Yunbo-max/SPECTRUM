# Paper / implementation / benchmark note

- Project and decision:
- Canonical work ID; exact paper version and primary URL:
- Read date, D0/D1/D2/D3, reused/newly read scope, inaccessible portions:
- Publication status; reproduction status (independent):

## Question, claim and boundary

Record the real problem, assumptions, objective, algorithm/equations, strongest
simple alternative and author-reported conclusions with exact locators. State
which proposition matters for this project's decision and what remains unknown.

## Actual implementation and measurement

| Paper locator | GitHub repo/commit + file/function/config | Native benchmark/data/split/scorer locator | Agreement, difference or missing access |
|---|---|---|---|
| | | | |

Keep paper-reported numbers, static observations, actual runs and qualified
confirmations separate. Link real commands, environment/assets and receipts only
when observed. Retain native metric, denominator, allowed information and cost.

## Knowledge changes

Link semantic facts, explicit interpretation corrections and candidate procedural
rules through knowledge-change cards. Retain support, conflict and scope; do not
force a fixed number of cards or infer that reading caused experimental success.

## Hypothesis and experiment obligation

- Residual observed failure and rival explanations:
- Minimal intervention, decisive control and closest-work difference:
- H03 / G01 / protocol links; proposed versus authorized/executed status:
- Outcomes, falsifier, fair budget, precision, cost and stop rule:

## Review handoff

Record what changed, unaffected conclusions, pending gaps and source dependencies.
During a frozen batch retain these for unified human review; no automatic new
scientific direction. Link the actual consolidated report and human decision.
