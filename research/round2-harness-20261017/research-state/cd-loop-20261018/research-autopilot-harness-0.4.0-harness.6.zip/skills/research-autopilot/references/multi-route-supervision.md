# Multi-project, multi-chat and multi-agent route supervision

The 16-region, 84-node, 221-edge research map remains the task-type graph. A
supervised route is a runtime instance owned by a particular chat/agent, with its
own project, goal, scope, source versions, branch, workspace and budget. Many routes
may visit the same node. Registration, freshness, reservations and handoff checks
add no scientific phase, gate or legal value to `research-state`.

Use this reference when the user wants a portfolio supervisor, several research
chats in one ChatGPT Project, independent worker agents, or a map showing current
route instances. This is a registry and coordination protocol, not an installed
background scheduler or a source of authority.

For concurrent research workers, apply
[dependency-resource-scheduling.md](dependency-resource-scheduling.md): a bounded
worker pool, actual task DAG, ready-task admission and separate agent/API/GPU
limits. The map's 221 relationships are not an executable schedule. Keep complete
G01 comparisons and E04 verification under soft report points and up-to-24-hour
Local cycles; long Web authoring uses web-background-work.md. Unfinished
approved tasks carry within existing cumulative bounds. Propose evidence-driven
candidate convergence for human review rather than restore 20 ideas each window.

## ChatGPT Project setup and capability boundary

[OpenAI's Projects documentation](https://help.openai.com/en/articles/10169521-projects-in-chatgpt)
describes a shared container for chats, files and project instructions. It explains
creating a project, moving eligible existing chats into it, and starting chats
inside it. Checked 2026-10-03. Project context can help a supervisor, but the
documentation supplies no guarantee that this skill can exhaustively enumerate,
stream or control every chat through an available tool.

One **ChatGPT Project** can contain a portfolio of several **scientific projects**.
Keep these identities distinct. Each scientific project retains its own canonical
`project_id`, ledger, origin, protocol versions and evidence. Several worker chats
or spawned agents can own independent `route_id` values within one scientific
project. The supervisor itself is a separate chat, usually a read-only observer.

1. Have the user create/select the desired ChatGPT Project through the supported
   interface, move the intended existing chats into it, and create a supervisor
   chat. Reuse an existing supported capability when available; do not pretend
   that the local Python command created, moved or inspected any conversation.
2. Copy the exact project instructions from
   [project-chat-instructions.md](project-chat-instructions.md). Set the actual
   registry destination and use the worker/supervisor opening prompts there.
3. Select one authorized durable host for the registry and project artifacts.
   If no real destination is known, report `DURABLE_DESTINATION_MISSING` and
   continue the permitted local setup. A chat summary or a path in one temporary
   container does not establish cross-chat durability.
4. Register only named routes backed by inspected canonical project artifacts.
   A chat alias, agent ID or model value is caller-supplied metadata, not proof
   that a chat exists, that a particular model ran, or that a human granted access.
   Use `unspecified` when the host does not expose the model; do not guess.
5. Each worker writes a checkpoint after every material milestone and at the end
   of its turn/session, then actually saves it to the shared host. The supervisor
   fetches and replays that host state when asked to review. Scheduled review or
   continuous monitoring requires an actually requested and supported automation.

Show coverage honestly: registered routes, unregistered routes reported by the
user, last verified source time and inaccessible sources. Unseen chats stay unseen.
Do not invent a fleet, progress bars, results or synchronization receipts.

## Executable local registry

Use absolute `SUPERVISOR`, `PROJECT` and `SKILL_DIR` paths. The supervisor root is
separate from each scientific project root. `registry.json` and its lock are private
by default; the file is an atomically replaced, hash-chained event history plus a
checked state projection. The helpers do not read arbitrary ChatGPT conversations,
invoke project code, run a GPU, authorize expenditure, create branches, publish an
overview or save to a remote host.

```bash
python3 "$SKILL_DIR/scripts/supervise_routes.py" init \
  --root "$SUPERVISOR" --registry-id RESEARCH_PORTFOLIO \
  --configuration CONFIGURATION_JSON
python3 "$SKILL_DIR/scripts/supervise_routes.py" register \
  --root "$SUPERVISOR" --request-id REGISTER_REQUEST_ID \
  --expected-revision CURRENT_REVISION --request ROUTE_JSON
python3 "$SKILL_DIR/scripts/supervise_routes.py" checkpoint \
  --root "$SUPERVISOR" --request-id CHECKPOINT_REQUEST_ID \
  --expected-revision CURRENT_REVISION --request CHECKPOINT_JSON
python3 "$SKILL_DIR/scripts/supervise_routes.py" overview --root "$SUPERVISOR"
python3 "$SKILL_DIR/scripts/supervise_routes.py" replay --root "$SUPERVISOR"
```

`init` accepts `resources`, `budget`, `destination` and `stale_after_seconds` in
its optional configuration file. Defaults are empty capacity/budget declarations,
no durable destination and a 3600-second stale interval. Known capacities are
objects such as `{"gpu-0":{"kind":"gpu","capacity":1}}`; kinds are `gpu`,
`workspace` or `other`. GPU capacities/reservations are whole device counts;
a workspace capacity/reservation is exactly one. Add the actual source of an
inventory declaration as metadata; the helper cannot prove physical availability.
Budget dimensions are nonnegative quantities with consistent units, such as
`cost`, `seconds`, `api_tokens`, `storage_bytes` and `egress_bytes`. Unknown limits
remain unknown and block reservations for those dimensions. Never substitute a
declared local ceiling for a host's trusted spending limit.

If local setup began with no destination, retain that history and attach the
later observed private destination using the dedicated CAS operation:

```bash
python3 "$SKILL_DIR/scripts/supervise_routes.py" set-destination \
  --root "$SUPERVISOR" --request-id DESTINATION_REQUEST_ID \
  --expected-revision CURRENT_REVISION --request DESTINATION_JSON
```

The request contains only `destination: {kind, uri, private}`; `kind` is
`repository`, `page` or `drive`. This appends a versioned destination event while
preserving routes, leases and original configuration. It changes no capacity,
budget or authority. Its receipt is `destination_recorded_not_synced` until an
actual conditional host write/readback receipt is recorded. Changing a destination
does not silently delete or synchronize either host copy; earlier receipts remain
historical. Do not reset the registry with a changed `init` configuration.

A destination is `{"kind":"repository|page|drive","uri":"ACTUAL_URI","private":true}`.
Choose one kind, and use the real destination rather than the literal placeholder.
Declaring a destination does not write to it. Reinitialization resumes only an
unchanged registry ID/configuration; it never resets history or raises ceilings.

The registration request contains exactly:

```json
{
  "route_id": "CALLER_ASSIGNED_UNIQUE_ROUTE_ID",
  "project_root": "/absolute/materialized/canonical/project",
  "owner": {"agent_id": "ACTUAL_AGENT_OR_ALIAS", "chat_id": "ACTUAL_CHAT_OR_ALIAS", "model": "unspecified"},
  "repository": "ACTUAL_REPOSITORY_IDENTITY",
  "branch": "ACTUAL_ISOLATED_BRANCH",
  "workspace": "/absolute/isolated/workspace",
  "goal": "Existing sourced route goal",
  "scope": ["Authorized bounded work"],
  "budget": {},
  "writer": true,
  "status": "active",
  "overlay": {"path": ["P01", "P02"], "current_node": "P02", "next_node": "I01", "last_evidence": null}
}
```

This is an input-format illustration, not a claimed research execution. Replace
every placeholder with observed project/session metadata. `path` is the visited
task-type path, ending at `current_node`; `next_node` is an adjacent planned task
or `null`. The helper checks existing map IDs/relationships, not their scientific
acceptance conditions. Revisits and valid graph cycles are allowed. Every selected
task still loads its current bound node contract. `last_evidence` is `null` or an
existing relative project reference with a verified SHA-256.

Registration reads the existing project under its lock, verifies ledger/anchor,
projection, frozen artifacts and retained references with the project validator,
and records the imported state, head, sequence, file identities and verification
time. It does not patch or advance that state. A pending canonical commit or an
unavailable/invalid ledger is a blocker. One project ID has one canonical ledger
root; independent route workspaces must not become conflicting canonical copies.

Create/check the real isolated branch and workspace before registering an active
writer. Active writers cannot claim the same repository/branch or equal/nested
workspace paths. Use the same normalized repository identity for a shared repo.
For Web code/design publication, `main` has one integration writer under
repository-round-trips.md. Isolated preparation branches/workspaces are not
alternate remote delivery targets; hand their scoped outputs to that writer and
do not push Web code elsewhere. Claim `main` ownership honestly when publishing;
do not weaken the registry's active-writer conflict checks to allow concurrent pushes.
Read-only observers can share them. The helper checks ownership declarations; a
host-enforced sandbox and the real filesystem/git tools establish actual isolation.
Pause/complete the previous writer and release its writer leases before reusing a
workspace. Changes to owner, project, branch, workspace, scope or goal use a new
route ID, keeping the old route and its handoff history visible.

## Checkpoints, freshness and upstream validation

A checkpoint contains `route_id`, `expected_route_revision`, `kind`, `observed_at`,
`summary`, `status`, `blockers`, `changed_results`, `overlay` and `lease_tokens`.
The map overlay has the same shape as registration. Status is `active`, `waiting`,
`blocked`, `paused` or `completed`. Each used lease token is
`{"lease_id":"LEASE_ID","fencing_token":POSITIVE_INTEGER}`.

Use `kind: verified` when the canonical project artifacts are present and can be
replayed. Its verification means the imported **project ledger** was checked; it
does not authenticate the chat author's narrative or certify scientific claims.
Use `kind: manual` plus a nonempty `source` for a user-reported/manual milestone.
Optional `reported_state` is retained as a report only. Manual checkpoints remain
`unverified_manual_report`, cannot replace the imported scientific state, and do
not become fresh verified results merely because their timestamp is recent.

Every mutation needs a unique `request-id` and the expected registry revision.
Checkpoint updates also need the expected route revision. Requests with stale
revisions, older observations, future observations, rolled-back project sequences
or conflicting canonical histories cannot overwrite newer state. A higher source
sequence must contain the previously imported head as an ancestor. Retry an exact
request with the same ID and original revision to retrieve its original receipt;
changing its payload while reusing its ID is rejected. The filesystem lock and
atomic replacement prevent competing local writers from winning the same revision.
Replay verifies event hashes, unique request IDs, continuity, state digests,
projection and head. Hashes are not signatures against someone able to rewrite
the complete file; retain the head and content identity on a trusted durable host.

`overview` classifies only actual registered records:

| Classification | Meaning |
| --- | --- |
| `fresh` | Recent verified checkpoint, unchanged accessible canonical head, no recorded blocker |
| `stale` | Old checkpoint, manual report or canonical state newer than the route's last import |
| `blocked` | Missing source, reported dependency, denied reservation or required upstream validation |
| `conflicts` | Canonical project identity/head/sequence conflicts with the previously verified import |

The route's lifecycle status remains separate from this classification. Display
specific reason codes and last evidence, current node, next node, owners, scope,
budget holds and spent records. A checkpoint received after the source changed
does not automatically make the route's scientific findings valid.

Set `changed_results: true` for any changed result-bearing code, evaluator,
protocol, data/asset version, raw result or interpretation requiring prior gates
or claim closure to be revisited. This creates a shared upstream-validation
obligation for **all routes in that scientific project**. A routine report cannot
erase it. Continue the necessary upstream work under the existing scientific
contracts and permissions. Set `resolve_upstream_validation: true` only on a
verified checkpoint after a newer canonical full-validation PASS and committed
closure. The helper replays the source and checks the anchored decision, current
closure and validated method/project versions before resolving the shared warning.
This reads a completed scientific validation; it does not invoke a scorer or
implicitly rerun an experiment to refresh a supervision checkpoint.
For earlier-stage changes, keep
the warning while carrying out the appropriate existing upstream checks; a route
checkpoint alone never issues a gate verdict. Worker-supplied `verification` or
`validation_resolution` fields are rejected.

## Resource leases and cumulative accounting

```bash
python3 "$SKILL_DIR/scripts/supervise_routes.py" reserve \
  --root "$SUPERVISOR" --request-id RESERVATION_REQUEST_ID \
  --expected-revision CURRENT_REVISION --request LEASE_REQUEST_JSON
python3 "$SKILL_DIR/scripts/supervise_routes.py" leases --root "$SUPERVISOR"
python3 "$SKILL_DIR/scripts/supervise_routes.py" check-lease \
  --root "$SUPERVISOR" --lease-id LEASE_ID --route-id ROUTE_ID \
  --fencing-token CURRENT_FENCING_TOKEN
python3 "$SKILL_DIR/scripts/supervise_routes.py" release \
  --root "$SUPERVISOR" --request-id RELEASE_REQUEST_ID \
  --expected-revision CURRENT_REVISION --request RELEASE_JSON
python3 "$SKILL_DIR/scripts/supervise_routes.py" record-usage \
  --root "$SUPERVISOR" --request-id USAGE_REQUEST_ID \
  --expected-revision CURRENT_REVISION --request USAGE_JSON
```

A lease request has `lease_id`, `route_id`, positive `resources` amounts, `budget`
and future `expires_at`. Existing unexpired reservations across every project
count against the shared inventory. Capacity/budget conflicts are recorded as
denied leases and route blockers without consuming capacity or duplicating holds.
The route budget and portfolio budget both apply. Accepted leases get globally
increasing fencing tokens. Expiry frees resource capacity; the old token cannot
pass `check-lease` or a fenced checkpoint. Release requires the matching route and
token. Reusing a lease ID for a different attempt is prohibited.

Host execution adapters must check the exact route/lease/token immediately before
effects and enforce fencing at the resource. A local preflight alone cannot stop a
remote process or eliminate a race with expiry. The helper does not launch, cancel,
renew or kill jobs. Include tokens for resources used by the reported milestone;
omitting a token does not authorize unreserved effects. Ordinary notes and read-only
work can be checkpointed without claiming a compute lease.
Only an `active` route may use a lease to authorize an effect; paused/completed
owners fail the lease preflight. Their usage settlement/release remains available.
A paused writer with an unexpired reservation still blocks branch/workspace reuse.
After release or expiry, its old token cannot pass; a resumed writer must also
pass the current isolation check. Stopping real processes remains the host's job.

Expiry and release keep unaccounted budget **held**. They do not imply a free
job, a refund or known final spend. Usage records have `lease_id`, `route_id`,
`fencing_token`, nonnegative **incremental** `usage`, boolean `final`, and a real
`receipt` locator. Usage can account for a late provider receipt after resource
expiry/release, but cannot authorize new effects. Actual spending is accumulated;
unknown remainder stays reserved until a final settlement. Usage greater than the
reservation is rejected for reconciliation instead of quietly raising a limit.
Receipt strings are accounting evidence supplied by the caller; inspect real
provider receipts through the host. Local budget data supplies no compute,
spending, account or publication authority. Follow `host-adapters.md` and the user's
authorized scope for actual operations.

## Durable host handoff and connectors

`registry.json` becomes available across chats only after an **actual authorized
host write**. Local locking/CAS is not distributed locking across separate clones.
Before each externally coordinated mutation:

1. Fetch the latest authoritative registry and project ledger through the installed
   supported connector/skill. Verify its schema, head and evidence; materialize
   retained references. Do not use project memory as a substitute for this read.
2. Pin the remote version/ETag/commit. Reconcile all local changes against it before
   applying local CAS. Conflicting histories require an explicit handoff/rebase of
   the intended updates, preserving both receipts; never overwrite the latest head.
3. Perform the host write with a real version precondition. Read back the exact
   content and capture target, account, before/after revision, operation ID and hash.
   If the host cannot reject a concurrent update, use one designated host writer or
   report that distributed writer coordination is blocked.
4. Record the actual receipt with `sync-receipt` and save that receipt on the host.
   Workers and supervisor report the destination and pinned version. A write lost
   acknowledgment is reconciled through its real provider identity before retry.

For **GitHub**, use the actual installed connector/git tools, an isolated route
branch/worktree, the resolved commit/tree/dirty-patch identities and the remote
base revision. A real conditional push/PR and its receipt establish delivery;
creating a file or commit locally does not. Do not publish, merge or push outside
the user's scope. Keep raw evidence private unless its release is authorized.

For **Hugging Face**, follow `repository-round-trips.md` and the installed HF
skill/connector. Fetch the current repo type/revision before updating; retain
commit IDs, upload/readback receipts and the exact checkpoint/data/model versions.
If the connector lacks safe concurrent updates, serialize writes through one host
writer. HF upload does not connect the user's GPU or certify the returned results.

For a **Page/Space or Google Drive** host, use the installed host skill/connector to
read the current item/version and then actually update the named private item. A
read-only connector or an unsupported conditional write is a named blocker. Project
sources can include a fetched snapshot or supported source link, but do not assume
that the Project continuously syncs it or that every worker has identical access.
Keep full ledger/evidence files in a file-capable host; a Page can serve as an index
to those pinned artifacts rather than claiming to be their canonical raw store.

`sync-receipt` requires `destination`, `source_revision`, `source_head_digest`,
`source_sha256`, `remote_revision_before`, `remote_revision_after`, `operation_id`
and `readback_sha256`. The source must be the exact current registry head and file;
the readback hash must match. The local receipt is labeled `host_receipt_recorded`
and `independently_verified_by_helper: false`: this command stores the host evidence
and does not independently authenticate a remote write. Inspect the actual tool
receipt before claiming durable delivery. A subsequent route/resource/accounting
event makes the receipt stale and the overview reports `unsynced_changes`.
Recording the receipt itself adds a local event; retain that receipt separately
on the host or include it on the next pinned registry write.

## Private overview export

```bash
python3 "$SKILL_DIR/scripts/supervise_routes.py" export \
  --root "$SUPERVISOR" --output /absolute/private/route-overview.html --format html
```

Formats are `html`, `mermaid` and `json`. The export is a private, read-only snapshot
derived from current registered records, with revision, source freshness and
durability state. HTML includes the actual 16-region/84-node/221-edge map in
editable SVG, colored recorded paths, current-node rings and dashed planned next
steps. Per-route checkboxes filter the visible paths. Its detail table shows owner/
reported model, source time/verification, path, last evidence, budget/held usage,
upstream dependencies and blockers. Mermaid connects each recorded route's steps
and distinguishes its planned next step. No route is fabricated to fill the map.
HTML escapes route text and loads no remote scripts. It has no live chat connection
and publishes nothing. Regenerate from a newly fetched/replayed
registry when an updated overview is requested. A public Site, live hosted dashboard
or automation is a separate authorized deliverable, with actual source access,
update mechanism, confidentiality review and deployment receipts.

## Engineering verification

`tests/test_supervisor.py` uses the existing non-evaluation project fixture and
temporary files to check coordination behavior. Its schema examples come from real
helper outputs. These tests exercise no GPU, benchmark, research experiment, live
chat or external host. Passing them establishes local engineering behavior only.
