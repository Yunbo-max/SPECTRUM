"""Cooperation policy/template regressions, not live multi-agent compliance tests."""
import json
from pathlib import Path
import unittest

SKILL = Path(__file__).resolve().parents[1]


def text(path):
    file = SKILL / path
    return ' '.join(file.read_text(encoding='utf-8').split()) if file.exists() else ''


class ProjectCooperationPolicyTests(unittest.TestCase):
    def test_entry_requires_end_of_every_cycle_and_before_dispatch(self):
        entry = text('SKILL.md')
        for term in ('Project cooperation barrier', 'after every cycle',
                     'before dispatch', 'project-cooperation.md'):
            self.assertIn(term, entry)

    def test_policy_is_loaded_before_action_selection(self):
        entry = text('SKILL.md')
        head = entry.split('## Start or resume')[0]
        self.assertIn('project-cooperation.md', head)

    def test_existing_advance_is_not_shared_admission(self):
        self.assertIn('advance is not a project-wide claim', text('SKILL.md'))

    def test_scope_requires_one_shared_authority(self):
        policy = text('references/project-cooperation.md')
        for term in ('project_id', 'coordination_branch', 'project_root',
                     'participant registry', 'not just the current branch'):
            self.assertIn(term, policy)

    def test_full_inventory_then_incremental_content_reads(self):
        policy = text('references/project-cooperation.md')
        for term in ('initial inventory', 'every participant', 'new or changed',
                     'source revision', 'coverage gaps', 'unchanged pinned'):
            self.assertIn(term, policy)

    def test_no_invented_access_or_disclosure(self):
        policy = text('references/project-cooperation.md')
        for term in ('unavailable is not empty', 'private conversations',
                     'credentials', 'authorized project destination'):
            self.assertIn(term, policy)

    def test_all_outcomes_have_shared_reconciliation(self):
        policy = text('references/project-cooperation.md')
        for term in ('success, failure, refutation, repair', 'paused', 'before yielding',
                     'publication receipt', 'cooperation_pending'):
            self.assertIn(term, policy)

    def test_identity_is_semantic_not_labels(self):
        policy = text('references/project-cooperation.md')
        for term in ('semantic equivalence', 'task_key', 'hypothesis', 'data/split',
                     'code', 'scorer', 'seed', 'Renaming'):
            self.assertIn(term, policy)

    def test_completed_running_failed_unknown_are_distinct(self):
        policy = text('references/project-cooperation.md')
        for term in ('reuse', 'running', 'failed', 'unknown', 'reconcile',
                     'material change', 'evidence repair'):
            self.assertIn(term, policy)

    def test_atomic_admission_and_lost_acknowledgement(self):
        policy = text('references/project-cooperation.md')
        for term in ('expected-parent', 'readback', 'conflict', 'never force',
                     'not a distributed lock', 'lost acknowledgement'):
            self.assertIn(term, policy)

    def test_stale_lease_never_proves_job_stopped(self):
        policy = text('references/project-cooperation.md')
        for term in ('expiry alone', 'original operation', 'fencing',
                     'single coordinator', 'read-only'):
            self.assertIn(term, policy)

    def test_replication_is_not_accidental_duplication(self):
        policy = text('references/project-cooperation.md')
        for term in ('replication_of', 'replication_reason', 'independent review',
                     'confirmation', 'not a new discovery'):
            self.assertIn(term, policy)

    def test_collaboration_changes_plan_and_preserves_provenance(self):
        policy = text('references/project-cooperation.md')
        for term in ('plan delta', 'reuse_refs', 'avoided_duplicates',
                     'help_requests', 'parent', 'actual run identity'):
            self.assertIn(term, policy)

    def test_no_scheduler_or_full_context_requirement(self):
        policy = text('references/project-cooperation.md')
        for term in ('does not schedule', 'does not grant', 'bounded',
                     'Large datasets', 'not a scientific PASS'):
            self.assertIn(term, policy)

    def test_template_is_empty_not_invented_activity(self):
        path = SKILL / 'assets/templates/project-cooperation.json'
        self.assertTrue(path.is_file(), 'shared cooperation template is missing')
        state = json.loads(path.read_text(encoding='utf-8'))
        self.assertEqual(state['schema_version'], 1)
        self.assertEqual(state['kind'], 'project-cooperation')
        for key in ('project_id', 'repository', 'coordination_branch',
                    'project_root', 'coordinator_id', 'observed_revision'):
            self.assertIsNone(state[key])
        for key in ('participants', 'sources', 'tasks', 'sync_receipts'):
            self.assertEqual(state[key], [])
        self.assertEqual(state['coverage_status'], 'unobserved')

    def test_claim_and_sync_receipt_contracts_are_concrete(self):
        policy = text('references/project-cooperation.md')
        for term in ('owner_id', 'input_refs', 'output_paths', 'claim_revision',
                     'observation_time', 'cycle_id', 'next_action', 'source_heads'):
            self.assertIn(term, policy)


class GithubOnlyCooperationTests(unittest.TestCase):
    """Lint the loaded policy and real template; not a live-agent execution test."""

    def test_entry_binds_github_before_first_task(self):
        entry = text('SKILL.md')
        startup = entry.split('## Start or resume')[1].split('## Project cooperation barrier')[0]
        self.assertIn('GitHub-only', startup)
        self.assertIn('before choosing the first task', startup)
        self.assertIn('repository, coordination_branch, project_root', startup)

    def test_optional_cross_chat_read_path_removed(self):
        policy = text('references/project-cooperation.md')
        self.assertNotIn('Use host-supported project conversation search/read', policy)
        self.assertIn('Do not search or read other Chat/Work conversations', policy)

    def test_conversation_visibility_is_not_a_prerequisite(self):
        policy = text('references/project-cooperation.md')
        self.assertIn('even when conversation tools are available', policy)
        self.assertIn('Chat visibility is not a coverage gap', policy)

    def test_one_binding_has_startup_readback(self):
        policy = text('references/project-cooperation.md')
        self.assertIn('## GitHub-only startup binding', policy)
        self.assertIn('Reuse the already selected repository', policy)
        self.assertIn('.autopilot/project-cooperation.json', policy)
        self.assertIn('before choosing the first task', policy)
        self.assertIn('GitHub readback', policy)

    def test_workers_do_not_need_ui_names(self):
        policy = text('references/project-cooperation.md')
        self.assertIn('not a ChatGPT project name or conversation title', policy)
        self.assertIn('same GitHub account', policy)
        self.assertIn('distinct stable owner_id', policy)

    def test_every_cycle_uses_github_for_both_publication_and_reads(self):
        policy = text('references/project-cooperation.md')
        barrier = policy.split('## Mandatory end-of-cycle sequence')[1].split('## Semantic de-duplication')[0]
        self.assertIn('Publish to GitHub', barrier)
        self.assertIn('Refresh GitHub', barrier)
        self.assertIn('Save to GitHub', barrier)
        self.assertIn('GitHub task ledger', barrier)

    def test_github_failure_never_falls_back_to_chat_search(self):
        policy = text('references/project-cooperation.md')
        self.assertIn('Do not fall back to conversation search', policy)
        self.assertIn('cooperation_pending', policy)
        self.assertIn('local-only', policy)

    def test_scope_is_cooperation_not_research_sources_or_user_authority(self):
        policy = text('references/project-cooperation.md')
        self.assertIn('Current user instructions remain authoritative', policy)
        self.assertIn('Primary-paper web research and local CPU execution remain allowed', policy)

    def test_existing_projects_migrate_without_second_ledger(self):
        policy = text('references/project-cooperation.md')
        self.assertIn('Preserve existing GitHub records', policy)
        self.assertIn('do not create a second ledger', policy)
        self.assertIn('unshared progress remains unobserved', policy)

    def test_template_defaults_disable_conversation_discovery(self):
        state = json.loads((SKILL / 'assets/templates/project-cooperation.json').read_text())
        self.assertEqual(state.get('collaboration_backend'), 'github')
        self.assertIs(state.get('conversation_discovery'), False)
        self.assertEqual(state.get('policy_revision'), 'github-only-v1')
        self.assertIn('coordination_path', state)
        self.assertIsNone(state['coordination_path'])


if __name__ == '__main__':
    unittest.main()
