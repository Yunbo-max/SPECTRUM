"""Engineering checks for generation boundaries, not scientific experiments."""
import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from fixtures import C, DIGEST, PACKAGE, ProjectFixture, write
from test_method_verification import BatchFixture
import run_experiments as R
import verify_methods as V


class GenerationBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.f = BatchFixture(self.root)

    def check(self, action, candidate="c1"):
        self.assertTrue(callable(getattr(V, "before_action", None)), "generation-boundary checker is missing")
        return V.before_action(self.root, self.f.batch, action, candidate)

    def test_verified_selection_allows_code_but_not_experiment_design(self):
        self.assertTrue(self.check("code")["workflow_boundary"]["ready"])
        self.assertFalse(self.check("experiment-design")["workflow_boundary"]["ready"])

    def test_math_gap_blocks_code_even_when_the_user_message_asks_for_code(self):
        self.f.batch["user_message"] = "Please generate the code immediately"
        self.f.batch["candidates"][0].pop("math_review_ref")
        self.assertFalse(self.check("code")["workflow_boundary"]["ready"])

    def test_reserve_candidate_cannot_receive_code_investment(self):
        self.assertFalse(self.check("code", "c20")["workflow_boundary"]["ready"])

    def test_current_code_allows_design_and_changed_code_revokes_it(self):
        self.f.implementation()
        self.assertTrue(self.check("experiment-design")["workflow_boundary"]["ready"])
        (self.root / "c1.py").write_text("def update(x, eta):\n    return x\n")
        self.assertFalse(self.check("experiment-design")["workflow_boundary"]["ready"])

    def test_cli_checks_a_requested_boundary_before_generation(self):
        write(self.root, "batch.json", self.f.batch)
        command = [sys.executable, str(PACKAGE / "scripts/verify_methods.py"), "--root", str(self.root),
                   "--batch", "batch.json", "--candidate", "c1", "--before"]
        code = subprocess.run([*command, "code"], capture_output=True, text=True)
        self.assertEqual(code.returncode, 0, code.stderr)
        self.assertTrue(json.loads(code.stdout)["workflow_boundary"]["ready"])
        design = subprocess.run([*command, "experiment-design"], capture_output=True, text=True)
        self.assertEqual(design.returncode, 2)
        self.assertFalse(json.loads(design.stdout)["workflow_boundary"]["ready"])


class MethodDispatchBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.project = ProjectFixture()
        self.addCleanup(self.project.close)
        self.root = self.project.root
        self.f = BatchFixture(self.root)
        self.code = self.f.implementation()
        self.protocol = self.project.protocol()
        self.protocol["method_version"] = self.code["method_version"]
        contract = self.protocol["native_eval_contract"]
        contract["arm_requirements"]["treatment"]["implementation_refs"] = self.code["code_refs"]
        self.protocol["method_discovery"] = {
            "candidate_id": "c1", "batch_ref": write(self.root, "discovery-code.json", self.f.batch)}
        self.protocol["protocol_digest"] = C.protocol_hash(self.protocol)
        self.protocol_ref = write(self.root, "protocol.json", self.protocol)

    def plan(self, verification_ref=None, protocol_ref=None):
        contract = self.protocol["native_eval_contract"]
        provenance = {"git_revision": "engineering-fixture", "model_revision": "none",
                      "data_revision": "existing-engineering-fixtures", "environment_digest": DIGEST}
        if verification_ref is not None:
            provenance["method_verification_ref"] = verification_ref
        plan = C.envelope("experiment-run-plan", run_id="boundary-fixture", purpose="scientific",
            evidence_mode="developmental", protocol_ref=protocol_ref or self.protocol_ref,
            protocol_digest=self.protocol["protocol_digest"], output_root="runs/boundary-fixture",
            provenance=provenance, limits={"max_attempts": 1, "max_development_trials": 1,
            "max_confirmation_trials": 0, "max_retries_per_trial": 0,
            "wall_time_seconds": 10, "attempt_timeout_seconds": 5},
            jobs=[{"trial_id": "treatment-fixture", "command": [sys.executable, "-V"], "cwd": ".",
                   "input_refs": [contract["sample_manifest_ref"], contract["labels_or_tests_ref"]],
                   "code_refs": self.code["code_refs"], "output_paths": [],
                   "seed": self.protocol["seed_policy"]["seeds"][0],
                   "group": self.protocol["required_groups"][0], "arm_role": "treatment"}])
        plan["plan_digest"] = R.plan_digest(plan)
        return plan

    def reject(self, code, plan):
        with self.assertRaises(C.Failure) as raised:
            R.validate_plan(self.root, plan)
        self.assertEqual(raised.exception.code, code)

    def test_method_protocol_without_complete_design_binding_is_rejected(self):
        self.reject("RUN_METHOD_DESIGN_EVIDENCE_REQUIRED", self.plan())

    def test_code_only_packet_does_not_unlock_experiment_dispatch(self):
        batch_ref = write(self.root, "dispatch-batch.json", self.f.batch)
        self.reject("RUN_METHOD_DESIGN_NOT_VERIFIED", self.plan(batch_ref))

    def test_current_complete_design_unlocks_only_its_bound_protocol(self):
        self.f.design(self.protocol_ref)
        batch_ref = write(self.root, "dispatch-batch.json", self.f.batch)
        self.assertEqual(R.validate_plan(self.root, self.plan(batch_ref))["run_id"], "boundary-fixture")
        other = copy.deepcopy(self.protocol)
        other["protocol_id"] = "different-frozen-protocol"
        other["protocol_digest"] = C.protocol_hash(other)
        self.protocol = other
        other_ref = write(self.root, "other-protocol.json", other)
        self.reject("RUN_METHOD_DESIGN_PROTOCOL_MISMATCH", self.plan(batch_ref, other_ref))

    def test_missing_design_is_rejected_before_any_command_or_attempt_exists(self):
        plan = self.plan()
        with self.assertRaises(C.Failure):
            R.run_plan(self.root, plan, authorizer=lambda scope: True)
        self.assertFalse((self.root / "runs/boundary-fixture").exists())


if __name__ == "__main__":
    unittest.main()
