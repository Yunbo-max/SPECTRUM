"""Node-level retrieval, source integrity and map-preservation checks."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

SKILL = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("research_nodes", SKILL / "scripts/research_nodes.py")
nodes = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(nodes)


class NodeSourceTests(unittest.TestCase):
    def setUp(self):
        self.registry = nodes.load_registry()

    def test_all_nodes_have_traceable_entries_and_valid_edges(self):
        report = nodes.validate(self.registry)
        self.assertEqual(report["node_count"], 84)
        self.assertEqual(report["region_count"], 16)
        self.assertEqual(report["edge_count"], 221)
        self.assertEqual(report["errors"], [])
        self.assertEqual(sum(report["coverage_counts"].values()), 84)

    def test_inventory_retrieves_asset_contract_not_website_story(self):
        text = nodes.show(self.registry, "P02")
        self.assertIn("resolved_commit:", text)
        self.assertIn("dirty_patch_digest:", text)
        self.assertIn("7.1 Resume and recovery", text)
        self.assertNotIn("Design a scientific interaction", text)

    def test_paragraph_entry_retrieves_own_writing_rules(self):
        text = nodes.show(self.registry, "W05")
        self.assertIn("paragraph", text.lower())
        self.assertIn("Safe prose revision invariants", text)
        self.assertIn("writing-top-tier-papers", text)
        self.assertNotIn("Natural Gate 0 PASS", text)

    def test_platform_contract_distinguishes_drafting_from_publishing(self):
        node = next(n for n in self.registry["nodes"] if n["id"] == "C03")
        self.assertEqual(node["coverage"], "detailed")
        self.assertTrue(node["sources"])
        text = nodes.show(self.registry, "C03")
        self.assertIn("LinkedIn", text)
        self.assertIn("小红书", text)
        self.assertIn("draft", text)
        self.assertIn("receipt", text)

    def test_every_node_has_authored_contract_without_claiming_runtime_validation(self):
        for node in self.registry["nodes"]:
            with self.subTest(node=node["id"]):
                self.assertEqual(node["coverage"], "detailed")
                self.assertTrue(node["sources"])
                self.assertEqual(node.get("runtime_validation"), "not_certified_by_binding")

    def test_heading_parser_ignores_example_fences(self):
        text = "## Real\n\n```markdown\n## Fake\n```\n\n## Next\nvalue\n"
        self.assertEqual(nodes.extract_section(text, "## Real"), "## Real\n\n```markdown\n## Fake\n```\n\n")
        with self.assertRaises(nodes.SourceError):
            nodes.extract_section(text, "## Fake")

    def test_idea_and_method_nodes_load_required_math_core_and_navigation(self):
        for node_id in ("H01", "H03", "M02"):
            with self.subTest(node=node_id):
                node = nodes.get_node(self.registry, node_id)
                self.assertTrue({"m-core", "m-navigation"}.issubset(
                    {binding["source"] for binding in node["sources"]}))
                text = nodes.show(self.registry, node_id)
                self.assertIn("# Mathematical structure analysis and method discovery", text)
                self.assertIn("## How to navigate", text)
                self.assertIn("every proposed research", text.lower())

    def test_math_sources_work_without_a_separate_math_skill(self):
        original_find = nodes.find_skill

        def without_standalone(name, root):
            if name == "research-math-analysis":
                raise nodes.SourceError("standalone math skill is not installed")
            return original_find(name, root)

        for key in ("m-core", "m-navigation"):
            self.assertEqual(self.registry["source_catalog"][key]["skill"],
                             "research-autopilot")
        with patch.object(nodes, "find_skill", side_effect=without_standalone):
            self.assertEqual(nodes.validate(self.registry)["errors"], [])
            for node_id in ("H01", "H03", "M02"):
                text = nodes.show(self.registry, node_id)
                self.assertIn("built-in part of research-autopilot", text)
                self.assertNotIn("research-math-analysis", text)

    def test_changed_source_is_rejected_with_locator(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            skill = root / "skill-fixture"
            skill.mkdir()
            (skill / "SKILL.md").write_text("---\nname: fixture-skill\ndescription: fixture\n---\n# Source\nchanged\n")
            catalog = {"fixture": {"skill": "fixture-skill", "path": "SKILL.md"}}
            binding = {"source": "fixture", "heading": "# Source", "sha256": "0" * 64}
            with self.assertRaisesRegex(nodes.SourceError, "source_changed.*fixture.*# Source"):
                nodes.read_source(catalog, binding, root)

    def test_unsafe_source_path_is_rejected(self):
        catalog = {"bad": {"skill": "research-autopilot", "path": "../outside.md"}}
        binding = {"source": "bad", "heading": "# Outside", "sha256": "0" * 64}
        with self.assertRaisesRegex(nodes.SourceError, "unsafe_source_path"):
            nodes.read_source(catalog, binding, SKILL.parent)

    def test_unknown_node_is_not_silently_substituted(self):
        with self.assertRaisesRegex(nodes.SourceError, "unknown_node"):
            nodes.show(self.registry, "C99")

    def test_standard_skill_directory_is_resolved_by_declared_name(self):
        with tempfile.TemporaryDirectory() as directory:
            skill = Path(directory) / "writing-top-tier-papers"
            skill.mkdir()
            (skill / "SKILL.md").write_text("---\nname: writing-top-tier-papers\ndescription: fixture\n---\n# Writing\n")
            self.assertEqual(nodes.find_skill("writing-top-tier-papers", directory), skill)


if __name__ == "__main__":
    unittest.main()
