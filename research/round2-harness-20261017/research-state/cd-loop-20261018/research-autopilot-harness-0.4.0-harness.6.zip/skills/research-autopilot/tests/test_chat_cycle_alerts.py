"""Operational incident reporting must preserve actual checkpoint semantics."""
import hashlib
import io
import json
from contextlib import redirect_stderr
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from test_chat_cycle import C
A = C._science_module('chat_alerts')


class ChatCycleAlertTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.path = self.root / 'state.json'
        request = self.write('request.txt', 'Finite engineering fixture; no research experiment')
        C.initialize(self.path, dict(goal_id='fixture', goal='Check two operations',
            goal_contract=dict(mode='bounded_task', request_ref=request,
                               continuation_action='Complete the two fixture operations'),
            criteria=['checked'], deliveries=[], budget=dict(max_attempts=2),
            procedure=dict(id='fixture-procedure', ref=request),
            tasks=[dict(id=name, action='Check ' + name, candidate_id='fixture',
                        dependencies=[], input_refs=[]) for name in ['first', 'independent']]))

    def write(self, name, value):
        path = self.root / name
        path.write_text(value if isinstance(value, str) else json.dumps(value))
        return dict(path=name, sha256=hashlib.sha256(path.read_bytes()).hexdigest())

    def event(self, op, **kwargs):
        return C.record(self.path, C.status(self.path)['revision'], dict(op=op, **kwargs))

    def test_cpu_capability_block_reports_but_independent_work_can_continue(self):
        attempt = C.advance(self.path, 0)['attempt']
        self.event('result', attempt_id=attempt['id'], outcome='blocked',
            reason='CPU tool is unavailable in this observed host', next_action='Continue source inspection')
        incident, = A.pending(self.root)
        self.assertEqual(incident['scope'], attempt['id'])
        self.assertEqual(incident['notification_status'], 'pending')
        self.assertIn('CPU tool', incident['summary'])
        state = C.status(self.path)
        self.assertIsNone(state['current_attempt'])
        next_work = C.advance(self.path, state['revision'])
        self.assertEqual(next_work['attempt']['task_id'], 'independent')

    def test_invalid_record_preserves_checkpoint_and_original_error(self):
        before = self.path.read_bytes()
        with self.assertRaisesRegex(ValueError, 'revision conflict'):
            C.record(self.path, 999, dict(op='begin', task_id='first'))
        self.assertEqual(before, self.path.read_bytes())
        incident, = A.pending(self.root)
        self.assertEqual(incident['category'], 'controller_error')
        self.assertIn('revision conflict', incident['summary'])

    def test_pause_is_not_failure_or_permission_to_resume(self):
        self.event('pause', request_ref=self.write('pause.txt', 'Pause fixture'), reason='Requested pause')
        state = C.status(self.path)
        self.assertEqual(C.advance(self.path, state['revision'])['reason'], 'user_stopped')
        self.assertEqual(C.next_action(self.path)['reason'], 'user_stopped')
        self.assertEqual(A.pending(self.root), [])

    def test_expected_active_observation_is_not_an_incident(self):
        C.advance(self.path, 0)
        self.assertEqual(C.advance(self.path, 1)['reason'], 'active_attempt_requires_observation')
        self.assertEqual(A.pending(self.root), [])

    def test_failed_alert_storage_does_not_turn_settlement_into_failure_or_replay(self):
        attempt = C.advance(self.path, 0)['attempt']
        with patch.object(A, 'report', side_effect=OSError('disk full')), redirect_stderr(io.StringIO()) as output:
            state = self.event('result', attempt_id=attempt['id'], outcome='blocked',
                reason='Capability unavailable', next_action='Report through host text')
        self.assertIsNone(state['current_attempt'])
        self.assertEqual(C.status(self.path)['attempts'][0]['outcome'], 'blocked')
        self.assertIn('unsaved', output.getvalue())
        self.assertEqual(state['started_attempts'], 1)

    def test_corrupt_checkpoint_reports_without_overwriting_it(self):
        self.path.write_text('{invalid')
        with self.assertRaises(ValueError):
            C.next_action(self.path)
        self.assertEqual(self.path.read_text(), '{invalid')
        self.assertEqual(len(A.pending(self.root)), 1)

    def test_blocked_decision_deduplicates_without_mutating_checkpoint(self):
        for name in ['first', 'independent']:
            attempt = self.event('begin', task_id=name)['current_attempt']
            self.event('result', attempt_id=attempt['id'], outcome='blocked',
                reason='Fixture dependency unavailable', next_action='Acquire actual dependency')
        before = self.path.read_bytes()
        first = C.next_action(self.path)['notification']
        second = C.next_action(self.path)['notification']
        self.assertEqual(first['incident_id'], second['incident_id'])
        self.assertEqual(second['version'], first['version'])
        self.assertEqual(second['occurrences'], first['occurrences'] + 1)
        self.assertEqual(self.path.read_bytes(), before)

    def test_valid_hypothesis_refutation_is_not_execution_fault(self):
        attempt = C.advance(self.path, 0)['attempt']
        raw = self.write('negative.txt', 'Synthetic fixture counterexample')
        evidence = self.write('evidence.json', dict(attempt_id=attempt['id'], task_id='first',
            candidate_id='fixture', procedure_id='fixture-procedure', outcome='refuted', raw_evidence=[raw]))
        self.event('result', attempt_id=attempt['id'], outcome='refuted', evidence_ref=evidence,
            reason='Counterexample to fixture assertion', next_action='Consider a different assertion')
        self.assertEqual(A.pending(self.root), [])

    def test_failed_child_is_reported_even_while_parent_remains_active(self):
        import test_chat_parallel as parallel
        fixture = parallel.ChatParallelTests()
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        fixture.start()
        fixture.prepare('reader')
        fixture.bind('reader')
        fixture.finish('reader', outcome='failed')
        incident, = A.pending(fixture.root)
        self.assertEqual(incident['category'], 'child_failure')
        self.assertEqual(fixture.state()['current_attempt']['status'], 'active')

    def test_observed_failed_child_reports_before_result_collection(self):
        import test_chat_parallel as parallel
        fixture = parallel.ChatParallelTests()
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        fixture.start()
        fixture.prepare('reader')
        fixture.bind('reader')
        fixture.observe('reader', 'failed')
        incident, = A.pending(fixture.root)
        self.assertEqual(incident['category'], 'child_failure')
        self.assertEqual(fixture.child('reader')['status'], 'stopped')

    def test_length_boundary_reports_preserved_partial_without_failed_attempt(self):
        attempt = C.advance(self.path, 0)['attempt']
        self.event('checkpoint', attempt_id=attempt['id'], reason='max_tokens',
                   next_action='Continue saved partial next invocation')
        incident, = A.pending(self.root)
        self.assertEqual(incident['category'], 'execution_interrupted')
        self.assertEqual(C.status(self.path)['current_attempt']['status'], 'partial')

    def test_reporter_and_stderr_failure_cannot_mask_successful_settlement(self):
        attempt = C.advance(self.path, 0)['attempt']
        with patch.object(A, 'safe_report', side_effect=RuntimeError('reporter unavailable')), \
                patch('sys.stderr.write', side_effect=OSError('broken stderr')):
            state = self.event('result', attempt_id=attempt['id'], outcome='blocked',
                reason='Capability unavailable', next_action='Use the host response')
        self.assertIsNone(state['current_attempt'])
        self.assertEqual(C.status(self.path)['revision'], state['revision'])


if __name__ == '__main__':
    unittest.main()
