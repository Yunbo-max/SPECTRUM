# Local runtime controller and backend operations

**Fifth-edition entry:** `autonomous-rsi-harness` uses
[research-harness.md](research-harness.md) for the actual managed research program.
It retains the selected existing command agent, complete obligations, real planner
and separate review, v4 bindings and archived-result continuation. The Controller,
ACP and native bridge described below remain underlying interfaces, not a claim
that their worker or monitor alone completes a research loop. Use the actual pinned
local or authorized SSH target, one experiment across the project, and native
scoring. The inherited 24-hour cycle cap bounds a task; it is not the program's
total deadline. Cumulative limits and explicit pause still bind. No default service
installation or source-triggered migration occurs.

**Autonomous branch:** read [autonomous-rsi](autonomous-rsi.md) with this module. Its finite delegated machine supervisor replaces routine human step-7 selection and selects the startup-authorized delivery branch; scientific evidence, existing goals, budgets and same-attempt recovery remain binding. Older human-at-every-batch/main-only wording below describes the baseline and is superseded only within that explicit delegation.

Read for controller/backend configuration, finite queues, reconnection or native
result return. Research scientific policy remains in the entry and linked modules;
this runtime does not replace their gates. Restore current evidence/revisions,
existing authorization and real identities before operational changes.

## Contents

- [Installation and ownership](#installation-and-ownership)
- [Trusted project and task contracts](#trusted-project-and-task-contracts)
- [Agent guidance and ACP](#agent-guidance-and-acp)
- [Scientific admission](#scientific-admission)
- [Native execution and return](#native-execution-and-return)
- [Recovery and delivery](#recovery-and-delivery)
- [Limits and evidence](#limits-and-evidence)

## Installation and ownership

Install three distinct parts on the user's controller: the complete Research
Autopilot plus three writing/figure sibling skills; Python 3.11+ library
`research-autopilot-runtime`; and actual upstream vendor binaries plus their own
authentication/provider configuration. A copied SKILL.md installs neither the
library nor agents or credentials. The source repository's docs/INSTALL_LOCAL.md,
docs/PROVIDERS.md and docs/LOCAL_AGENT_RUNBOOK.md contain the concrete commands.

Hermes defaults to `hermes acp`; upstream `@agentclientprotocol/codex-acp` exposes
`codex-acp`, and `@agentclientprotocol/claude-agent-acp` exposes `claude-agent-acp`.
They use the same implemented ACP v1 client. GLM/Qwen/DeepSeek are selected in
Hermes's current provider/model registry, not in scientific task parameters.
Use upstream auth/setup separately; this client implements no universal login.

One trusted controller registers project authority. Workers receive fixed tasks,
not a right to grant approvals, install dependencies or change scientific scope.
Use one integration writer for publication; independent workers have isolated
workspaces. ACP agent slots differ from GPU concurrency. The existing single
host resource pool/harness alone determines qualified CPU/RAM/GPU admission.

## Trusted project and task contracts

Use `research-autopilot --db /absolute/controller.sqlite3 COMMAND` (global --db
precedes COMMAND), or `python -m research_autopilot` with the same arguments:

| Operation | Actual CLI arguments after --db PATH |
|---|---|
| Initialize | `init` |
| Current skill digest | `skill-digest /absolute/skill` |
| Pin actual input | `pin /absolute/project relative/file` |
| Register trusted project | `register-project /absolute/project.json` |
| Enqueue immutable task | `enqueue PROJECT /absolute/task.json` |
| Inspect queue/budget | `status PROJECT` |
| Read events | `events PROJECT --after 0 --limit 1000` |
| One finite ACP task | `worker PROJECT --owner OWNER --adapter hermes` |
| Explicit registry | worker/inspect/reconcile add `--adapters-config /absolute/adapters.json` |
| One native task | `worker PROJECT --owner OWNER --adapter native --native-target /absolute/target.json` |
| Same retained observation | `inspect PROJECT TASK --owner ORIGINAL_OWNER --fence ORIGINAL_FENCE --adapter BACKEND` |
| Observed reconciliation | `reconcile PROJECT TASK --owner ORIGINAL_OWNER --fence ORIGINAL_FENCE --adapter BACKEND --outcome completed --reason 'actual observed evidence'` |
| Read-only MCP stdio | `mcp PROJECT` |

Native inspect/reconcile use the same --native-target as dispatch. Registry JSON
maps allowed stable names to explicit argv arrays; supplying it replaces defaults.
No shell string or task-supplied executable is used. CLI success is exit 0 (worker
may return null if nothing eligible); JSON errors return exit 2. It installs nothing.

Project fields are project_id, absolute root, workflow_class (`scientific_method`
or `runtime_maintenance`), assigned role, adapter allowlist, skill_root/digest,
and finite limits. max_cost is integer micro-USD, max_seconds is cumulative
attempt usage/reservations, max_workers agent slots; optional report_seconds is
soft cadence and cycle_seconds is <=86400. Scientific skill_root/digest is required.
Tasks bind stable task_id, fixed action, inputs/instructions `{path,sha256}` refs,
previously registered dependencies, output paths, completion
`{"kind":"outputs_verified"}`, max_cost/max_seconds and capability names; optional
priority, adapter and parameters carry data, never authority. Unknown keys and
path escape fail closed. Register generated downstream refs only after actual
bytes exist and can be pinned. Same ID/same contract is idempotent; conflict rejects.

Actions: source_read, math_work, math_review, candidate_code, experiment_design,
native_harness, result_verify, writing, runtime_maintenance. Registration fixes
workflow/role: research cannot relabel itself as maintenance. Mathematical/source
review alone is not a completed discovery/selection boundary.

## Agent guidance and ACP

`Controller(db_path, admission=ScientificAdmission())` composes the queue/checkers;
`Worker(controller, registry=None, ...)` claims one non-native task. SQLite WAL
transactions reserve slots and cumulative budgets. Bind real run/owner/fence and
native agent session before prompt dispatch; heartbeats retain the lease. Fixed
inputs, instruction bytes and skill digest are rechecked at claim and handoff.

`instruction_handoff(claim, max_bytes=2097152)` always embeds actual SKILL.md plus
modules selected by canonical `assets/runtime-guidance.json`. The version-1 index
has exactly version/actions; actions maps every fixed runtime action to a unique
list of existing canonical Markdown paths other than SKILL.md. All index paths
are validated, including other actions. Entry/module text has SHA-256; unselected
Markdown appears as canonical_catalog locators/hashes. guidance_index records the
actual index hash; guidance_notice requires reading further applicable modules.
Older skills without an index receive entry/catalog/notice. No action/index grants
permissions/readiness. Full skill digest is checked before/after canonical reads;
selected text and serialized envelope are bounded and fail instead of truncating.
This reduces repeated context, not total scientific reading obligations.

ACP is POSIX stdio JSON-RPC v1: initialize, session/new, session/load when actually
supported, text-only prompt/update, permission requests, explicit filesystem
handlers and cancel notification. No implicit images/terminal/auth/session-resume
extension. Python callers may supply trusted handlers/allowed tool kinds; CLI
supplies none. Unknown tools, handler exceptions and capability mismatches deny.
Vendor-internal tools/credentials can bypass client requests; configure actual
vendor/OS isolation separately. ACP is not an OS sandbox.

## Scientific admission

`ScientificAdmission` invokes current canonical project/method/native checkers
with actual pinned batch/plan refs and rechecks the skill digest. Source reading,
math review and writing need no artificial new intake; math_work checks the ledger.
Code requires current parent/Gate 0/IPCG and selected mathematical evidence.
Web design remains a complete generated draft; Local accepted design requires
current tested code. Native claims require local_executor and complete applicable
protocol/design/authority/resources; new scientific plans require method_discovery.

Reading pending results uses source_read. result_verify is the **verdict** boundary,
with current result/qualification evidence. Admission does not supply trusted live
native replay and never launches an implicit Web scorer; it can deny a complete
packet until trusted canonical verification. Actual approved native scoring/E04
and final method verification remain separate tasks/contracts. Engineering task
completion never grants a scientific verdict, Gate A, full validation or writing
eligibility. Explicit authorized runtime-engineering tests qualify only the runtime.

## Native execution and return

`NativeTarget(root, skill_root, host=None, python='python3')` contains trusted
absolute host paths, a plain SSH host/user@host and the actual Conda Python path.
Scientific native execution requires the separate SSH host. No-host mode permits
maintenance CPU only; local scientific/GPU dispatch is denied. GPU host needs
identical pinned skill/project sources, dependencies and assets, not the Python
controller library or GPU-side LLM agent. No Docker or invented upload service.

`NativeBridge.prepare/observe/execute` pins target, pool/batch/root/skill/plan/native
run identities. It queries the same identity before launch; only absent first
work starts. SSH uses explicit local argv and POSIX quoting. Target bootstrap
verifies the entire retained source digest before importing checkers, compiles
captured verified Python bytes and bypasses unpinned __pycache__; rechecks before
emitting observations. Live running requires /proc boot/start/PID identity;
completion requires actual receipts and output-byte verification. Stale text,
malformed responses, partial/changed state and lost processes are unknown.

`NativeWorker.run_once` binds this identity before dispatch and still requires
actual controller-local declared outputs. Copy/retrieve required outputs through
the authorized host mechanism and hash-check them against verified host receipts;
there is **no automatic artifact transfer**. Large artifacts may stay remote with
honest locator/hash records. Missing declared local bytes keeps reconciliation
pending even after verified host completion. GPU sharing requires the existing
measured peak/throughput/headroom contract, never number of agent slots.


Use one outer native_harness task around the batch's existing inner DAG of ideas
and experiments; never start one harness driver per idea on the same host pool.
The current harness permits one driver per pool. For several scientific projects
sharing that pool, the integration owner serializes native batches: this release
implements no cross-project GPU broker. Separate hosts/pools may run independently.

## Recovery and delivery

Lease expiry, interrupted dispatch or lost acknowledgment becomes
reconcile_required with held slot and reservations. Inspect the exact retained
backend/session or host/run identity with original owner/fence. ACP session/load
history proves neither stopped nor completed work; use actual provider observation.
Native inspect only observes. Reconcile never silently creates a retry: native
status must support the requested outcome, and completed checks actual local files.
No new session/run/batch IDs, state deletion, budget reset or blind retry on unknown.

Retain logs, receipts/hashes, exact commit/dirty patch, current/next node, remaining
budgets and scientific deficits. Submit consolidated Local results to the existing
project repo; one integration writer checks current main/expected parent, updates
literal main and reads back exact commit/files. Running workspaces stay pinned.
Web then reads raw evidence, joins paper/code/benchmark review and proposes the
next complete direction for human batch decision; no automatic branch selection.

## Limits and evidence

Unknown actual vendor cost charges the full micro-USD reservation. Uncertain work
holds the full reservation; restarts do not reset it. This is conservative local
accounting, not a provider billing firewall. Eight-hour reports are soft; finite
Local cycles <=24h/shorter authorized bounds and actual cumulative budgets bind.

Observable events retain exposed tool/source/state/model/usage metadata, not hidden
reasoning or universal cross-provider conversation conversion. Read-only MCP
negotiates 2025-11-25 and provides status/events/instructions only; no submission,
approval, scoring or execution tools. Instruction retrieval uses this same handoff.

Engineering subprocess/SQLite tests and local CPU native receipts qualify only
those interfaces. Authenticated Hermes/Codex/Claude/model runs and the owner's
SSH/GPU environment need real separate qualification; do not invent logs or claim
those deployments from unit tests. A usable scientific project handoff still needs
its own full data/model acquisition commands, runbook and acceptance conditions.
