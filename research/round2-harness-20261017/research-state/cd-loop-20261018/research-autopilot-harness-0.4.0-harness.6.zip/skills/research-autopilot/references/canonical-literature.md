# Canonical literature identities and versions

Count underlying works separately from source records and versions. An arXiv
preprint, its revised preprint, and its final proceedings/journal record can
represent one work. They can still differ in claims, theorem assumptions, read
depth, reproduction evidence, publication status, and priority dates.

Normalize only supplied identifiers: lowercase a supplied DOI, convert a supplied
DOI/arXiv identifier URL to its identifier, and separate an arXiv version suffix
from the underlying arXiv ID. Never infer a DOI from a title, venue, author list,
or a presumed publication; never fabricate one. Title similarity is a retrieval
clue, not identity evidence. Distinct arXiv and proceedings/DOI identities remain
distinct until a primary source explicitly links them.

## Retain an explicit primary link

Use additive `work-record` fields under schema version `1.0.0`:

| Field | Meaning |
| --- | --- |
| `work_id` | Supplied source identity, such as `arxiv:2401.00001` or a supplied DOI/proceedings ID. |
| `version_id` | Exact source version identity; keep native arXiv `v1`, `v2`, etc. distinct. |
| `identity_aliases` | Potential alternate identities; unsupported links remain unresolved. |
| `identity_links` | Explicit same-work links with retained primary identity evidence. |
| `canonical_work_id` | Derived identity for deduplicating underlying works. A declaration alone cannot create a link. |
| `publication_status` | `unknown`, `preprint`, `accepted`, `formally_published`, `unpublished`, or `withdrawn`. |
| `reproduction_status` | `unknown`, `not_attempted`, `in_progress`, `reproduced`, `failed`, or `partial`. |

An `identity_links` item has `from_id`, `to_id`, `relation: same_work`, and nonempty
`evidence_refs`. Its record must be one of the linked works. Each retained capture
has `capture_format: work-identity-link-v1`, the same relation and `identifiers`,
`primary_source: true`, an actual `source_url`, `locator`, and nonempty primary
`excerpt`. Typical sources include an arXiv DOI/journal-reference field, the
publisher/proceedings record identifying the preprint, or an author-provided
version note in the primary full text. Unsupported aliases stay in
`unresolved_aliases`; neither a generic source file nor a title-only claim can
certify the link.

The capture is a source adapter format. Preserve the underlying primary text
and audit that the locator/excerpt actually supports the identity assertion;
hashes and a `primary_source` field cannot make a false assertion true.

## Preserve per-version status

Each source version retains its own `read_depth`, `full_text_status`, claims,
evidence, publication date, `publication_status`, and `reproduction_status`.
A D2 preprint does not make the final version D2. A DOI does not establish formal
publication. D3 alone does not establish a successful reproduction. Accepted,
formally published, read, and reproduced are different facts and require their
corresponding primary evidence. When legacy records lack separate status fields,
both statuses remain `unknown`; do not silently upgrade them.

Without an explicit `version_id`, native arXiv identifiers produce
`arxiv:IDENTIFIERvN` when a version is available. Other records use
`SOURCE_ID#version` as a compatibility fallback. A legacy free-text `version`
field is not proof of an exact retrieved source revision. Retain source-native
version identity in new captures. Distinct source/version records cannot be
silently overwritten; conflicting records for the same canonical work/version
are a named error.

## Deterministic helper interfaces

`scripts/_literature.py` exposes:

- `canonical_work_id(root, work_record_or_id, records=None) -> str`.
- `canonicalize_search_records(root, records) -> dict` containing normalized
  version `works`, deduplicated `work_ids`, `version_ids`, `d2_work_ids`,
  `identity_evidence_refs`, and `identity_map`.

Normalized records keep their source `work_id` and add `canonical_work_id`,
`version_id`, `identity_status`, and `unresolved_aliases`. The helper uses only
the exact supplied records and referenced captures. It does not search the
network or scan a directory for later evidence. This makes canonicalization
deterministic for the frozen evidence set. The canonical identifier prefers a
supplied, linked DOI, then a supplied proceedings ID, then another supplied ID;
this is a stable identifier selection within that set, not publication evidence.
When newly captured primary evidence links an old preprint ID to its publication,
the new event explicitly resolves the old identifier through the new identity
map while older events retain their own captured evidence set.

Major functional-collision budgets count these underlying-work identities.
Repeated versions or a linked arXiv/final pair count once. Two genuinely distinct
works still force the existing per-parent restart. Missing links remain explicit
and cannot be silently guessed to avoid or trigger a restart.

Search replay must version the normalization algorithm. Existing `work-v1` /
`identifier-v1` captures retain their original digest and exact normalization.
After checking that digest, `replay_search` returns separate `canonical_identity`
metadata derived only from captured records/primary links. Original `works` and
`evidence_units` remain unchanged. The old digest does not prove newly supplied
alias evidence. A future normalizer that rewrites normalized records needs its
own explicit version. `1.0.0` artifact envelopes remain compatible through additive
fields, while parser/canonicalization/deduplication versions identify the actual
operation. D2 coverage counts underlying works, never duplicate source versions.
