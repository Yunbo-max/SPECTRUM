"""Cross-component engineering contracts; no scientific cases or scorer runs."""
import copy
import unittest
from fixtures import C, ProjectFixture, sample_artifacts, write
import _evidence as E
import _writing as W
from test_native_eval import native_contract_fixture


class IntegratedScopeTests(unittest.TestCase):
    def setUp(self):
        self.f = ProjectFixture()
        self.addCleanup(self.f.close)

    def two_benchmark_protocol(self):
        p = self.f.protocol("full-validation")
        primary = copy.deepcopy(p["native_eval_contract"])
        secondary = native_contract_fixture(self.f.root, p,
            namespace="engineering/secondary", benchmark_id="engineering-secondary-fixture")
        p["native_eval_contract"] = primary
        p["required_groups"] = ["main", "transfer"]
        p["native_eval_contracts"] = {"main": primary, "transfer": secondary}
        card = p["claim_cards"][0]
        card["scope"] = {"groups": ["main", "transfer"], "metrics": ["accuracy"],
            "evaluation_scopes": {group: {
                "benchmark_id": contract["benchmark_id"], "version": contract["benchmark_revision"],
                "split": contract["split"], "sample_manifest_ref": contract["sample_manifest_ref"],
                "metrics": ["accuracy"], "budget": contract["budget"]}
                for group, contract in p["native_eval_contracts"].items()}}
        return p

    def test_claim_can_bind_each_published_benchmark_group(self):
        p = self.two_benchmark_protocol()
        self.assertEqual(set(W.validate_claim_cards(p)), {"claim-1"})

    def test_one_group_scope_cannot_certify_a_different_group(self):
        p = self.two_benchmark_protocol()
        scopes = p["claim_cards"][0]["scope"]["evaluation_scopes"]
        scopes["transfer"] = copy.deepcopy(scopes["main"])
        with self.assertRaises(C.Failure):
            W.validate_claim_cards(p)

    def test_incomplete_claim_scope_is_a_named_contract_failure(self):
        p = self.two_benchmark_protocol()
        del p["claim_cards"][0]["scope"]["metrics"]
        with self.assertRaises(C.Failure):
            W.validate_claim_cards(p)

    def test_external_design_cannot_silently_use_builtin_mean_analysis(self):
        p = self.f.protocol()
        p.update(design="external", aggregation="project")
        p["protocol_digest"] = C.protocol_hash(p)
        runs, refs = self.f.runs(p)
        result = C.evaluate(self.f.root, p, runs, refs, "gate-a")
        self.assertEqual(result["outcome"], "INCONCLUSIVE")
        self.assertIn("EXTERNAL_DESIGN_REQUIRES_PROJECT_ANALYSIS", result["reason_codes"])

    def test_unknown_eligibility_policy_is_not_ignored(self):
        p = self.f.protocol()
        p["eligibility"]["omit_unfavorable_runs"] = True
        p["protocol_digest"] = C.protocol_hash(p)
        runs, refs = self.f.runs(p)
        result = C.evaluate(self.f.root, p, runs, refs, "gate-a")
        self.assertEqual(result["outcome"], "INCONCLUSIVE")
        self.assertIn("UNSUPPORTED_ELIGIBILITY_POLICY", result["reason_codes"])

    def test_parent_benchmark_cannot_be_silently_replaced(self):
        from ipcg_fixtures import parent_card
        parent = parent_card()
        pref = write(self.f.root, "problems/scope.json", parent)
        p = self.f.protocol()
        p["parent_problem_ref"] = pref
        p["native_eval_contract"]["benchmark_id"] = "another-task"
        self.assertTrue(hasattr(E, "verify_problem_eval_binding"))
        with self.assertRaises(C.Failure):
            E.verify_problem_eval_binding(self.f.root, p, pref)

    def test_captured_identity_map_does_not_change_legacy_normalized_digest(self):
        from test_literature_versions import LiteratureVersionTests
        helper = LiteratureVersionTests()
        helper.f = self.f
        records, source = helper.linked()
        for record in records:
            record["publication_date"] = "2024-01-01"
        records = sorted(records, key=lambda r: r["work_id"])
        captured = {"works": records, "evidence_units": []}
        capture = write(self.f.root, "evidence/search-capture.json", captured)
        search = copy.deepcopy(sample_artifacts()["search-run"])
        search.update(raw_capture_refs=[capture], returned_count=2,
            normalized_output_digest=C.hashed(captured), cutoff="2026-10-03")
        result = E.replay_search(self.f.root, search)
        self.assertEqual({k: result[k] for k in captured}, captured)
        self.assertEqual(result["canonical_identity"]["work_ids"], ["doi:10.1234/example"])
        self.assertEqual(result["canonical_identity"]["identity_evidence_refs"], [source])


if __name__ == "__main__":
    unittest.main()
