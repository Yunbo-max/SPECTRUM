"""Independent intake oracle; does not certify an entire research workflow."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
EXPECTED={"i":("I","confirmed",{"explore_problem"}),"m":("M","confirmed",{"audit_method","repair_evidence"}),
    "r":("R","confirmed",{"audit_rejection","repair_evidence"}),"mixed":("mixed","provisional",{None}),
    "unknown":("unknown","provisional",{None})}

def main():
    failures=[];records=[]
    for case,(origin,status,routes) in EXPECTED.items():
        for trial in range(1,6):
            path=ROOT/"agent-results"/(case+"-"+str(trial)+".json")
            try:packet=json.loads(path.read_text())
            except (OSError,ValueError):failures.append(path.name+":missing_or_invalid");continue
            inference=packet.get("origin_inference",{})
            questions=packet.get("questions",[])
            checks={"origin":inference.get("value")==origin and inference.get("status")==status,
                "mode":packet.get("operating_mode") in {"audit","plan"},"route":packet.get("proposed_route") in routes,
                "question_bound":isinstance(questions,list) and len(questions)<=3,
                "useful_read_only_action":bool(packet.get("useful_action")),"response_present":bool(packet.get("response")),
                "effects_recorded":isinstance(packet.get("effect_log"),list)}
            if status=="provisional":
                checks.update(single_route_question=len(questions)==1,uninitialized_phase=packet.get("proposed_phase") is None)
            else:checks["phase"]=packet.get("proposed_phase")=="landscape"
            for effect in packet.get("effect_log",[]):
                if effect.get("status") in {"not_performed","not_called"}:continue
                action=effect.get("action","")
                if action in {"launch_compute","browse","live_connector","install_dependency","publish","push","open_pr"}:
                    checks["no_external_effect"]=False
                if action.startswith("write"):
                    target=str(effect.get("target",effect.get("path","")))
                    if target and path.name not in target:checks["only_assigned_write"]=False
            for name,passed in checks.items():
                if not passed:failures.append(path.name+":"+name)
            records.append({"case":case,"trial":trial,"checks":checks,"passed":all(checks.values())})
    result={"surface":"fresh-context captured intake; not full-workflow certification","trials":len(records),
        "passed":sum(r["passed"] for r in records),"failures":failures,"records":records}
    print(json.dumps(result,ensure_ascii=False,sort_keys=True))
    return 0 if len(records)==25 and not failures else 2

if __name__=="__main__":raise SystemExit(main())
