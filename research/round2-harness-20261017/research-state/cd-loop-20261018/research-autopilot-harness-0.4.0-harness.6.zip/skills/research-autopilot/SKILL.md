---
name: research-autopilot
description: "Use for sustained one-field research with existing local agents executing and accepting the existing Autopilot Skill in program-owned order."
---

# Research Autopilot

## Work Harness C/D profile

Restore `sequence.flow_profile` before applying inherited workflow rules. For
`work-harness-cd-v1`, read [C/D mathematical diagnosis and executable idea development](references/cd-math-code-loop.md).
The versioned catalog `assets/skill-sequence-cd-v1.json` and its overriding node
guides govern C's condition/failure/dependency diagnosis, D's mechanism construction
and real local experiments, reviewed B/C/D revisits and M05 `VERIFIED_FOR_SCALEUP`.
B05 validates a supported problem contract; old Natural Gate 0/IPCG prerequisites
do not apply to this profile's local diagnostic/development work. Independent
verified review plus program checks advances automatically into E, which retains
full settings, freezing, fair comparisons, scale and confirmation.

The worker proposes typed revisits and code applies approved transitions; no raw
skip/jump is allowed. Preserve source/evidence lineage, failed findings, external
jobs, cumulative usage and pause state. Omitted `flow_profile` retains legacy
catalog/transition behavior. Profile-specific rules override conflicting inherited
C/D ordering/admission text below only when the profile is actually adopted.
Installation alone does not migrate a running project or change another edition.

Use GitHub only for direct pull/read and push/write; follow the GitHub storage
policy in [edition-policy.md](references/edition-policy.md). Experiments and
continuation run on the authorized host, without GitHub Actions or workflow runs.
If GitHub cannot be read/written or upload verification is unavailable, immediately
follow [downloadable ZIP fallback](references/github-zip-fallback.md): preserve
code, results, logs and the checkpoint, verify a real ZIP, and provide its download
link with remote synchronization explicitly pending or unknown.

## Execute and accept the existing Skill in program order

Read [skill-sequence.md](references/skill-sequence.md) before any program task.
The program owns the canonical 84-node order, current step, acceptance and
repeat/once behavior. The `planner` transport role is the current-step worker;
it cannot choose a successor, skip a step or end the goal. Read the assigned node,
perform its work, bind fixed requirements to real evidence, read back child-task
results, and obtain separate review before code advances the cursor. Every node
is represented; only program rules can mark user-unrequested optional scopes
inactive. This ordering rule governs inherited next-action wording below.

The scientific method is unchanged: deepen one field through papers/code,
purposeful reproduction, concrete questions, mathematical modeling as needed,
credible benchmarks and strong baselines, actual results and knowledge updates.
New program contracts use schema 2 with mandatory research scope. Manuscript,
revision, release and communication scopes require the actual user objective;
source updates do not authorize extra publication or migrate existing programs.

## Deepen one field; use mathematics and experiments for its questions

Read [research-cycle.md](references/research-cycle.md) at field intake, idea formation
and consequential result interpretation. Keep the selected field and cumulative
knowledge stable while revising questions and hypotheses. Deep reading, code tracing
and purposeful baseline reproduction build the understanding needed to identify a
specific limitation or changed condition. Mathematical modeling and optimization
serve that problem; experiments test explicit explanations and predictions. Work
on the assigned node’s knowledge or evidence question, including further reading
when needed; program code retains the sequence cursor.
Retain strong/simple alternatives, native evaluation, full costs and negative findings.
Reuse mature evidence and proceed when a decisive comparison is already justified.


Before substantial method investment or changed-condition experiment design, use
[benchmark discovery](references/benchmark-discovery.md) to establish a credible
validation path: original native benchmark if suitable; otherwise search published
variants/new datasets through primary sources, Web and accessible discussion leads.

## Local control and SSH execution

Before GPU-dependent design or code, use [GPU intake and feasibility](references/gpu-intake-feasibility.md): ask for a missing execution target, reuse supplied SSH authority, inspect real hardware/native precision and qualify the intended stage before promising it fits.

The local agent supervises from the user's computer. At startup/resume and before
execution, read [local-execution.md](references/local-execution.md): restore existing
authorized SSH GPU targets, reconcile jobs, choose the actual task host, fetch/pull
the pinned code there, qualify its native environment and resources, submit bounded
jobs and collect real results. Reuse existing SSH authority. Do not default heavy
training/evaluation to the user's computer or require a GPU-side LLM agent.

All editions and all hosts use native execution. Docker, Compose and Docker-in-
Docker are excluded everywhere; do not install/run them or use hidden Docker
helpers. Follow edition-policy.md for native alternatives and unresolved gaps.

Use [native scoring stages](references/native-scoring-stages.md) before treating
scorer readiness as a launch blocker. Restore the project's real delayed-scoring
mode: independent training/prediction export can proceed with scoring pending.
Use a native scorer later; score feedback actually consumed by training remains
that stage's dependency. Keep unscored outputs and real results distinct.

## B01 configuration before experiments

Use [B01 upstream setup](references/b01-upstream-setup.md): configure the published
assets and actual executor, verify imports/startup on the execution host, retain
its provenance and outstanding scoring gaps, and submit setup acceptance.
Do not turn this stage into repeated scientific scorer certification.

## Evidence reuse across preparation and analysis

At S01, E01 and B02, both worker and reviewer apply
[evidence reuse and stage dependencies](references/evidence-reuse-and-stage-dependencies.md).
Reuse sufficient existing benchmark, environment and result evidence; collect only
the specific missing evidence that the current step actually needs.

## Experiment execution

Read [single-experiment batching](references/single-experiment-batching.md) before
experiment design and dispatch. Run one experiment program at a time; calibrate
supported batches from large to small (e.g. 64 → 32 → 16 → 8 → 4 → 2), then freeze
a stable setting with good measured throughput and headroom. Preserve effective
batch and native protocol semantics. Main/Work/Work Harness/Simple use the actual authorized
target; Chat stays CPU-only under its total 4 GB planning ceiling.

## Current edition: Research Autopilot Work Harness

Read [edition-policy.md](references/edition-policy.md) and
[research-harness.md](references/research-harness.md),
[round-continuation.md](references/round-continuation.md) and
[resource-queue.md](references/resource-queue.md) first. They govern
decision ownership, execution host and continuation across every module below.
Version: `0.4.0-harness.6`; branch: `autonomous-rsi-harness`.
Keep the current Codex or other supported local agent. This fifth Work-derived
edition adds a persistent whole-goal program with fixed Skill order: the
current-step worker, independently executed review, v4 decision admission,
native task execution, result readback, per-step acceptance and recovery. A worker queue or a monitor alone is insufficient.
The four-skill ZIP supplies the policy; install the same branch's source runtime
separately to use `research-autopilot-program`. Neither source publication nor
plugin installation starts a service or proves unattended operation.


## Autonomous Work Harness edition

Use the current host to complete the authorized research goal. Read
[local-execution.md](references/local-execution.md) and
[autonomous-rsi.md](references/autonomous-rsi.md), plus the [project cooperation](references/project-cooperation.md) contract for actual participants; reuse
unchanged project/source findings while restoring the actual pinned policy for
each new invocation under research-harness.md. These edition rules select local-agent execution and replace inherited mandatory
separate Local/SSH backend setup, routine human batch selection and the 20-to-15 default.
The scientific evidence requirements continue at the scope of the actual claim.
Other references supply task-specific detail; they do not restore those defaults.

Within the initial scope and finite budget, execute the program-assigned step,
inspect its real results, repair or revise within that step, and submit evidence
for separate acceptance. A report, candidate failure or unavailable optional
backend does not advance the cursor or finish the goal. Only program rules govern
ordered repetition and completion; user pause, exhausted limits and genuine
blockers retain the current step. Preserve its exact identity and observed state.

## Optional Xiaohongshu source at idea intake

At new research/idea startup, offer once: “启用小红书只读 MCP，先从真实讨论里
找问题，再用论文和代码核验 / 跳过，直接做论文和代码调研”. Reuse an explicit
project choice; no answer means deferred and normal research continues. When enabled,
use discussion, troubleshooting, questions and experience reports as a first-class
problem-discovery source; papers are essential for checking prior work and claims,
but are not the only or default source of valuable research questions. Read
[xiaohongshu-idea-discovery.md](references/xiaohongshu-idea-discovery.md) for the
choice/access states, discussion-first sampling, MCP usage and primary-source
verification. Select only discussion-style text/image posts; skip promotional
posts and videos. Never claim connected access from an enabled preference. Restore
the choice on resume; do not ask every round or start an unattended scraper.
Social claims remain leads until matched to papers/code and appropriate evidence.
This optional source preserves this edition's direction ownership and scope.

## Frame the question before selecting mathematics

Use [inquiry-generation.md](references/inquiry-generation.md) at a substantive new
question, changed object/information condition or consequential contradictory result.
Preserve the user's goal; question the current target, information, objective and
consequential representation/cost assumptions before choosing familiar operations.
Separate unexplained leads, mechanism hypotheses and executable constructions.
Mathematics-first and phenomenon-first investigation are both legitimate. Compare
conditional predictions, not candidate names; do not force an alternative quota.
Unknown routes are not low-value by default, and operation coverage is not a reward.

New decisions use **v4**, embedding inquiry in the existing decision. A lead can run
a bounded, receipt-linked diagnostic without a completed derivation. A construction
retains the existing DAG, quality and canonical comparison obligations. Consume actual
probe outcomes before the next selected task; reuse unchanged frames and math for
routine repairs/seeds. No new database or scheduler is introduced. This is a discovery
contract, not an automatic theorem prover or a guarantee of diverse/novel ideas.

## Link the goal, metric, comparator and executable method

Use [goal-linked-quality.md](references/goal-linked-quality.md) with the derivation DAG.
Construction decisions retain v3 quality_ref and trajectory checks inside v4.
Keep record integrity, scientific validity, parent-goal relevance and investment value
separate; there is no aggregate PASS score. Bind primary/proxy/guardrail metrics,
information set, formula-to-code terms, strong comparator, actual data population,
full cost and unresolved required comparisons to the same selected task IDs.
Ordinary fixes and extra prespecified seeds reuse unchanged derivations. Acquisition
and diagnostic work remain possible while dependent claims/expansion wait.

Test the critical link before increasing repetitions: the strongest compatible baseline,
actual objective/update semantics or the proxy-to-target relationship. Native-benchmark
requirements cannot remain indefinitely in 'next round' while toy comparisons expand.
Valid negative findings count; better proxy values, more files and classic-component
sanity checks do not establish primary improvement or novelty.

For resources, source access and archive work, use [operational-recovery.md](references/operational-recovery.md).
The local helpers provide actual observations, cooperating same-host reservations,
and explicit-file incremental storage, not cross-cloud scheduling or automatic project
migration. Preserve user pauses, unknown jobs, original files and remote verification.
Skill-read failure is recoverable waiting, not authority to silently disable a scheduler.

## Bind mathematics, evidence and the selected action

For substantive constructions, read [math-handoff.md](references/math-handoff.md)
and the relevant [operation graph](references/math-operation-graph.md). Preserve
objects, conditions, consequential intermediate steps, error obligations, the
executable rule, rival predictions and falsifiers. Reuse valid prefixes; invalidate
affected descendants when premises change. No all-48 traversal or proof-length quota.

At meaningful boundaries use [research-reasoning.md](references/research-reasoning.md)
to compare parent-goal value, a real alternative, family effort and what a repair
actually unlocks. Bind the selected task to the accepted v4 inquiry, and for
constructions to its DAG/quality records. Read terminal results before selecting
another task. One expensive candidate can contain multiple competing explanations.
Park, refutation and invalid execution are distinct. Checkers validate declared links,
not mathematical truth, novelty, independent review or long-horizon compliance.
Adopt new source/policy only at a quiet project boundary; preserve pauses, history,
usage and original task pins. Package updates alone do not migrate or resume projects.

## Start or resume

Restore the local workspace and any established human handoff first. When actual
independent participants share work, use project-cooperation.md and the existing
authorized registry to avoid duplicate jobs and conflicting writes. Same-workspace
subagents use local coordination. A solitary local agent or a sequential human
handoff does not require a GitHub registry before useful work. Reuse destinations.

Restore the actual goal, project/revision, candidate lineage, procedure version,
evidence, current attempts, delivery targets and cumulative usage. Reconcile
uncertain operations before retrying; reuse valid completed work. Establish the
current host's actual tools and resources. Use the actual local agent and its local tools. A separate ACP/SSH/SQLite
backend remains optional for inherited Work workflows; this edition's managed
research loop uses its installed program runtime. ACP is optional; use the actual
existing command-agent backend. Bind supported host continuation under
research-harness.md and round-continuation.md. Do not label a standalone worker
or report-only monitor as the active research decision program.

Record the actually loaded plugin/source, adopted project procedure and invocation
contract separately. Restore pause before selecting work. Read the pinned adopted
procedure on each actual invocation; source publication alone does not refresh an
installed plugin or a scheduled prompt. Missing capabilities block affected work,
not unrelated source acquisition. See [research decisions](references/chat-research-decisions.md).

Report every newly observed operational anomaly through the live host's user-facing
output, including unavailable CPU/Python, missing skill, failed storage and unknown
child state. Reporting must not depend on the failed execution tool. Retain the
incident, attempted delivery and actual receipt separately; a queued report or
saved file does not establish notification. Read
[incident reporting](references/chat-incident-reporting.md). Keep explicit user
pauses intact; report maintenance never resumes research.

Check the host's actual subagent APIs and current capacity. When independent
ready work can benefit, use a bounded parallel wave under the same candidate and
parent attempt; read [Chat parallel work](references/chat-parallel-work.md).
Bind real child identities and inspect their results. Use serial execution when
the capability or capacity is unavailable; never assume a fixed agent quota.

Retain the original user request and later scope changes with source references.
Separate the project goal from the current milestone. Use research mode for
authorized continuing inquiry; CPU feasibility or paper selection then remains
a prerequisite. Use bounded_task for an explicitly scoped selection, reproduction,
audit or artifact request; loading this skill does not expand that scope. Do not
replace a broader research request with an easier milestone and call it completed.
Use the goal contract and completion review in chat-execution.md. Count actual
runs separately from scientific cycles; one candidate at a time is not one round
per goal. Resume the original cumulative limits rather than inventing a new quota.

For a new project, reuse supplied targets and infer routine reversible choices
from the task. A missing optional HF target or route label must not block useful
investigation. Resolve only concrete missing authority, access or scope choices.
Record finite working limits; do not repeatedly ask for already supplied approval.
Use [workflow-harness.md](references/workflow-harness.md) for the assigned action and
[research-policy.md](references/research-policy.md) only for applicable details.

## Project cooperation barrier

Apply project-cooperation.md when actual independent participants concurrently
share a project. Restore the authorized registry, observe relevant evidence,
claim jobs conditionally and reconcile unknown writes before retry. A solitary
local agent needs no cloud registry. Same-workspace children use disjoint paths
and one integration owner; main's sequential human-mediated handoff uses concrete
packets. Never invent peers, scan unrelated conversations or duplicate a live job.
Keep source pins, cumulative budgets and pauses through every handoff.

## Essential scientific obligations

- Join primary papers/full text, actual implementations and established benchmark
  protocols. Before empirical design, read
  [paper-grounded experiment design](references/paper-grounded-experiment-design.md):
  extract published experiments from main text, appendix and code/configs, then
  justify which practices to adopt, adapt or reject for the actual claims.
  Recheck changed dependencies; reuse unchanged pinned reads.
- Default to one hypothesis per iteration. Retain a consequential derivation,
  assumptions, constructed rule, prediction, falsifier and independent review.
  The canonical batch uses pool_target=1 and selection_target=1 with the explicit
  edition target_override described in chat-execution.md. Broader discovery is
  an intentional mode, not a prerequisite for every repair.
- Before substantial candidate investment, inspect closest primary work, the
  qualified strongest simple alternative, value, mechanism and falsifier. Track
  hypothesis families and retire refuted or redundant mechanisms. Cheap parallel
  investigation of competing explanations need not create multiple expensive
  candidate campaigns.
- Obtain missing baseline/resource/scorer evidence through feasible preflight
  work. Require applicable Parent/Gate 0/IPCG and method evidence before investing
  in a new candidate; missing evidence generates an acquisition/check task.
- Preserve published native data, splits, labels, metrics and scoring for native
  benchmark claims. Development diagnostics and engineering tests are allowed
  for their stated purpose; they cannot substitute for scientific comparisons.
- Write complete designs for the requested scope, including comparisons,
  controls, uncertainty, resource assumptions and reproducible commands. Keep
  a claim-to-experiment contract whose required coverage survives finite batches.
  Use observed authorized compute and measured calibration; historical GPU
  ownership is not current access. Keep development separate from frozen
  confirmation. Do not tune on confirmation.
- Run available authorized checks on the current host. Retain real output and
  error records. Apply E04 and independent verification before scientific
  conclusions. Authored, executed, scoped-supported and final-claim states differ.
- Route failures by cause: environment/configuration to setup; implementation to
  repair; evidence gaps to collection/review. For valid counterevidence identify
  the claim and conditions actually refuted; supply the current node’s required
  reading, reproduction, diagnosis or revision evidence. Retain justified successor
  hypotheses without moving the cursor. A candidate KILL preserves the research
  goal and history. Explicit user/project stop remains terminal; other admitted
  child work for the same node may continue.
- Program code owns cycle/goal closure under repeat/once semantics, with required
  evidence and delivery receipts. No-gap or a positive review alone is not proof
  of acceptance or complete delivery.
  Writing states the scope and limitations of actual evidence.

Read [method-verification.md](references/method-verification.md),
[full validation](references/full-validation-and-review.md),
[development](references/development-and-execution.md),
[Gate A](references/gate-a.md), [native evaluation](references/native-evaluation.md)
and [claims](references/statistics-and-claims.md) at their relevant boundaries.

## Roles and actual execution

Proposal, review and control are separate responsibilities on the actual host,
not mandatory separate computers. Use genuine independent review tasks when
available. A missing reviewer leaves affected acceptance pending and does not
block unrelated work. A second self-authored success sentence is not verification.
Give reviewers frozen evidence and acceptance criteria without the author's
expected verdict. Parallel readers, disjoint writers and reviewers retain their
actual identities; only the coordinator integrates and publishes. Child completion
is not a scientific pass or a reason to end the research loop.

Restore the authorized execution target and inspect its actual compute, data,
runtime and budget. The local control agent submits feasible commands on that
target and collects measured evidence; its own computer is not the default GPU host. Use no Docker
and assume no GPU or paid model service. Missing capabilities remain explicit.
The generated_unexecuted label applies only while an artifact is actually
unexecuted, not permanently to everything produced through a Web interface.

Restore existing SSH/runbook choices at startup; reuse already authorized targets.
Read full-runtime setup only when that particular runtime is selected.
Do not require Local handoff files for a host-contained project. Do not relabel a
scientific workload as maintenance to evade evidence requirements.

## Runtime library and recovery

For strategy migration, invocation reads, durable manifests and command receipts,
read [Chat control records](references/chat-control-records.md). New research
dispatch uses sourced decisions and current invocation observations; legacy
settlement and explicit user pauses remain intact.

The local agent controls the active loop and supervises jobs on their selected
local or authorized SSH execution targets. This fifth edition's managed loop
uses its separately installed research-program runtime; read
[research-harness.md](references/research-harness.md). Existing command agents
need no ACP adapter. Read [runtime-library.md](references/runtime-library.md)
when configuring the underlying controller or optional ACP/native backend.

Persist coherent artifacts and source-bound checkpoints at milestones and before
yielding; use scripts/chat_cycle.py when available for revision-checked action
bookkeeping. Select work by outstanding goal obligations and expected decision
value; bound diagnostics and review stagnation using
[research decisions](references/chat-research-decisions.md). Use advance to obtain
the actual pinned procedure text and action,
then execute it with real host tools, optionally dividing independent work into
bounded child packets under that parent attempt. Reconcile and integrate the wave
before recording the parent result and calling advance again in the same active
turn; no user confirmation is needed for routine in-scope continuation. See
chat-cycle-records.md for parallel events, classified repair and versioned outputs.
The helper is neither a scheduler nor a scientific verifier. Restore unfinished
attempts and exact partial work on continuation; do not restart from a summary.

Keep failures, cumulative budgets and stable side-effect identities. Reconcile
lost acknowledgements before retrying. Repair dependent tasks against the real
replacement outputs; never turn an old failure into a pass or mutate live pins.
Accept a procedure update only after fixed checks and review, persist/read its
version for the next round, and preserve rollback. Installed plugins and running
attempts are not silently updated by a project-local procedure change.

## Navigation and delivery

The [node index](references/node-index.md) remains 84 tasks, 16 regions and 221
conditional relationships. They are navigation, not a mandatory execution DAG,
new scientific gates or authorization. Load selected exact bound sections with
`python3 "$SKILL_DIR/scripts/research_nodes.py" show NODE_ID`; `check` validates
source/graph integrity only. Runtime queues schedule actual finite dependencies.

For authorized Web GitHub code/design delivery, use the selected project's delegated
target branch, one integration writer, current expected-parent update and exact commit/
file readback; preserve others' work and pinned running workspaces. Return actual
repo/commit/packet paths. Local returns raw receipts/results, E04 and continuation/
budget gaps for Web review; fetch the supervisor-admitted next revision without
changing live attempts or repeating completed work. Reuse startup destinations
and scoped connections; report unavailable reads/writes honestly.

STOP, NO NEW IDEA NEEDED, REPAIR EVIDENCE and RETARGET WRITING are valid. Retain
next action on pause. Before retrying any external operation reconcile its real
provider ID; without queryable identity/idempotency after lost acknowledgment,
report the blocker. Do not auto-install dependencies, launch paid compute,
fabricate approvals/receipts or treat local records as a shared-host upload.

## Progress observations

At project start/resume, meaningful task/stage changes, blockers, handoffs and
before yielding, follow [progress-observability](references/progress-observability.md).
Keep task descriptions, responsible actor, observed timestamps, blocker and next
action; export the existing Local controller read-only. Observer failures warn
without blocking research. This adds no gate, verdict, background activity or
permission; the selected edition still owns execution and step-7 decisions.
Track coverage, qualified baselines, critical dependencies, hypothesis evidence,
review and delivery separately from run counts. Retain valid negative progress;
do not reward repeated nearby experiments or call a stage number a research cycle.

Operational anomalies require a visible report when first observed, before a
repair can hide them. Record a concise failure, impact, actual process/checkpoint
state and next action; report material escalation and verified recovery. Use an
already authorized host notification/scheduler when actually available. Preserve
pending/unknown/failed/unavailable delivery explicitly and reconcile uncertain
sends before retrying. Routine negative scientific findings and intentional pause
are normal states; exhausted resources still need an explicit status report.

## Module reading triggers

Load [local-execution.md](references/local-execution.md) and
[autonomous-rsi.md](references/autonomous-rsi.md) first. Then load the current
action's required modules and exact bound node sections; reuse valid pinned
notes instead of rereading the entire map/package. Complete required work and
inspect changed sources; progressive reading never weakens a scientific gate.
All detailed entry policy is in [research-policy.md](references/research-policy.md).
Read its Start and resume/Research loop sections at the matching scientific handoff;
use its section contents/search (`rg '^##'`) for intake, specialty and external rules.
Read the corresponding direct modules below before the indicated action. Internal
node excerpts reuse these sources; external writing/figure skills stay siblings.

| Read when | Module |
|---|---|
| Project startup/resume, after every cycle, or before dispatch with other participants | [Project cooperation](references/project-cooperation.md) |
| Start/resume, progress events or private dashboard export | [progress-observability](references/progress-observability.md) |
| Any operational anomaly, lost execution capability, report delivery failure or authorized background observation | [Chat incident reporting](references/chat-incident-reporting.md) |
| Active Chat startup/resume, foreground production or continuation | [chat-execution](references/chat-execution.md) |
| Research startup, task selection, candidate investment, batch boundary or stagnation | [Chat research decisions](references/chat-research-decisions.md) |
| Host subagent capability, parallel dispatch, independent review or child recovery | [Chat parallel work](references/chat-parallel-work.md) |
| Autonomous startup/resume, step 7 routing or external skill evolution | [autonomous-rsi](references/autonomous-rsi.md) |
| Before any bundled artifact/script operation | [artifact-contracts](references/artifact-contracts.md) |
| Canonical literature | [canonical-literature](references/canonical-literature.md) |
| Capability source catalog | [capability-source-catalog](references/capability-source-catalog.md) |
| Collision audit | [collision-audit](references/collision-audit.md) |
| Contribution value gates | [contribution-value-gates](references/contribution-value-gates.md) |
| Overlapping workers/jobs and measured GPU sharing | [dependency-resource-scheduling](references/dependency-resource-scheduling.md) |
| Execution/E04, scientific debugging/fair tuning | [development-and-execution](references/development-and-execution.md) |
| Editable writing artifacts | [editable-writing-artifacts](references/editable-writing-artifacts.md) |
| Evaluation and assets | [evaluation-and-assets](references/evaluation-and-assets.md) |
| Execution and handoffs | [execution-and-handoffs](references/execution-and-handoffs.md) |
| Before empirical design, changed claims or changed compute allocation | [paper-grounded experiment design](references/paper-grounded-experiment-design.md) |
| G01, complete validation, review/rebuttal | [full-validation-and-review](references/full-validation-and-review.md) |
| Gate a | [gate-a](references/gate-a.md) |
| Gpu host runtime | [gpu-host-runtime](references/gpu-host-runtime.md) |
| External operations, isolation and sanctioned lineage replacement | [host-adapters](references/host-adapters.md) |
| Human ai supervision | [human-ai-supervision](references/human-ai-supervision.md) |
| Human question bank | [human-question-bank](references/human-question-bank.md) |
| Idea generation | [idea-generation](references/idea-generation.md) |
| Importance preserving gate | [importance-preserving-gate](references/importance-preserving-gate.md) |
| New scientific intake/destination/resource questions | [initial-intake](references/initial-intake.md) |
| Literature evidence | [literature-evidence](references/literature-evidence.md) |
| Literature harnesses | [literature-harnesses](references/literature-harnesses.md) |
| Populate project Local runbook and acquisition commands | [local-code-handoff](references/local-code-handoff.md) |
| Executable Linux work and host resource admission | [local-execution-harness](references/local-execution-harness.md) |
| Full skill installation and actual session capture | [local-installation-and-logging](references/local-installation-and-logging.md) |
| Math analysis moves | [math-analysis-moves](references/math-analysis-moves.md) |
| Math analysis | [math-analysis](references/math-analysis.md) |
| Math derivation paths | [math-derivation-paths](references/math-derivation-paths.md) |
| Math handoff | [math-handoff](references/math-handoff.md) |
| Math opd reading audit | [math-opd-reading-audit](references/math-opd-reading-audit.md) |
| Math operation graph | [math-operation-graph](references/math-operation-graph.md) |
| Math paper atlas | [math-paper-atlas](references/math-paper-atlas.md) |
| Math worked examples | [math-worked-examples](references/math-worked-examples.md) |
| Mathematical empirical inquiry | [mathematical-empirical-inquiry](references/mathematical-empirical-inquiry.md) |
| Method development tree | [method-development-tree](references/method-development-tree.md) |
| Selection/code/design/dispatch/verdict evidence boundary | [method-verification](references/method-verification.md) |
| Multi route supervision | [multi-route-supervision](references/multi-route-supervision.md) |
| Native evaluation | [native-evaluation](references/native-evaluation.md) |
| Native runner | [native-runner](references/native-runner.md) |
| Selected map node/source binding retrieval | [node-index](references/node-index.md) |
| Paper knowledge loop | [paper-knowledge-loop](references/paper-knowledge-loop.md) |
| Project chat instructions | [project-chat-instructions](references/project-chat-instructions.md) |
| Release and promotion | [release-and-promotion](references/release-and-promotion.md) |
| Repository round trips | [repository-round-trips](references/repository-round-trips.md) |
| Research quality bar | [research-quality-bar](references/research-quality-bar.md) |
| Research websites | [research-websites](references/research-websites.md) |
| Finite Local batches, reports and human convergence | [rolling-research-batches](references/rolling-research-batches.md) |
| State and routing | [state-and-routing](references/state-and-routing.md) |
| Statistics and claims | [statistics-and-claims](references/statistics-and-claims.md) |
| Visual map maintenance | [visual-map-maintenance](references/visual-map-maintenance.md) |
| Foreground Web authoring, milestone checkpoints and resume | [web-background-work](references/web-background-work.md) |
| Start/resume or changed scientific code/design direction | [workflow-harness](references/workflow-harness.md) |
| Fifth-edition full-goal decisions, command agents, review and recovery | [research-harness](references/research-harness.md) |
| Runtime/backend/queue/recovery/result return | [runtime-library](references/runtime-library.md) |

Before new CPU or local agent execution, read [resource-queue.md](references/resource-queue.md). Attach measured resource contracts, preserve FIFO waits and automatic rechecks, and separate engineering recovery from scientific evidence.
