"""Real checker and CPU executor regressions, not independent research reviews."""
import copy
import json
from pathlib import Path
import sys
import time
import unittest
import test_goal_linked_quality as quality_fixtures
import test_research_reasoning as reasoning_fixtures
S=Path(__file__).resolve().parents[1]/'scripts';sys.path.insert(0,str(S))

class BindingTests(unittest.TestCase):
    ref=quality_fixtures.QualityTests.ref
    packet=quality_fixtures.QualityTests.packet
    def setUp(self):
        quality_fixtures.QualityTests.setUp(self)
        self.f=reasoning_fixtures.ReasoningTests();self.f.setUp();self.addCleanup(self.f.doCleanups)
        self.root=self.f.root;self.n=1000;self.evidence=self.ref('quality binding fixture')
        import research_reasoning
        self.r=research_reasoning
    def decision(self):
        d=self.f.adaptive_decision();d['schema_version']=3;d['quality_ref']=self.ref(self.packet());return d
    def task(self,ref):
        return dict(task_id='task',research_scope='method',reasoning_ref=ref,input_refs=[ref],phase='experiment')
    def test_v3_quality_is_checked(self):
        d=self.decision();r=self.r.check_decision(self.root,d)
        self.assertEqual(r['status'],'record_complete',r['gaps'])
        self.assertIn(d['quality_ref'],r['required_input_refs'])
    def test_v3_cannot_omit_quality(self):
        d=self.decision();del d['quality_ref'];r=self.r.check_decision(self.root,d)
        self.assertIn('quality_required',{x['code'] for x in r['gaps']})
    def test_v3_cannot_launch_expansion_with_baseline_debt(self):
        d=self.decision();q=self.packet();q['stage']='expand';q['baselines'][0]['status']='planned';d['quality_ref']=self.ref(q)
        r=self.r.check_task(self.root,self.task(self.ref(d)))
        self.assertIn('strong_baseline_unqualified',{x['code'] for x in r['gaps']})
    def test_quality_cannot_call_experiment_a_derivation(self):
        d=self.decision();q=self.packet();q['stage']='derive';d['quality_ref']=self.ref(q)
        r=self.r.check_task(self.root,self.task(self.ref(d)))
        self.assertIn('quality_stage_mismatch',{x['code'] for x in r['gaps']})
    def test_v3_quality_task_linkage_is_exact(self):
        d=self.decision();q=self.packet();q['selected_task_ids']=['wrong'];d['quality_ref']=self.ref(q)
        self.assertIn('quality_task_mismatch',{x['code'] for x in self.r.check_decision(self.root,d)['gaps']})
    def test_v3_cannot_downgrade_to_skip_quality(self):
        d=self.decision();old=self.ref(d);d.update(schema_version=2,previous_ref=old,decision_id='downgrade')
        self.assertIn('quality_policy_downgrade',{x['code'] for x in self.r.check_decision(self.root,d)['gaps']})
    def test_quality_source_is_immutable_between_intake_dispatch(self):
        d=self.decision();task=self.task(self.ref(d));task['input_refs']=self.r.require_task(self.root,task,expand=True)
        (self.root/d['quality_ref']['path']).write_text('{}')
        with self.assertRaises(ValueError):self.r.require_task(self.root,task,expand=False)
    def test_chat_intake_pins_and_rechecks_quality(self):
        if not (S/'chat_cycle.py').is_file():self.skipTest('This edition has no Chat adapter')
        import chat_cycle
        d=self.decision();r=self.ref(d)
        task=dict(id='task',action='execute selected comparison',candidate_id='candidate',
                  research_scope='method',reasoning_ref=r,input_refs=[r])
        checked=chat_cycle._task(self.root,task)
        self.assertIn(d['quality_ref'],checked['input_refs'])
        (self.root/d['quality_ref']['path']).write_text('{}')
        with self.assertRaises(ValueError):chat_cycle._task(self.root,task)

    def test_actual_simple_dispatch_consumes_quality(self):
        if not (S/'simple_runner.py').is_file():self.skipTest('This edition has no Simple executor')
        import simple_runner
        r=simple_runner.SimpleRunner(self.root)
        r.initialize(dict(idea='candidate',goal='goal',goal_contract=dict(mode='bounded_task',completion_criteria=[dict(id='c',description='CPU fixture')]),
             limits=dict(max_attempts=3,max_command_seconds=30,deadline_seconds=30,max_concurrency=1)))
        self.addCleanup(lambda:r.stop('fixture cleanup'))
        d=self.decision();ref=self.ref(d)
        r.loop.record(dict(event_id='q',kind='research_review',reason='quality fixture',decision_ref=ref,evidence=[ref]),r.loop.status()['version'])
        task=self.task(ref);task.update(argv=[sys.executable,'-c',"from pathlib import Path;Path('done.txt').write_text('4')"],
                   purpose='quality-bound CPU fixture',timeout_seconds=5,outputs=['done.txt'])
        r.submit(dict(submission_id='q',idea='candidate',revision=1,tasks=[task]))
        until=time.monotonic()+15
        while time.monotonic()<until:
            r.tick();st=r.status()
            if st['tasks'][0]['state']=='succeeded':break
            time.sleep(.03)
        self.assertEqual(st['tasks'][0]['state'],'succeeded',st['tasks'])
        self.assertIn(d['quality_ref'],st['attempts'][0]['contract']['input_refs'])
        self.assertEqual((self.root/'done.txt').read_text(),'4')
if __name__=='__main__':unittest.main()
