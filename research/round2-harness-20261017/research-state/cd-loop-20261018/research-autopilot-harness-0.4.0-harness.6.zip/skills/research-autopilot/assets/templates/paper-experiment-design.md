# Published experiment extraction and transfer

Paper ID/title/version:
Role in our question (closest / strongest / simple / evaluator / conflicting):
Claim or uncertainty motivating this read:

## Inspected sources

| Kind | Primary URL and exact version/commit | Captured artifact path and SHA256 | Page/section/table or code/config locator | Unavailable/conflicting details |
|---|---|---|---|---|
| Main paper | | | | |
| Appendix | | | | |
| Code/config | | | | |
| Native benchmark | | | | |

## Extract only source-supported facts

| Item | Extracted facts and exact source locator | Unknowns or methodological weakness |
|---|---|---|
| Question, prediction, falsifier, rival explanation | | |
| Treatment, strongest/simple baselines, controls and substitutions | | |
| Data/version/splits/sample policy/leakage control | | |
| Native scorer, metric/direction/aggregation/denominator | | |
| Tuning/search/information and compute fairness | | |
| Independent unit, pairing, repeats/seeds and variability | | |
| Uncertainty, selection/multiplicity, missing/failed runs | | |
| Generalization axes and boundaries | | |
| Hardware, runtime/memory, per-run and total compute | | |
| Actual commands/configs/environment and reproducibility | | |

## Transfer decisions

| Practice and source locator | Adopt / adapt / reject | Reason for our claim/resources | Exact change and scientific consequence | Claim and obligation IDs |
|---|---|---|---|---|
| | | | | |

Do not fill unknown source facts with inferred measurements. Rejecting a source
practice does not waive a required experiment. Put our actual observed resource
profile, calibration, six-dimension claim coverage, explicit contrasts, jobs and
budgets in the experiment contract; this reading card is not execution evidence.
