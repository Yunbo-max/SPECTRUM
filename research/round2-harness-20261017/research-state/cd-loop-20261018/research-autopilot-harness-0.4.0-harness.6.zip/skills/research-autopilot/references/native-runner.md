# Bounded experiment runner

Before blocking a stage on scorer availability/isolation, apply
[native-scoring-stages.md](native-scoring-stages.md). Restore real deferred scoring
support from the project. Independent training/export may proceed with saved
unscored artifacts; final metric claims wait for actual native scoring. No Docker
on any host. Requirements for a scorer that executes generated programs belong
to that operation, not automatically to training or prediction generation.


Use `scripts/run_experiments.py` to validate a finite command plan, stage pinned
inputs/code into fresh attempt workspaces, execute reviewed commands, and retain
all logs, outputs, failures, and retry history. It collects evidence and never
advances gates. Scientific scoring follows [native-evaluation.md](native-evaluation.md).
For concurrent independent plans, resource admission, durable resumption and
soft reports and up-to-24-hour Local cycles, use [local-execution-harness.md](local-execution-harness.md).
The native runner still executes jobs within one plan serially. Under the owner's
fixed workflow, use it as the inner executor of the local harness for project
workloads; standalone execution examples below document the API, not permission
to bypass the host's resource pool or generation/design checks.

Apply [gpu-host-runtime.md](gpu-host-runtime.md) before freezing commands. Use the
actual Conda interpreter or `conda run --no-capture-output` with the reviewed native
entry point, for both workloads and official scorer replay. Pin the runtime
profile/dependency manifests through `provenance.environment_refs`; the runner
does not create Conda environments, install Docker or make a container-only
benchmark compatible. Preserve the harness's actual `CUDA_VISIBLE_DEVICES` scope.

## Plan and authorization

Apply [workflow-harness.md](workflow-harness.md) before generating candidate code
or experiment plans. For a protocol with `method_discovery`, pin the complete
current design batch through `provenance.method_verification_ref`. Validation
requires its selected candidate's `design_verified`, current selection and exact
protocol binding; a code-only discovery batch is insufficient for dispatch.

`make_plan(root, *, run_id, jobs, provenance, limits, purpose='engineering',
evidence_mode='developmental', protocol_ref=None, output_root='runs/attempts')`
returns a validated `experiment-run-plan` with a canonical `plan_digest`.
`validate_plan(root, plan)` is read-only. Plan identities include Git, model, data,
and environment revisions/digest; retained `git_refs`, `model_refs`, `data_refs`,
and `environment_refs` can additionally bind host-acquired identity manifests.
The host must ensure these declared revisions actually describe its dependencies.
The runner verifies declared files and preserves identities; it does not provision
an environment or download a model.

Each job freezes `trial_id`, argv `command`, project-relative `cwd`, pinned
`input_refs` and `code_refs`, expected relative `output_paths`, seed, group, and
arm role. Scientific jobs require a verified native protocol, declared native
arm implementation refs, native sample/label/test inputs, and frozen seed/group
inventory. Confirmation requires a frozen matching protocol. Engineering plans
cannot claim a scientific protocol.

Limits require finite `max_attempts`, `max_development_trials`,
`max_confirmation_trials`, `max_retries_per_trial`, `wall_time_seconds`, and
`attempt_timeout_seconds`. The trial inventory must fit the relevant mode's
budget. Confirmation and retrospective audit permit no retries. Timeout cannot
exceed overall wall time. Development retries retain every failed attempt and
consume the same total attempt/wall-time budgets; they never become independent
confirmation replications.

`run_plan(root, plan, *, authorizer=None, lease_factory=None)` requires a live
`authorizer(scope_request)` callback returning `True` for the exact reviewed
command, paths, inputs/code, provenance, and budget. A stored approval flag is not
accepted. It authorizes the concrete plan scope before creating run directories
and each actual staged command before executing it. Scope mismatch or missing
authorization blocks execution. Existing user authorization can supply this host
callback; there is no extra confirmation requirement in the runner.

CLI validation does not execute commands:

```bash
python scripts/run_experiments.py reviewed-plan.json --root /absolute/project
```

Explicit CLI execution binds the exact reviewed digest:

```bash
python scripts/run_experiments.py reviewed-plan.json --root /absolute/project \
  --execute --approved-plan-digest REVIEWED_SHA256
```

Only use execution when the requested scope already authorizes those commands
and their resource budget. For software verification, use existing non-evaluation
tools/fixtures. Do not launch real research or GPU workloads to test this skill.

## Isolation, collection, and limits

Each run ID is single use, including unsuccessful runs. Each attempt gets a new
directory and a staged workspace containing its pinned project inputs/code;
commands execute with `shell=False` and a new process group. Declared input
paths in argv are rewritten to staged copies. Outputs cannot overlap pinned
inputs. Every attempt retains stdout/stderr, actual command/cwd, provenance,
seed/group/role/mode, exit status, wall time, and declared output refs. The run
receipt retains the complete attempt inventory and `gate_advanced: false`.
Large-file hashes stream in bounded buffers. Staging uses isolated filesystem
reflinks when supported, otherwise ordinary copies, and verifies the staged digest.

Process timeouts kill the entire process group. Global wall time and total
attempt limits stop further launches. Resource or authorization failures are
retained as interrupted attempts and are not retried. Failed/OOM process exits
remain failed attempts; the host may classify OOM from its resource telemetry.
No attempt cleanup or result filtering removes negative outcomes.
A successful foreground launcher that leaves process-group children is interrupted;
those children are killed and the attempt cannot qualify or retry. The outer
harness supplies inherited ownership FDs to a Linux parent-death/deadline watchdog.

`lease_factory(scope)` may return the host's resource-pool context manager.
Acquisition precedes command execution; release occurs on completion, failure,
or timeout. Local directories are isolation for artifacts, not an OS security
sandbox. Review the actual command's effects and declare all dependencies. A
host must provide suitable existing OS-enforced isolation when required; Conda
and worktrees alone are not security sandboxes. On the owner's container-free GPU
host, unavailable isolation blocks only the operation that needs it. A Docker
example triggers inspection of the real native scorer and deferred-scoring path;
it does not establish that independent training must stop.
Do not install a container runtime or run untrusted generated programs directly
to bypass that missing capability.

## Live native scorer context

`build_official_replay_context(root, authorizer, *,
output_root='runs/native-replays', timeout_seconds=60.0, lease_factory=None)`
returns the trusted replay callable accepted by `_native_eval.verify_run`.
Constructing it launches no process. Each invocation validates the pinned
existing scorer argv, working directory, input/code refs, and nonce-bound request;
the host authorizer sees the exact execution scope before launch.

Native scorers must produce JSON via stdout or an explicit file output. Frozen
argv placeholders are `{predictions}`, `{samples}`, `{labels}`, `{seed}`, and
`{output}`. File scorers must use a standalone `{output}` argument so each replay
can receive a fresh output path. The collector preserves raw stdout/stderr/native
outputs and execution metadata. It performs no score computation. Scorer output
parsing and metric/denominator checks remain inside `_native_eval`.
An interrupted/timed-out replay is rejected after its execution record is saved,
including when its foreground launcher returned zero.

Replays need a real trusted host/runner callable. Unit tests use a clearly named
engineering replay double to exercise the contract; that double is not a scorer
and must never be installed as scientific execution proof. A production callback
that merely reads saved JSON violates the live replay contract even if it can
echo the nonce. Trust and actual execution are responsibilities of the injected
host, not conclusions drawn from user-controlled files.
