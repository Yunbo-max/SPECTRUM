"""CPU-only strategy regressions; synthetic receipts are not research evidence."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location('chat_strategy', Path(__file__).resolve().parents[1] / 'scripts/chat_strategy.py')
S = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(S)


class StrategyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.n = 0
        self.source = self.write('original request and authorized finite test budget')
        self.state = dict(goal_id='goal', criteria=['main', 'originality'], deliveries=['paper'],
            goal_contract=dict(mode='research', request_ref=self.source),
            budget={'max_attempts': 100}, usage={'totals': {}}, attempts=[], tasks=[], current_attempt=None)
        self.config = dict(kind='chat_research_strategy', goal_id='goal', request_ref=self.source,
            source_ref=self.source, obligations=[
                dict(id='main', description='Original main task coverage', priority='critical',
                     criterion_ids=['main'], delivery_ids=['paper']),
                dict(id='novelty', description='Independent method contribution review', priority='required',
                     criterion_ids=['originality'], delivery_ids=[]),
                dict(id='side', description='Optional diagnostic clarification', priority='optional',
                     criterion_ids=[], delivery_ids=[])],
            families=[dict(id='mechanism-a', mechanism='Decision cost relative to actual decrease',
                mechanism_ref=self.source,
                diagnostic_limits=dict(max_attempts=3, wall_seconds=30, gpu_seconds=0, cost=0))],
            limits=dict(max_no_progress_attempts=2, max_diagnostic_attempts=4,
                        diagnostic_wall_seconds=40, diagnostic_gpu_seconds=0, diagnostic_cost=0))
        self.ref = self.write(self.config)
        S.initialize(self.root, self.state, {'strategy_ref': self.ref}, self.read)
        self.scope = self.write(dict(kind='chat_research_scope', candidate_id='candidate',
            implementation_ref=self.source, protocol_ref=self.source, default_parameters_ref=self.source,
            baselines=[dict(implementation_ref=self.source, protocol_ref=self.source,
                           default_parameters_ref=self.source, implementation_kind='official')],
            claim_kind='new_method'))

    def write(self, value):
        self.n += 1
        path = self.root / ('evidence-%d.json' % self.n)
        data = value if isinstance(value, str) else json.dumps(value, sort_keys=True)
        path.write_text(data)
        return {'path': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

    def read(self, root, ref, *, as_json=False):
        if not isinstance(ref, dict):
            raise ValueError('reference required')
        data = (root / ref['path']).read_bytes()
        if hashlib.sha256(data).hexdigest() != ref.get('sha256'):
            raise ValueError('hash mismatch')
        return json.loads(data) if as_json else ref

    def reviewed(self, **values):
        return dict(proposal_task_id='proposer', review_task_id='reviewer',
                    execution_ref=self.source, raw_evidence=[self.source], **values)

    def task(self, name, purpose='analysis', *, obligation='main', candidate='candidate',
             family='mechanism-a', decision=None, falsifier=None, estimate=5, kind='research_analysis', **extra):
        intent = dict(kind='chat_task_intent', goal_id='goal', candidate_id=candidate, family_id=family,
            obligation_ids=[obligation], purpose=purpose, decision=decision or 'Choose ' + name,
            falsifier=falsifier or 'Reject if independent measurement disproves ' + name,
            estimate=dict(wall_seconds=estimate, gpu_seconds=0, cost=0), scope_ref=self.scope)
        intent.update(extra.pop('intent_extra', {}))
        task = dict(id=name, candidate_id=candidate, kind=kind, dependencies=[], input_refs=[],
                    status='pending', intent_ref=self.write(intent), **extra)
        self.state['tasks'].append(task)
        return task

    def qualify(self, scope=None, candidate='candidate', family='mechanism-a'):
        receipt = self.reviewed(kind='chat_research_qualification', goal_id='goal',
            candidate_id=candidate, family_id=family, scope_ref=scope or self.scope,
            checks={name: dict(verdict='distinct_testable_gap' if name == 'nearest_work' else 'verified',
                               evidence_refs=[self.source], finding='Test fixture comparison independently checked')
                    for name in ('source', 'baseline', 'nearest_work')})
        ref = self.write(receipt)
        S.apply(self.root, self.state, dict(op='strategy_qualify', qualification_ref=ref), self.read)
        return ref

    def usage(self, attempt_id, wall=1):
        totals = dict(wall_seconds=wall, gpu_seconds=0, cost=0)
        ref = self.write(dict(kind='chat_strategy_usage', attempt_id=attempt_id, totals=totals,
                              terminal=True, raw_evidence=[self.source]))
        return dict(totals=totals, receipt_ref=ref)

    def start(self, task):
        attempt = dict(id='attempt-' + str(len(self.state['attempts']) + 1), task_id=task['id'],
                       candidate_id=task['candidate_id'], kind=task['kind'])
        S.before_begin(self.root, self.state, task, attempt, self.read)
        self.state['current_attempt'] = attempt
        task['status'] = 'active'
        return attempt

    def finish(self, task, outcome='completed', wall=1):
        attempt = self.state['current_attempt']
        attempt.update(outcome=outcome, failure_class='implementation' if outcome == 'failed' else None)
        raw = self.write('actual synthetic output for ' + attempt['id'])
        attempt['evidence_ref'] = self.write(dict(attempt_id=attempt['id'], raw_evidence=[raw]))
        event = dict(outcome=outcome)
        if wall is not None:
            event['strategy_usage'] = self.usage(attempt['id'], wall)
        S.after_result(self.root, self.state, attempt, event, self.read)
        self.state['attempts'].append(attempt)
        self.state['current_attempt'] = None
        task['status'] = outcome
        return attempt, raw

    def execute(self, task, **kwargs):
        self.start(task)
        return self.finish(task, **kwargs)

    def progress(self, attempt, raw, **change):
        change = dict(type='dependency_resolved', obligation_ids=['main'],
                      before='Missing source or unresolved prediction', after='Independent evidence establishes next decision',
                      evidence_refs=[raw], **change)
        ref = self.write(self.reviewed(kind='chat_strategy_progress', goal_id='goal',
                    attempt_ids=[attempt['id']], changes=[change]))
        S.apply(self.root, self.state, dict(op='strategy_progress', progress_ref=ref), self.read)
        return ref

    def test_legacy_checkpoint_readable_but_new_dispatch_requires_migration(self):
        self.state.pop('strategy')
        self.assertEqual(S.guard(self.root, self.state, self.read)['reason'], 'strategy_migration_required')
        # A pre-migration in-flight observation can still settle.
        S.after_result(self.root, self.state, {'id': 'legacy', 'outcome': 'failed'}, {}, self.read)
        self.assertNotIn('strategy', self.state)

    def test_invalid_strategy_cannot_shrink_goal_or_use_unbounded_limits(self):
        for mutate in (lambda c: c['obligations'][0].update(criterion_ids=[]),
                       lambda c: c['limits'].update(max_no_progress_attempts=0),
                       lambda c: c['limits'].update(diagnostic_wall_seconds=float('inf'))):
            config = copy.deepcopy(self.config)
            mutate(config)
            state = copy.deepcopy(self.state)
            with self.assertRaises(ValueError):
                S.initialize(self.root, state, {'strategy_ref': self.write(config)}, self.read)

    def test_source_acquisition_is_admitted_before_scientific_qualification(self):
        task = self.task('read-official-code', 'acquire', kind='action')
        S.admit_task(self.root, task, self.state, self.read)
        investment = self.task('expensive-candidate', 'diagnostic', kind='research_experiment', experiment_phase='diagnostic')
        S.validate_task(self.root, investment, self.state, self.read)  # May be planned early.
        with self.assertRaisesRegex(ValueError, 'qualification required'):
            S.admit_task(self.root, investment, self.state, self.read)

    def test_qualification_experiment_requires_specific_prerequisite_scope(self):
        task = self.task('baseline-check', 'qualify', kind='research_experiment', experiment_phase='diagnostic',
            intent_extra=dict(prerequisite_only=True, qualification_targets=['baseline_fidelity']))
        S.admit_task(self.root, task, self.state, self.read)
        disguised = self.task('disguised-efficacy', 'acquire', kind='research_experiment', experiment_phase='diagnostic')
        with self.assertRaisesRegex(ValueError, 'qualification checks'):
            S.admit_task(self.root, disguised, self.state, self.read)

    def test_qualification_bound_to_actual_scope_and_parameter_pins(self):
        self.qualify()
        task = self.task('candidate-test', 'main_evidence')
        S.admit_task(self.root, task, self.state, self.read)
        revised_scope = self.read(self.root, self.scope, as_json=True)
        revised_scope['default_parameters_ref'] = self.write('changed delta')
        changed = self.task('new-delta', 'main_evidence', intent_extra={'scope_ref': self.write(revised_scope)})
        with self.assertRaisesRegex(ValueError, 'exact scope'):
            S.admit_task(self.root, changed, self.state, self.read)
        (self.root / revised_scope['default_parameters_ref']['path']).write_text('tampered')
        with self.assertRaisesRegex(ValueError, 'hash mismatch'):
            self.qualify(scope=self.read(self.root, changed['intent_ref'], as_json=True)['scope_ref'])

    def test_existing_method_nearest_work_does_not_qualify_new_method_claim(self):
        reference = self.qualify()
        receipt = self.read(self.root, reference, as_json=True)
        receipt['checks']['nearest_work']['verdict'] = 'known_comparison'
        with self.assertRaisesRegex(ValueError, 'nearest_work'):
            S.apply(self.root, self.state, dict(op='strategy_qualify', qualification_ref=self.write(receipt)), self.read)

    def test_main_obligation_and_independent_review_precede_easy_optional_diagnostic(self):
        diagnostic = self.task('easy-side', 'diagnostic', obligation='side', estimate=1)
        main = self.task('missing-main', 'main_evidence')
        review = self.task('review-main', 'independent_review', kind='action')
        self.assertEqual([t['id'] for t in S.order_tasks(self.root, self.state, [diagnostic, main, review], self.read)],
                         [review['id'], main['id'], diagnostic['id']])

    def test_classified_repair_preempts_optional_work_without_false_qualification(self):
        self.qualify()
        failed = self.task('main-implementation', 'main_evidence')
        attempt, _ = self.execute(failed, outcome='failed')
        # Qualification unavailable now; repair is still eligible.
        self.state['strategy']['qualifications'] = []
        repair = dict(failed, id='repair', status='pending', repairs=failed['id'],
                      failure_context={'attempt_id': attempt['id']})
        self.state['tasks'].append(repair)
        side = self.task('side', 'analysis', obligation='side')
        S.admit_task(self.root, repair, self.state, self.read)
        self.assertEqual(S.order_tasks(self.root, self.state, [side, repair], self.read)[0]['id'], 'repair')
        fabricated = dict(repair, failure_context={'attempt_id': 'invented'})
        with self.assertRaisesRegex(ValueError, 'qualification required'):
            S.admit_task(self.root, fabricated, self.state, self.read)

    def test_failed_diagnostics_consume_family_and_global_attempt_budget(self):
        config = copy.deepcopy(self.config)
        config['limits']['max_no_progress_attempts'] = 20
        S.initialize(self.root, self.state, {'strategy_ref': self.write(config)}, self.read)
        self.qualify()
        for index in range(3):
            task = self.task('renamed-' + str(index), 'diagnostic', kind='research_experiment', experiment_phase='diagnostic')
            self.execute(task, outcome='failed')
        next_task = self.task('renamed-again', 'diagnostic', kind='research_experiment', experiment_phase='diagnostic')
        with self.assertRaisesRegex(ValueError, 'cumulative diagnostic attempt limit'):
            S.admit_task(self.root, next_task, self.state, self.read)
        self.assertEqual(S.summary(self.state)['diagnostic_usage']['attempts'], 3)

    def test_unknown_actual_preserves_reservation_and_allows_source_recovery(self):
        self.qualify()
        first = self.task('diagnose', 'diagnostic', kind='research_experiment', experiment_phase='diagnostic', estimate=10)
        attempt, _ = self.execute(first, outcome='failed', wall=None)
        self.assertEqual(S.summary(self.state)['diagnostic_usage']['wall_seconds'], 10)
        second = self.task('new-name', 'diagnostic', kind='research_experiment', experiment_phase='diagnostic')
        with self.assertRaisesRegex(ValueError, 'usage or reconciliation'):
            S.admit_task(self.root, second, self.state, self.read)
        source = self.task('obtain-missing-receipt', 'acquire', kind='action')
        S.admit_task(self.root, source, self.state, self.read)
        S.apply(self.root, self.state, dict(op='strategy_usage', attempt_id=attempt['id'], usage=self.usage(attempt['id'], 0.02)), self.read)
        S.admit_task(self.root, second, self.state, self.read)
        self.assertEqual(S.summary(self.state)['diagnostic_usage']['wall_seconds'], 0.02)

    def test_actual_overrun_is_recorded_and_future_investment_blocked(self):
        self.qualify()
        task = self.task('overrun', 'diagnostic', kind='research_experiment', experiment_phase='diagnostic')
        self.execute(task, wall=31)
        following = self.task('next', 'diagnostic', kind='research_experiment', experiment_phase='diagnostic')
        with self.assertRaisesRegex(ValueError, 'remaining budget'):
            S.admit_task(self.root, following, self.state, self.read)
        self.assertEqual(S.summary(self.state)['diagnostic_usage']['wall_seconds'], 31)

    def test_stale_global_usage_cannot_admit_another_non_diagnostic_attempt(self):
        self.state['budget']['limits'] = dict(wall_seconds=100, gpu_seconds=0, cost=0)
        self.state['usage'] = dict(totals=dict(wall_seconds=0, gpu_seconds=0, cost=0), observed_attempt_ids=[])
        first = self.task('read-big-source', 'acquire', kind='action', estimate=60)
        attempt, _ = self.execute(first, wall=60)
        following = self.task('read-another-big-source', 'acquire', kind='action', estimate=60)
        with self.assertRaisesRegex(ValueError, 'refresh actual cumulative project usage'):
            S.admit_task(self.root, following, self.state, self.read)
        self.state['usage'] = dict(totals=dict(wall_seconds=60, gpu_seconds=0, cost=0), observed_attempt_ids=[attempt['id']])
        with self.assertRaisesRegex(ValueError, 'remaining project wall_seconds'):
            S.admit_task(self.root, following, self.state, self.read)

    def test_renamed_candidate_cannot_reset_global_diagnostic_budget(self):
        config = copy.deepcopy(self.config)
        config['families'][0]['diagnostic_limits']['max_attempts'] = 20
        config['limits']['max_no_progress_attempts'] = 20
        S.initialize(self.root, self.state, {'strategy_ref': self.write(config)}, self.read)
        self.qualify()
        for n in range(4):
            self.execute(self.task('run-' + str(n), 'diagnostic', kind='research_experiment', experiment_phase='diagnostic'))
        task = self.task('new-candidate', 'diagnostic', candidate='renamed-candidate',
                         kind='research_experiment', experiment_phase='diagnostic')
        scope = self.read(self.root, self.scope, as_json=True)
        scope['candidate_id'] = 'renamed-candidate'
        scope_ref = self.write(scope)
        intent = self.read(self.root, task['intent_ref'], as_json=True)
        intent['scope_ref'] = scope_ref
        task['intent_ref'] = self.write(intent)
        self.qualify(scope_ref, 'renamed-candidate')
        with self.assertRaisesRegex(ValueError, 'cumulative diagnostic attempt limit'):
            S.admit_task(self.root, task, self.state, self.read)

    def test_no_progress_detected_across_task_ids_and_recovery_is_bounded(self):
        for n in range(2):
            self.execute(self.task('different-name-' + str(n)))
        task = self.task('yet-another-name')
        with self.assertRaisesRegex(ValueError, 'strategy_review_required'):
            S.admit_task(self.root, task, self.state, self.read)
        for n in range(2):
            self.execute(self.task('recovery-' + str(n), 'acquire', kind='action'))
        with self.assertRaisesRegex(ValueError, 'strategy_review_required'):
            S.admit_task(self.root, self.task('recovery-loop', 'acquire', kind='action'), self.state, self.read)
        self.assertEqual(S.summary(self.state)['no_progress_attempts'], 4)

    def test_reviewed_negative_or_dependency_evidence_counts_without_claiming_goal_completion(self):
        attempt, raw = self.execute(self.task('counterexample'), outcome='refuted')
        self.progress(attempt, raw)
        self.assertEqual(S.summary(self.state)['no_progress_attempts'], 0)
        self.assertEqual(self.state['criteria'], ['main', 'originality'])
        self.assertNotIn('goal_review', self.state)

    def test_old_progress_cannot_erase_later_stagnation_or_be_recounted(self):
        first, raw = self.execute(self.task('first'))
        self.execute(self.task('second'))
        self.progress(first, raw)
        self.assertEqual(S.summary(self.state)['no_progress_attempts'], 1)
        with self.assertRaisesRegex(ValueError, 'renamed'):
            self.progress(first, raw)

    def test_missing_progress_bytes_cannot_keep_stagnation_cleared(self):
        attempt, raw = self.execute(self.task('one'))
        receipt = self.progress(attempt, raw)
        self.execute(self.task('two'))
        task = self.task('three')
        S.admit_task(self.root, task, self.state, self.read)
        (self.root / receipt['path']).unlink()
        with self.assertRaisesRegex(ValueError, 'strategy_review_required'):
            S.admit_task(self.root, task, self.state, self.read)

    def test_progress_must_use_actual_attempt_outputs(self):
        attempt, _ = self.execute(self.task('one'))
        with self.assertRaisesRegex(ValueError, 'bound attempt outputs'):
            self.progress(attempt, self.write('unrelated old result'))

    def test_failed_execution_cannot_be_called_resolved_progress(self):
        attempt, raw = self.execute(self.task('broken-solver'), outcome='failed')
        with self.assertRaisesRegex(ValueError, 'failed or blocked execution'):
            self.progress(attempt, raw)

    def test_strategy_review_releases_only_concrete_changed_work_without_reset(self):
        first = self.task('one')
        self.execute(first)
        self.execute(self.task('two'))
        changed = self.task('new-causal-test')
        receipt = self.reviewed(kind='chat_strategy_review', goal_id='goal', strategy_ref=self.state['strategy']['ref'],
            attempt_ids=list(self.state['strategy']['settled_attempt_ids']), diagnosis='Repeated measurement cannot resolve cause',
            alternative_considered='Stop the old mechanism and examine source defaults', why_changed_plan='New counterexample distinguishes mechanisms',
            exit_condition='Retire on equal prediction', retained_obligation_ids=['main', 'novelty', 'side'],
            next_intent_refs=[changed['intent_ref']])
        receipt['raw_evidence'] += [a['evidence_ref'] for a in self.state['attempts']]
        reference = self.write(receipt)
        S.apply(self.root, self.state, dict(op='strategy_review', review_ref=reference), self.read)
        self.assertEqual(S.summary(self.state)['no_progress_attempts'], 2)
        self.assertEqual(self.state['strategy']['reviews'][-1]['ref'], reference)
        self.execute(changed)
        with self.assertRaisesRegex(ValueError, 'strategy_review_required'):
            S.admit_task(self.root, self.task('unreviewed-next'), self.state, self.read)

    def test_strategy_review_rejects_renamed_same_question(self):
        first = self.task('one', decision='Same decision', falsifier='Same falsifier')
        self.execute(first)
        changed = self.task('new-round-name', decision='Same decision', falsifier='Same falsifier')
        receipt = self.reviewed(kind='chat_strategy_review', goal_id='goal', strategy_ref=self.state['strategy']['ref'],
            attempt_ids=list(self.state['strategy']['settled_attempt_ids']), diagnosis='No progress', alternative_considered='Another approach',
            why_changed_plan='Renamed', exit_condition='Enough rounds', retained_obligation_ids=['main', 'novelty', 'side'],
            next_intent_refs=[changed['intent_ref']])
        receipt['raw_evidence'] += [a['evidence_ref'] for a in self.state['attempts']]
        with self.assertRaisesRegex(ValueError, 'changed decision/falsifier'):
            S.apply(self.root, self.state, dict(op='strategy_review', review_ref=self.write(receipt)), self.read)

    def test_adoption_preserves_history_and_rejects_budget_reset(self):
        attempt, _ = self.execute(self.task('first'), outcome='failed')
        config = copy.deepcopy(self.config)
        config['source_ref'] = self.write('Reviewed policy revision')
        ref = self.write(config)
        review = self.reviewed(kind='chat_strategy_adoption', goal_id='goal', strategy_ref=ref,
            previous_strategy_ref=self.state['strategy']['ref'], attempt_ids=[attempt['id']], reason='Clarify policy')
        S.adopt_strategy(self.root, self.state, ref, self.read, self.write(review))
        self.assertIn(attempt['id'], self.state['strategy']['entries'])
        self.assertEqual(S.summary(self.state)['no_progress_attempts'], 1)
        config['limits']['max_diagnostic_attempts'] += 1
        ref2 = self.write(config)
        review.update(strategy_ref=ref2, previous_strategy_ref=ref)
        with self.assertRaisesRegex(ValueError, 'cumulative limits'):
            S.adopt_strategy(self.root, self.state, ref2, self.read, self.write(review))

    def test_valid_goal_extension_can_adopt_covering_strategy_without_deadlock(self):
        attempt, _ = self.execute(self.task('existing-work'))
        old_ref = self.state['strategy']['ref']
        expanded_request = self.write('Original obligations plus a new robustness criterion')
        self.state['criteria'].append('robustness')
        self.state['goal_contract']['request_ref'] = expanded_request
        self.assertEqual(S.guard(self.root, self.state, self.read)['reason'], 'strategy_source_invalid')
        config = copy.deepcopy(self.config)
        config['request_ref'] = expanded_request
        config['obligations'].append(dict(id='robustness', description='New owner-requested robustness check',
            priority='required', criterion_ids=['robustness'], delivery_ids=[]))
        ref = self.write(config)
        review = self.reviewed(kind='chat_strategy_adoption', goal_id='goal', strategy_ref=ref,
            previous_strategy_ref=old_ref, attempt_ids=[attempt['id']], reason='Sourced goal extension')
        S.adopt_strategy(self.root, self.state, ref, self.read, self.write(review))
        self.assertIsNone(S.guard(self.root, self.state, self.read))
        self.assertEqual(S.summary(self.state)['no_progress_attempts'], 1)
        self.assertEqual(self.state['strategy']['adoptions'][0]['previous_ref'], old_ref)

    def test_migration_requires_every_failure_and_does_not_invent_actual_usage(self):
        attempt, _ = self.execute(self.task('legacy-work'), outcome='failed')
        self.state.pop('strategy')
        review = self.reviewed(kind='chat_strategy_adoption', goal_id='goal', strategy_ref=self.ref,
            previous_strategy_ref=None, attempt_ids=[attempt['id']], reason='Preserve prior work', historical_attempts=[])
        with self.assertRaisesRegex(ValueError, 'every old attempt'):
            S.adopt_strategy(self.root, self.state, self.ref, self.read, self.write(review))
        review['historical_attempts'] = [dict(attempt_id=attempt['id'], family_id='mechanism-a', diagnostic=True,
             reservation=dict(wall_seconds=5, gpu_seconds=0, cost=0), reservation_source_ref=self.source)]
        S.adopt_strategy(self.root, self.state, self.ref, self.read, self.write(review))
        self.assertEqual(S.summary(self.state)['unsettled_usage_attempt_ids'], [attempt['id']])
        self.assertEqual(S.summary(self.state)['diagnostic_usage']['attempts'], 1)

    def test_legacy_task_binding_is_reviewed_and_never_overwrites_existing_binding(self):
        task = self.task('legacy')
        intent = task.pop('intent_ref')
        ref = self.write(self.reviewed(kind='chat_strategy_task_binding', goal_id='goal', task_id=task['id'], intent_ref=intent))
        event = dict(op='strategy_bind_task', task_id=task['id'], intent_ref=intent, review_ref=ref)
        S.apply(self.root, self.state, event, self.read)
        self.assertEqual(task['intent_ref'], intent)
        with self.assertRaisesRegex(ValueError, 'legacy tasks'):
            S.apply(self.root, self.state, event, self.read)


if __name__ == '__main__':
    unittest.main()
