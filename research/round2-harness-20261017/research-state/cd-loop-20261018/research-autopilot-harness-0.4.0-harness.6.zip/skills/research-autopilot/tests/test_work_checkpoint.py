"""Checkpoint integrity and recovery tests, with engineering-only artifacts."""
import copy
import importlib
import json
from pathlib import Path
import tempfile
import unittest
from fixtures import C, write


class WorkCheckpointTests(unittest.TestCase):
    def setUp(self):
        self.api = importlib.import_module('work_checkpoint')
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.manifest = dict(version=1, project_id='example', sequence=1, previous_ref=None,
                            state='paused', latest_batch='B15',
                            policy=dict(edition='autonomous-rsi', version='0.2.0-autonomous.4',
                                        source_revision='a'*40, skill_digest='b'*64),
                            executor=dict(name='simple', version='0.2.0-simple.6', source_revision='c'*40),
                            contract_ref=write(self.root, 'contract.json', {'scope': 'engineering fixture'}),
                            ledger_ref=write(self.root, 'ledger.json', {'history': ['B01', 'B15']}),
                            report_ref=write(self.root, 'report.json', {'batch': 'B15'}),
                            pending_attempt_refs=[], obligations=['independent confirmation'],
                            counters={'cpu_seconds': 100, 'rounds': 15},
                            limits={'cpu_seconds': 7200, 'rounds': 30},
                            next_action='Preserve pause; report existing evidence',
                            adoption_ref=None, resume_authority_ref=None, transition_ref=None)

    def advance(self, previous, **changes):
        value = copy.deepcopy(self.manifest)
        value.update(sequence=2, previous_ref=previous, latest_batch='B16')
        value.update(changes)
        return value

    def test_publish_inspect_preserves_pause_and_separate_policy_executor(self):
        pin = self.api.publish(self.root, self.manifest)
        result = self.api.inspect(self.root)
        self.assertEqual(result['checkpoint_ref'], pin)
        self.assertEqual(result['checkpoint']['state'], 'paused')
        self.assertFalse(result['may_continue'])
        self.assertEqual(result['checkpoint']['policy']['edition'], 'autonomous-rsi')
        self.assertEqual(result['checkpoint']['executor']['name'], 'simple')

    def test_stale_writer_cannot_overwrite_current_checkpoint(self):
        one = self.api.publish(self.root, self.manifest)
        two = self.api.publish(self.root, self.advance(one), expected_ref=one)
        with self.assertRaises(C.Failure):
            self.api.publish(self.root, self.advance(one), expected_ref=one)
        self.assertEqual(self.api.inspect(self.root)['checkpoint_ref'], two)

    def test_old_embedded_prompt_and_wrong_loaded_edition_are_detected(self):
        self.api.publish(self.root, self.manifest)
        for expected in ({'expected_batch': 'B03'}, {'expected_policy': dict(self.manifest['policy'], edition='rsi-simple')}):
            with self.assertRaises(C.Failure):
                self.api.inspect(self.root, **expected)

    def test_reference_corruption_never_returns_ready(self):
        self.api.publish(self.root, self.manifest)
        (self.root/'report.json').write_text('corrupted')
        with self.assertRaises(C.Failure):
            self.api.inspect(self.root)

    def test_history_counters_limits_and_contract_cannot_be_reset(self):
        one = self.api.publish(self.root, self.manifest)
        for changes in (dict(counters={'cpu_seconds': 0, 'rounds': 15}),
                        dict(limits={'cpu_seconds': 9000, 'rounds': 30}),
                        dict(contract_ref=write(self.root, 'replacement.json', {'scope': 'more'})),
                        dict(previous_ref=None), dict(sequence=9)):
            with self.subTest(changes=changes), self.assertRaises(C.Failure):
                self.api.publish(self.root, self.advance(one, **changes), expected_ref=one)
        self.assertEqual(self.api.inspect(self.root)['checkpoint_ref'], one)

    def test_paused_state_needs_explicit_retained_resume_authority(self):
        one = self.api.publish(self.root, self.manifest)
        with self.assertRaises(C.Failure):
            self.api.publish(self.root, self.advance(one, state='active'), expected_ref=one)
        authority = write(self.root, 'resume.json', {'instruction': 'explicit scoped engineering continuation'})
        self.api.publish(self.root, self.advance(one, state='active', resume_authority_ref=authority), expected_ref=one)
        self.assertTrue(self.api.inspect(self.root)['may_continue'])

    def test_policy_change_needs_adoption_and_does_not_repin_live_attempts(self):
        self.manifest['pending_attempt_refs'] = [write(self.root, 'attempt.json', {'owner': 'original'})]
        one = self.api.publish(self.root, self.manifest)
        policy = dict(self.manifest['policy'], version='0.2.0-autonomous.5')
        adoption = write(self.root, 'adoption.json', {'old': self.manifest['policy'], 'new': policy})
        for pin in (None, adoption):
            with self.assertRaises(C.Failure):
                self.api.publish(self.root, self.advance(one, policy=policy, adoption_ref=pin), expected_ref=one)

    def test_new_checkpoint_can_change_policy_only_after_quiescent_adoption(self):
        one = self.api.publish(self.root, self.manifest)
        policy = dict(self.manifest['policy'], version='0.2.0-autonomous.5')
        with self.assertRaises(C.Failure):
            self.api.publish(self.root, self.advance(one, policy=policy), expected_ref=one)
        adoption = write(self.root, 'adoption.json', {'old': self.manifest['policy'], 'new': policy})
        self.api.publish(self.root, self.advance(one, policy=policy, adoption_ref=adoption), expected_ref=one)
        self.assertFalse(self.api.inspect(self.root)['may_continue'])

    def test_symlinked_state_directory_is_rejected(self):
        target = self.root/'elsewhere'; target.mkdir()
        (self.root/'research-state').symlink_to(target)
        with self.assertRaises(C.Failure):
            self.api.publish(self.root, self.manifest)

    def test_completion_cannot_drop_open_obligations_or_pending_attempts(self):
        self.manifest['state'] = 'completed'
        with self.assertRaises(C.Failure):
            self.api.publish(self.root, self.manifest)

    def test_pending_ownership_cannot_disappear_without_bound_closure_receipts(self):
        attempt = write(self.root, 'attempt.json', {'owner': 'original', 'fence': 9, 'state': 'reconcile_required'})
        self.manifest['pending_attempt_refs'] = [attempt]
        one = self.api.publish(self.root, self.manifest)
        closed = self.advance(one, state='completed', pending_attempt_refs=[], obligations=[])
        with self.assertRaises(C.Failure):
            self.api.publish(self.root, closed, expected_ref=one)
        receipt = write(self.root, 'receipt.json', {'outcome': 'cancelled', 'owner': 'original', 'fence': 9})
        review = write(self.root, 'closure-review.json', {'scope': 'engineering fixture cancellation verified'})
        transition = dict(version=1, previous_ref=one, review_ref=review,
                          closed_attempts=[dict(attempt_ref=attempt, outcome='cancelled', receipt_ref=receipt)],
                          closed_obligations=[dict(obligation='independent confirmation', evidence_refs=[review])])
        closed['transition_ref'] = write(self.root, 'closure.json', transition)
        two = self.api.publish(self.root, closed, expected_ref=one)
        self.assertEqual(self.api.inspect(self.root)['checkpoint']['state'], 'completed')
        stale = dict(closed, sequence=3, previous_ref=two)
        with self.assertRaises(C.Failure):
            self.api.publish(self.root, stale, expected_ref=two)
        (self.root/'receipt.json').write_text('corrupted after publication')
        with self.assertRaises(C.Failure):
            self.api.inspect(self.root)

    def test_resume_instruction_cannot_be_reused_after_intermediate_clear(self):
        one = self.api.publish(self.root, self.manifest)
        authority = write(self.root, 'resume.json', {'instruction': 'one scoped resumption'})
        value = self.advance(one, state='active', resume_authority_ref=authority)
        two = self.api.publish(self.root, value, expected_ref=one)
        value.update(sequence=3, previous_ref=two, state='paused', resume_authority_ref=None)
        three = self.api.publish(self.root, value, expected_ref=two)
        value.update(sequence=4, previous_ref=three, state='active', resume_authority_ref=authority)
        with self.assertRaises(C.Failure):
            self.api.publish(self.root, value, expected_ref=three)

    def test_normal_ledger_update_can_advance_with_new_evidence_and_old_history(self):
        one = self.api.publish(self.root, self.manifest)
        ledger = write(self.root, 'ledger.json', {'history': ['B01', 'B15', 'B16']})
        with self.assertRaises(C.Failure):
            self.api.inspect(self.root)
        two = self.api.publish(self.root, self.advance(one, ledger_ref=ledger), expected_ref=one)
        self.assertEqual(self.api.inspect(self.root)['checkpoint_ref'], two)
        self.assertEqual(self.api.inspect(self.root)['checkpoint']['previous_ref'], one)


if __name__ == '__main__':
    unittest.main()
