"""Real short CPU commands test scheduling; GPU telemetry doubles test admission only."""
import copy
from contextlib import contextmanager
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import tempfile
import time
import tracemalloc
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from fixtures import C, DIGEST, env, write
import run_experiments as R

try:
    import run_harness as H
except ModuleNotFoundError:
    H = None


class HarnessTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(H, "local execution harness is missing")
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = pathlib.Path(self.temp.name)

    def task(self, name, *, delay=0.25, depends=(), fail=False, missing=False, command=None, timeout=2):
        # This command is an engineering workload, not a model/scorer/benchmark.
        command = command if command is not None else [sys.executable, "-c", "import pathlib,time; time.sleep(%r); %s" %
                   (delay, "raise SystemExit(3)" if fail else
                    ("pass" if missing else "pathlib.Path('result.txt').write_text('engineering output')"))]
        native = R.make_plan(self.root, run_id=name, jobs=[{"trial_id":name,"command":command,"cwd":".",
            "input_refs":[],"code_refs":[],"output_paths":["result.txt"],"seed":1,"group":"engineering","arm_role":"engineering"}],
            provenance={"git_revision":"engineering-fixture","model_revision":"none","data_revision":"none","environment_digest":DIGEST},
            limits={"max_attempts":1,"max_development_trials":1,"max_confirmation_trials":1,
                    "max_retries_per_trial":0,"wall_time_seconds":timeout+1,"attempt_timeout_seconds":timeout})
        ref = write(self.root, "plans/" + name + ".json", native)
        return {"task_id":name,"idea_id":"engineering-fixture","plan_ref":ref,"depends_on":list(depends),"priority":10,
                "resources":{"cpu_cores":1,"ram_mib":32,"gpu_count":0,"gpu_peak_mib":None,
                             "allow_gpu_share":False,"memory_profile_ref":None,"exclusive_keys":[]}}

    def plan(self, tasks, *, window=8*3600, total=10, parallel=2):
        return H.make_plan(self.root, batch_id="fixture", tasks=tasks, pool_dir=str(self.root / "host-pool"),
            limits={"window_seconds":window,"total_wall_seconds":total,"max_parallel_tasks":parallel,
                    "cpu_cores":2,"ram_mib":1024,"max_gpu_task_seconds":0},
            gpus={"uuids":[],"safety_margin_mib":512,"max_tasks_per_gpu":1})

    def execute(self, plan, **kwargs):
        return H.run_harness(self.root, plan, authorizer=lambda scope: True, poll_seconds=0.02, **kwargs)

    def reject(self, code, action):
        with self.assertRaises(C.Failure) as raised: action()
        self.assertEqual(raised.exception.code, code)

    def barrier_task(self, name, *, release=None, depends=(), observe=None):
        # Real finite CPU peers: a release marker controls completion, while the
        # ready marker proves the native command has actually entered its body.
        command = [sys.executable, "-c",
            "import json,pathlib,time\n"
            f"root = pathlib.Path({str(self.root)!r})\n"
            f"observe = {observe!r}\n"
            "identity = None\n"
            "if observe is not None:\n"
            "    identity = json.loads((root/'runs/harness/fixture/tasks'/observe/'process.json').read_text())\n"
            "    stat = pathlib.Path('/proc/%s/stat' % identity['pid']).read_text().rsplit(')',1)[1].split()\n"
            "    actual = {'pid':identity['pid'],'start_ticks':stat[19],\n"
            "              'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()}\n"
            "    assert stat[0] != 'Z' and actual == identity\n"
            "stat = pathlib.Path('/proc/self/stat').read_text()\n"
            "command_process = {'pid':int(stat.split()[0]),'start_ticks':stat.rsplit(')',1)[1].split()[19],\n"
            "                   'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()}\n"
            "evidence = {'observed_process':identity,'observed_at':time.time(),'command_process':command_process}\n"
            f"(root/{(name+'-ready.json')!r}).write_text(json.dumps(evidence))\n"
            f"release = {release!r}\n"
            "deadline = time.monotonic()+7\n"
            "while release is not None and not (root/release).exists():\n"
            "    if time.monotonic() >= deadline: raise SystemExit(91)\n"
            "    time.sleep(.02)\n"
            "pathlib.Path('result.txt').write_text('engineering output')\n"]
        if release is not None: self.release_paths.append(self.root/release)
        return self.task(name, command=command, timeout=8, depends=depends)

    @contextmanager
    def handoff(self, plan):
        # Retain real Popen handles for bounded cleanup even when an assertion
        # fails while a causal barrier is holding a worker alive.
        children = []; real_popen = subprocess.Popen
        def capture(*args, **kwargs):
            child = real_popen(*args, **kwargs); children.append(child); return child
        try:
            with patch.object(H.subprocess, "Popen", side_effect=capture):
                first = self.execute(plan, stop_after_report=True)
            yield first
        finally:
            for path in self.release_paths: path.touch()
            for child in children:
                try: child.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    child.kill(); child.wait(timeout=1)

    def wait_live_task(self, name):
        batch = self.root/"runs/harness/fixture"
        deadline = C.load_file(batch/"state.json")["hard_deadline_monotonic"]
        process = batch/"tasks"/name/"process.json"
        while time.monotonic() < deadline:
            if process.is_file() and (self.root/(name+"-ready.json")).is_file():
                identity = C.load_file(process)
                if H._alive(identity): return identity
            time.sleep(.02)
        self.fail("No acknowledged live task: " + C.canonical({"task":name,
            "state":C.load_file(batch/"state.json"), "events":(batch/"events.jsonl").read_text()}))

    def test_independent_tasks_really_overlap_and_dependent_waits(self):
        from concurrent.futures import ThreadPoolExecutor
        self.release_paths = []
        plan = self.plan([self.barrier_task("a",release="overlap-release"),
                          self.barrier_task("b",release="overlap-release"),
                          self.task("c",depends=("a",),delay=0)])
        # Keep the driver alive while the test awaits both peer acknowledgments;
        # a report window can expire before dispatch on a busy host.
        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(self.execute,plan)
            try:
                state_path = self.root/"runs/harness/fixture/state.json"
                deadline = time.monotonic()+plan["limits"]["total_wall_seconds"]
                while not state_path.exists() and not future.done() and time.monotonic()<deadline:
                    time.sleep(.02)
                self.assertTrue(state_path.exists(),"driver did not initialize")
                self.wait_live_task("a")
                self.wait_live_task("b")
                self.assertFalse((self.root/"runs/harness/fixture/tasks/c").exists())
            finally:
                (self.root/"overlap-release").touch()
            result = future.result(timeout=15)
        self.assertEqual(result["status"], "completed")
        records = result["tasks"]
        a,b,c = (records[name] for name in ("a","b","c"))
        self.assertLess(C.stamp(a["started_at"]),C.stamp(b["completed_at"]))
        self.assertLess(C.stamp(b["started_at"]),C.stamp(a["completed_at"]))
        self.assertGreaterEqual(C.stamp(c["started_at"]),C.stamp(a["completed_at"]))
        self.assertFalse(result["gate_advanced"])
        for name in records:
            C.verify_ref(self.root,records[name]["receipt_ref"])
            self.assertEqual(len(records[name]["output_refs"]),1)

    def test_window_handoff_keeps_live_task_and_resume_never_duplicates_it(self):
        self.release_paths = []
        plan = self.plan([self.barrier_task("a",release="a-release"),
                          self.task("b",depends=("a",),delay=0.05)],window=0.15)
        with self.handoff(plan) as first:
            self.assertEqual(first["status"],"handoff")
            self.assertEqual(first["tasks"]["a"]["status"],"running")
            identity = self.wait_live_task("a")
            self.assertFalse((self.root/"runs/harness/fixture/tasks/a/result.json").exists())
            (self.root/"a-release").touch()
            second = self.execute(plan)
        self.assertEqual(second["status"],"completed")
        self.assertEqual(second["started_at"],first["started_at"])
        self.assertEqual(second["tasks"]["a"]["started_at"],first["tasks"]["a"]["started_at"])
        self.assertEqual(second["tasks"]["a"]["process"],identity)
        native = json.loads(C.verify_ref(self.root,second["tasks"]["a"]["receipt_ref"]).read_text())
        self.assertEqual(len(native["attempts"]),1)
        self.assertGreaterEqual(len(list((self.root / "runs/harness/fixture/reports").glob("window-*.json"))),2)
        started = second["started_at"]
        third = self.execute(plan)
        self.assertEqual(third["started_at"],started)
        self.assertEqual(third["tasks"]["a"]["process"],identity)

    def test_resume_starts_ready_child_while_unrelated_orphan_is_still_running(self):
        self.release_paths = []
        plan = self.plan([self.barrier_task("a",release="a-release"),
                          self.barrier_task("b",release="c-ready.json"),
                          self.barrier_task("c",depends=("a",),observe="b")],window=0.12)
        with self.handoff(plan) as first:
            self.assertEqual(first["status"],"handoff")
            identities = {name:self.wait_live_task(name) for name in ("a","b")}
            self.assertFalse((self.root/"runs/harness/fixture/tasks/b/result.json").exists())
            (self.root/"a-release").touch()
            result = self.execute(plan)
        batch = self.root/"runs/harness/fixture"
        events = [json.loads(line) for line in (batch/"events.jsonl").read_text().splitlines()]
        diagnosis = C.canonical({"state":C.load_file(batch/"state.json"),"events":events})
        self.assertEqual(result["status"],"completed",diagnosis)
        self.assertEqual(result["started_at"],first["started_at"])
        observed = C.load_file(self.root/"c-ready.json")
        self.assertEqual(observed["observed_process"],identities["b"])
        for name,identity in identities.items():
            self.assertEqual(result["tasks"][name]["process"],identity)
            self.assertEqual(result["tasks"][name]["started_at"],first["tasks"][name]["started_at"])
        for name in ("a","b","c"):
            native = C.load_file(C.verify_ref(self.root,result["tasks"][name]["receipt_ref"]))
            self.assertEqual(len(native["attempts"]),1)
            self.assertEqual(native["run_id"],name)
            self.assertEqual(len(result["tasks"][name]["output_refs"]),1)
            C.verify_ref(self.root,result["tasks"][name]["output_refs"][0])
            self.assertEqual(sum(e["event"] == "task_started" and e["task_id"] == name for e in events),1)
        self.assertFalse(result["gate_advanced"])
        self.assertGreaterEqual(C.stamp(result["tasks"]["c"]["started_at"]),C.stamp(result["tasks"]["a"]["completed_at"]))
        self.assertLess(C.stamp(result["tasks"]["c"]["started_at"]),C.stamp(result["tasks"]["b"]["completed_at"]))

    def test_live_ram_pressure_limits_aggregate_pending_reservations(self):
        tasks = [self.task("a",delay=0.2),self.task("b",delay=0.2)]
        for task in tasks: task["resources"]["ram_mib"] = 350
        with patch.object(H,"_available_ram",return_value=500):
            result = self.execute(self.plan(tasks))
        self.assertGreaterEqual(C.stamp(result["tasks"]["b"]["started_at"]),C.stamp(result["tasks"]["a"]["completed_at"]))

    def test_failed_or_missing_output_blocks_descendants_but_not_independent_work(self):
        for missing in (False,True):
            with self.subTest(missing=missing):
                plan = self.plan([self.task("bad"+str(missing),fail=not missing,missing=missing),
                    self.task("child"+str(missing),depends=("bad"+str(missing),)),self.task("good"+str(missing))])
                plan["batch_id"] += str(missing); plan["plan_digest"] = H.plan_digest(plan)
                result = self.execute(plan)
                self.assertEqual(result["tasks"]["bad"+str(missing)]["status"],"failed")
                self.assertEqual(result["tasks"]["child"+str(missing)]["status"],"blocked")
                self.assertEqual(result["tasks"]["good"+str(missing)]["status"],"completed")
                self.assertNotIn("process",result["tasks"]["child"+str(missing)])

    def test_exact_authorization_and_changed_plan_fail_before_launch(self):
        plan = self.plan([self.task("a")])
        self.reject("HARNESS_EXECUTION_AUTHORIZATION_REQUIRED",lambda:H.run_harness(self.root,plan))
        self.reject("HARNESS_EXECUTION_NOT_AUTHORIZED",lambda:H.run_harness(self.root,plan,authorizer=lambda scope:False))
        self.assertFalse((self.root / "runs/harness/fixture").exists())
        changed = copy.deepcopy(plan); changed["limits"]["max_parallel_tasks"] = 1
        self.reject("HARNESS_PLAN_DIGEST_MISMATCH",lambda:H.validate_plan(self.root,changed))

    def test_hard_budget_stops_process_without_reset_on_resume(self):
        from concurrent.futures import ThreadPoolExecutor
        self.release_paths = []
        plan = self.plan([self.barrier_task("a",release="budget-release")],window=0.1)
        batch = self.root/"runs/harness/fixture"
        # Move only the driver's clock after both the worker and its real command
        # acknowledge readiness. The worker's own real-time alarm remains intact;
        # advancing past the original deadline and cleanup grace must make the
        # driver stop that live worker, rather than expire before command entry.
        offset = [0.0]
        clock = SimpleNamespace(time=lambda: time.time()+offset[0],
            monotonic=lambda: time.monotonic()+offset[0],sleep=time.sleep)
        children = []; real_popen = subprocess.Popen
        def capture(*args, **kwargs):
            child = real_popen(*args, **kwargs); children.append(child); return child
        with patch.object(H,"time",clock), patch.object(H.subprocess,"Popen",side_effect=capture):
            with ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(self.execute,plan)
                try:
                    ready_deadline = time.monotonic()+plan["limits"]["total_wall_seconds"]
                    while not (batch/"state.json").exists() and not future.done() and time.monotonic()<ready_deadline:
                        time.sleep(.02)
                    self.assertTrue((batch/"state.json").exists(),"driver did not initialize")
                    identity = self.wait_live_task("a")
                    command = C.load_file(self.root/"a-ready.json")["command_process"]
                    self.assertTrue(H._alive(command),"barrier command did not stay alive")
                    original = C.load_file(batch/"state.json")
                    self.assertLess(time.monotonic(),original["hard_deadline_monotonic"])
                    offset[0] = original["hard_deadline_monotonic"]+2.1-time.monotonic()
                    first = future.result(timeout=5)
                    self.assertEqual(first["status"],"budget_exhausted")
                    record = first["tasks"]["a"]
                    self.assertNotEqual(record["status"],"completed")
                    self.assertTrue(record["deadline_signal_sent"])
                    self.assertIsNotNone(record.get("receipt_ref"))
                    receipt = C.load_file(C.verify_ref(self.root,record["receipt_ref"]))
                    self.assertEqual(len(receipt["attempts"]),1)
                    self.assertEqual(receipt["attempts"][0]["status"],"interrupted")
                    for child in children: child.wait(timeout=1)
                    self.assertFalse(H._alive(identity),"deadline left harness worker alive")
                    self.assertFalse(H._alive(command),"deadline left native command alive")
                    for _ in range(2):
                        second = self.execute(plan)
                        self.assertEqual(second["status"],"budget_exhausted")
                        self.assertEqual(second["started_at"],first["started_at"])
                        self.assertEqual(second["tasks"]["a"]["process"],identity)
                        self.assertEqual(second["tasks"]["a"]["receipt_ref"],record["receipt_ref"])
                        state = C.load_file(batch/"state.json")
                        for key in ("started_epoch","started_monotonic","hard_deadline_epoch","hard_deadline_monotonic"):
                            self.assertEqual(state[key],original[key])
                    events = [json.loads(line) for line in (batch/"events.jsonl").read_text().splitlines()]
                    self.assertEqual(sum(event["event"]=="task_started" for event in events),1)
                    self.assertEqual(len(children),1)
                finally:
                    (self.root/"budget-release").touch()
                    for child in children:
                        try: child.wait(timeout=1)
                        except subprocess.TimeoutExpired:
                            child.kill(); child.wait(timeout=1)

    def test_cycle_duplicate_run_and_idea_overflow_are_rejected(self):
        a,b = self.task("a",depends=("b",)),self.task("b",depends=("a",))
        self.reject("HARNESS_DEPENDENCY_CYCLE",lambda:self.plan([a,b]))
        b = self.task("b"); b["plan_ref"] = a["plan_ref"]; a["depends_on"] = []
        self.reject("HARNESS_DUPLICATE_NATIVE_RUN",lambda:self.plan([a,b]))
        tasks = [self.task("idea"+str(n),delay=0) for n in range(21)]
        for n,task in enumerate(tasks): task["idea_id"] = "idea"+str(n)
        self.reject("HARNESS_TOO_MANY_IDEAS",lambda:self.plan(tasks))

    def test_exclusive_mutable_asset_serializes_otherwise_independent_tasks(self):
        tasks = [self.task("a",delay=0.2),self.task("b",delay=0.2)]
        for task in tasks: task["resources"]["exclusive_keys"] = ["shared-build-cache"]
        result = self.execute(self.plan(tasks))
        self.assertGreaterEqual(C.stamp(result["tasks"]["b"]["started_at"]),C.stamp(result["tasks"]["a"]["completed_at"]))

    def test_gpu_admission_uses_peak_reservations_headroom_and_foreign_processes(self):
        # Explicit hardware double: this test does not claim live GPU execution.
        resource = {"cpu_cores":1,"ram_mib":32,"gpu_count":1,"gpu_peak_mib":8000,
                    "allow_gpu_share":True,"memory_profile_ref":{"path":"unused","sha256":DIGEST},"exclusive_keys":[]}
        gpu = {"uuid":"GPU-fixture","total_mib":22000,"used_mib":5000,"foreign_mib":0,"foreign_pids":[]}
        active = [{"resources":{**resource,"gpu_peak_mib":8000},"devices":["GPU-fixture"]}]
        policy = {"uuids":["GPU-fixture"],"safety_margin_mib":2048,"max_tasks_per_gpu":2}
        self.assertEqual(H.select_devices(resource,active,[gpu],policy),["GPU-fixture"])
        larger = {**resource,"gpu_peak_mib":14000}
        self.assertIsNone(H.select_devices(larger,active,[gpu],policy))
        foreign = {**gpu,"foreign_mib":1000,"foreign_pids":[999]}
        self.assertIsNone(H.select_devices(resource,active,[foreign],policy))
        exclusive = {**resource,"gpu_peak_mib":None,"allow_gpu_share":False,"memory_profile_ref":None}
        self.assertIsNone(H.select_devices(exclusive,active,[gpu],policy))
        self.assertEqual(H.select_devices(exclusive,[],[{**gpu,"used_mib":0}],policy),["GPU-fixture"])
        self.assertIsNone(H.select_devices(resource,[],[],policy))
        over_peak = {**gpu,"used_mib":18000}
        self.assertIsNone(H.select_devices(resource,active,[over_peak],policy))

    def test_completed_batch_keeps_completion_after_budget_time_has_passed(self):
        # Complete a real command first. Its replay semantics must not depend
        # on fitting interpreter startup into a 300 ms wall-clock budget.
        plan = self.plan([self.task("a",delay=0)],window=0.1)
        result = self.execute(plan)
        self.assertEqual(result["status"],"completed")
        state = C.load_file(self.root/"runs/harness/fixture/state.json")
        later = SimpleNamespace(time=lambda: state["hard_deadline_epoch"]+1,
            monotonic=lambda: state["hard_deadline_monotonic"]+1, sleep=time.sleep)
        with patch.object(H,"time",later):
            for stop_after_report in (False,True):
                resumed = self.execute(plan,stop_after_report=stop_after_report)
                self.assertEqual(resumed["status"],"completed")
                self.assertEqual(resumed["started_at"],result["started_at"])
                self.assertEqual(resumed["tasks"]["a"]["receipt_ref"],result["tasks"]["a"]["receipt_ref"])

    def test_background_child_cannot_keep_running_after_foreground_task_finishes(self):
        task = self.task("a",delay=0)
        native = C.load_file(C.verify_ref(self.root,task["plan_ref"]))
        native["jobs"][0]["command"] = [sys.executable,"-c",
            "import pathlib,subprocess,sys; subprocess.Popen([sys.executable,'-c',"
            "\"import pathlib,time; time.sleep(.4); pathlib.Path('late.txt').write_text('unowned child')\"]); "
            "pathlib.Path('result.txt').write_text('leader exited')"]
        native["plan_digest"] = R.plan_digest(native)
        task["plan_ref"] = write(self.root,"plans/a.json",native)
        result = self.execute(self.plan([task],total=0.3))
        self.assertNotEqual(result["tasks"]["a"]["status"],"completed")
        time.sleep(0.45)
        self.assertEqual(list((self.root/"runs/attempts/a").rglob("late.txt")),[])

    def test_changed_completed_output_is_rejected_on_resume(self):
        plan = self.plan([self.task("a",delay=0)])
        result = self.execute(plan)
        output = self.root / result["tasks"]["a"]["output_refs"][0]["path"]
        output.write_text("changed after execution")
        self.reject("EVIDENCE_DIGEST_MISMATCH",lambda:self.execute(plan))

    def test_existing_native_run_is_held_for_reconciliation_without_new_attempt(self):
        task = self.task("a",delay=0)
        native = C.load_file(C.verify_ref(self.root,task["plan_ref"]))
        R.run_plan(self.root,native,authorizer=lambda scope:True)
        result = self.execute(self.plan([task]))
        self.assertEqual(result["status"],"reconciliation_required")
        self.assertEqual(result["tasks"]["a"]["reason_code"],"HARNESS_NATIVE_RUN_EXISTS_RECONCILE_REQUIRED")
        receipt = C.load_file(self.root/"runs/attempts/a/receipt.json")
        self.assertEqual(len(receipt["attempts"]),1)

    def test_cli_freezes_validates_and_reads_status_without_starting_extra_work(self):
        plan = self.plan([self.task("a",delay=0)])
        draft = {key:value for key,value in plan.items() if key != "plan_digest"}
        draft_ref = write(self.root,"draft.json",draft)
        script = str(pathlib.Path(H.__file__))
        output = subprocess.run([sys.executable,script,str(self.root/draft_ref["path"]),"--root",str(self.root),"--freeze"],
                                capture_output=True,text=True,check=True)
        self.assertEqual(json.loads(output.stdout),plan)
        frozen = write(self.root,"harness.json",plan)
        argv = [sys.executable,script,str(self.root/frozen["path"]),"--root",str(self.root)]
        output = subprocess.run(argv,capture_output=True,text=True,check=True)
        self.assertFalse(json.loads(output.stdout)["execution_started"])
        self.assertFalse((self.root/"runs/harness/fixture").exists())
        self.execute(plan)
        output = subprocess.run(argv+["--status"],capture_output=True,text=True,check=True)
        self.assertEqual(json.loads(output.stdout)["tasks"]["a"]["status"],"completed")

    def test_gpu_share_requires_a_matching_pinned_measurement_profile(self):
        task = self.task("a",delay=0)
        task["resources"].update(gpu_count=1,gpu_peak_mib=1000,allow_gpu_share=True)
        limits = {"window_seconds":8*3600,"total_wall_seconds":10,"max_parallel_tasks":2,
                  "cpu_cores":2,"ram_mib":1024,"max_gpu_task_seconds":3}
        gpu = {"uuids":["GPU-fixture"],"safety_margin_mib":512,"max_tasks_per_gpu":2}
        kwargs = dict(batch_id="fixture",tasks=[task],pool_dir=str(self.root/"pool"),limits=limits,gpus=gpu)
        self.reject("HARNESS_SHARING_PROFILE_REQUIRED",lambda:H.make_plan(self.root,**kwargs))
        native = C.load_file(C.verify_ref(self.root,task["plan_ref"]))
        evidence = write(self.root,"profile-evidence.json",{"engineering_hardware_double":True})
        profile = env("gpu-memory-profile",workload_digest=H.workload_digest(native),device_uuids=["GPU-fixture"],
            peak_mib=900,reservation_mib=1000,qualified_max_concurrency=2,measured_at="2026-10-04T00:00:00Z",
            co_location_workload_digests=[H.workload_digest(native)],measurement_refs=[evidence],throughput_evidence_refs=[evidence])
        task["resources"]["memory_profile_ref"] = write(self.root,"profile.json",profile)
        H.make_plan(self.root,**kwargs)
        profile["workload_digest"] = DIGEST
        task["resources"]["memory_profile_ref"] = write(self.root,"profile.json",profile)
        self.reject("HARNESS_MEMORY_PROFILE_MISMATCH",lambda:H.make_plan(self.root,**kwargs))

    def test_checkpoint_hash_uses_bounded_memory(self):
        path = self.root/"engineering-checkpoint.bin"
        block = b"engineering artifact"*50000; expected = hashlib.sha256()
        with path.open("wb") as stream:
            for _ in range(24): stream.write(block); expected.update(block)
        tracemalloc.start()
        try:
            actual = C.filehash(path); peak = tracemalloc.get_traced_memory()[1]
        finally: tracemalloc.stop()
        self.assertEqual(actual,expected.hexdigest())
        self.assertLess(peak,5*1024*1024)

    def test_worker_death_cleans_up_native_process_before_ownership_is_reused(self):
        task = self.task("a",delay=0)
        native = C.load_file(C.verify_ref(self.root,task["plan_ref"]))
        native["jobs"][0]["command"] = [sys.executable,"-c",
            "import pathlib,time;time.sleep(.65);pathlib.Path('late.txt').write_text('owner lost');pathlib.Path('result.txt').write_text('late')"]
        native["plan_digest"] = R.plan_digest(native); task["plan_ref"] = write(self.root,"plans/a.json",native)
        children = []; real_popen = subprocess.Popen
        def capture(*args,**kwargs):
            child = real_popen(*args,**kwargs); children.append(child); return child
        with patch.object(H.subprocess,"Popen",side_effect=capture):
            first = self.execute(self.plan([task],window=0.15),stop_after_report=True)
        self.assertEqual(first["tasks"]["a"]["status"],"running")
        children[0].kill(); children[0].wait()
        second_plan = self.plan([self.task("b",delay=0.03)],total=2)
        second_plan["batch_id"] = "other"; second_plan["plan_digest"] = H.plan_digest(second_plan)
        self.assertEqual(self.execute(second_plan)["status"],"completed")
        time.sleep(0.7)
        self.assertEqual(list((self.root/"runs/attempts/a").rglob("late.txt")),[])

    def test_owner_write_failure_does_not_leak_a_host_lock(self):
        lock = self.root/"pool"/"execution.lock"
        with patch.object(H,"_atomic",side_effect=OSError("engineering ENOSPC double")):
            with self.assertRaises(OSError): H._owned_lock(lock,{"batch":"fixture"})
        fd = H._lock(lock)
        self.assertIsNotNone(fd)
        os.close(fd)


def schema_contract_examples():
    fixture = HarnessTests(); fixture.setUp()
    try:
        plan = fixture.plan([fixture.task("schema",delay=0)])
        ref = write(fixture.root,"engineering/profile-source.json",{"engineering_hardware_double":True})
        profile = env("gpu-memory-profile",workload_digest=DIGEST,device_uuids=["GPU-fixture"],peak_mib=100,
            reservation_mib=200,qualified_max_concurrency=2,measured_at="2026-10-04T00:00:00Z",
            co_location_workload_digests=[DIGEST],measurement_refs=[ref],throughput_evidence_refs=[ref])
        return {"harness-plan":(plan,"limits"),"gpu-memory-profile":(profile,"measurement_refs")}
    finally: fixture.doCleanups()


if __name__ == "__main__": unittest.main()
