# Optional Chat action records

Use scripts/chat_cycle.py when Python and a persistent writable project
directory are actually available. It is operational bookkeeping with a bridge
to the canonical scientific verifier, not an executor, scheduler or permission grant. The active Chat
agent calls advance, reads its actual procedure text, executes the returned
action with host tools, records the result and advances again in the same turn.

Before new research dispatch or migration, read [Chat control records](chat-control-records.md)
for strategy, actual invocation, persistence and runner events. These constraints
also apply to diagnostic investment; they do not grant scientific acceptance.

## Commands

Copy assets/templates/chat-cycle.json into the actual project, replace its
placeholders and calculate real hashes. The user/project supplies a finite
max_attempts; no usage or receipts are invented.

    python3 chat_cycle.py init --state PROJECT/chat-cycle.json --config PROJECT/config.json
    python3 chat_cycle.py next --state PROJECT/chat-cycle.json
    python3 chat_cycle.py advance --state PROJECT/chat-cycle.json --expected-revision N
    python3 chat_cycle.py record --state PROJECT/chat-cycle.json --expected-revision N --event PROJECT/event.json
    python3 chat_cycle.py resume --state PROJECT/chat-cycle.json --expected-revision N

Read the returned revision for the next mutation. All evidence paths are relative
to the checkpoint directory. Save the checkpoint and its referenced files to
the actual durable destination with readback; a transient local file is not
automatically durable. When the helper is unavailable, preserve the same facts
using actual artifact/repository tools without creating a new software gate.

## Actual host subagents inside a parent attempt

Use [parallel work](chat-parallel-work.md) when independent useful packets exist.
Keep one current parent attempt and one canonical candidate. All mutations below
use the same `record --expected-revision N --event FILE` command and are made by
the coordinator. These events never spawn, poll, stop or authenticate an agent;
the coordinator must make the corresponding actual host call and save its receipt.

| Event `op` | Additional fields and effect |
|---|---|
| `team_capability` | `observation_ref`: capture current host capability/inventory |
| `team_start` | `attempt_id`, `config`: set finite team bounds once |
| `team_prepare` | `attempt_id`, `packet`: reserve a child and persist dispatch intent |
| `team_bind` | `attempt_id`, `child_id`, `dispatch_token`, `receipt_ref`: bind the actual returned identity |
| `team_observe` | `attempt_id`, `child_id`, `receipt_ref`: record an actual observation or reconcile lost acknowledgement |
| `team_continue` | `attempt_id`, `child_id`: prepare a bounded continuation of an acknowledged partial child |
| `team_result` | `attempt_id`, `child_id`, `result_ref`: settle actual terminal evidence |
| `team_usage` | `attempt_id`, `totals`, `accounted_child_ids`, `receipt_ref`: reconcile cumulative usage without resetting history |

The capability JSON has `kind=chat-team-capability`, `session_id`,
`parent_agent_id`, `capabilities={spawn,observe,continue}` booleans,
`max_active_agents`, `active_agent_ids`, `observed_at`, `expires_at` and
`source_ref`. Count the parent and external active agents in the inventory.
Times are timezone-qualified; the observation expires within one hour and must
remain current at dispatch. The helper requires an observed numeric capacity;
if the host does not expose it, retain equivalent bounded records through actual
artifact tools and obey real admission responses. Missing capabilities permit
serial work; they do not grant independent-review credit.

`config` contains `source_ref`, `max_children`, `deadline_seconds`,
`parent_reserve`, `parent_output_paths` and `parent_resource_ids`. The limits
come from the actual project/working plan. `parent_reserve` and each packet's
`reserve` cover exactly the project's declared budget units. Empty dictionaries
are appropriate only when no such units are declared; they do not assert zero
provider usage or authorize a paid service. Team bounds cannot be reset by
starting another team in the same attempt.

A packet contains `id`, `role` (`source`, `implement`, `experiment`, `review`),
`action`, `acceptance`, `input_refs`, `output_paths`, `resource_ids`, `job_ids`,
`reserve`, `deadline_seconds`, `max_continuations`, and optional `review_of`
producer child IDs. Inputs are pinned parent inputs or settled child outputs.
Outputs name exact, nonoverlapping project-relative files, including the
reviewer's own findings file. A read-only child may return its text to the
coordinator, who saves those actual returned bytes in the assigned file.
Never give a child ownership of the checkpoint or pinned source artifacts.
Internal state fields such as `actual_usage`, `status` and `agent_id` are not
packet inputs. Do not inject them to change reservations or invent execution.

An experiment child owns one pinned confirmation job. The helper rechecks the
real experiment admission and derives an exclusive `experiment-host:HOST_ID`
resource from that job's contract; caller-supplied resource labels cannot remove
it. This first implementation serializes experiments sharing a contracted host,
even if the host has several GPUs. The helper can admit separate contracted hosts,
but single-experiment-batching.md requires the coordinator to serialize experiments
across the whole project as well. Readers/reviewers may proceed within resources. Diagnostic experiments
remain parent actions. General per-job eligibility is not aggregate concurrency
permission, and this helper does not provision or partition GPU resources.

Read the saved child record after `team_prepare`: it contains the immutable
parent/candidate/procedure pins and unique `dispatch_token`. Include that token
in the task-local packet, then make the actual spawn call. Save and bind the
returned agent identity. A crash or lost acknowledgement leaves the dispatch
reserved: query the original host operation before any replacement. Do not
blindly repeat spawn by replaying the prepared packet.

An operation receipt has `kind=chat-team-operation`, `attempt_id`, `child_id`,
`dispatch_token`, `session_id`, `agent_id`, `state`, `observed_at`, `source_ref`.
States describe actual `running`, `queued`, `partial`, `unknown`, `completed`,
`failed`, `cancelled` or `not_started` observations. An acknowledged partial
receipt also includes `partial_refs` and `next_action`; `team_continue` pins a
new dispatch token for the same agent and preserves the earlier operation.
Call the supported host continuation API once, then bind its real response.
An agent-stop observation alone does not prove its experimental process stopped.

A child result JSON has `kind=chat-child-result`, `attempt_id`, `child_id`,
`candidate_id`, `procedure` (the full pinned object), exact `input_refs`,
`dispatch_token`, `agent_id`, `outcome=completed|failed|cancelled`,
`operation_ref`, `raw_evidence`, `output_refs`, `actual_usage` and `usage_ref`.
Require an actual terminal operation, fresh owned output files and original
identity bindings. Cancellation before binding requires a real `not_started`
observation. A missing acknowledgement is insufficient. The packet's completed
producer and reviewer must have different actual agent identities.

Experiment results additionally retain `job_receipts`: each referenced JSON has
`kind=chat-team-job-receipt`, `attempt_id`, `child_id`, `contract_ref`,
`dispatch_token`, `host_id`, `job_id`, terminal `state`, `execution_id` (unless
actually `not_started`), `observed_at` and `source_ref`. Observe the original experimental
process/provider operation before releasing its resource. These receipts prove
neither native-score validity nor scientific acceptance by themselves.

A usage receipt has `kind=chat-team-usage`, `attempt_id`, `totals`,
`accounted_child_ids`, `observed_at` and `source_ref`. Record whole-project observed wall time,
not the sum of concurrent child durations; additive device/model/cost units
include every actual operation once. Keep unknown usage unresolved. Accounting
for terminal children releases only their unused reservation; live or unknown
operations retain their reservation. Observation and settlement remain possible
after a dispatch budget or deadline expires.

`next`/`advance` returns `kind=parallel` while child work needs observation or
integration. Poll actual identities and do independent ready work. Checkpointing
retains the team; it does not authorize replay. Parent settlement/resumption
requires terminal children and reconciled declared usage. Include every child's
`result_ref` in the parent's `raw_evidence`, preserve failures, and run the existing
parent/scientific acceptance checks. Child results do not add criteria, deliveries
or research cycles automatically. After the parent settles, advance the original
goal as usual. Checkpoints without a team retain their serial behavior.

When an input or previously settled child artifact becomes invalid, record the
actual failure and reconcile the original operation. Failed/blocked settlement
retains original identities and explicit invalidation records so recovery can
proceed. Successful parent settlement still revalidates all child evidence;
the failure route never creates scientific or completed-task credit.

## Goal scope and amendments

Save the actual original request and relevant later steering as immutable evidence.
The configuration's goal_contract contains mode (research or bounded_task), a
request_ref with its real path/hash, and continuation_action. Read those source
bytes when choosing the mode; neither the plugin name nor an agent's short goal
summary authorizes expanding or narrowing the request. Use bounded_task for an
explicit paper-selection, reproduction, audit or code-only request. The template
defaults to research and must be filled from the actual request before use.

Keep task milestones separate from the parent goal. For research, even a completed
preflight with every declared criterion does not close the goal. When advance
returns replan, the current Chat host reads the outstanding obligations, creates
the concrete next authorized task with add_task, and calls advance again before
executing it. Do not finish the turn merely by printing the returned next action.
Actual budget, unknown-operation and capability boundaries still apply.

Use record op=revise_goal for a sourced correction or later scope extension.
Retain the prior goal, contract and stop observation in history. Preserve existing
criteria/deliveries and add newly required obligations, without resetting attempts,
usage, task outcomes or procedure versions. Reconcile any current attempt first.
A legitimate completed selection goal stays a completed historical milestone;
the new research goal has no scientific cycles until they are actually evidenced.
Old helper checkpoints without a contract remain readable and executable but need
scope review before terminal completion. Arbitrary checkpoint.json files from
other formats are not automatically imported: preserve their original bytes and
append the same sourced scope amendment in their existing record format.

Known prior usage carries forward. Unknown usage is not zero, and a new research
allowance must not be backdated. Revising a goal alone grants no new budget; retain
the original cumulative bounds and follow the actual user's budget authority.

## Records and receipts

Tasks declare id, action, candidate_id, dependencies and input_refs. Optional kind
is action, preflight, research_experiment or research_analysis. Begin pins
task/candidate/procedure/input versions to an attempt. Result evidence binds
attempt_id, task_id, candidate_id, procedure_id, outcome and raw_evidence refs.
Completed criteria must name originally requested IDs. Deliveries need receipt
refs with attempt_id, destination and equal delivered_sha256/readback_sha256,
matching a supplied raw artifact. A path alone, old unbound evidence or a changed
prerequisite cannot establish fresh completion.

The helper checks actual referenced bytes and bindings. It cannot authenticate
the stated provider/reviewer/destination: the agent must perform the independent
review or delivery and retain its genuine result. bookkeeping_complete means
all declared operational records are present, not canonical scientific PASS.

## Scientific cycles and goal completion

Count an execution attempt or seed run separately from a scientific cycle. A
preflight is not a research_experiment. More seeds from the same diagnostic batch
cannot supply a hypothesis, validation design or independent review.

Use record with op=research_cycle and cycle containing cycle_id, candidate_id,
attempt_ids, hypothesis_ref, design_ref and review_ref. Retain these actual files:

- hypothesis_ref: JSON kind=research_hypothesis, candidate_id, proposal_task_id,
  hypothesis, derivation, prediction and falsifier.
- design_ref: JSON kind=research_design, candidate_id, the same hypothesis_ref,
  mode=empirical or theoretical, comparison and protocol. A theoretical contract
  identifies the formal comparison/proof obligation, not an invented benchmark.
- review_ref: JSON kind=research_cycle_review, the same cycle_id, candidate_id,
  attempt_ids, hypothesis_ref, design_ref and proposal_task_id; a distinct
  review_task_id; verdict=supported, refuted or inconclusive; next_action; and
  raw_evidence containing the referenced attempts' evidence_ref values.

Before execution, pin hypothesis_ref and design_ref in each research task's
input_refs. A later hypothesis cannot retrospectively adopt an unrelated run.
Referenced attempts must have actually settled with completed or refuted evidence
for the same candidate. Empirical cycles require a research_experiment attempt;
theoretical cycles permit research_analysis. Duplicate cycle IDs, reused
attempts, and more seeds for the same candidate/hypothesis/design cannot inflate
the cycle count. Negative results retain their verdict;
counting a reviewed cycle does not credit a refuted candidate as a success.
next/advance returns scientific_cycle_count and invalid_research_cycles after
rechecking references, not merely the length of a saved list.

Before closing a research goal, perform the real independent completion review.
Record op=goal_review with review_ref pointing to JSON kind=goal_review,
goal_id, goal, goal_revision, state_revision (before this record), the exact
goal_contract, criteria, deliveries, attempt_ids (all settled, in saved order),
cycle_ids (all valid, in saved order), distinct proposal_task_id/review_task_id,
outcome=complete, and raw_evidence containing every settled evidence_ref and each
cycle review_ref. Review the sourced request, all required claims, unresolved work
and actual delivery receipts, rather than inferring success from those strings.

The helper requires current, recomputed scientific evidence for empirical research
completion, as specified below; a counted cycle or matching text is insufficient.
It retains prerequisite, criterion and delivery checks, revalidates bytes and rejects
stale scope/revision bindings. Later mutation or changed evidence requires a fresh
review. An explicit bounded_task may meet its
operational obligations without creating a research cycle; the host still checks
that the actual request is satisfied. These records do not authenticate a reviewer
or replace scientific validation in the applicable research modules.

## Paper-grounded, resource-bound empirical completion

Research experiment tasks explicitly declare experiment_phase=diagnostic or
confirmation. Diagnostics may establish feasibility or revise a hypothesis;
they cannot close an empirical research goal. Confirmation tasks pin all three
experiment_contract_ref, experiment_review_ref and canonical_batch_ref in their
input_refs, plus experiment_job_ids naming the exact planned jobs. Use the
experiment-design-contract template and experiment_contract.py for the published
paper/appendix/code extraction, adopt/adapt/reject decisions, claim-to-obligation
coverage, real host probes, calibration, cumulative allowance and independent
design review. Owned GPUs do not imply reachable, authorized or allocated GPUs.

Before dispatch, the helper checks job eligibility and the canonical method
batch through design. Each scientific obligation must match its actual canonical
claim, metric, explicit arm weights, groups, benchmark revision/split/sample,
scorer, uncertainty method and minimum independent units. A required comparison
cannot be substituted with a different convenient positive criterion.

Confirmation requires cumulative budget limits and observed usage in wall_seconds,
gpu_seconds and cost. Explicit zero GPU/cost allowances permit CPU/free jobs.
For an older max_attempts-only checkpoint, record bind_resources with source_ref,
limits, totals and receipt_ref. This adds the actual sourced resource bounds and
current observed totals while preserving all prior limits and attempts. Record
usage after every settled attempt, including failed retries, before another
confirmation or final closure. Unknown usage is not zero. Selected jobs must fit
the current remaining allowance; settled frozen jobs are never silently replayed.

The completion goal_review adds execution_ref for the actual independent review,
scientific_evidence and claim_coverage. Each scientific_evidence entry contains
cycle_id, contract_ref, design_review_ref, completion_ref and canonical_batch_ref.
The completion packet contains the actual job/attempt/execution receipts and
operational check receipts described in experiment_contract.py. Attach canonical
run-manifest refs to the actual attempt raw_evidence and matching completion
receipts. claim_coverage maps every goal criterion to a nonempty list of
{cycle_id,claim_id}. Include all four scientific refs in goal review raw_evidence.
Cycle reviews used for closure also retain execution_ref and unresolved_obligations.

Closure reruns verify_methods against the current full-validation protocol and
actual native evidence. Gate A, diagnostic batches, saved PASS strings and missing
live scoring/analysis capabilities cannot stand in for that computation. Mixed
claim outcomes are checked individually against recomputed confidence bounds;
resource-limit KILL is not scientific refutation. A scoped hypothesis-evaluation
goal may declare allowed_outcomes=["supported","refuted"] from the actual request;
the default is ["supported"]. Valid negative evidence retains its negative verdict.

Inconclusive reviews preserve their concrete next action. If a direction is
retired in favor of a materially changed verified successor, goal_review may
include retired_cycles entries {cycle_id,successor_cycle_id,review_ref}. The
independent retirement review has kind=research-cycle-retirement, those IDs,
cycle_review_ref, successor_hypothesis_ref, proposal_task_id, review_task_id,
execution_ref and a reason explaining the scope/obligation transfer. Include
that review in raw_evidence; preserve the earlier results and unresolved history.
An unexplained omission never clears a research gap.

Old unlabelled tasks remain readable and return migration/replan without consuming
an attempt. Use revise_task with task_id, reason and a new task object to version an
unstarted pending/blocked contract. Keep the same candidate and existing dependency
obligations; old records remain intact. Existing bounded_task behavior is unchanged.

## Live verification on the current host

The Python API exposes scientific_runtime(native_replay_context=callable,
analysis_context=callable). It delegates to the existing trusted evaluation context;
callbacks are never loaded from checkpoint JSON. Supply actual bounded scorer and
analysis execution with the current host's existing permissions. No Local, SSH,
ACP or model API is required. The standalone CLI without a configured host callback
returns a concrete scientific-verification blocker instead of trusting a receipt.
next does not mutate the checkpoint, but a configured callback may replay a scorer.

Pure theoretical goals use actual proof obligations, not an empirical benchmark.
Their scientific_evidence entry names formal_evidence_ref instead of an experiment
contract. That packet has kind=formal-goal-evidence, candidate_id, cycle_id,
hypothesis_ref, design_ref, claim_ids and proof_refs attached to the actual analysis
attempt. A host-supplied formal_completion_validator receives this pinned evidence
and cycle review; it must independently verify the real obligations and return
verified, evidence_ref, claim_ids, verdict and its execution_ref. No such capability
means a formal-review blocker, never invented proof. Bounded theoretical artifacts
remain deliverable under the original bounded_task contract.

Failures/refutations retain evidence, reason and next_action. A repair task
names repairs and points to actual replacement inputs; failure history stays.
Acknowledged partial work uses checkpoint then resume on the same attempt.
Lost acknowledgements are reconciled by real host identities before retrying.
Use usage only with actual observations and refs; unknown costs are not zero.

## Procedure adoption

Stage an actual candidate procedure file and separately review it against the
pinned baseline. The adoption review binds kind=procedure_review,
base_procedure_id, base_procedure_sha256, candidate_procedure_id,
candidate_sha256, distinct proposal_task_id/review_task_id, outcome=supported
and raw_evidence. Adoption uses a fresh version ID and affects only future
attempts; current attempts retain their version. Read the adopted bytes before
the next real action. Independent assignment and validation remain actual agent
obligations, not facts proven by strings in JSON.

Use the prior accepted file as a newly recorded rollback version after a
regression; do not rewrite history or reuse a version ID for different bytes.
Project procedure adoption does not install a plugin or change system rules.

## Automatic active-turn continuation

advance uses the expected revision and returns the selected attempt, action,
procedure_text/procedure_ref, input_refs, dependency_evidence_refs, checkpoint_refs,
failure_context and new revision. It begins ready work or resumes an explicitly
checkpointed partial attempt with the same identity and original procedure.
An already active attempt is uncertain to a new caller: reconcile the real host
operation rather than replay it. No eligible task is not proof of goal completion.

Record an engineering failure with failure_class=environment, implementation or
evaluation. If classification is initially missing, inspect its evidence and use
record with op=classify_failure, attempt_id, failure_class, evidence_ref and
next_action. Hypothesis/refuted outcomes do not authorize automatic engineering
retries. Each repair chain permits at most three automatic generations within
the original cumulative max_attempts; restarting does not reset either bound.

The next advance creates a distinct repair task containing the actual failure
context. Once it succeeds, pending consumers receive distinct successor IDs
and new dependency pins, one layer at a time. Old tasks, attempts and failures
remain recorded. Unrelated ready tasks may continue when one repair is blocked.

Keep raw failure/partial evidence and producer outputs as immutable versioned
files. Optional result envelope output_bindings maps a stable logical output
name to a real {path,sha256} ref that is also in raw_evidence. This lets a repair
produce a new versioned path and lets downstream inputs follow that exact output.
output_refs may name the raw refs that are actual outputs. Other static inputs
retain their old pins; missing or changed evidence blocks only affected actions.

After a valid adopt, the next new attempt's advance returns the adopted file's
actual UTF-8 text. The host must consume this handoff when doing the action;
current/partial attempts keep their previous version. These actions run in an
already active Chat turn, without Local, a new model API or a background service.
