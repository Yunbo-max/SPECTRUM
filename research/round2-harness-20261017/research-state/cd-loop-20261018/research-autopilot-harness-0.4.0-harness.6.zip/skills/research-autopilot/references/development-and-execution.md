# Development, Gate A and recoverable execution

Use [single-experiment batching](single-experiment-batching.md): one active
experiment program, sequential descending batch calibration (for example
64 → 32 → 16 → 8 → 4 → 2), preserved scientific semantics and measured useful
throughput/headroom. Queue other experiments; keep Chat within CPU/4 GB.

Before blocking a stage on scorer availability/isolation, apply
[native-scoring-stages.md](native-scoring-stages.md). Restore real deferred scoring
support from the project. Independent training/export may proceed with saved
unscored artifacts; final metric claims wait for actual native scoring. No Docker
on any host. Requirements for a scorer that executes generated programs belong
to that operation, not automatically to training or prediction generation.


**Chat RSI scope:** follow chat-execution.md for execution host, continuation
and candidate count. The current host may run authorized feasible checks; new
discovery defaults to one candidate with the recorded target_override. Local
acceptance and 20-to-15 references describe optional legacy-backend/broad-discovery
modes. Preserve the evidence requirements for the actual action and claim.

Read gate-a.md for authoritative gate conditions. Development is a loop, not a
one-shot pass requirement. Preserve the existing state machine and exact caller
route. The phases below are workflow descriptions, not new enum values.
For new/reopened method discovery, require mathematical generation of about 20
candidates, per-card verification and ranked top-15 selection before code design
under [method-verification.md](method-verification.md). Require current
code/design evidence before candidate dispatch; tagged native protocols recheck
their pinned discovery prerequisites. Historical code and baseline tests remain
scoped historical evidence, not proof that this order was followed.

## G01 Minimum informative design

Choose the cheapest valid contrast that distinguishes the core prediction from
the strongest competitor. Minimum means decision-capable, not a fixed tiny n.
Define unit, endpoint, control, practical effect, uncertainty and budget. Route
implementation needs to E; return to this same question with exact task identity.
Apply full-validation-and-review.md's G01 card and rolling-research-batches.md:
keep complete comparisons across soft report points and up-to-24-hour Local
cycles, at most 20 active
ideas, and finite capacity-aware dispatch. Unfinished eligible approved units
carry forward unchanged; a partial comparison is not a scientific verdict.

## G02 Development before confirmation

Use discovery/dev data for code repair, qualified baseline tuning and prespecified
exploratory ranges. Allow repeated attempts within agreed time/cost/attempt bounds;
record failed and unselected trials, changed parameters and reasons. Human may
revise the development budget with a recorded decision. Do not kill a scientific
hypothesis because the first implementation crashed.

Before an affected full run, choose the cheapest informative acceptance/diagnostic
from actual code/log/input evidence; evaluation checks require benchmark-supplied
native cases and scoring. Give each task a finite
diagnosis/repair allowance inside the cumulative development budget: inspected
evidence, competing cause, next distinguishing check, attempt and elapsed-time
ceilings, resource/spend limits and a stop condition. Local may inspect, diagnose
and repair within that allowance before or during development. Repeated failed
repairs or checks that add no material evidence end that task's current repair
effort; use E04's bounded continuation rule. Small checks do not replace the full
scientific comparisons, controls, scoring or confirmation obligations.

Give Local an explicit adaptive development envelope in the project runbook:
implementation repairs preserving the construction, tunable parameters and
justified bounds or bounded range-selection rules, development-only objectives,
fair baseline allowances, resource calibration/replanning rules and cumulative
time/compute/spend/attempt ceilings. Within that envelope Local may diagnose,
repair, choose the next informative settings, requalify affected properties and
continue without asking for each ordinary adjustment. Initial parameter choices
and cost estimates are developmental assumptions, not permanent constants.
Record measured costs and adjust pending feasible dispatch within remaining
bounds through versioned future operational plans; never edit active plan
identities or exceed hard limits. A broader
search, changed scientific construction/coverage/metric/training scope or budget
requires the existing human/child-protocol decision. Freeze confirmation only
after development; its settings cannot be adapted to inspected outcomes.

Separate development loop → qualification → frozen confirmation → verdict.
Freeze all result-affecting setup, hypotheses, metrics, tolerance/uncertainty,
eligibility, exclusions, budgets and verdict rules before seeing confirmation.
Previously viewed results stay developmental. A result-affecting repair or new
hyperparameter after unblinding creates a child protocol and new valid confirmation,
never retroactively turns the old result into a prespecified test. Preserve lineage.
Use [native-runner.md](native-runner.md) to freeze actual trial inventory,
per-attempt/global wall time and development/retry ceilings. It stages distinct
attempt workspaces and retains failed/OOM/timeout outputs. Confirmation permits
no retries or reused inspected outputs. A collected receipt never advances a gate.

## G03 Qualification

Check paper-to-code semantics, metric/evaluator canaries, correct baseline,
sourced existing known-outcome controls and resource feasibility. Qualify the
eval path on benchmark-provided cases/tests and their actual model outputs;
never handcraft eval cases, labels or scoring fixtures. Missing native cases
block that eval check; ordinary engineering checks remain separate.
Failure to qualify is INCONCLUSIVE/repair, not scientific falsification. Confirm
that disabled modules really remove the intended function and no held-out label
or unauthorized information enters inference. Record actual scope of checks.
Qualify each affected task and its real shared prerequisites. One candidate's
failed acceptance is not a global first-candidate gate for other independently
qualified work. A shared environment/scorer fault blocks only work that actually
uses the faulty dependency; missing inputs or native scoring still block their
dependents. Keep unavailable benchmark coverage as an explicit unfinished
obligation rather than removing it from the agreed comparison.

## G04 Executing the chosen route

Use the project's real prompt, inference or training command and appropriate
harness; don't introduce a framework just for uniformity. Bind protocol/code/config
digests and authorized resource limits to a unique run/job ID. Capture raw outputs,
predictions, stderr, timestamps, failures and costs. A planned command or submitted
job is not completed evidence. Reconcile provider status before retry after an
unknown acknowledgment. Record unsupported adapters rather than simulate success.
For supported local execution, use the bounded runner with a live authorizer for
the exact reviewed commands and existing scope. Its working directories/process
groups are artifact isolation, not an OS sandbox or a GPU scheduler. Require the
real host isolation for untrusted code, actual resource inventory/leases, and the
native scorer context for scientific measurements. Do not install test host doubles.

For user-run GPU work, use repository-round-trips.md to deliver a versioned round
plan and actual run/collect/return commands. Preserve the caller and protocol;
delivery is separate from user execution and reading the returned evidence.

## G05 Verdict and next branch

Evaluate only eligible confirmation evidence with frozen rules. PASS justifies
specified next-stage work; REVISE requires a substantive developmental revision;
KILL is scientific or importance failure under valid conditions; INCONCLUSIVE
is inadequate/invalid evidence. Distinguish engineering failure, insufficient
power/resources and contradicted hypothesis. Unexpected result loops to H/M or
B if the cause/problem changes; always preserve frozen Parent and IPCG obligations.

## E01 Environments and file isolation

For Work Harness, worker and reviewer apply [evidence reuse and stage dependencies](evidence-reuse-and-stage-dependencies.md). Reuse sufficient existing artifacts; resolve concrete current-stage gaps through targeted work.

Use native host execution and the project's existing Conda environment for each
compatible project/protocol family. Read [gpu-host-runtime.md](gpu-host-runtime.md).
Lock dependencies and record the interpreter, Conda environment/prefix,
CUDA/driver/library versions and exact preparation/train/inference/scoring/replay
commands. Docker/container execution is excluded on every control and execution host;
do not emit Docker run/build/compose commands, provision a daemon or substitute
another container runtime. A venv is a conditional native alternative when Conda
is unavailable and its dependencies are qualified, not a reason to add containers.
Use separate working directories, output roots, temporary paths, caches when writes
can clash, ports and checkpoint names. Reuse read-only model/data caches only
when safe; do not duplicate huge data without need. Avoid mutating one shared
environment during other running jobs. Capture full command and dirty patch.

Conda does not reserve GPUs. Inspect actual device IDs and scheduler allocations.
CUDA_VISIBLE_DEVICES scopes processes but does not reserve the hardware against
other users. Keep one active experiment program, sharing disabled, with measured
peaks/headroom and bounded descending batch calibration under
single-experiment-batching.md. Reconcile unknown jobs before dispatch. A confirmed
single-GPU host uses zero-GPU CPU tasks or one-GPU workloads; supported multi-GPU
ranks require an actual allocation for that one program. Preserve run IDs/output
roots and frozen scientific settings. These rules do not install a scheduler.
Conda and work directories are not OS security sandboxes. If a benchmark requires
an unavailable container or a host lacks required isolation for untrusted code,
retain the affected blocker; never weaken the native scorer or execute unsafe
generated programs on the host as a workaround.

## E02 Semantic checks and canaries

Check properties that can change scientific results: dimensions, train/test split,
masking, gradient flow, normalization, information access, scorer denominators,
disabled-component behavior and restore equivalence. For tests that qualify
benchmark evaluation or support research performance, reuse benchmark-supplied
cases/tests, native scoring and actual run outputs. Never handcraft an eval unit,
canary or positive-control case. Keep source/sample/version identities; pause
eval checks lacking suitable cases rather than generating a substitute. Isolated
non-evaluation engineering fixtures may check software properties, but cannot
qualify benchmark scoring or count as scientific evidence. Do not spend the
development budget testing every implementation detail.

## E03 Queue and monitoring

Use [local-execution-harness.md](local-execution-harness.md) and
`scripts/run_harness.py` for approved Linux-host independent-task concurrency,
resource admission, stable resumption and soft reports. Native plans are
serial internally; the outer scheduler collects execution evidence without
advancing scientific gates. Future generated inputs require actual qualification
and a ready frozen plan, rather than invented hashes or mid-batch mutation.

Record resource request/reservation vs actual allocation, project/protocol/job ID,
env/workdir/device, owner, dependencies, limits, log path, heartbeat, costs and
status from real provider receipts. Queue conflicting tasks or adjust with P04.
Measure CPU/RAM/storage/GPU memory and utilization as relevant. Stop/retry only
according to real job state and requested scope. No scheduler, API or paid run
is presumed available because a node exists.

At a soft progress boundary, retain actual completed/remaining units,
running job identity, compatible permitted checkpoint and cumulative use. Continue
unfinished approved work unchanged in the next window only within valid scope,
dependencies, leases and total time/cost/attempt limits. Reconcile the provider
before any restart. Do not duplicate a running job, redo completed units, reset
the budget or turn a window ID into a new scientific protocol. Keep required
controls/scoring/verification pending until complete. Approved execution may
continue for up to 24 elapsed hours under the current owner policy; do not copy
report cadence into hard limits or stop a healthy job at a report. Real timeouts still apply;
the bundled serial runner is not a persistent eight-hour scheduler.

Use dependency-resource-scheduling.md for independent ready-task dispatch with
actual artifact dependencies, a bounded agent pool and separate GPU-job limits.
Same-GPU sharing needs qualified peak memory/headroom and an implemented host
allocator; whole-device registry leases do not supply VRAM subleases. Inspect
contention/throughput and keep code/config/confirmation isolation and one integrator.

## E04 Diagnosis and protocol branching

For Web-delivered code, first read the project Local runbook/round handoff under
[local-code-handoff.md](local-code-handoff.md). Its debug table points to actual
source/config/log/diagnostic locations; instantiate those pointers with the
current failed attempt, then apply this scientific contract. A generic “debug”
direction, passed software exit or parameter sweep is not a completed diagnosis.

Use this internal debug skill for crashes, anomalous results and mixed performance
across data/scenarios. It is active after every relevant result/feedback under
[literature-evidence.md](literature-evidence.md)'s joined reading/design contract.
Preserve the scientific question, exact caller, native evaluator and declared
resource/training scope. Mathematical self-consistency is one checked property;
empirical usefulness also depends on assumptions, information, implementation and
optimization. Neither a bad run nor a good dataset proves that the whole method
is wrong/right, and missing tuning is a hypothesis to investigate.

### Bounded task repair and independent continuation

Use the G02 per-task allowance, real logs/source and a named causal hypothesis
to choose each next diagnostic or repair. Count all failed, timed-out and
unselected attempts and their elapsed time/compute against the same task and
project ceilings. Do not repeat a deterministic failure unchanged or enlarge a
search merely to obtain a favorable result. Reconcile uncertain process/provider
state before any new launch; an unknown acknowledgment is not a failed attempt
that can safely be retried.

When repeated unsuccessful diagnosis/repair reaches its declared attempt/time
allowance, or no next check would add decision-relevant evidence, pause that
task's repair effort and skip it for current dispatch. Retain the exact blocker,
failed versions/attempts, consumed and remaining budgets, affected descendants,
missing checks/comparisons and a concrete resume condition in the debug card and
handoff. This is an operational disposition, not a new ledger/harness enum or
evidence that the scientific idea was refuted. Preserve valid bounded observations;
bugs, missing native evidence and unavailable benchmarks remain unresolved.

Continue the next already authorized, independently ready task, including another
candidate, benchmark or necessary scientific reading/code work. Reuse qualified
unchanged shared dependencies, and hold only work that actually depends on the
faulty code/environment/scorer or absent outputs. Never execute a dependent with
missing actual inputs or substitute scoring, remove blocked benchmarks from final
coverage, invent new tasks to fill compute time or turn repair exhaustion into a
new idea cycle. If no eligible independent work remains, retain the queue and
seek human intervention on the concrete access, feasibility, scope or budget
blocker; do not repeatedly request permission for ordinary in-envelope repairs.

The controller may recalibrate estimates and prepare versioned pending operational
plans within the existing development envelope and remaining limits. Active
digests, workspaces, identities and counters stay unchanged. The bundled harness
continues already pinned independent tasks after known failure; it does not
autonomously diagnose, park/requeue a failed task or admit a newly repaired plan.
Use [local-execution-harness.md](local-execution-harness.md) for the actual runtime
boundary and later-plan ownership/reconciliation. A result-affecting change to
frozen confirmation still requires the existing child-protocol route and fresh
eligible confirmation; operational replanning cannot waive that obligation.

### Post-run verification before a scientific verdict

After every run/coherent batch completes, retain a scoped verification record.
Execution status stays distinct from evidence validity; prose `verified` is not
a gate PASS or a proof of mathematics/efficacy. Use method-verification.md's
derived per-method records and checker. Check the following before a
scientific verdict or result-driven method revision:

| Obligation | Evidence and pending condition |
|---|---|
| Execution and actual parameters | Actual code/dirty patch, model/config/seed/data/sample identities, effective parameters versus frozen settings, exit/logs, failed/unscored units, time/GPU/cost and all expected outputs; stale/missing records stay pending. |
| Implementation semantics | Relevant paper/math-to-code mapping, preprocessing, state/masks/gradients/normalization and enabled/disabled interventions; use meaningful source checks and native cases/actual outputs. No exhaustive bug-free claim from a successful command or software test. |
| Native measurement and baseline | Recompute/replay eligible raw outputs with the actual native scorer, denominator, split, aggregation and error policy; link current baseline/control qualification, fair information/compute and comparator tuning. A self-made proxy or unfair baseline blocks interpretation. |
| Parameter and optimization validity | Verify the intended settings ran, convergence/precision/resource signals where relevant, fair development tuning and decision-relevant sensitivity/control evidence. Record which ranges/scenes were investigated and what remains unknown; under-tuning is not presumed absent or automatically the only cause. |
| Confirmation and scientific scope | Development versus eligible fresh confirmation, selection provenance, replication/uncertainty and claim coverage. New parameters chosen after inspecting outcomes are developmental and require a versioned policy plus independent confirmation. |

Reuse unchanged qualified semantics/baseline/scorer evidence at the same pinned
conditions; reconcile each new run's actual settings and outputs against it.
Add sensitivity/diagnostic experiments only when they resolve a named material
parameter or bug concern, within the development budget and native protocol.
Do not tune after seeing confirmation and relabel the same outcomes verified.
Record outcome as verified for the stated checks/scope, verification pending,
or invalid evidence with reasons and the next repair/check. These are evidence
descriptions, not new ledger enums. The helper verifies retained identities and
review coverage, and reuses the existing native evaluator for final scoped
outcomes; it does not certify every mathematical or software claim.
Unresolved material confounds prevent declaring the method effective or ineffective;
retain valid bounded observations as such. Verification establishes checked
conditions, not a guarantee against all bugs or every possible parameter setting.

### Scientific debug and fair scene-dependent tuning

1. **Retain and qualify the observation.** Pin code/model/data/split/scorer/config,
   commands, raw predictions, logs, error/exclusion denominators, cost and prior
   settings. Separate runtime/scoring faults, uncertainty/selection effects and
   actual task failures before interpreting gains or losses. Verify benchmark
   claim fit and current paper-to-code mapping. Missing evidence stays unknown.
2. **Compare successful and unsuccessful conditions.** Use sourced native development
   cases with denominators. Check data/preprocessing, task difficulty, information
   access, model capacity, scale/normalization, gradient/state/masking behavior,
   initialization/convergence and resource limits where relevant. Inspect actual
   relevant files; name bounded read scope. Patterns found after viewing outcomes
   are exploratory and need independent confirmation. Do not fabricate eval cases.
3. **Form competing root-cause hypotheses.** Distinguish implementation/evaluator
   error, inadequate optimization, distribution/assumption mismatch, insufficient
   information and genuine mechanism limits. State the observation supporting each
   and the contrast that would distinguish it. Review primary assumptions and
   related implementations before proposing a repair or parameter search.
4. **Plan bounded development tuning when supported.** State the implicated parameter,
   why it might change behavior, development-only search range, selection metric,
   meaningful control and total attempt/time/GPU/spend ceiling before searching.
   Give the method and strongest baselines comparable tuning/information/compute.
   Start with the smallest justified intervention; use interaction controls when
   parameters or modules are coupled. Preserve every attempted/failed/unselected
   configuration and complete costs. No blind sweep or indefinite rescue effort.
5. **Respect the deployed selection rule.** Compare a frozen global configuration
   with scene-dependent settings only when scene identity/features are available
   at deployment and the selection policy is learned/fixed on development data.
   Hold out new scenes/tasks when claiming transfer. No test-label tuning, oracle
   best-per-test configuration, test-driven scene definitions or unreported
   per-dataset cherry-picking. Give comparable baselines the same policy allowance
   and report aggregate and per-scene effects with uncertainty and selection cost.
   Distinguish hyperparameter/configuration tuning from weight fine-tuning; a
   training-free project cannot silently train weights or change its method scope.
6. **Version, requalify and confirm.** Fix the identified cause or freeze the selected
   configuration/policy; record code/config/claim changes and the affected checks.
   Prediction/scoring changes use existing child-protocol obligations and fresh
   independent confirmation. Reusing viewed test/confirmation results supports
   development only. Diagnose within G01's full scientific standard even when
   the run scope is small; a software check cannot establish scientific recovery.
7. **Return an evidence-based disposition to the caller.** Record a verified repair,
   supported optimization sensitivity, conditional regime/boundary, unresolved
   evidence or valid hypothesis contradiction. A rescued subset does not establish
   universal efficacy; retain unresolved and unfavorable scenes. When tuning stops
   adding decision-relevant evidence or its agreed budget is exhausted, report
   the boundary/uncertainty and choose the existing next route rather than extend
   spend, repeatedly change seeds or shrink the claim to save the method. Apply
   existing gate/stop rules only with their actual evidence, not a new debug verdict.
   During an agreed batch, record this per-task/per-idea disposition and continue
   independently eligible planned work under frozen stop/repair rules. Apply the
   bounded continuation rule above when repeated repair fails; affected dependent
   tasks stay pending. The new scientific direction or
   writing branch waits for consolidated batch-end human review under
   [state-and-routing.md](state-and-routing.md); explicit human steering may occur
   earlier. No automatic new idea/literature cycle follows a single failed idea.
   A soft report boundary preserves unfinished approved repair/experiment work
   for the next window within existing bounds; it does not require a new idea
   round. Propose convergence at human review: deepen/confirm positive candidates,
   stop/park validly refuted ones and group mixed effects by competing causes.
   Missing controls, bugs and inadequate precision remain pending, not confirmed
   failure. No new directions, materially changed designs or writing are implied.

Return a compact debug card with observation/versions, inspected paper/code/task
evidence, rival causes, selected diagnostic and falsifier, affected parameter,
development search/selection policy, fair baseline allowances, budget/stop rule,
all trial records, confirmation status, scope/boundaries and next caller action.
Retain it with the project's existing GitHub/HF targets. This self-contained
scientific contract does not require an additional debugging plugin, invent a
ledger schema or deploy an automatic GPU tuning service.

Classify environment, implementation, evaluator, data, resource, optimization or
hypothesis failure. Find the smallest causal explanation from real logs and a
minimal reproduction. Change one justified cause, recheck affected semantics,
and retain before/after evidence. Changes affecting predictions, samples or scores
invalidate affected confirmation and require child protocol qualification; pure
display changes need only artifact checks. Repeated repair failures end the
affected effort under its finite allowance; independent eligible work continues.
If none remains, raise the retained feasibility/scope/access/budget blocker for
human intervention, rather than seeking repeated blanket permissions.

## E05 Recovery and repository maintenance

Save immutable run manifest, logs, predictions, configs, environment, checkpoints,
random state, protocol lineage and next action. Separate private data/secrets from
publishable artifacts. Resume by reconciling committed code, dirty patches and
actual provider status. Restore only a compatible checkpoint and record resumed
work without double-counting samples/runs. Use branches/releases and issues on
GitHub; record HF model/data/Space revisions/cards with the same release identity.
Link fixes to affected experiments and releases; never overwrite negative evidence.

Use repository-round-trips.md for per-round GitHub/HF delivery and result intake,
including private developmental rounds. Read and verify returned files, rather
than treating an uploaded summary or screenshot as a complete run.
