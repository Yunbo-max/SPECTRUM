"""Regression tests for premature Chat research completion; fixture data is not science."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
from unittest.mock import patch
import tempfile
import unittest

from chat_control_fixtures import ChatControlFixture

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts/chat_cycle.py'
SPEC = importlib.util.spec_from_file_location('chat_cycle_goal', SCRIPT)
C = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(C)


class ResearchGoalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.path = self.root / 'state.json'
        self.procedure = {'id': 'v1', 'ref': self.write('procedure.txt', 'Research procedure')}
        self.proposals = {}
        self.controls = ChatControlFixture(self.root, C)
        self.addCleanup(self.controls.close)

    def write(self, name, value):
        data = value if isinstance(value, str) else json.dumps(value, sort_keys=True)
        (self.root / name).write_text(data)
        return {'path': name, 'sha256': hashlib.sha256((self.root / name).read_bytes()).hexdigest()}

    def contract(self, mode='research', name='request.txt'):
        return {'mode': mode, 'request_ref': self.write(name, 'Source request: ' + mode),
                'continuation_action': 'Review the native baseline and design a falsifiable comparison'}

    def proposal(self, candidate='candidate-a', mode='empirical'):
        if candidate not in self.proposals:
            hypothesis = self.write(candidate + '-hypothesis.json', {
                'kind': 'research_hypothesis', 'candidate_id': candidate, 'proposal_task_id': 'proposal-' + candidate,
                'hypothesis': 'A changed rule reduces error under the stated assumptions',
                'derivation': 'The proposed bound implies the declared inequality',
                'prediction': 'The measured error is below the fixed reference threshold',
                'falsifier': 'Failure of the declared inequality refutes this candidate'})
            design = self.write(candidate + '-design.json', {
                'kind': 'research_design', 'candidate_id': candidate, 'hypothesis_ref': hypothesis,
                'mode': mode, 'comparison': 'Original rule versus changed rule',
                'protocol': 'Use the frozen comparison, conditions, and falsification threshold'})
            self.proposals[candidate] = (hypothesis, design)
        return self.proposals[candidate]

    def task(self, name, kind='research_experiment', candidate='candidate-a', **extra):
        refs = []
        if kind in {'research_experiment', 'research_analysis'}:
            refs = list(self.proposal(candidate, 'theoretical' if kind == 'research_analysis' else 'empirical'))
        if kind == 'research_experiment':
            extra.setdefault('experiment_phase', 'diagnostic')
        return dict(id=name, candidate_id=candidate, kind=kind, action='Perform ' + name,
                    dependencies=[], input_refs=refs, **extra)

    def init(self, tasks=None, mode='research', budget=None):
        config = dict(goal_id='goal-a', goal='Investigate the requested hypothesis',
            criteria=['reviewed'], deliveries=[], procedure=self.procedure,
            budget=budget or {'max_attempts': 30}, tasks=tasks or [self.task('compare')])
        if mode:
            config['goal_contract'] = self.contract(mode)
        C.initialize(self.path, self.controls.configure(config))
        return self.controls.activate(self.path)

    def event(self, op, **values):
        state = C.status(self.path)
        if state.get('strategy') and op in {'add_task', 'revise_task'}:
            values['task'] = self.controls.task(values['task'])
            self.controls.qualify_new_candidates(self.path)
        if state.get('strategy') and op == 'result':
            values.setdefault('strategy_usage', self.controls.usage(values['attempt_id']))
        return C.record(self.path, C.status(self.path)['revision'], dict(op=op, **values))

    def settle(self, task_id, outcome='completed', credit=True):
        attempt = self.event('begin', task_id=task_id)['current_attempt']
        raw = self.write(attempt['id'] + '.txt', 'Real fixture observation for ' + attempt['id'])
        reference = self.write(attempt['id'] + '.json', {
            'attempt_id': attempt['id'], 'task_id': task_id,
            'candidate_id': attempt['candidate_id'], 'procedure_id': attempt['procedure']['id'],
            'outcome': outcome, 'raw_evidence': [raw], 'criteria_met': ['reviewed'] if credit else [],
            'delivery_receipts': {}})
        self.event('result', attempt_id=attempt['id'], evidence_ref=reference, outcome=outcome,
                   reason='Fixture observation', next_action='Review and choose the next scientific action')
        return C.status(self.path)['attempts'][-1]

    def cycle(self, attempts, cycle_id='cycle-1', verdict='supported', mode='empirical'):
        candidate = attempts[0]['candidate_id']
        hypothesis, design = self.proposal(candidate, mode)
        ids = [a['id'] for a in attempts]
        review = self.write(cycle_id + '-review.json', {
            'kind': 'research_cycle_review', 'cycle_id': cycle_id, 'candidate_id': candidate,
            'attempt_ids': ids, 'hypothesis_ref': hypothesis, 'design_ref': design,
            'proposal_task_id': 'proposal-' + candidate, 'review_task_id': 'review-' + cycle_id,
            'verdict': verdict, 'next_action': 'Run the remaining confirmation comparison',
            'raw_evidence': [a['evidence_ref'] for a in attempts]})
        return dict(cycle_id=cycle_id, candidate_id=candidate, attempt_ids=ids,
                    hypothesis_ref=hypothesis, design_ref=design, review_ref=review)

    def goal_review(self):
        state = C.status(self.path)
        return self.write('goal-review-' + str(state['revision']) + '.json', {
            'kind': 'goal_review', 'goal_id': state['goal_id'], 'goal': state['goal'],
            'goal_revision': state['goal_revision'], 'state_revision': state['revision'],
            'goal_contract': state['goal_contract'], 'criteria': state['criteria'],
            'deliveries': state['deliveries'], 'attempt_ids': [a['id'] for a in state['attempts']],
            'cycle_ids': [c['cycle_id'] for c in state.get('research_cycles', [])],
            'proposal_task_id': 'goal-proposal', 'review_task_id': 'goal-independent-review',
            'outcome': 'complete', 'raw_evidence': [a['evidence_ref'] for a in state['attempts']]
                + [c['review_ref'] for c in state.get('research_cycles', [])]})

    def test_nine_preflight_runs_count_zero_cycles_and_advance_replans(self):
        self.init([self.task('seed-' + str(i), 'preflight') for i in range(9)])
        for i in range(9):
            self.settle('seed-' + str(i))
        result = C.advance(self.path, C.status(self.path)['revision'])
        self.assertEqual(result['kind'], 'replan')
        self.assertEqual(result['scientific_cycle_count'], 0)
        self.assertIn('baseline', result['action'])
        before = self.path.read_bytes()
        with self.assertRaisesRegex(ValueError, 'research'):
            self.event('research_cycle', cycle=self.cycle(C.status(self.path)['attempts']))
        self.assertEqual(self.path.read_bytes(), before)

    def test_true_bounded_selection_request_can_complete_after_preflight(self):
        self.init([self.task('select', 'preflight')], mode='bounded_task')
        self.settle('select')
        self.assertEqual(C.next_action(self.path)['kind'], 'bookkeeping_complete')

    def test_legacy_checkpoint_requires_sourced_scope_review_before_complete(self):
        self.init([self.task('select', 'preflight')], mode=None)
        self.settle('select')
        self.assertEqual(C.next_action(self.path)['kind'], 'needs_goal_review')

    def test_one_valid_cycle_selects_next_action_without_completing_goal(self):
        self.init()
        attempt = self.settle('compare')
        self.event('research_cycle', cycle=self.cycle([attempt]))
        result = C.next_action(self.path)
        self.assertEqual(result['kind'], 'replan')
        self.assertEqual(result['scientific_cycle_count'], 1)
        self.assertEqual(result['action'], 'Run the remaining confirmation comparison')
        self.assertEqual(C.advance(self.path, C.status(self.path)['revision'])['kind'], 'replan')

    def test_replayed_cycle_and_reused_attempts_are_rejected(self):
        self.init()
        attempt = self.settle('compare')
        cycle = self.cycle([attempt])
        self.event('research_cycle', cycle=cycle)
        for duplicate in [cycle, self.cycle([attempt], cycle_id='cycle-2')]:
            with self.assertRaisesRegex(ValueError, 'used|unique|duplicate'):
                self.event('research_cycle', cycle=duplicate)

    def test_only_bound_independent_review_can_record_cycle(self):
        self.init()
        attempt = self.settle('compare')
        cycle = self.cycle([attempt])
        review = json.loads((self.root / cycle['review_ref']['path']).read_text())
        review['review_task_id'] = review['proposal_task_id']
        cycle['review_ref'] = self.write('self-review.json', review)
        with self.assertRaisesRegex(ValueError, 'separate|independent'):
            self.event('research_cycle', cycle=cycle)

    def test_retrospective_hypothesis_cannot_relabel_an_old_research_run(self):
        self.init()
        attempt = self.settle('compare')
        self.proposals.clear()
        hypothesis, design = self.proposal()
        content = json.loads((self.root / hypothesis['path']).read_text())
        content['prediction'] = 'A different, retrospectively chosen prediction'
        hypothesis = self.write('unrelated-hypothesis.json', content)
        content = json.loads((self.root / design['path']).read_text())
        content['hypothesis_ref'] = hypothesis
        design = self.write('unrelated-design.json', content)
        self.proposals['candidate-a'] = (hypothesis, design)
        with self.assertRaisesRegex(ValueError, 'pinned'):
            self.event('research_cycle', cycle=self.cycle([attempt]))

    def test_additional_seeds_of_same_frozen_design_do_not_create_new_cycles(self):
        self.init([self.task('seed-1'), self.task('seed-2')])
        first = self.settle('seed-1')
        second = self.settle('seed-2')
        self.event('research_cycle', cycle=self.cycle([first]))
        with self.assertRaisesRegex(ValueError, 'already counted'):
            self.event('research_cycle', cycle=self.cycle([second], cycle_id='cycle-2'))
        self.assertEqual(C.next_action(self.path)['scientific_cycle_count'], 1)

    def test_changed_hypothesis_or_output_removes_cycle_count(self):
        self.init()
        attempt = self.settle('compare')
        cycle = self.cycle([attempt])
        self.event('research_cycle', cycle=cycle)
        self.write(cycle['hypothesis_ref']['path'], 'Changed claim')
        result = C.next_action(self.path)
        self.assertEqual(result['scientific_cycle_count'], 0)
        self.assertEqual(len(result['invalid_research_cycles']), 1)
        self.assertNotEqual(result['kind'], 'bookkeeping_complete')

    def test_refuted_cycle_is_preserved_and_does_not_make_candidate_pass(self):
        self.init()
        attempt = self.settle('compare', outcome='refuted')
        self.event('research_cycle', cycle=self.cycle([attempt], verdict='refuted'))
        result = C.next_action(self.path)
        self.assertEqual(result['scientific_cycle_count'], 1)
        self.assertEqual(result['missing_criteria'], ['reviewed'])
        self.assertEqual(C.status(self.path)['attempts'][0]['outcome'], 'refuted')
        self.assertEqual(result['kind'], 'replan')

    def test_invalidated_refutation_does_not_resurrect_candidate_credit(self):
        self.init()
        attempt = self.settle('compare')
        cycle = self.cycle([attempt], verdict='refuted')
        self.event('research_cycle', cycle=cycle)
        self.assertEqual(C.next_action(self.path)['missing_criteria'], ['reviewed'])
        self.write(cycle['review_ref']['path'], 'Lost review bytes')
        result = C.next_action(self.path)
        self.assertEqual(result['scientific_cycle_count'], 0)
        self.assertEqual(result['missing_criteria'], ['reviewed'])

    def test_old_failures_of_retired_candidate_do_not_block_successor_planning(self):
        self.init([self.task('unknown-setup', 'preflight'), self.task('known-setup', 'preflight'),
                   self.task('compare')])
        unknown = self.settle('unknown-setup', outcome='failed')
        classified = self.settle('known-setup', outcome='failed')
        self.event('classify_failure', attempt_id=classified['id'], failure_class='implementation',
                   evidence_ref=self.write('diagnosis.txt', 'A verified defect'), next_action='Repair setup')
        compared = self.settle('compare')
        self.event('research_cycle', cycle=self.cycle([compared], verdict='refuted'))
        before = C.status(self.path)
        result = C.advance(self.path, before['revision'])
        self.assertEqual(result['kind'], 'replan')
        self.assertEqual(result['scientific_cycle_count'], 1)
        self.assertEqual(C.status(self.path), before)
        self.event('add_task', task=self.task('successor', candidate='candidate-b'))
        self.assertEqual(C.advance(self.path, C.status(self.path)['revision'])['kind'], 'execute')

    def test_theoretical_cycle_accepts_actual_formal_analysis(self):
        self.init([self.task('proof', 'research_analysis')])
        attempt = self.settle('proof')
        self.event('research_cycle', cycle=self.cycle([attempt], mode='theoretical'))
        self.assertEqual(C.next_action(self.path)['scientific_cycle_count'], 1)

    @patch.object(C, '_science_completion')
    def test_explicit_current_goal_review_is_required_and_new_work_invalidates_it(self, scientific_completion):
        self.init()
        attempt = self.settle('compare')
        self.event('research_cycle', cycle=self.cycle([attempt]))
        old_review = self.goal_review()
        self.event('goal_review', review_ref=old_review)
        self.assertEqual(C.next_action(self.path)['kind'], 'bookkeeping_complete')
        self.event('add_task', task=self.task('confirm'))
        self.settle('confirm')
        self.assertEqual(C.next_action(self.path)['kind'], 'replan')
        with self.assertRaisesRegex(ValueError, 'binding|revision'):
            self.event('goal_review', review_ref=old_review)
        self.event('goal_review', review_ref=self.goal_review())
        self.assertEqual(C.next_action(self.path)['kind'], 'bookkeeping_complete')

    def test_preflight_cannot_be_closed_by_review_with_no_real_cycle(self):
        self.init([self.task('check', 'preflight')])
        self.settle('check')
        with self.assertRaisesRegex(ValueError, 'cycle'):
            self.event('goal_review', review_ref=self.goal_review())

    @patch.object(C, '_science_completion')
    def test_nested_failed_attempt_evidence_is_revalidated_at_completion(self, scientific_completion):
        self.init([self.task('setup', 'preflight'), self.task('compare')])
        failed = self.settle('setup', outcome='failed')
        completed = self.settle('compare')
        self.event('research_cycle', cycle=self.cycle([completed]))
        self.event('goal_review', review_ref=self.goal_review())
        self.assertEqual(C.next_action(self.path)['kind'], 'bookkeeping_complete')
        envelope = json.loads((self.root / failed['evidence_ref']['path']).read_text())
        self.write(envelope['raw_evidence'][0]['path'], 'Changed failed observation')
        result = C.next_action(self.path)
        self.assertNotEqual(result['kind'], 'bookkeeping_complete')
        self.assertIn('hash', result['invalid_goal_review'])
        with self.assertRaisesRegex(ValueError, 'hash'):
            self.event('goal_review', review_ref=self.goal_review())

    def test_goal_revision_reopens_completed_selection_without_resetting_any_usage(self):
        self.init([self.task('check', 'preflight')], mode='bounded_task',
                  budget={'max_attempts': 5, 'limits': {'seconds': 100}})
        self.event('usage', totals={'seconds': 7}, receipt_ref=self.write('usage.txt', 'Observed 7s'))
        self.settle('check')
        old = C.status(self.path)
        self.assertEqual(C.next_action(self.path)['kind'], 'bookkeeping_complete')
        self.event('revise_goal', goal='Continue the full authorized research',
                   goal_contract=self.contract('research', 'extended-request.txt'),
                   criteria=['reviewed', 'confirmed'], deliveries=[])
        state = C.status(self.path)
        for key in ['attempts', 'tasks', 'usage', 'budget', 'started_attempts', 'procedure', 'procedure_versions']:
            self.assertEqual(state[key], old[key], key)
        self.assertEqual(state['goal_history'][0]['goal'], old['goal'])
        self.assertEqual(state['goal_revision'], old['goal_revision'] + 1)
        self.controls.migrate_research(self.path)
        self.assertEqual(C.next_action(self.path)['kind'], 'replan')

    def test_legacy_stop_reason_is_archived_when_scope_is_corrected(self):
        self.init([self.task('check', 'preflight')], mode=None)
        self.settle('check')
        original = C.status(self.path)
        original['stop_reason'] = 'completed'
        # Simulate the legacy unanchored checkpoint that this migration test targets.
        original.pop('lineage')
        self.path.write_text(json.dumps(original))
        self.event('revise_goal', goal='Restore the authorized research scope',
                   goal_contract=self.contract(), criteria=['reviewed'], deliveries=[])
        state = C.status(self.path)
        self.assertEqual(state['goal_history'][0]['stop_reason'], 'completed')
        self.assertEqual(state['stop_reason'], 'continuation_pending')
        self.assertEqual(state['attempts'], original['attempts'])
        self.controls.migrate_research(self.path)
        self.assertEqual(C.next_action(self.path)['kind'], 'replan')

    def test_revision_cannot_drop_obligations_shrink_research_or_rewrite_active_attempt(self):
        self.init()
        revision = dict(goal='Changed', goal_contract=self.contract(), criteria=['reviewed'], deliveries=[])
        bad = copy.deepcopy(revision)
        bad['criteria'] = ['weaker']
        with self.assertRaisesRegex(ValueError, 'obligation'):
            self.event('revise_goal', **bad)
        bad = copy.deepcopy(revision)
        bad['goal_contract'] = self.contract('bounded_task', 'bounded-request.txt')
        with self.assertRaisesRegex(ValueError, 'research'):
            self.event('revise_goal', **bad)
        self.event('begin', task_id='compare')
        with self.assertRaisesRegex(ValueError, 'active|attempt'):
            self.event('revise_goal', **revision)

    def test_exhausted_budget_is_not_reset_or_replanned(self):
        self.init([self.task('check', 'preflight')], budget={'max_attempts': 1})
        self.settle('check')
        result = C.next_action(self.path)
        self.assertEqual(result['kind'], 'blocked')
        self.assertEqual(result['reason'], 'attempt_budget_exhausted')

    def test_tampered_goal_source_cannot_finish_or_start_new_work(self):
        self.init([self.task('check', 'preflight')], mode='bounded_task')
        self.settle('check')
        self.write('request.txt', 'Altered scope')
        self.assertEqual(C.next_action(self.path)['kind'], 'needs_goal_review')

    def test_kind_pinned_and_preserved_through_repair(self):
        self.init([self.task('check', 'preflight')])
        attempt = self.settle('check', outcome='failed')
        self.assertEqual(attempt['kind'], 'preflight')
        self.event('classify_failure', attempt_id=attempt['id'], failure_class='implementation',
                   evidence_ref=self.write('diagnosis.txt', 'A verified setup defect'), next_action='Repair setup')
        handoff = C.advance(self.path, C.status(self.path)['revision'])
        self.assertEqual(handoff['kind'], 'execute')
        self.assertEqual(handoff['attempt']['kind'], 'preflight')

    def test_diagnostic_cycle_cannot_close_scientific_goal_with_matching_strings(self):
        self.init()
        attempt = self.settle('compare')
        self.event('research_cycle', cycle=self.cycle([attempt]))
        with self.assertRaisesRegex(ValueError, 'scientific_evidence'):
            self.event('goal_review', review_ref=self.goal_review())
        self.assertEqual(C.next_action(self.path)['kind'], 'replan')

    def test_inconclusive_review_retains_concrete_continuation(self):
        self.init()
        attempt = self.settle('compare')
        self.event('research_cycle', cycle=self.cycle([attempt], verdict='inconclusive'))
        action = C.next_action(self.path)
        self.assertEqual(action['kind'], 'replan')
        self.assertEqual(action['scientific_pending'][0]['next_action'], action['action'])
        self.assertEqual(action['scientific_pending'][0]['cycle_id'], 'cycle-1')

    def test_legacy_unlabelled_experiment_replans_without_spending_and_migrates(self):
        task = self.task('compare')
        del task['experiment_phase']
        self.init([task])
        action = C.advance(self.path, C.status(self.path)['revision'])
        self.assertEqual(action['kind'], 'replan')
        self.assertIn('legacy research task', action['action'])
        self.assertEqual(C.status(self.path)['started_attempts'], 0)
        self.event('revise_task', task_id='compare', task=self.task('diagnose'), reason='Classify the original bounded diagnostic')
        self.assertEqual(C.advance(self.path, C.status(self.path)['revision'])['kind'], 'execute')
        self.assertEqual(C.status(self.path)['tasks'][0]['status'], 'superseded')

    def test_confirmation_missing_structured_design_does_not_reserve_attempt(self):
        task = self.task('compare', experiment_phase='confirmation')
        self.init([task])
        result = C.advance(self.path, C.status(self.path)['revision'])
        self.assertEqual(result['kind'], 'replan')
        self.assertIn('pinned experiment_contract_ref', result['action'])
        self.assertEqual(C.status(self.path)['started_attempts'], 0)

    def test_theory_completion_uses_actual_formal_review_callback_without_empirical_gate(self):
        self.init([self.task('proof', 'research_analysis')])
        attempt = self.settle('proof')
        cycle = self.cycle([attempt], mode='theoretical')
        cycle_review = C._ref(self.root, cycle['review_ref'], as_json=True)
        execution = self.write('formal-review.txt', 'Engineering fixture independent formal reviewer receipt')
        cycle_review.update(execution_ref=execution, unresolved_obligations=[])
        cycle['review_ref'] = self.write('formal-cycle-review.json', cycle_review)
        self.event('research_cycle', cycle=cycle)
        proof = self.write('formal-evidence.json', dict(kind='formal-goal-evidence', candidate_id='candidate-a',
            cycle_id='cycle-1', hypothesis_ref=cycle['hypothesis_ref'], design_ref=cycle['design_ref'],
            proof_refs=C._ref(self.root, attempt['evidence_ref'], as_json=True)['raw_evidence'], claim_ids=['claim-proof']))
        review = C._ref(self.root, self.goal_review(), as_json=True)
        review.update(execution_ref=execution, scientific_evidence=[dict(cycle_id='cycle-1', formal_evidence_ref=proof)],
            claim_coverage={'reviewed': [dict(cycle_id='cycle-1', claim_id='claim-proof')]})
        review['raw_evidence'].append(proof)
        reference = self.write('formal-goal-review.json', review)
        with self.assertRaisesRegex(ValueError, 'formal verification capability'):
            self.event('goal_review', review_ref=reference)
        def actual_review_double(request):
            self.assertEqual(request['evidence_ref'], proof)
            return dict(verified=True, evidence_ref=proof, claim_ids=['claim-proof'], verdict='supported', execution_ref=execution)
        with C.scientific_runtime(formal_completion_validator=actual_review_double):
            self.event('goal_review', review_ref=reference)
            self.assertEqual(C.next_action(self.path)['kind'], 'bookkeeping_complete')


if __name__ == '__main__':
    unittest.main()
