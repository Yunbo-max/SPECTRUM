"""Resource observations must not grant resources or hide unknown constraints."""
import contextlib
import importlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))


class SimpleResourcesTests(unittest.TestCase):
    def module(self):
        return importlib.import_module("host_resources")

    def test_nvidia_csv_preserves_identifiers_and_unknown_metrics(self):
        resources = self.module()
        result = resources.parse_nvidia_csv(
            '0, GPU-aaaa, "NVIDIA Example, revision 2", 24576, 12288, 17\n'
            '2, GPU-bbbb, NVIDIA Example B, 40960, 30720, [N/A]\n'
        )
        self.assertEqual(result["devices"][0], {
            "index": 0, "uuid": "GPU-aaaa", "model": "NVIDIA Example, revision 2",
            "memory_total_mib": 24576, "memory_free_mib": 12288,
            "utilization_gpu_percent": 17,
        })
        self.assertEqual(result["devices"][1]["index"], 2)
        self.assertIsNone(result["devices"][1]["utilization_gpu_percent"])
        self.assertEqual(result["status"], "partial")

    def test_empty_or_malformed_inventory_is_unknown_not_zero_gpus(self):
        resources = self.module()
        for output in ("", "No devices were found\n", "0, malformed\n"):
            with self.subTest(output=output):
                result = resources.parse_nvidia_csv(output)
                self.assertEqual(result["status"], "unknown")
                self.assertIsNone(result["devices"])
                self.assertTrue(result["diagnostics"])

    def test_invalid_nvidia_metrics_do_not_become_available_capacity(self):
        result = self.module().parse_nvidia_csv(
            "0, GPU-aaaa, Example, 1000, 2000, 101\n"
        )
        self.assertEqual(result["status"], "partial")
        self.assertEqual(result["devices"][0]["memory_total_mib"], 1000)
        self.assertIsNone(result["devices"][0]["memory_free_mib"])
        self.assertIsNone(result["devices"][0]["utilization_gpu_percent"])

    def test_missing_nvidia_tool_does_not_attempt_subprocess_or_claim_absence(self):
        resources = self.module()
        with mock.patch.object(resources.shutil, "which", return_value=None), \
                mock.patch.object(resources.subprocess, "run") as command:
            result = resources.probe_nvidia(timeout_seconds=0.2)
        command.assert_not_called()
        self.assertEqual(result["status"], "unknown")
        self.assertIsNone(result["devices"])
        self.assertIn("missing_tool", [item["kind"] for item in result["diagnostics"]])

    def test_nvidia_timeout_is_bounded_and_preserves_cpu_snapshot(self):
        resources = self.module()
        with mock.patch.object(resources.shutil, "which", return_value="/mock/nvidia-smi"), \
                mock.patch.object(resources.subprocess, "run", side_effect=subprocess.TimeoutExpired(
                    ["/mock/nvidia-smi"], 0.15)) as command:
            result = resources.collect_resources(timeout_seconds=0.15)
        self.assertEqual(command.call_args.kwargs["timeout"], 0.15)
        self.assertEqual(result["nvidia_gpus"]["status"], "unknown")
        self.assertIsNone(result["nvidia_gpus"]["devices"])
        self.assertIn("cpu", result)
        self.assertIn("memory", result)
        self.assertIn("timeout", [item["kind"] for item in result["nvidia_gpus"]["diagnostics"]])

    def test_driver_failure_retains_diagnostic_without_dumping_environment(self):
        resources = self.module()
        failed = subprocess.CompletedProcess(["nvidia-smi"], 9, "", "Failed to initialize NVML")
        with mock.patch.object(resources.shutil, "which", return_value="/mock/nvidia-smi"), \
                mock.patch.object(resources.subprocess, "run", return_value=failed), \
                mock.patch.dict(resources.os.environ, {
                    "CUDA_VISIBLE_DEVICES": "MIG-GPU-aaaa/1/0",
                    "PRIVATE_API_TOKEN": "must-never-be-serialized",
                }, clear=True):
            result = resources.collect_resources()
        gpu = result["nvidia_gpus"]
        self.assertEqual(gpu["status"], "unknown")
        self.assertIsNone(gpu["devices"])
        self.assertEqual(gpu["visibility"]["cuda_visible_devices_raw"], "MIG-GPU-aaaa/1/0")
        self.assertEqual(gpu["visibility"]["mapping_status"], "unknown")
        self.assertTrue(any(item.get("returncode") == 9 for item in gpu["diagnostics"]))
        serialized = json.dumps(result)
        self.assertNotIn("PRIVATE_API_TOKEN", serialized)
        self.assertNotIn("must-never-be-serialized", serialized)
        self.assertFalse(result["scope"]["authorizes_execution"])
        self.assertFalse(result["scope"]["reserves_resources"])

    def test_inventory_does_not_establish_cuda_ordinal_or_mig_visibility(self):
        resources = self.module()
        command_result = subprocess.CompletedProcess(
            ["nvidia-smi"], 0, "3, GPU-abcd, Example, 16000, 12000, 0\n", "")
        for raw in ("0", "GPU-abcd", "MIG-GPU-abcd/2/0", "", "-1"):
            with self.subTest(raw=raw), \
                    mock.patch.object(resources.shutil, "which", return_value="/mock/nvidia-smi"), \
                    mock.patch.object(resources.subprocess, "run", return_value=command_result), \
                    mock.patch.dict(resources.os.environ, {"CUDA_VISIBLE_DEVICES": raw}, clear=True):
                result = resources.probe_nvidia()
            self.assertEqual(result["devices"][0]["index"], 3)
            self.assertEqual(result["visibility"]["cuda_visible_devices_raw"], raw)
            self.assertEqual(result["visibility"]["mapping_status"], "unknown")

    def write(self, path, content):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)

    def test_v2_ancestor_limits_constrain_affinity_and_memory(self):
        resources = self.module()
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            proc, cgroup = base / "proc", base / "cgroup"
            self.write(proc / "self/cgroup", "0::/job\n")
            self.write(proc / "self/mountinfo", f"10 1 0:1 / {cgroup} rw - cgroup2 cgroup rw\n")
            self.write(proc / "meminfo", "MemTotal: 16777216 kB\nMemAvailable: 8388608 kB\n")
            for directory, quota, cpuset, limit, current in (
                    (cgroup, "100000 100000", "0-7", 4 * 2**30, 7 * 2**29),
                    (cgroup / "job", "200000 100000", "2-5", 2 * 2**30, 2**29)):
                for name, value in {"cpu.max": quota, "cpuset.cpus.effective": cpuset,
                                    "memory.max": limit, "memory.current": current}.items():
                    self.write(directory / name, str(value) + "\n")
            with mock.patch.object(resources.os, "cpu_count", return_value=32), \
                    mock.patch.object(resources.os, "sched_getaffinity", return_value={2, 3, 4, 5}):
                cpu, memory, diagnostics = resources.collect_cpu_memory(proc_root=proc)
            self.assertEqual(cpu["affinity"]["count"], 4)
            self.assertEqual(cpu["cgroup"]["cpu_quota_count_upper_bound"], 1.0)
            self.assertEqual(cpu["capacity_upper_bound"], 1.0)
            self.assertEqual(cpu["cgroup"]["cpuset_ids"], [2, 3, 4, 5])
            self.assertTrue(cpu["cgroup"]["hierarchy_complete"])
            self.assertEqual(memory["mem_total_bytes"], 16 * 2**30)
            self.assertEqual(memory["effective_total_bytes_upper_bound"], 2 * 2**30)
            self.assertEqual(memory["cgroup_headroom_bytes"], 2**29)
            self.assertEqual(memory["observed_headroom_bytes"], 2**29)
            self.assertTrue(any(str(cgroup / "cpu.max") in item["sources"]
                                for item in cpu["cgroup"]["observations"]))
            self.assertEqual(diagnostics, [])

    def test_v1_mount_root_and_fractional_quota_are_respected(self):
        resources = self.module()
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            proc = base / "proc"
            cpu_mount, memory_mount, cpuset_mount = (base / name for name in ("cpu", "memory", "cpuset"))
            self.write(proc / "self/cgroup", "2:cpu,cpuacct:/jobs/job\n3:memory:/jobs/job\n4:cpuset:/jobs/job\n")
            self.write(proc / "self/mountinfo", "\n".join(
                f"{number} 1 0:1 /jobs {mount} rw - cgroup cgroup rw,{controller}"
                for number, mount, controller in ((10, cpu_mount, "cpu,cpuacct"),
                    (11, memory_mount, "memory"), (12, cpuset_mount, "cpuset"))) + "\n")
            self.write(proc / "meminfo", "MemTotal: 8388608 kB\nMemAvailable: 4194304 kB\n")
            for directory, quota in ((cpu_mount, -1), (cpu_mount / "job", 50000)):
                self.write(directory / "cpu.cfs_quota_us", str(quota))
                self.write(directory / "cpu.cfs_period_us", "100000")
            for directory, limit, current in ((memory_mount, 9223372036854771712, 0),
                                              (memory_mount / "job", 2**30, 2**28)):
                self.write(directory / "memory.limit_in_bytes", str(limit))
                self.write(directory / "memory.usage_in_bytes", str(current))
            self.write(cpuset_mount / "cpuset.cpus", "0-7")
            self.write(cpuset_mount / "job/cpuset.cpus", "2-3")
            with mock.patch.object(resources.os, "cpu_count", return_value=8), \
                    mock.patch.object(resources.os, "sched_getaffinity", return_value={0, 1, 2, 3}):
                cpu, memory, _ = resources.collect_cpu_memory(proc_root=proc)
            self.assertEqual(cpu["capacity_upper_bound"], 0.5)
            self.assertEqual(cpu["cgroup"]["cpuset_ids"], [2, 3])
            self.assertEqual(memory["cgroup_limit_bytes"], 2**30)
            self.assertEqual(memory["observed_headroom_bytes"], 3 * 2**28)

    def test_unmapped_cgroup_is_explicitly_incomplete(self):
        resources = self.module()
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            proc, cgroup = base / "proc", base / "cgroup"
            self.write(proc / "self/cgroup", "0::/unrelated/job\n")
            self.write(proc / "self/mountinfo", f"10 1 0:1 /other {cgroup} rw - cgroup2 cgroup rw\n")
            self.write(proc / "meminfo", "MemTotal: 1048576 kB\n")
            self.write(cgroup / "cpu.max", "max 100000")
            with mock.patch.object(resources.os, "cpu_count", return_value=4), \
                    mock.patch.object(resources.os, "sched_getaffinity", return_value={0, 1}):
                cpu, memory, diagnostics = resources.collect_cpu_memory(proc_root=proc)
            self.assertFalse(cpu["cgroup"]["hierarchy_complete"])
            self.assertIsNone(cpu["cgroup"]["cpu_quota_count_upper_bound"])
            self.assertIsNone(memory["mem_available_bytes"])
            self.assertIn("unmapped_cgroup", [item["kind"] for item in diagnostics])

    def v2_fixture(self, base, *, member="/job", mount_root="/"):
        proc, cgroup = base / "proc", base / "cgroup"
        self.write(proc / "self/cgroup", "0::" + member + "\n")
        self.write(proc / "self/mountinfo", f"10 1 0:1 {mount_root} {cgroup} rw - cgroup2 cgroup rw\n")
        self.write(proc / "meminfo", "MemTotal: 8388608 kB\nMemAvailable: 4194304 kB\n")
        # The kernel exposes these core files even on the actual hierarchy root.
        self.write(cgroup / "cgroup.controllers", "cpu memory cpuset\n")
        self.write(cgroup / "cgroup.procs", "1\n")
        relative = Path(member).relative_to(mount_root)
        leaf = cgroup / relative
        if leaf != cgroup:
            self.write(leaf / "cgroup.type", "domain\n")
            self.write(leaf / "cpu.max", "100000 100000\n")
            self.write(leaf / "memory.max", str(2 * 2**30))
            self.write(leaf / "memory.current", str(2**29))
        return proc, cgroup, leaf

    def admissions(self, observed, disk_path):
        resources = self.module()
        harness = importlib.import_module("run_harness")
        queue = importlib.import_module("resource_queue")
        with mock.patch.object(resources, "collect_cpu_memory", return_value=observed):
            return harness._available_ram(), queue.snapshot(disk_path)

    def test_v2_real_root_without_limit_files_admits_known_host_memory(self):
        resources = self.module()
        for member, expected in (("/", 4 * 2**30), ("/job", 3 * 2**29)):
            with self.subTest(member=member), tempfile.TemporaryDirectory() as temporary:
                base = Path(temporary)
                proc, cgroup, _ = self.v2_fixture(base, member=member)
                observed = resources.collect_cpu_memory(proc_root=proc)
                ram, queued = self.admissions(observed, base)
                self.assertEqual(ram, expected // 2**20)
                self.assertEqual(queued["memory_available"], expected)
                self.assertGreater(queued["cpu_slots"], 0)
                root = next(o for o in observed[1]["cgroup_observations"] if o["path"] == str(cgroup))
                self.assertEqual(root["limit_state"], "not_applicable_root")
                self.assertIsNone(root["current_bytes"])

    def test_v2_namespaced_or_subtree_root_missing_limits_is_not_unlimited(self):
        resources = self.module()
        for mount_root, core_type in (("/", "domain"), ("/tenant", None)):
            with self.subTest(mount_root=mount_root), tempfile.TemporaryDirectory() as temporary:
                base = Path(temporary)
                proc, cgroup, _ = self.v2_fixture(base, member=mount_root, mount_root=mount_root)
                if core_type:
                    self.write(cgroup / "cgroup.type", core_type)
                observed = resources.collect_cpu_memory(proc_root=proc)
                ram, queued = self.admissions(observed, base)
                self.assertEqual(ram, 0)
                self.assertIsNone(queued["memory_available"])
                self.assertEqual(observed[1]["cgroup_observations"][0]["limit_state"], "unknown")

    def test_v2_root_without_readable_core_evidence_stays_unknown(self):
        resources = self.module()
        for source in ("cgroup.controllers", "memory.max", "memory.current", "directory"):
            with self.subTest(source=source), tempfile.TemporaryDirectory() as temporary:
                base = Path(temporary)
                proc, cgroup, _ = self.v2_fixture(base, member="/")
                original_open = Path.open
                original_iterdir = Path.iterdir
                def open_checked(path, *args, **kwargs):
                    if source != "directory" and path == cgroup / source:
                        raise PermissionError(13, "Permission denied")
                    return original_open(path, *args, **kwargs)
                def iterdir_checked(path):
                    if source == "directory" and path == cgroup:
                        raise PermissionError(13, "Permission denied")
                    return original_iterdir(path)
                with mock.patch.object(Path, "open", open_checked), mock.patch.object(Path, "iterdir", iterdir_checked):
                    observed = resources.collect_cpu_memory(proc_root=proc)
                ram, queued = self.admissions(observed, base)
                self.assertEqual(ram, 0)
                self.assertIsNone(queued["memory_available"])

    def test_v2_missing_or_unreadable_nonroot_limit_stays_blocked(self):
        resources = self.module()
        for failure in ("missing_limit", "missing_usage", "permission", "invalid_usage"):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as temporary:
                base = Path(temporary)
                proc, _, leaf = self.v2_fixture(base)
                if failure == "missing_limit":
                    (leaf / "memory.max").unlink()
                elif failure == "missing_usage":
                    (leaf / "memory.current").unlink()
                elif failure == "invalid_usage":
                    self.write(leaf / "memory.current", "invalid")
                original_open = Path.open
                def open_checked(path, *args, **kwargs):
                    if failure == "permission" and path == leaf / "memory.max":
                        raise PermissionError(13, "Permission denied")
                    return original_open(path, *args, **kwargs)
                with mock.patch.object(Path, "open", open_checked):
                    observed = resources.collect_cpu_memory(proc_root=proc)
                ram, queued = self.admissions(observed, base)
                self.assertEqual(ram, 0)
                self.assertIsNone(queued["memory_available"])

    def test_v2_incomplete_root_interfaces_are_not_assumed_unlimited(self):
        resources = self.module()
        for source in ("memory.max", "memory.current"):
            with self.subTest(source=source), tempfile.TemporaryDirectory() as temporary:
                base = Path(temporary)
                proc, cgroup, _ = self.v2_fixture(base, member="/")
                self.write(cgroup / source, "1000")
                observed = resources.collect_cpu_memory(proc_root=proc)
                ram, queued = self.admissions(observed, base)
                self.assertEqual(ram, 0)
                self.assertIsNone(queued["memory_available"])

    def test_v2_namespace_root_retains_its_actual_memory_limit(self):
        resources = self.module()
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            proc, cgroup, _ = self.v2_fixture(base, member="/")
            self.write(cgroup / "cgroup.type", "domain")
            self.write(cgroup / "cpu.max", "100000 100000")
            self.write(cgroup / "memory.max", str(2**30))
            self.write(cgroup / "memory.current", str(2**29))
            observed = resources.collect_cpu_memory(proc_root=proc)
            ram, queued = self.admissions(observed, base)
            self.assertEqual(ram, 512)
            self.assertEqual(queued["memory_available"], 2**29)
            self.assertEqual(queued["memory_total"], 2**30)

    def test_v2_real_root_keeps_tighter_visible_ancestor_limits(self):
        resources = self.module()
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            proc, cgroup, _ = self.v2_fixture(base, member="/parent/job")
            parent = cgroup / "parent"
            self.write(parent / "cgroup.type", "domain")
            self.write(parent / "cpu.max", "50000 100000")
            self.write(parent / "memory.max", str(2**30))
            self.write(parent / "memory.current", str(3 * 2**28))
            observed = resources.collect_cpu_memory(proc_root=proc)
            ram, queued = self.admissions(observed, base)
            self.assertEqual(ram, 256)
            self.assertEqual(queued["memory_available"], 2**28)
            self.assertEqual(queued["memory_total"], 2**30)
            self.assertEqual(queued["cpu_slots"], 0.5)

    def test_cpu_range_parser_rejects_invalid_or_unbounded_expansion(self):
        resources = self.module()
        self.assertEqual(resources.parse_cpu_list("1-3,5,3"), [1, 2, 3, 5])
        for value in ("3-1", "-1", "0,cat", "0-999999999"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                resources.parse_cpu_list(value)

    def test_atomic_write_does_not_destroy_previous_snapshot_on_serialization_failure(self):
        resources = self.module()
        with tempfile.TemporaryDirectory() as temporary:
            target = Path(temporary) / "snapshot.json"
            resources.write_snapshot(target, {"generation": 1})
            with self.assertRaises(ValueError):
                resources.write_snapshot(target, {"bad": float("nan")})
            self.assertEqual(json.loads(target.read_text()), {"generation": 1})
            self.assertEqual([path.name for path in target.parent.iterdir()], ["snapshot.json"])
            resources.write_snapshot(target, {"generation": 2})
            self.assertEqual(json.loads(target.read_text()), {"generation": 2})

    def test_cli_writes_json_and_rejects_nonfinite_timeout(self):
        resources = self.module()
        with tempfile.TemporaryDirectory() as temporary:
            target = Path(temporary) / "snapshot.json"
            with mock.patch.object(resources, "collect_resources", return_value={
                    "schema_version": 1, "nvidia_gpus": {"status": "unknown"}}), \
                    contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(resources.main(["--output", str(target), "--timeout-seconds", "0.2"]), 0)
            self.assertEqual(json.loads(target.read_text())["schema_version"], 1)
            for timeout in ("nan", "inf", "0", "-1"):
                with self.subTest(timeout=timeout), contextlib.redirect_stderr(io.StringIO()), \
                        self.assertRaises(SystemExit) as raised:
                    resources.main(["--output", str(target), "--timeout-seconds", timeout])
                self.assertEqual(raised.exception.code, 2)


if __name__ == "__main__":
    unittest.main()
