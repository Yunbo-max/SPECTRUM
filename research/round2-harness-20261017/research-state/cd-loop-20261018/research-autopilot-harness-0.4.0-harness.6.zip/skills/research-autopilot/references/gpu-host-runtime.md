# Native GPU-host runtime

Use [single-experiment batching](single-experiment-batching.md): one active
experiment program, sequential descending batch calibration (for example
64 → 32 → 16 → 8 → 4 → 2), preserved scientific semantics and measured useful
throughput/headroom. Queue other experiments; keep Chat within CPU/4 GB.

Before blocking a stage on scorer availability/isolation, apply
[native-scoring-stages.md](native-scoring-stages.md). Restore real deferred scoring
support from the project. Independent training/export may proceed with saved
unscored artifacts; final metric claims wait for actual native scoring. No Docker
on any host. Requirements for a scorer that executes generated programs belong
to that operation, not automatically to training or prediction generation.


For target selection and direct SSH supervision, first read local-execution.md.
This module's full harness/runtime details apply when that backend is selected;
the local control agent does not need to install an LLM agent on the GPU host.


Apply this contract during G01 design, E01 preparation, local-agent handoff,
training, inference, native benchmark evaluation, live scorer replay and collection.
Apply [workflow-harness.md](workflow-harness.md) before generation and run all
executable project stages through the one admitted local harness.
The Local Codex/GPT controller is on the user's computer; invoke this runtime on
the separate GPU host through SSH, following local-execution-harness.md's host
contract. Remote Conda/runtime/project files are required, remote Codex/GPT is
not. Resolve paths, environment, telemetry and process evidence on that target.
Use native host execution. Use the selected native environment. The owner excludes Docker on every host; do not install, start or invoke Docker, Docker Compose, Docker-in-Docker,
Podman, containerd, Singularity or Apptainer as an automatic substitute.

Contents: [topology and readiness](#step-1-sourced-topology-and-readiness),
[native commands](#prepare-native-commands),
[operational tuning](#bounded-native-operational-tuning),
[benchmark compatibility](#benchmark-and-execution-compatibility),
[scheduling and handoff](#topology-based-scheduling-and-handoff),
[primary references](#primary-runtime-interfaces).

## Step 1: sourced topology and readiness

Start with [GPU intake and feasibility](gpu-intake-feasibility.md). User-stated hardware is a lead; inspect actual visible/allocated devices, native precision and the chosen project environment before implementation.

Copy [the planning template](../assets/templates/gpu-host-runtime.yaml) into the
project and resolve its actual environment identity. Retain source, status and
timestamp. Reuse the current project's explicitly stated device allocation; do not assume a count from this template. Verify device telemetry on its actual host. New/different hosts retain their own current sourced inventory;
do not impose a blanket single-GPU default. Keep model, VRAM, UUID, driver and
actual allocation unknown until read from the host; never infer them from old runs.

Resolve sourced topology before code/design: one GPU, multiple GPUs on one host,
or a multi-host cluster. Reuse current actual inventory/allocation records and
distinguish physical inventory from the resources this project may use. Web may
deliver hardware-bound or conditional `generated_unexecuted` code/design with named
unknown capacities/measurements and pending Local qualification. Local reads the
authorized SSH target's live allocated/usable devices, per-host UUIDs, memory/
external usage, CPU/RAM/storage/I/O and runtime restrictions before affected launches.
For a distributed proposal also retain relevant interconnect/topology and scheduler
allocation evidence. Missing live access leaves native placement/profile qualification
pending; it does not block truthful unexecuted Web delivery or justify inventing
a cluster or claiming measured performance.

Retain the runtime profile as top-level `runtime_profile` planning metadata in
the sourced intake or as a separate pinned project artifact. Do not extend strict
numeric resource fields with unvalidated keys. Bind actual profile, dependency
lock and environment manifest through native-plan `provenance.environment_refs`.
The profile is neither a permission grant, a host sandbox nor a readiness receipt.

G01's runtime portion must contain the environment name/prefix, Python interpreter,
dependency lock/version identities, driver/CUDA/framework compatibility, complete
native setup/train/inference/eval/replay/collect commands, device scope, current
capacity, the Local agent/subagent and CPU/GPU queue orchestration plan under
dependency-resource-scheduling.md, and separate software/native-scoring qualification
evidence. A bare
`containers_allowed: false` or planned Conda command does not prove execution.

## Prepare native commands

1. Inspect existing Conda environments and the actual host. Reuse a compatible
   environment; create a project-specific environment only when needed within
   the requested preparation scope. Do not reinstall the host driver or assume
   root/daemon access.
2. Read pinned upstream Python requirements, lockfiles, setup scripts and official
   scorer instructions. A Dockerfile may document dependencies; it cannot be
   treated as permission to run a container. Inspect helpers for hidden Docker
   calls before calling a setup, train, inference, evaluation or collection entry.
3. Use an upstream-supported Python version and CUDA/framework combination.
   Avoid arbitrary latest-package upgrades. Keep incompatible protocol families
   in separate Conda environments and do not mutate an environment in use.
   The scheduler needs Python 3.11+; the model/scorer environment may differ.
4. Use an absolute environment interpreter or `conda run --no-capture-output` so
   noninteractive SSH jobs do not depend on shell activation. Invoke the reviewed
   native entry point in the foreground. Retain stdout/stderr and exact argv.
5. Lock or export the actual resolved environment, retaining Conda and pip package
   versions, interpreter, driver/runtime and source identities. A list of requested
   dependencies alone is not a manifest of successfully installed packages.

Command shape only; substitute the real qualified entry point and arguments:

```bash
conda run --no-capture-output -n "$PROJECT_ENV" python "$NATIVE_ENTRYPOINT" "$@"
```

The script and model/data/input paths must still satisfy the existing pinned native
plan. Preserve `CUDA_VISIBLE_DEVICES` assigned by the harness; do not reset every
worker to device 0. For SSH-controlled execution, preserve the remote harness's
admitted device; SSH is transport, not an alternative GPU scheduler.
On the owner's sourced one-GPU host, use a single admitted device; do not invent
a multi-GPU `torchrun`/DDP launch. A different verified topology follows the
placement/qualification contract below rather than this host-specific choice.

## Bounded native operational tuning

Design real supported hooks for operational microbatch size, inference batching,
`num_workers`, prefetch and other relevant loader controls. Bind each hook to the
pinned native entry point/config and framework version; PyTorch DataLoader exposes
`num_workers`, `prefetch_factor`, `persistent_workers` and `pin_memory`, but an
arbitrary train/eval program need not expose corresponding CLI flags. If a needed
hook is absent, implement/review a scoped adapter under the code contract first.
The harness admits frozen plans; it has no generic automatic batch probe or
workload autotuner. Do not pretend a `run_harness.py` flag supplies these hooks.

Local autonomously tunes these operational settings only within explicit allowed
development ranges, attempt/time/compute limits and semantic acceptance rules
written before handoff. Keep precision, samples, seeds, metrics and scientific
hyperparameters fixed unless an existing scoped design authorization permits a
change. Freeze each admitted probe's real argv/config; never mutate active plan
digests or a confirmation run. Retain the tuning table, raw logs and reason for
the empirically best feasible setting among tested candidates, including a smaller
batch or fewer workers when they yield better useful throughput/headroom.

Use the descending calibration procedure in single-experiment-batching.md.
Try supported sizes sequentially, for example 64 → 32 → 16 → 8 → 4 → 2, starting
inside the bounded range supported by actual capacity and known workload profiles.
Retain failures and restore state after terminal cleanup before a smaller attempt.
Stop at a stable qualified setting unless throughput/headroom evidence warrants a
bounded comparison below it. Reuse unchanged qualified profiles; do not impose a
full sweep or retune frozen confirmation. Adjust supported worker/prefetch settings
within the same CPU/RAM/I/O budget and preserve the native scientific semantics.

1. Qualify the actual native train/inference/scorer path in its Conda environment.
   Admit short development probes through the existing harness, initially exclusive,
   using representative real inputs and worst permitted shapes/lengths. Training
   profiles include warmup, forward, backward, optimizer state/step and checkpoints;
   inference profiles include permitted prompt/output lengths, batching/KV cache,
   native scoring and export as applicable. A dummy forward or instantaneous free
   VRAM reading cannot qualify the full workload's envelope.
2. Measure stage and end-to-end throughput, elapsed time, allocated/reserved peaks,
   actual device/process usage, CPU/RAM/I/O/loader stalls, headroom and OOM/error
   outcomes. In PyTorch use CUDA synchronization or completed CUDA Events for GPU
   timing and `max_memory_allocated`/`max_memory_reserved` for framework peaks,
   together with host telemetry; cached or external memory is not tensor memory.
   Measure loader workers/prefetch together with independent CPU preparation and
   any scoring internal to this same program; standalone scoring stays queued.
   CPU saturation can starve the GPU. Keep enough native iterations to cover
   transient peaks and steady state under the stated finite profiling budget.
3. Compare only feasible settings that pass native semantic/acceptance checks and
   fit conservative resource reservations plus measured operating headroom. OOM
   is a retained failed development probe, not successful capacity measurement.
   Apply the written bounded recovery rule, restore the declared model/optimizer/
   RNG/input state for the next probe and account for every attempt; do not conceal
   fallback changes. Stop tuning when its bound is reached and retain unqualified
   settings as blocked. Confirmation uses its frozen no-inspected-retry policy.
4. Freeze the selected native settings and conservative profile into a new ready
   plan with actual workload/environment/input/protocol identities. Keep one active
   experiment program throughout qualification and full execution; disable sharing
   and serialize experiments across project runners/hosts as described in
   single-experiment-batching.md. Requalify changed identities or input shapes.

Treat microbatch/accumulation as operational only when their semantics are preserved
and checked. For equal-sized distributed batches, document effective batch as
`microbatch_per_rank * accumulation_steps * world_size`; explicitly handle token
weighting and uneven/last batches rather than applying that formula blindly.
Retain loss normalization, optimizer update count, clipping, scheduler cadence,
AMP scale/step handling and data/RNG ordering. PyTorch AMP accumulation keeps the
scale fixed within an effective batch and steps/updates at that boundary. Matching
effective batch alone does not establish equivalence for batch-dependent layers,
cross-example losses or stochastic execution. Inference batching must preserve
case/sample identity, per-case RNG, decoding limits and scorer semantics. Preserve
loader order/seeding and correctly shard iterable data; worker count, persistent
state or out-of-order delivery can otherwise change the scientific comparison.
An unproven semantic change requires the existing scientific design decision.

Choose settings to maximize qualified useful throughput within priorities/budgets,
while overlapping independent eligible CPU and GPU work. Target measured bottlenecks
and stable headroom; do not require full VRAM or 100% utilization, guarantee a global
optimum, or create useless jobs to keep a device busy.

## Benchmark and execution compatibility

| Observed upstream path | Required decision |
|---|---|
| Official evaluator supports native Python | Pin and qualify that path, including data/tests, sampling, metric and denominator. |
| Dockerfile plus a native evaluator are published | Inspect dependencies and use the native evaluator; verify every helper is container-free. |
| Only a Docker example is documented | Inspect the real scorer entry point, helpers and dependency files first; configure and qualify a faithful native Conda path when feasible. Documentation or a Dockerfile alone is not an unavoidable container dependency. |
| A necessary execution capability is actually unavailable | Pause only this affected evaluation while resolving its named compatibility/qualification gap; continue independent admitted work. Do not emit a container command or replace scoring as a fallback. |
| A new native port is proposed | Retain it as unqualified until source semantics and available trusted native outputs establish the existing parity contract; missing official evidence stays a blocker. |
| The scorer executes generated programs and needs unavailable isolation | Hold that scoring operation; use a supported deferred-scoring route for independent training/export. Qualify a native scoring path. Conda is not an OS sandbox. |

Keep the published task, splits, cases/tests, labels, metrics, sampling, timeouts
and budgets unchanged. Do not replace missing Docker evaluation with hand-made
tests, easier scoring or a different benchmark under the old protocol identity.
A different existing benchmark requires an explicit scoped design revision.
Use legitimate host/OS isolation only when it actually supplies the required
capability; absence is not a reason to install containers against this profile.

## Topology-based scheduling and handoff

On the confirmed one-GPU host, use `gpu_count: 0` for CPU-only tasks and `1` for
GPU tasks. Keep one active experiment program; calibration, training, inference
and standalone scoring are sequential. Independent reading and CPU preparation may
overlap within measured CPU/RAM/I/O limits. Keep same-card experiment sharing off.
Model weights, activations/KV cache, native scorer, warmup and output export all
contribute to the resource/time plan. Retain unfinished work under stable IDs.

For a verified multi-GPU host or cluster, the project still runs one experimental
program at a time. Use DDP/distributed execution only within that program when
actual framework support, allocated capacity and measured benefit justify it,
with rank/device binding, data sharding, effective-batch/optimizer/RNG semantics,
communication costs and recovery/collection ownership retained. Data-loader
workers and distributed ranks share this job's allocation. Preserve each
scheduler's assigned device scope and queue independent experiments.

The existing harness controls one host and UUID pool, including several devices
on that host; it does not coordinate a cluster. Multi-host work requires one
coordinated controller/allocator per host and implemented external top-level
admission for all participating hosts/devices, with cumulative budgets and failure
reconciliation. A configured scheduler such as Slurm can provide external admission;
the skill neither installs it nor adds multi-host flags to the harness. Until that
layer is real and qualified, admit only supported single-host work. CPU/API/agent
tasks can still proceed independently within their actual resource contracts.

The web-to-local packet includes the sourced runtime profile, actual dependency
lock, foreground native command list, topology-specific resource requests,
Local coordinator/subagent ownership and CPU/GPU ready/blocked queue/DAG plan,
allowed tuning ranges/budget/semantic checks and profile/throughput evidence,
complete baseline/control/scorer obligations, blocked tasks, and run/collect/export paths.
The return packet includes actual environment/version evidence, raw logs, result
and E04 verification scope, selected operational settings and measurements,
actual placement/contention, remaining work/budgets and remote readback. This contract
does not claim that the current host has been provisioned or a workload deployed.

## Primary runtime interfaces

Checked 2026-10-08; use documentation matching the pinned deployed versions:

- [PyTorch DataLoader](https://docs.pytorch.org/docs/stable/data.html): supported
  batching/worker/prefetch controls, ordering, worker seeds and iterable-data sharding.
- [PyTorch CUDA semantics](https://docs.pytorch.org/docs/stable/notes/cuda.html):
  synchronized/Event timing and allocated versus reserved caching-allocator memory.
- [PyTorch AMP accumulation](https://docs.pytorch.org/docs/stable/notes/amp_examples.html#gradient-accumulation):
  effective-batch boundaries and scaling/optimizer handling.
- [PyTorch DDP](https://docs.pytorch.org/docs/stable/generated/torch.nn.parallel.DistributedDataParallel.html):
  process/device binding, explicit input sharding and supported `no_sync` accumulation.
- [NVIDIA SMI](https://docs.nvidia.com/deploy/nvidia-smi/index.html): UUID-based
  inventory, device/process memory telemetry and topology.
- [Slurm GRES](https://slurm.schedmd.com/gres.html): configured cluster resource
  admission and assigned device visibility; this is an external implementation.
