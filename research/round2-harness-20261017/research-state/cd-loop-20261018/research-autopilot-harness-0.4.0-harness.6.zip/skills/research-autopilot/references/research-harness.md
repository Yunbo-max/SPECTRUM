# Work Harness research program

## Work Harness C/D profile

Restore `sequence.flow_profile` before applying inherited workflow rules. For
`work-harness-cd-v1`, read [C/D mathematical diagnosis and executable idea development](cd-math-code-loop.md).
The versioned catalog `assets/skill-sequence-cd-v1.json` and its overriding node
guides govern C's condition/failure/dependency diagnosis, D's mechanism construction
and real local experiments, reviewed B/C/D revisits and M05 `VERIFIED_FOR_SCALEUP`.
B05 validates a supported problem contract; old Natural Gate 0/IPCG prerequisites
do not apply to this profile's local diagnostic/development work. Independent
verified review plus program checks advances automatically into E, which retains
full settings, freezing, fair comparisons, scale and confirmation.

The worker proposes typed revisits and code applies approved transitions; no raw
skip/jump is allowed. Preserve source/evidence lineage, failed findings, external
jobs, cumulative usage and pause state. Omitted `flow_profile` retains legacy
catalog/transition behavior. Profile-specific rules override conflicting inherited
C/D ordering/admission text below only when the profile is actually adopted.
Installation alone does not migrate a running project or change another edition.

Read this at startup, every actual agent invocation, after a terminal result, and
before reporting completion or unattended continuation. This is the fifth edition,
`autonomous-rsi-harness`, version `0.4.0-harness.6`. Preserve the original Work
scientific method and the user's existing Codex or other supported local agent.

## What the harness adds

The program executes the existing Autopilot Skill in the fixed catalog order under
[skill-sequence.md](skill-sequence.md). Its legacy `planner` role is a current-step
worker, with a separately executed reviewer. It may perform the assigned step
and request necessary child work, but cannot choose the next node, skip a node or
end the goal. The program advances only after fixed requirements have real pinned
evidence, actual child results have been read back and the step is accepted.
All canonical 84 nodes remain represented; only code determines inactivity for
optional scopes absent from the authorized objective. The scientific method stays
unchanged. The whole goal remains separate from the currently executable queue.

The design draws on the explicit lifecycle and durable-state separation in
[DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness/tree/687f282e8625c6b8d11ff58211a90524be2e4317).
It does not install DeepSeek Harness, switch the user's agent/model/account, or
treat its foreground workflow as a research scheduler. Its goal activation and
worker-reported completion are not evidence that our research loop will resume
or that a scientific claim is true. See the source repository's
[comparison and architecture](https://github.com/Yunbo-max/Research_Autopilot/blob/autonomous-rsi-harness/docs/architecture/research-program.md).

## Restore the actual adopted edition

Restore the project ID, original objective and later steering, immutable source
revision/digest, `assets/harness-policy.json`, program/controller records, coverage
reference, accepted v4 decision, review, sequence catalog/cycle/cursor/attempt,
accepted steps, pending result inspections, known jobs, current resources and budgets.
Compare them with the actual loaded skill. An old installed Simple/Work skill is
not this edition. Source publication does not repin a running project or refresh
a scheduled prompt. Adopt changed policy only at a quiet, authorized boundary,
retaining historical evidence and unknown operations.

Each real command-agent invocation receives the adopted skill entry and the
action-required canonical modules from `assets/runtime-guidance.json`, with actual
hashes retained in its guidance manifest. Read those contents and relevant primary
evidence. An injection receipt proves supplied bytes, not that a model understood
or obeyed them; the reviewer and deterministic admission still inspect the result.
Do not claim full compliance from having used a worker, queue or native harness.

## Full obligations, then the ready subset

Maintain the complete known goal obligations in a pinned `research-coverage`
manifest: knowledge, implementation, experiments, scoring, review and delivery.
Include every justified comparator, condition and replication needed for the
claim, not just the first available method. Future tasks whose inputs do not yet
exist stay as unfinished obligations; never fabricate future artifact hashes.
Only the currently ready subset enters the executable Controller task queue.

Every successor coverage manifest links to the last accepted reference. Preserve
prior obligation IDs, descriptions, task bindings and evidence. New evidence may
refute a hypothesis or require new work; preserve that history and the original
goal. A status-only edit cannot turn pending work into satisfied work. Missing
or altered evidence cannot be silently removed to make the coverage look complete.
Canonical experiment design contracts retain paper-derived comparison scope,
resources, review and actual completion receipts. Use eligible jobs for dispatch;
pending work elsewhere is not a blanket block on independent reading/preparation.

The runtime's coverage inspection checks real file identities and contract shape.
It does not execute a scorer or certify mathematical truth, novelty or scientific
PASS. A completed comparison can have a negative or inconclusive outcome. The
independent review must distinguish finished investigation from a successful new
method, and final claims still need native scientific verification.

## Current-step work, review, execution and archive

1. Restore the exact sequence state and reconcile running or unknown operations
   by their retained run/owner/fence identities. A missing response is not a retry.
2. Read the program-assigned node's source modules, fixed requirements, adopted
   policy and relevant primary evidence. Papers/code, purposeful reproduction,
   concrete conditions, mathematical modeling, benchmarks and strong baselines
   remain the existing scientific progression; a new method is not forced each cycle.
3. The current-step worker supplies per-requirement findings with real pins, the
   applicable v4 decision and complete coverage. Child tasks serve this same node.
   No worker response controls the next node or claims the program is complete.
4. A separate actual reviewer invocation checks the exact node identity,
   requirements, evidence, alternatives and interpretation. Rejection or missing
   evidence keeps the node open. Canonical scientific admission still applies.
5. Dispatch only admitted current-node child tasks with existing input bytes and
   finite reservations. Archive their actual outputs and receipts, then invoke
   the current-step worker to inspect and integrate them. Child completion does
   not itself accept the node or move the sequence cursor.
6. Program code advances only after node acceptance. At cycle closure, the current
   frozen empirical matrix needs actual native verification with exact contract,
   method-batch and candidate bindings, full comparisons and applicable E04.
   Knowledge work requires no fabricated experiment. A self-reported PASS cannot
   replace actual scoring or scientific evidence.
7. In `repeat` mode, program code returns to the first active node after the cycle
   and its current empirical obligations are accepted. Unresolved knowledge and
   negative findings carry forward. In `once` mode, full original-goal coverage
   is also required before completion. Original budgets and pause state persist.

New contracts require schema 2 with `sequence: {mode, scopes, flow_profile}` (new Work Harness
programs select `flow_profile: work-harness-cd-v1`; omission retains legacy behavior) and mandatory
`research` scope. Optional manuscript/revision/release/communication scopes follow
the actual user objective; they do not authorize unrequested publication. Old
schema-1 programs are exact-contract recovery only, without automatic migration.

The planner/reviewer command contract cannot globally prevent a fully privileged
agent from using its own shell or SSH outside the program. Use the existing native
permissions and trustworthy command configuration; never advertise an unbypassable
sandbox or universal skill-compliance guarantee.

## Hosts, scoring and one experiment at a time

The local agent controls and supervises. Restore the existing authorized SSH GPU
route, choose the actual execution target, sync pinned code, and read back its
environment, allocation and job identity under [local-execution.md](local-execution.md).
For cross-root/SSH native tasks, pin explicit `native_transfer_limits` and reserve
computation plus collection time. Declare every required raw result/log/receipt
output so bounded transport can bring it back before current-step acceptance. Existing
conflicting files and unknown attempts are retained; they are not overwritten or
restarted. Final scoring audit refs remain labelled with their actual host/root.
Do not silently run GPU workloads on the user's computer or assume another LLM
agent must be installed on the GPU server.

Apply [native-scoring-stages.md](native-scoring-stages.md): restore the project's
actual deferred-scoring implementation, save checkpoints/predictions and score
them natively when that stage is ready. Final scoring capability does not block
independent training/export. Training-time reward/filtering/selection preserves its
real score dependency. All stages exclude Docker and hidden Docker helpers.

Apply [single-experiment-batching.md](single-experiment-batching.md): one active
experiment program, supported batch sizes descending, such as 64 → 32 → 16 → 8 →
4 → 2, preserving effective batch and native evaluation semantics. Measure useful
throughput and stable headroom on the real target. Queue other experiments; a
planner/reviewer task is not permission to launch a competing GPU workload.

## Install, operate and report the actual state

The four-skill ZIP carries instructions and skill helpers. It does not contain or
install `src/research_autopilot`, a Python environment, vendor authentication, SSH
access or a live decision service. For this research-program implementation, use
the selected fifth-branch source checkout with Python 3.11+ and install its runtime
using `python -m pip install -e .` in the chosen native environment. Keep that
checkout fixed while a project is pinned to it. Do not install a daemon by default.

The source runtime provides `research-autopilot-program --db PATH` with `init`,
`status`, `pause`, `resume`, `tick`, and `run`. Read the actual installed `--help`
and the source repository's [program guide](https://github.com/Yunbo-max/Research_Autopilot/blob/autonomous-rsi-harness/docs/RESEARCH_PROGRAM.md)
for contracts and arguments. A program initialization is not a live consumer.
Observed successful agent invocations and retained event/receipt readback establish
what has actually run. This source update does not claim unattended qualification.

Run deadlines and explicit cumulative user limits remain binding. A 24-hour
attempt/cycle boundary or reporting window does not mean the research goal is
finished or require a manual scientific decision for every next cycle. A resident
authorized driver can keep invoking eligible bounded tasks while it is alive.
Persisted program state alone cannot keep a terminated host running. After process
loss, use the already authorized host continuation mechanism or recover the same
program, reconcile unknown attempts and continue within the original limits.
If no such sequence consumer exists, report that specific capability gap.

An explicit pause is durable program state even when the conversation host has no
active long-goal object. Re-read it before dispatch and reconcile in-flight work.
Only sourced user resumption clears it. Do not infer resumption from a plugin
update, elapsed time or a new machine process. Report source publication, package
validation, installation, project adoption and observed live operation separately.
