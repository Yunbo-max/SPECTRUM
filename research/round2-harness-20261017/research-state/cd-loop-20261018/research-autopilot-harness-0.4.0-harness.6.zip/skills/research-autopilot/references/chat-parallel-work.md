# Parallel work in the active Chat

Use actual host subagents proactively when independent useful work can save
elapsed time or improve review. Keep one research candidate and one current
parent attempt, with bounded child packets and one integration coordinator.
Keep tiny or tightly dependent tasks serial when dispatch overhead outweighs
the useful work; do not fill all available slots as an objective in itself.
Parallelism changes how that work executes, not the goal, scientific gates,
permissions or total budget. It needs no separate Local executor, paid daemon
or new Work goal and cannot wake an ended Chat turn.

## Observe capacity, then dispatch useful work

At startup/resume, read the current host's advertised spawn, message/follow-up,
list/status and wait operations. Inspect existing children and the available
slots when observable. Record the observation source and time. A quota applies
to its actual host/session and may include the parent; do not encode a fixed
agent count or infer capacity from a previous conversation. If the remaining
count is not exposed, use a small bounded wave and respect actual admission
responses; do not fill slots with test agents.

Use the first useful spawn as capability confirmation. Keep its returned actual
child/session identity and subsequent observation or result. Planned roles,
successful local bookkeeping and a statement that an agent ran do not prove
host execution. If spawning is unsupported, rejected or temporarily full,
continue safe serial or other ready work. A genuine independent review remains
pending if no independent reviewer can execute; serial self-review cannot
replace it. Do not re-probe unchanged unavailable capabilities on every tick.

## Select an independent ready wave

Good parallel work includes primary-paper/appendix/code evidence extraction,
separate mathematical or experimental-design reviews of already frozen
artifacts and code patches with disjoint owned files. Experimental jobs from
a frozen admitted design run sequentially under single-experiment-batching.md. Independent means a packet can execute with
its current pinned inputs without waiting for another writer's changing output.
Run dependencies in later waves; a review of an unfinished design is advisory,
not acceptance of the eventual design.

One possible four-role arrangement is below. It is an example, not a minimum
staffing requirement; use fewer roles when work or capacity does not justify it.

| Role | Bounded responsibility | Integration boundary |
|---|---|---|
| Coordinator | Restore goal, admit packets, do unassigned work, inspect outputs and choose the next wave | Sole checkpoint writer and publisher |
| Source reader | Extract exact paper/appendix/code facts and contradictions | Return source locators and evidence; do not assert experimental success |
| Implementer/executor | Patch owned files or run uniquely assigned admitted jobs | Return actual changes, commands, receipts and unresolved failures |
| Independent reviewer | Check a frozen derivation, design, patch or result against stated criteria | Read-only findings with actual reviewer identity; never review their own production as independent |

A producer and reviewer must have distinct actual identities, not merely
different role labels. For acceptance review, provide the frozen artifact,
underlying source/evidence and objective acceptance criteria in a fresh or
minimal-context task when supported. Do not include the author's desired
verdict, a prewritten success summary or an instruction to agree. Preserve
separate supporting evidence, counterevidence, unresolved checks and adverse
findings, and adjudicate disagreements using evidence. Separate agents
can still share blind spots; their agreement is not proof of correctness.

For scientific strategy, assign useful independent challenges: a primary-source
reader checks nearest work and the strongest simple alternative; a mathematical
reader tests rival explanations, assumptions and counterexamples; an experiment
reviewer checks fairness, inference and the next decisive comparison. Several
cheap causal hypotheses can be examined before selecting one candidate for
expensive verification. Do not use extra agents merely to multiply nearby runs.
Numerical E04 replication does not replace review of value or originality.
Integrate their evidence through [research decisions](chat-research-decisions.md).

## Packet and ownership contract

Before dispatch, record a stable packet ID, parent attempt/candidate, purpose,
dependencies, input hashes and procedure revision, actual permitted tools,
exclusive output paths or explicit read-only scope, acceptance checks, finite
time/resource bounds and required return evidence. Send the child only the
context needed for that task. The child inherits existing authority and pins;
it cannot widen permissions, alter the experiment or reset a counter.
Children return scoped artifacts and findings; only the coordinator advances
the canonical study state after its existing acceptance checks.

All children share the real host's filesystem and resource allocation unless
the host demonstrably isolates them. Assign nonoverlapping write paths, use
isolated patches/worktrees when actually available, and keep shared contracts,
checkpoints, integrated manifests and publication under the coordinator. A
reviewer writes findings to its own assigned artifact, not into the reviewed
source. Do not dispatch nested children without coordinator admission into the
same capacity and budget accounting. No child publishes or starts a duplicate
job merely because its own queue is empty.

The optional `scripts/chat_cycle.py` records parallel bookkeeping under the
current parent attempt. Use the exact event/CLI contract in
[chat-cycle-records.md](chat-cycle-records.md); these records do not spawn agents
or schedule work. Without the helper, preserve equivalent fields with available
project artifact tools. Never make a missing helper or Python a new Chat gate.

## Shared resources and honest usage

Admit reading/review/code work against remaining cumulative bounds and actual
shared resources. Run only one experimental program across the project, including
all hosts, devices and agents; additional resources do not enable parallel trials.
Follow [single-experiment batching](single-experiment-batching.md). Chat remains
CPU-only under the lower of available RAM and total 4,000,000,000 bytes, including
children and margin. Preserve frozen confirmation, native protocols and accounting.

Each real experimental job has one owner, stable job/attempt identity, pinned
command/code/data/protocol and output location. Register the returned process
or provider ID and retain logs. Dispatch only jobs admitted by the current
design and resource checks. A subagent running the host's same GPU is not a
new allocation; parallel agents are not additional independent samples.

Project wall time is elapsed time across the wave, not the sum of overlapping
child durations. GPU/device time and model usage/cost are additive across actual
jobs/calls, including failures; parent and children share the same cumulative
limits. Keep per-packet reservations separate from actual usage, release only
unspent reservations after reconciliation, and avoid counting a child's already
included job receipts twice. Provider-unreported usage stays unknown with its
source gap; do not record it as zero or as a measured reservation. Do not infer
free usage or guaranteed speedup from the availability of subagents.

## Observe, reconcile and integrate

After each spawn, bind the actual child/session identity and observe actual
state/results through supported APIs. Do useful independent work during waits;
use bounded waits with meaningful progress updates. Preserve queued, running,
completed, failed, acknowledged-partial and unknown states distinctly. A
timeout, missing message or disconnected parent does not establish child
failure, completion or cancellation.

For acknowledged partial work, save produced artifacts and exact unfinished
action, and continue through the same observed child/session when supported.
For unknown activity, query the original child and its actual job/process IDs
before any retry. If the host cannot observe them, retain the blocker and do
unrelated work; do not spawn a replacement that could duplicate effects. Before
reassigning output/job ownership, establish that the old operation is terminal
or its cancellation actually acknowledged. Keep failed attempts and actual
consumption in history. Cancellation alone never proves the underlying GPU job
stopped; reconcile that operation separately.

Checkpoint packet/session IDs, last observed states/timestamps, immutable
inputs and procedure pins, output ownership, job/process identities, partial
artifact hashes, reservations/actual usage and concrete next actions. On
resume, reconcile that checkpoint before planning another wave. A new child,
turn or wave does not create a new project goal or budget.

The coordinator checks returned evidence and hashes, rejects stale/mismatched
inputs, resolves conflicts, performs necessary integrated verification and
settles the wave before recording the parent result. A completed child or a
parallel bookkeeping status is not canonical scientific PASS. Keep missing
comparisons, review and uncertainty obligations pending. Follow the existing
repair/continuation route and execute the next eligible wave in the same active
turn; neither child completion nor one successful wave ends the research goal.
