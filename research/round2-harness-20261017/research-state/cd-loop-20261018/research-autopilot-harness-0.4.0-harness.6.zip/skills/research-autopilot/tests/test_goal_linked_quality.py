"""Control-flow/metric fixtures based on reported failure patterns; not research results."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

S=Path(__file__).resolve().parents[1]/'scripts'
sys.path.insert(0,str(S))

class QualityTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue((S/'research_quality.py').is_file(), 'goal-linked quality checker is absent')
        spec=importlib.util.spec_from_file_location('quality_tested', S/'research_quality.py')
        self.m=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.m)
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.n=0
        self.evidence=self.ref('control-flow fixture evidence; no scientific claim')
    def ref(self,value):
        self.n+=1;p=self.root/f'e{self.n}.json'
        p.write_text(value if isinstance(value,str) else json.dumps(value))
        return {'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    def packet(self):
        return dict(kind='research_quality',schema_version=1,goal_id='goal',candidate_id='candidate',protocol_id='p1',
            stage='compare',selected_task_ids=['task'],primary_metric_id='error',
            metrics=[dict(id='error',role='primary',direction='lower',unit='degrees',denominator='one sequence',
                         independent_unit='sequence',definition_ref=self.evidence),
                     dict(id='proxy',role='proxy',direction='lower',unit='residual',denominator='one sequence',
                         independent_unit='sequence',definition_ref=self.evidence)],
            information=dict(signature='observed-history-v1',decision_time='before action',mapping_ref=self.evidence),
            implementation=dict(mapping_ref=self.evidence,terms=[dict(id='data',state='implemented',evidence_refs=[self.evidence]),
                           dict(id='temporal',state='omitted',evidence_refs=[self.evidence])]),
            population=dict(target='released benchmark',observed='released benchmark',status='native',manifest_ref=self.evidence),
            baselines=[dict(id='exact',role='strong_simple',status='qualified',information_signature='observed-history-v1',
                            evidence_refs=[self.evidence])],
            novelty=dict(status='unresolved',delta='Unknown',closest_refs=[self.evidence],discriminator_ref=None),
            statistics=dict(estimand='paired sequence difference',independent_unit='sequence',sampling='fixed sequences',
                            exposure='development',analysis_ref=self.evidence),
            costs=dict(scope='end_to_end',evidence_refs=[self.evidence],unmeasured=[]),
            obligations=[dict(id='native',status='resolved',required_before=['expand','confirm'],
                              next_task_ids=[],evidence_refs=[self.evidence])],
            claims=[],results=[])
    def codes(self,r):return {x['code'] for x in r['gaps']+r['claim_limits']}
    def check(self,p):return self.m.evaluate(self.root,p,task_id='task',goal_id='goal',candidate_id='candidate')
    def claim(self,metric='error',kind='effect',**kw):
        c=dict(id='c',kind=kind,status='supported',metric_id=metric,scope='released benchmark',
               required_terms=['data'],baseline_ids=['exact'],evidence_refs=[self.evidence]);c.update(kw);return c
    def values(self,metric='error',method=0.8,baseline=1.0):
        return dict(metric_id=metric,baseline_id='exact',paired_ref=self.ref([dict(unit_id='u1',method=method,baseline=baseline),
                       dict(unit_id='u2',method=method,baseline=baseline)]))
    def test_compare_can_investigate_unresolved_novelty(self):
        r=self.check(self.packet());self.assertEqual(r['status'],'ready_for_scoped_work')
        self.assertFalse(r['scientific_certification']);self.assertIsNone(r['aggregate_score'])
    def test_proxy_does_not_certify_primary_improvement(self):
        p=self.packet();p['claims']=[self.claim('proxy')];p['results']=[self.values('proxy')]
        self.assertIn('proxy_not_primary',self.codes(self.check(p)))
    def test_primary_worse_despite_proxy_win_is_not_improvement(self):
        p=self.packet();p['claims']=[self.claim()];p['results']=[self.values(method=1.2),self.values('proxy')]
        self.assertIn('observed_primary_not_improved',self.codes(self.check(p)))
    def test_omitted_temporal_term_cannot_support_temporal_claim(self):
        p=self.packet();p['claims']=[self.claim(required_terms=['temporal'])];p['results']=[self.values()]
        self.assertIn('claimed_term_not_implemented',self.codes(self.check(p)))
    def test_synthetic_work_cannot_claim_native_scope(self):
        p=self.packet();p['population'].update(observed='synthetic',status='diagnostic')
        p['claims']=[self.claim()];p['results']=[self.values()]
        self.assertIn('scope_mismatch',self.codes(self.check(p)))
    def test_missing_strong_baseline_prevents_expansion_not_diagnosis(self):
        p=self.packet();p['baselines'][0]['status']='planned';p['stage']='expand'
        self.assertIn('strong_baseline_unqualified',self.codes(self.check(p)))
        p['stage']='diagnostic';self.assertFalse(self.check(p)['gaps'])
    def test_mismatched_information_cannot_support_fair_superiority(self):
        p=self.packet();p['baselines'][0]['information_signature']='oracle'
        p['claims']=[self.claim()];p['results']=[self.values()]
        self.assertIn('information_mismatch',self.codes(self.check(p)))
    def test_component_time_is_not_end_to_end_speedup(self):
        p=self.packet();p['costs']['scope']='component';p['claims']=[self.claim(kind='efficiency')]
        self.assertIn('full_cost_missing',self.codes(self.check(p)))
    def test_required_baseline_debt_cannot_disappear_into_more_seeds(self):
        p=self.packet();p['stage']='expand';p['obligations'][0].update(status='pending',next_task_ids=['restore-native'])
        r=self.check(p);self.assertIn('critical_obligation_open',self.codes(r))
        self.assertIn('restore-native',r['priority_task_ids'])
    def test_resolving_dependency_is_not_blocked_by_debt(self):
        p=self.packet();p['stage']='acquire';p['obligations'][0].update(status='pending',next_task_ids=['task'])
        self.assertFalse(self.check(p)['gaps'])
    def test_resolved_obligation_requires_evidence(self):
        p=self.packet();p['obligations'][0]['evidence_refs']=[]
        self.assertIn('missing_evidence',self.codes(self.check(p)))
    def test_known_component_cannot_be_reported_as_new_theory(self):
        p=self.packet();p['novelty']['status']='known_component';p['claims']=[self.claim(kind='novelty')]
        self.assertIn('novelty_unestablished',self.codes(self.check(p)))
    def test_negative_result_is_valid_without_positive_primary_change(self):
        p=self.packet();p['claims']=[self.claim(status='not_supported')];p['results']=[self.values(method=1.2)]
        r=self.check(p);self.assertNotIn('observed_primary_not_improved',self.codes(r))
        self.assertFalse(r['scientific_certification'])
    def test_exposed_cases_cannot_become_confirmation(self):
        p=self.packet();p['stage']='confirm';p['statistics']['exposure']='development'
        self.assertIn('confirmation_exposed',self.codes(self.check(p)))
    def test_no_auto_stats_oracle_from_repeated_samples(self):
        rows=[dict(unit_id='same',method=1.,baseline=2.)]*10
        with self.assertRaises(ValueError):self.m.paired_summary(rows,'lower')
    def test_summary_is_descriptive_not_inferential(self):
        r=self.m.paired_summary([dict(unit_id='1',method=1.,baseline=2.)],'lower')
        self.assertEqual(r['mean_improvement'],1.);self.assertIsNone(r['confidence_interval'])
        self.assertFalse(r['independence_verified'])
    def test_metric_semantics_change_requires_new_protocol(self):
        p=self.packet();p['previous_ref']=self.ref(p);p['metrics'][0]['denominator']='per frame'
        self.assertIn('protocol_reused_after_semantic_change',self.codes(self.check(p)))
    def test_pending_obligation_cannot_be_deleted(self):
        p=self.packet();p['obligations'][0].update(status='pending',next_task_ids=['restore'])
        p['previous_ref']=self.ref(p);p['obligations']=[]
        self.assertIn('lost_obligation',self.codes(self.check(p)))
    def test_same_comparison_can_be_reused_without_new_derivation(self):
        p=self.packet();p['previous_ref']=self.ref(p)
        self.assertFalse(self.check(p)['gaps'])
    def test_outcome_missing_is_not_scientific_refutation(self):
        p=self.packet();p['claims']=[self.claim()]
        self.assertIn('measured_contrast_missing',self.codes(self.check(p)))
    def test_task_selection_is_bound(self):
        p=self.packet();p['selected_task_ids']=['other']
        self.assertIn('task_not_selected',self.codes(self.check(p)))
    def test_baseline_receipt_update_is_not_a_new_mathematical_protocol(self):
        p=self.packet();p['previous_ref']=self.ref(p);p['baselines'][0]['status']='executed'
        self.assertFalse(self.check(p)['gaps'])
    def test_malformed_metadata_gives_scoped_gap_not_crash(self):
        p=self.packet();p['stage']={'not':'a stage'}
        self.assertIn('malformed_quality_record',self.codes(self.check(p)))
    def test_changed_evidence_is_rejected(self):
        p=self.packet();(self.root/self.evidence['path']).write_text('changed')
        self.assertIn('invalid_reference',self.codes(self.check(p)))

if __name__=='__main__':unittest.main()
