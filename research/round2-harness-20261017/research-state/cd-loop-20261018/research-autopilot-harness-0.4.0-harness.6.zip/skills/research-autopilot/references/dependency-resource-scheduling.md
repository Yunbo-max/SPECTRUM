# Dependency and resource scheduling for research workers

Use [single-experiment batching](single-experiment-batching.md): one active
experiment program, sequential descending batch calibration (for example
64 → 32 → 16 → 8 → 4 → 2), preserved scientific semantics and measured useful
throughput/headroom. Queue other experiments; keep Chat within CPU/4 GB.

Use with rolling-research-batches.md and multi-route-supervision.md when the human
wants independent work to overlap during a research window. These are engineering
planning/admission contracts. The [local execution harness](local-execution-harness.md)
implements a single-host executor; reading a skill neither connects a GPU nor
installs Orca. Preserve G01/E04 and the scientific gates.

Contents: [actual topology and Local orchestration](#step-1-actual-topology-and-local-orchestration),
[task admission](#task-dag-and-resource-admission), [single-GPU sharing](#single-gpu-sharing),
[cluster placement](#multiple-devices-and-cluster-placement),
[implementation boundary](#existing-implementation-boundary),
[window handoff](#eight-hour-window-handoff), [references](#optional-execution-backends-and-primary-references).

## Step 1: actual topology and Local orchestration

Before code/design, resolve the current sourced host/allocation under
[gpu-host-runtime.md](gpu-host-runtime.md). Distinguish one GPU, several GPUs on
one host, and a multi-host cluster; reuse current actual inventory/allocation
records and name unknown UUIDs, capacity and measurements. Web may deliver
hardware-bound or conditional `generated_unexecuted` code/design with those gaps
and the Local qualification plan. Local obtains live available-device,
CPU/RAM/storage/I/O and external-use evidence through the authorized SSH target
before affected native launches. Use per-host device UUIDs and allocated scope,
not a guessed total or device index. Record interconnect/topology when a proposed
distributed workload needs it; unmeasured throughput does not block truthful
unexecuted Web delivery.
The owner's existing one-GPU answer remains sourced for that host until changed;
it neither proves live telemetry nor becomes a default for new hosts.

Write the Local agent's orchestration plan before web-to-local handoff. It names
the coordinator/integrator, reusable subagent pool and file ownership; the actual
task DAG and CPU/GPU ready/blocked queues; per-task resource envelopes, device/host
placement and allocator ownership; permitted operational tuning ranges, finite
profiling budget and acceptance evidence; and dispatch, OOM/contention recovery,
collection and reporting rules. Use supported Local subagents for independent
reading/design/code work and the admitted native process pool for execution.
Agent availability does not reserve CPU or GPU capacity. Independent CPU preparation
may overlap the single experiment after dependency/resource checks; standalone
experimental scoring joins the serial experiment queue.
One allocator owns each device UUID; all cooperating workers targeting it use
the same actual host pool rather than competing drivers or independent memory checks.

Optimize qualified useful throughput within the approved priorities and budgets:
completed valid comparisons and critical-path progress per elapsed time, with
measured native stage throughput as a diagnostic. Aim to keep both CPU and GPU
doing eligible useful work while avoiding loader starvation, RAM/I/O oversubscription
and harmful contention. VRAM fullness, utilization percentage or running-job count
alone is not the objective. An empirical best feasible schedule/settings choice
is bounded by tested workloads; do not claim a global optimum or launch wasteful
jobs solely to fill capacity.

## Task DAG and resource admission

New/reopened discovery first constructs consequential mathematics and verifies
readiness-based selection before code design under method-verification.md.
Decompose the actually selected methods into concrete tasks:
reading/design, implementation, qualification, training/inference, native scoring,
E04 verification and export. Keep at most 20 active independent ideas per project/
navigation goal. Idea count, agent count and running GPU-job count are different.
Each admitted task has a bounded owner/spec; one worker can serve several tasks.

Build a task DAG from actual artifact/decision dependencies. The research map's
84 task types and 221 relationships are an exploration graph, not this execution
DAG: graph adjacency neither orders all work nor establishes readiness. Repeated
research loops can produce new versioned tasks; each execution DAG remains acyclic.
Share a qualified baseline/upstream artifact only when versions and the scientific
contract permit; pin it read-only and avoid duplicated qualification or training.

Admission requires all of the following:

1. The task is scientifically/operationally ready, authorized and not already
   running. All required inputs/decisions exist at the pinned revisions and pass
   their applicable acceptance checks; a worker's completion message alone does
   not certify an upstream scientific result.
2. Its actual host, dependencies, resource allocation and cumulative budget are
   valid. Reserve capacity atomically through one host-enforced allocator; several
   agents independently reading free memory and launching is not a reservation.
3. Its branch/workspace/output paths and mutable shared assets do not conflict
   with active writers; retain protocol/confirmation isolation and one integrator.
4. Its conservative peak resource envelope fits available CPU/RAM/storage/I/O,
   GPU memory/compute and agent/API limits, with recorded operating headroom.
   Unknown GPU peaks or exclusive/multi-GPU jobs wait for bounded native-workload
   profiling or exclusive allocation, not guessed sharing.

Independent reading/code/CPU preparation may start within admitted limits.
Experimental workloads remain serial under single-experiment-batching.md. A dependent task waits for its own inputs,
not for unrelated ideas to finish. Event-driven dispatch considers completions,
failures, blocked dependencies and actual resource changes. Fill spare capacity
with useful ready work that does not delay a higher-priority reserved task; keep
its stop/admission rules. No unapproved new idea or adaptive experiment is created
to fill a slot. If no eligible task fits, retain the queue and report the reason.

Prefer decision-driving, consequential questions and dependency-critical work;
use remaining time/resources to place independent tasks without starving deferred
work. Record the priority rationale, wait age and actual dependencies rather than
a universal numerical score. Do not serialize everything by idea number or force
all 20 ideas to become 20 continuously running agents.

### Separate agent and execution concurrency

Use a bounded reusable worker pool with one coordinator/integrator and distinct
agent/API-token limits. Independent readers, isolated code writers and CPU data preparation may
overlap the one experiment when their inputs/resources are ready. Standalone
experimental scoring enters the serial experiment queue. Locally hosted agent models also consume GPU
resources; API-hosted agents do not imply local model residency.
Budget data-loader subprocesses, library threads, CPU scoring and staging together
with the GPU task's CPU/RAM/I/O envelope. More workers/prefetch can lower useful
throughput when they contend; use the measured native tuning contract in
gpu-host-runtime.md rather than maximizing every queue's concurrency independently.

Every worker spec identifies target files/artifacts, exact task/change, invariants,
ownership, pinned inputs, prerequisites, resource/attempt/time bounds, expected
outputs and observable acceptance. Retain actual task, dispatch/attempt, route,
job, PID/provider identity and start/end evidence. Heartbeats/contact establish
liveness, not correctness. Completion is accepted against the active attempt and
actual outputs; stale messages cannot complete a newer attempt. Reconcile unknown
SSH/process status before retry or resource release. An accepted completed worker
may be reused/released under its real host contract; no duplicate job on timeout.

### Single-GPU sharing

Same-card experiment sharing is disabled by single-experiment-batching.md. Read
actual allocation, external usage and peak memory on the execution target, keep
headroom, and run one experimental program. Fill useful capacity through supported
descending batch calibration and bounded loader tuning in that program. Preserve
actual failures, semantic invariants and the frozen confirmation policy. A generic
backend's sharing capability does not authorize concurrent project experiments.

### Multiple devices and cluster placement

On a verified multi-GPU host or cluster, keep one active experimental program
across the project. Multiple devices may serve that single program through a
supported, qualified distributed launch when allocation and measured capacity or
speed justify it. Retain rank/device/input-sharding rules, interconnect evidence,
effective-batch/optimizer/RNG semantics and collection/recovery ownership. Queue
independent baselines, seeds and method trials even when extra devices are idle.

`run_harness.py` is single-host. Its plan can admit several verified devices on
that host, including an exclusive multi-GPU native task, but it has no multi-host
placement, gang admission or distributed recovery controller. A cluster requires
one coordinated controller/pool per host plus real external top-level admission
that reserves every participating host/device before launch and reconciles failures
without duplicates. Existing configured Slurm or a reviewed implementation can
supply that layer; SSH, a shared JSON file or multiple independent harness drivers
cannot. Preserve scheduler-assigned device scope. Do not invent cluster support,
new CLI flags or install/configure an optional backend merely by reading this skill.

### Existing implementation boundary

The native runner is serial within each plan. `scripts/run_harness.py`
can coordinate independent native plans concurrently with actual host admission;
this edition restricts experimental use to one at a time with the settings in
single-experiment-batching.md. The backend retains
state and soft progress reports; use local-execution-harness.md for its
frozen-plan, watchdog, recovery and qualification boundaries. The local supervisor registry reserves whole
GPU counts and does not support fractional GPU or VRAM subleases; do not change a
declared count, reuse another route's token or bypass conflicts to pretend otherwise.
One actual execution-owner route can hold the whole GPU and an implemented host
allocator can manage its internal jobs under that ownership; other coding/read
routes submit requests and do not independently launch against that lease.
Report subjob scheduling as host-managed metadata, not a capability of the existing
registry schema. Keep experiments serial even when an adapter supports multiple
jobs; independent reading/code/CPU preparation may overlap within actual limits. Do not auto-install an execution framework.
The harness checks frozen workload/profile identities and performs admission; it
does not generate tuning probes, discover workload batch-size flags, adjust native
batch/loader settings or optimize a cluster. Local operational tuning uses reviewed
framework-supported native commands/adapters, admitted as bounded development
tasks, before freezing the chosen settings and profiles for scientific execution.

## Eight-hour window handoff

At each soft reporting boundary, persist the actual task DAG, completed outputs,
running jobs, ready/blocked queue, peak estimates, reservations and cumulative
time/spend. Carry eligible unfinished approved work into the next window with
stable idea/task/run/protocol identity; a window does not reset attempts or require
relaunching a live process. Frozen hard limits and lease expiry still apply.
Report useful completed comparisons separately from partial runs. Scientific
convergence, expansion and new validation/writing branches use human review;
runtime placement among already approved tasks needs no new scientific direction.
Approved Local execution may continue for up to 24 elapsed hours per cycle on
the actual persistent host and remaining resources. Do not copy report cadence
into native job/attempt or outer total limits; do not use stop-after-report for
ordinary continuous dispatch. Resolve old frozen limits without changing live jobs.

## Optional execution backends and primary references

Checked 2026-10-04. Orca is an ambiguous project name; these findings concern
[Stably Orca](https://github.com/stablyai/orca), not every project called ORCA.
No optional dependency is installed or connected by this update.

- [Orca orchestration](https://www.onorca.dev/docs/cli/orchestration) and its
  [actual guide](https://github.com/stablyai/orca/blob/main/skill-guides/orchestration.md)
  describe Run/task/dispatch identities, dependencies, isolated worker ownership,
  completion/heartbeat messages and decision gates. A Run does not schedule/place
  workers. Use its installed version-matched guide for real commands; do not copy
  retired scheduler commands or equate its engineering gates with scientific PASS.
- [Ray accelerator scheduling](https://docs.ray.io/en/latest/ray-core/scheduling/accelerators.html)
  supports fractional GPU resource declarations; applications remain responsible
  for staying within accelerator memory. This is an optional execution backend,
  not evidence that this skill currently schedules GPUs.
- [Ray fractional LLM serving](https://docs.ray.io/en/latest/serve/llm/user-guides/fractional-gpu.html)
  documents workload-specific memory preallocation and headroom. Its vLLM settings
  apply to that serving stack, not an automatic recipe for arbitrary training.

For a single GPU host, choose the smallest implemented admission/dispatch layer
that meets these contracts; an agent manager can manage workers while a separate
allocator manages GPU jobs. Recheck actual backend/version/capabilities before
implementation or deployment and retain real process/readback evidence.

Native topology/placement interfaces checked 2026-10-08:
[NVIDIA SMI device UUIDs and topology](https://docs.nvidia.com/deploy/nvidia-smi/index.html),
[PyTorch DDP rank/device and input-sharding responsibilities](https://docs.pytorch.org/docs/stable/generated/torch.nn.parallel.DistributedDataParallel.html),
and [Slurm configured GRES admission and device binding](https://slurm.schedmd.com/gres.html).
These interfaces support a reviewed adapter; they do not add one to the harness.
