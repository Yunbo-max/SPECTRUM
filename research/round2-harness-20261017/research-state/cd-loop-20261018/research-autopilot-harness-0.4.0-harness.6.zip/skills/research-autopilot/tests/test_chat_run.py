"""Finite real CPU subprocesses, not research experiments or scientific evidence."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from fixtures import C, write
import chat_run as R


class ChatRunTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.procedure = write(self.root, "procedure.json", {"version": "engineering-fixture"})

    def plan(self, code="from pathlib import Path; Path('result.txt').write_text('new')", **updates):
        value = dict(attempt_id="attempt-one", procedure_ref=self.procedure,
                     input_refs=[], code_refs=[], command=[sys.executable, "-c", code],
                     cwd=".", output_paths=["result.txt"], timeout_seconds=2,
                     max_log_bytes=4096, numeric_status_path=None)
        value.update(updates)
        return value

    def execute(self, plan):
        prepared = R.prepare(self.root, plan)
        result = R.execute(self.root, prepared["execution_id"], prepared["plan_digest"], authorizer=lambda scope: True)
        return prepared, result

    def wait_path(self, path, seconds=5):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if path.exists(): return
            time.sleep(.02)
        self.fail("missing bounded fixture signal: " + str(path))

    def test_resource_wait_reuses_execution_and_automatically_checks_again(self):
        import resource_queue as Q
        resources = dict(queue_dir=str(self.root / "queue"), cpu_slots=1,
                         peak_bytes=100, margin_bytes=20, min_disk_bytes=10)
        capacity = dict(domain="fixture", cpu_slots=1, memory_total=1000, memory_available=0,
                        disk_available=1000, disk_total=1000, disk_domain=1)
        prepared = R.prepare(self.root, self.plan(resources=resources))
        # Drive the wait clock independently of filesystem and host scheduling
        # speed; keep the real queue persistence and eventual CPU subprocess.
        elapsed = [0.0]
        def advance(seconds): elapsed[0] += seconds
        clock = SimpleNamespace(time=lambda: 1000000000+elapsed[0],
                                monotonic=lambda: elapsed[0], sleep=advance)
        with patch.object(Q, "snapshot", side_effect=lambda root: {**capacity, "observed_at": Q.time.time()}), patch.object(Q, "RECHECK_SECONDS", .01):
            with patch.object(R,"time",clock), patch.object(Q,"time",clock):
                waiting = R.execute(self.root, prepared["execution_id"], prepared["plan_digest"],
                                    authorizer=lambda scope: True, resource_wait_seconds=.03)
            self.assertEqual(waiting["status"], "waiting_resources")
            self.assertGreaterEqual(waiting["resource_wait"]["checks"], 2)
            self.assertFalse((self.root / R.BASE / prepared["execution_id"] / "commit.json").exists())
            capacity["memory_available"] = 1000
            result = R.execute(self.root, prepared["execution_id"], prepared["plan_digest"],
                               authorizer=lambda scope: True, resource_wait_seconds=.1)
        self.assertEqual(result["status"], "completed")
        self.assertEqual(result["execution_id"], prepared["execution_id"])
        queue = json.loads((self.root / "queue/queue.json").read_text())
        self.assertEqual(len(queue["tickets"]), 1)
        self.assertEqual(next(iter(queue["tickets"].values()))["status"], "settled")

    def test_success_bound_to_attempt_inputs_procedure_and_fresh_workspace(self):
        source = write(self.root, "input.json", {"value": 3})
        prepared, result = self.execute(self.plan(input_refs=[source]))
        self.assertEqual(result["status"], "completed")
        self.assertEqual(result["attempt_id"], "attempt-one")
        self.assertEqual(result["procedure_ref"], self.procedure)
        self.assertEqual(result["input_refs"], [source])
        self.assertFalse(result["scientific_accepted"])
        self.assertFalse(result["gate_advanced"])
        self.assertGreater(result["cpu_seconds"], 0)
        self.assertLess(result["wall_seconds"], 2)
        self.assertEqual(result, R.read_receipt(self.root, prepared["execution_id"]))
        self.assertIn(prepared["execution_id"], result["output_refs"][0]["path"])

    def test_configuration_failure_has_real_small_cost_and_error_without_command(self):
        prepared, result = self.execute(self.plan(command="not argv"))
        self.assertEqual(result["status"], "configuration_failed")
        self.assertEqual(result["cpu_seconds"], 0)
        self.assertEqual(result["model_charge"], 0)
        self.assertLess(result["wall_seconds"], .5)
        self.assertIn("ARGV", (self.root / result["stderr_ref"]["path"]).read_text())
        self.assertFalse((self.root / R.BASE / prepared["execution_id"] / "workspace").exists())

    def test_startup_failure_keeps_actual_exception(self):
        _, result = self.execute(self.plan(command=["/no/such/engineering-fixture-command"]))
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["reason"], "command_startup_failed")
        self.assertEqual(result["cpu_seconds"], 0)
        self.assertIn("FileNotFoundError", (self.root / result["stderr_ref"]["path"]).read_text())

    def test_stale_project_output_cannot_satisfy_new_attempt(self):
        (self.root / "result.txt").write_text("old")
        _, result = self.execute(self.plan(code="pass"))
        self.assertEqual(result["status"], "failed")
        self.assertIn("OUTPUT_MISSING", result["reason"])
        self.assertEqual(result["output_refs"], [])
        self.assertEqual((self.root / "result.txt").read_text(), "old")

    def test_staged_input_output_collision_and_noncanonical_paths_rejected(self):
        source = write(self.root, "result.txt", {"old": True})
        for changes in ({"input_refs": [source]}, {"output_paths": ["x", "x"]},
                        {"output_paths": ["x", "x/y"]}, {"output_paths": ["x/../result.txt"]},
                        {"output_paths": ["./result.txt"]}, {"input_refs": [source, source]}):
            with self.subTest(changes=changes):
                _, result = self.execute(self.plan(**changes))
                self.assertEqual(result["status"], "configuration_failed")

    def test_duplicate_and_changed_intent_never_launch_again(self):
        prepared, result = self.execute(self.plan())
        with self.assertRaisesRegex(ValueError, "ALREADY_DISPATCHED"):
            R.execute(self.root, prepared["execution_id"], prepared["plan_digest"], authorizer=lambda scope: True)
        with self.assertRaises(FileExistsError):
            R.prepare(self.root, self.plan(), execution_id=prepared["execution_id"])
        other = R.prepare(self.root, self.plan())
        with self.assertRaisesRegex(ValueError, "PLAN_CHANGED"):
            R.execute(self.root, other["execution_id"], "0" * 64, authorizer=lambda scope: True)
        self.assertNotEqual(other["execution_id"], prepared["execution_id"])

    def test_input_changed_before_dispatch_rejected_without_cost_reservation(self):
        source = write(self.root, "data.json", {"before": True})
        prepared = R.prepare(self.root, self.plan(input_refs=[source]))
        (self.root / "data.json").write_text("changed")
        result = R.execute(self.root, prepared["execution_id"], prepared["plan_digest"], authorizer=lambda scope: True)
        self.assertEqual(result["status"], "configuration_failed")
        self.assertEqual(result["cpu_seconds"], 0)

    def test_actual_argv_does_not_interpret_shell_syntax(self):
        code = "import pathlib,sys; pathlib.Path('result.txt').write_text(sys.argv[1])"
        _, result = self.execute(self.plan(command=[sys.executable, "-c", code, "$(touch injected); literal"]))
        self.assertEqual((self.root / result["output_refs"][0]["path"]).read_text(), "$(touch injected); literal")

    def test_timeout_kills_child_group_and_preserves_partial_output(self):
        code = ("import subprocess,sys,time,pathlib\n"
                "p=subprocess.Popen([sys.executable,'-c','import time; time.sleep(20)'])\n"
                "pathlib.Path('result.txt').write_text(str(p.pid))\n"
                "time.sleep(20)\n")
        # This test needs the child to reach its output write before termination.
        # The previous .25s assumption failed on both old and new packages on the
        # measured host. Test pre-output timeout separately; scientific budgets
        # and executor timeout behavior are unchanged.
        _, result = self.execute(self.plan(code=code, timeout_seconds=3))
        self.assertEqual(result["status"], "timeout")
        self.assertFalse(result["cleanup"]["foreground_group_alive"])
        self.assertEqual(result["cleanup"]["observed_surviving_descendants"], [])
        child_pid = int((self.root / result["output_refs"][0]["path"]).read_text())
        self.assertIsNone(R.H._identity(child_pid))
        self.assertLess(result["wall_seconds"], 6)

    def test_timeout_before_output_is_not_fabricated_as_partial_result(self):
        _, result = self.execute(self.plan(code="import time;time.sleep(20)", timeout_seconds=.05))
        self.assertEqual(result["status"], "timeout")
        self.assertEqual(result["output_refs"], [])
        self.assertFalse(result["scientific_accepted"])
        self.assertFalse(result["cleanup"]["foreground_group_alive"])

    def test_exit_zero_numeric_invalid_and_partial_have_distinct_statuses(self):
        for state, expected in [("invalid", "numeric_invalid"), ("partial", "partial"), ("valid", "completed")]:
            code = "from pathlib import Path; Path('status.json').write_text(%r)" % json.dumps({"status": state})
            _, result = self.execute(self.plan(code=code, output_paths=["status.json"], numeric_status_path="status.json"))
            self.assertEqual(result["exit_code"], 0)
            self.assertEqual(result["status"], expected)
            self.assertFalse(result["scientific_accepted"])

    def test_nonzero_exit_keeps_output_without_success_and_numeric_nan_rejected(self):
        _, result = self.execute(self.plan(code="from pathlib import Path; Path('result.txt').write_text('partial'); raise SystemExit(7)"))
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["exit_code"], 7)
        self.assertEqual(len(result["output_refs"]), 1)
        _, result = self.execute(self.plan(code="from pathlib import Path; Path('status.json').write_text('{\"status\":\"valid\",\"metric\":NaN}')",
                                          output_paths=["status.json"], numeric_status_path="status.json"))
        self.assertEqual(result["status"], "failed")

    def test_logs_are_bounded_drained_and_terminal_bytes_are_immutable(self):
        code = "import os,pathlib; os.write(1,b'x'*100000); os.write(2,b'e'*100000); pathlib.Path('result.txt').write_text('ok')"
        prepared, result = self.execute(self.plan(code=code, max_log_bytes=101))
        self.assertEqual(result["status"], "completed")
        for name in ("stdout", "stderr"):
            self.assertEqual(result["logs"][name]["observed_bytes"], 100000)
            self.assertEqual(result["logs"][name]["retained_bytes"], 101)
            self.assertTrue(result["logs"][name]["truncated"])
        (self.root / result["stdout_ref"]["path"]).write_text("changed")
        with self.assertRaises(C.Failure): R.read_receipt(self.root, prepared["execution_id"])

    def test_no_live_log_or_uncertain_launch_is_exposed_as_terminal(self):
        prepared = R.prepare(self.root, self.plan())
        directory = self.root / R.BASE / prepared["execution_id"]
        with self.assertRaisesRegex(ValueError, "NOT_TERMINAL"):
            R.read_receipt(self.root, prepared["execution_id"])
        state = C.load_file(directory / "state.json"); state["status"] = "launching"
        R._save(directory / "state.json", state)
        observation = R.reconcile(self.root, prepared["execution_id"])
        self.assertEqual(observation["status"], "reconcile_required")
        self.assertIsNone(observation["cpu_seconds"])
        with self.assertRaisesRegex(ValueError, "ALREADY_DISPATCHED"):
            R.execute(self.root, prepared["execution_id"], prepared["plan_digest"], authorizer=lambda scope: True)

    def test_mutating_pinned_input_cannot_produce_a_valid_completion(self):
        source = write(self.root, "input.json", {"original": True})
        code = "from pathlib import Path; Path('input.json').write_text('changed'); Path('result.txt').write_text('output')"
        _, result = self.execute(self.plan(code=code, input_refs=[source]))
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["output_refs"], [])
        self.assertEqual(C.load_file(self.root / "input.json"), {"original": True})

    def test_symlink_or_hardlink_old_file_is_not_owned_output(self):
        source = write(self.root, "input.json", {"old": True})
        for operation in ["symlink_to", "hardlink_to"]:
            code = "from pathlib import Path; Path('result.txt').%s('input.json')" % operation
            _, result = self.execute(self.plan(code=code, input_refs=[source]))
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["output_refs"], [])

    def test_output_byte_cap_and_malformed_numeric_status(self):
        _, result = self.execute(self.plan(code="from pathlib import Path; Path('result.txt').write_bytes(b'x'*20)", max_output_bytes=10))
        self.assertEqual(result["status"], "failed")
        self.assertIn("OUTPUT_BYTE_LIMIT", result["reason"])
        _, result = self.execute(self.plan(code="from pathlib import Path; Path('status.json').write_text('[]')",
                                          output_paths=["status.json"], numeric_status_path="status.json"))
        self.assertEqual(result["status"], "failed")
        self.assertIn("NUMERIC_STATUS_INVALID", result["reason"])

    def test_postlaunch_state_write_error_cannot_commit_while_command_is_alive(self):
        plan = self.plan(code="import time; time.sleep(10)", timeout_seconds=.5)
        prepared = R.prepare(self.root, plan)
        directory = self.root / R.BASE / prepared["execution_id"]
        command, cwd, _ = R.R._stage(self.root, plan, directory)
        state = C.load_file(directory / "state.json")
        state.update(status="launching", command=command, cwd=str(cwd), owner=R.H._self_identity())
        R._save(directory / "state.json", state)
        original_save = R._save; launched_identity = []
        def fail_running_save(path, value, **kwargs):
            if path.name == "state.json" and value.get("status") == "running":
                launched_identity.append(value.get("command_process"))
                raise OSError("injected state persistence failure after Popen")
            return original_save(path, value, **kwargs)
        previous = {s: signal.getsignal(s) for s in (signal.SIGTERM, signal.SIGINT)}
        libc = R.ctypes.CDLL(None, use_errno=True); old_subreaper = R.ctypes.c_int()
        self.assertEqual(libc.prctl(37, R.ctypes.byref(old_subreaper), 0, 0, 0), 0)
        try:
            with patch.object(R, "_save", side_effect=fail_running_save):
                R._worker(self.root, prepared["execution_id"])
            self.assertTrue(launched_identity)
            self.assertFalse(R.H._alive(launched_identity[0]))
            self.assertFalse((directory / "commit.json").exists())
            self.assertEqual(R.reconcile(self.root, prepared["execution_id"])["status"], "reconcile_required")
            self.assertIn("injected state persistence failure", (directory / "stderr.log").read_text())
            self.assertEqual(C.load_file(directory / "state.json")["reason"], "collector_failed_after_dispatch")
            with self.assertRaisesRegex(ValueError, "NOT_TERMINAL"):
                R.read_receipt(self.root, prepared["execution_id"])
        finally:
            for signum, handler in previous.items(): signal.signal(signum, handler)
            libc.prctl(36, old_subreaper.value, 0, 0, 0)
            for identity in launched_identity:
                local_pid = R._local_pid(identity)
                if local_pid:
                    try: os.kill(local_pid, signal.SIGKILL)
                    except ProcessLookupError: pass

    def test_parent_sigkill_watchdog_cleans_children_and_publishes_interrupted_receipt(self):
        plan = self.plan(code="import pathlib,time; pathlib.Path('result.txt').write_text('started'); time.sleep(20)", timeout_seconds=4)
        prepared = R.prepare(self.root, plan)
        directory = self.root / R.BASE / prepared["execution_id"]
        driver = subprocess.Popen([sys.executable, str(Path(R.__file__)), "execute", str(self.root),
                                   prepared["execution_id"], "--expected-digest", prepared["plan_digest"], "--execute"],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            self.wait_path(directory / "workspace/result.txt")
            state = C.load_file(directory / "state.json")
            driver.kill(); driver.wait(timeout=2)
            self.wait_path(directory / "commit.json")
            result = R.read_receipt(self.root, prepared["execution_id"])
            self.assertEqual(result["status"], "interrupted")
            self.assertFalse(R.H._alive(state["command_process"]))
            self.assertFalse(result["cleanup"]["foreground_group_alive"])
        finally:
            if driver.poll() is None: driver.kill(); driver.wait(timeout=2)

    def test_escaped_descendant_remains_unknown_and_cannot_release_resources(self):
        # An invalid daemonizing command violates the foreground contract. Detect
        # surviving descendants, keep the run uncommitted, and clean fixture only.
        code = ("import subprocess,sys,pathlib\n"
                "p=subprocess.Popen([sys.executable,'-c',\"import pathlib,time; pathlib.Path('child-ready.txt').write_text(pathlib.Path('/proc/self/stat').read_text().split()[0]); time.sleep(6)\"],start_new_session=True,"
                "stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)\n"
                "pathlib.Path('result.txt').write_text(str(p.pid))\n")
        prepared, result = self.execute(self.plan(code=code))
        directory = self.root / R.BASE / prepared["execution_id"]
        self.wait_path(directory / "workspace/child-ready.txt")
        child_pid = int((directory / "workspace/child-ready.txt").read_text())
        try:
            self.assertEqual(result["status"], "reconcile_required")
            self.assertFalse((directory / "commit.json").exists())
            self.assertIsNotNone(R.H._identity(child_pid))
        finally:
            try:
                local_pid = R._local_pid(R.H._identity(child_pid))
                if local_pid: os.kill(local_pid, signal.SIGKILL)
            except ProcessLookupError: pass


if __name__ == "__main__": unittest.main()
