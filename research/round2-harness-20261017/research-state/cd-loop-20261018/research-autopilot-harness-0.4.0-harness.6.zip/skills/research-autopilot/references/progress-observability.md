# Private research progress observations

Use this module at project start/resume and when recording a meaningful milestone,
blocker, handoff or pause. It applies to `main`, `autonomous-rsi`, `chat` and
`autonomous-rsi-chat`. It adds an operational view of existing project records;
it creates no scientific gate, approval requirement or research state transition.
Preserve the selected edition's Web host, Local SSH/Conda execution, step-7
decision owner, finite budgets and scientific prerequisites. Web scientific code
and plans remain `generated_unexecuted` until their existing Local checks run.

## Record observable work in the existing project

1. On start/resume restore the actual project, revision, task identities and
   checkpoint. Reuse the same project/task IDs; do not initialize a second project
   or mark an already completed task running. Record the project title, selected
   edition, task title, a concrete task description, visible stage, observed
   status, owner and next action. Unknown host/task identities stay unknown.
2. Update after a meaningful stage/status change, a new or resolved blocker,
   repair or outcome, owner/handoff change, and before yielding or ending a turn.
   Retain completed work and failure history. A continuing task can stay running
   at a yield only when the actual host supports continuation and current evidence
   supports that observation; otherwise record waiting, paused or unknown.
3. For a blocker state its cause, who can act, and the next concrete action.
   Distinguish missing evidence/access, dependency/resource waiting, required
   human decisions and lost dispatch acknowledgment. `reconcile_required` keeps
   its original run identity; it never authorizes a duplicate launch.
4. Keep canonical ledger, decision notes and route checkpoints under their
   existing contracts. A progress note links their evidence; it neither replaces
   them nor establishes a scientific PASS. `complete` describes the stated task's
   observed scope, not acceptance of its method, claims or whole project.
5. Read-only controller export observes existing Local tasks automatically.
   Record Web source reading, mathematics, design, writing and visible human
   decisions explicitly. These are short phase descriptions and evidence
   locators, never claims of access to hidden model reasoning.

Use the installed `scripts/research_progress.py`. `record` writes a local progress
journal at `.research-autopilot/progress/events.jsonl` in the specified project;
`export` reads project journals and/or controller SQLite databases without changing
controller state. Values below are command shapes: resolve the actual private
project and installed script paths first. Repeated observations refresh the
last-observed timestamp; a stage/status transition starts a new observed interval.
Before publication, inspect the actual research project's ignore policy for
`.research-autopilot/progress/` and the chosen private snapshot path. From that
project, this read-only check explains matching ignore rules:

```bash
git check-ignore --no-index -v -- .research-autopilot/progress/events.jsonl
```

Check tracked files separately: an ignore rule does not remove an already tracked
copy. If an ignore rule is missing, warn and keep output private while following
the authorized project workflow; do not make recording a scientific gate. The
observer does not edit Git policy, push changes or upload private progress.

```bash
python3 "$SKILL_DIR/scripts/research_progress.py" record \
  --project "$PROJECT_DIR" --project-id "$PROJECT_ID" \
  --edition main --title "$PROJECT_TITLE" \
  --task-id "$TASK_ID" --task-title "$TASK_TITLE" \
  --description 'Review selected candidate assumptions against the primary paper' \
  --stage 3 --status running --owner Web \
  --next-action 'Save the reviewed mathematical card and remaining evidence gaps'
```

Choose the actual edition. `--owner` names the observed owner, such as Web or
Local. `--blocker`, `--summary`, repeated `--dependency` and repeated `--evidence`
can add a concise cause, milestone, task dependencies and safe evidence locators.
The display statuses are `pending`, `running`, `waiting`, `blocked`, `paused`,
`complete`, `failed`, `cancelled`, `reconcile_required` and `unknown`. They do not
extend the controller's task-state enum or grant execution authority.

## Stages are labels, not a required execution chain

| Stage | Visible work |
|---|---|
| 1 | Intake, restore project scope, resources and existing authority |
| 2 | Primary papers, actual implementations and benchmark sources |
| 3 | Mathematical discovery, derivation, review and selection |
| 4 | Complete selected-method code and evaluation design |
| 5 | Authorized Local preparation, native execution and bounded repair |
| 6 | Result verification, E04 and applicable validation evidence |
| 7 | Existing decision about continuation, direction or stopping |
| 8 | Eligible writing, figures, delivery and release |

A task may revisit a stage, overlap an independent task or finish with negative
evidence. Preserve those observations rather than forcing a monotonically rising
stage. Stage 7 remains human-led in `main`/`chat`; the configured machine decision
in `autonomous-rsi`/`autonomous-rsi-chat` remains bounded by its existing initial
authority, verifier and budgets. The observer does not configure that loop.

## Private export and browser-local display

```bash
python3 "$SKILL_DIR/scripts/research_progress.py" export \
  --project "$PROJECT_DIR" --controller-db "$CONTROLLER_DB" \
  --output "$PRIVATE_EXPORT" --timezone Europe/London --freshness-seconds 300
```

`--project` and `--controller-db` are repeatable; omit an unavailable input rather
than inventing a database. Put the output at an actual absolute private `.json`
path, such as `$PROJECT_DIR/.research-autopilot/progress/snapshot.json`.
Open [the progress page](https://yunbo-max.github.io/research-progress/) and use
its file importer to select the JSON. The page is public application code; project
JSON stays in that browser's local processing. Do not commit or upload it to the
public page repository, GitHub Pages, Hugging Face or another hosted destination.
Review any explicitly requested public sample separately; do not seed a public
deployment with live private research data.

For an already authorized finite local observation window, `watch` repeats the
same read-only export with required `--cycles N` and optional `--interval 60`.
It refreshes the local output; it is not a research executor, task launcher or
unbounded daemon. The page also offers **Watch local file** in browsers with
`showOpenFilePicker`: the user explicitly selects the JSON and grants read access;
the open page rereads it every 30 seconds. Permission denial or a read error stops
watching, and clearing the page releases the file handle. Closing the page stops
refreshing; it does not continue research or upload the file. When that browser
capability is unavailable, or for a one-shot import, reimport the updated snapshot
manually. A changed JSON file does not prove the browser read it.

## Interpret counts and durations honestly

- Show currently fresh running observations separately from stale running,
  waiting, blocked and unknown tasks. Export time and last observation time are
  different facts: rereading an old record does not refresh its liveness.
- Stage/task elapsed time describes observed timestamp intervals. Identify the
  interval coverage and freshness bound; gaps and offline activity are unknown.
  Open intervals are clipped to their freshness expiry or snapshot time. An
  expired controller run lease retains its run identity and needs reconciliation.
  It is not hidden thinking time, GPU-active time, billed usage or verified effort.
- Keep waiting cause and owner visible. Long waiting or blocked intervals can
  indicate a bottleneck; duration alone does not establish its root cause.
- Parallel task durations may overlap. Do not sum them and call that project wall
  time. Preserve actual native receipts for execution duration and provider usage.
- Daily grouping uses the chosen IANA timezone; `Europe/London` follows its daylight
  saving transitions. Report the date/timezone and snapshot freshness. An empty
  date means no captured observations, not proof that no work happened.
- Do not infer a percentage of research completed from stage numbers, counts or
  elapsed time. The existing evidence and decision contracts define readiness.

## Coverage, privacy and failure handling

A skill cannot guarantee capture of all host operations or all sessions. Report
which project journals/databases were actually read and any missing coverage.
If the current Web surface lacks authorized file/execution capability, provide
the concrete event or snapshot for authorized Local recording and say it remains
unrecorded there. Do not fabricate saved files, task activation, live feeds or
past timestamps. Native session capture remains a separate host feature under
[local-installation-and-logging.md](local-installation-and-logging.md).

Keep journals, exports, controller databases, transcript records and raw receipts
in the project's private destination and applicable Git ignore policy. Store
minimal descriptions and safe locators. Exclude credentials, tokens, signed URLs,
raw personal data and whole conversations from progress JSON; the export is not
an archive of transcripts or private reasoning. Ignore rules do not make a file
private or remove an already tracked copy.

Recorder/exporter failures produce a concise warning and an observation gap.
Continue otherwise authorized research under its existing gates; an observer
failure never creates an approval question or stalls an independent scientific
task. Claim saved/exported progress only after the actual operation succeeds.
