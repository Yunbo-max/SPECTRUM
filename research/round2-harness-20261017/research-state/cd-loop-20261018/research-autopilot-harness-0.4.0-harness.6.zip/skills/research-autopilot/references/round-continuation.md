# Automatic research rounds and host continuation

## Work Harness C/D profile

Restore `sequence.flow_profile` before applying inherited workflow rules. For
`work-harness-cd-v1`, read [C/D mathematical diagnosis and executable idea development](cd-math-code-loop.md).
The versioned catalog `assets/skill-sequence-cd-v1.json` and its overriding node
guides govern C's condition/failure/dependency diagnosis, D's mechanism construction
and real local experiments, reviewed B/C/D revisits and M05 `VERIFIED_FOR_SCALEUP`.
B05 validates a supported problem contract; old Natural Gate 0/IPCG prerequisites
do not apply to this profile's local diagnostic/development work. Independent
verified review plus program checks advances automatically into E, which retains
full settings, freezing, fair comparisons, scale and confirmation.

The worker proposes typed revisits and code applies approved transitions; no raw
skip/jump is allowed. Preserve source/evidence lineage, failed findings, external
jobs, cumulative usage and pause state. Omitted `flow_profile` retains legacy
catalog/transition behavior. Profile-specific rules override conflicting inherited
C/D ordering/admission text below only when the profile is actually adopted.
Installation alone does not migrate a running project or change another edition.

Read this at research startup, after consuming a result, and before yielding.
It is the current continuation policy for Auto Work, Work Harness, Auto Chat and Simple.
Human–AI uses the same execution/recovery loop inside the human-selected plan;
its scientific direction choices remain with the human under edition-policy.md.
This policy replaces older defaults that finish each round, await a new user
message, or treat an empty queue, status report or single candidate KILL as a
project stop. It does not override an explicit pause or a sourced project limit.

For this fifth Work Harness edition, use [research-harness.md](research-harness.md)
and the installed research-program runtime for full obligations, actual decision
and review invocations, result archiving and durable pause. Its source/skill ZIP
does not itself activate a consumer. Preserve existing source pins and use a real
host mechanism for process recovery; a 24-hour attempt boundary is not goal completion.

## Continue the program-assigned step

In this Work Harness/DSH Harness source, [skill-sequence.md](skill-sequence.md)
governs step navigation. Other editions retain their own decision ownership.

1. Restore the sourced goal, immutable policy, 84-node catalog hash, current
   cycle/node/attempt, accepted evidence, child tasks and remaining allowances.
   Reconcile active or unknown operations by existing identities.
2. Read the current node's required modules and actual results. Apply
   [research-cycle.md](research-cycle.md) within that step: relevant papers/code,
   reproduction, concrete limitations, mathematical tools, suitable benchmarks,
   strong alternatives, actual results and knowledge updates. Distinguish invalid
   measurement/code from valid negative evidence and preserve both.
3. Perform only the assigned node and admitted supporting child work. The legacy
   planner role cannot select the next node. A report or child process exit does
   not advance the cursor. Inspect actual outputs and submit fixed requirement
   findings with their real references for a separately executed review.
4. Rejection, missing evidence and result readback remain on the same node. Only
   program code accepts and advances to the next canonical active node. Optional
   nodes are inactive only through code-determined scope applicability.
5. After the accepted ordered pass and current frozen empirical matrix/native
   verification, code repeats in `repeat` mode while preserving unresolved
   knowledge and negative findings. `once` additionally requires complete goal
   coverage. Neither mode lets a worker emit a navigation or completion decision.

Do not ask for a routine manual wakeup when the authorized sequence consumer is
already alive. A genuine pause, exhausted limit or unavailable capability remains
explicit; no wording in this document creates a live host process by itself.

## Distinguish the control agent from remote jobs

The local agent supervises, while an SSH GPU server may own running workloads.
Restore remote host/job/source identities and query those jobs on resume; a lost
SSH connection does not prove completion or justify a duplicate launch. A live
remote training process does not by itself invoke the local decision agent again.
Keep both continuation states and budgets explicit under local-execution.md.

## Arrange continuation before a host boundary

Apply the GitHub storage policy in edition-policy.md: GitHub only persists source
and evidence through direct pull/push. Use a supported host task or runner for
continuation; do not use GitHub Actions, workflow runs or CI APIs as a scheduler.

A research round and a host conversation turn are different boundaries. Use the
active host until a real limit, blocked dependency, explicit stop or completion.
For a goal that spans host turns, configuring supported automatic continuation
is part of starting that authorized autonomous goal. Do it early, while tools
are available; do not defer it until the last context window.

- Discover the actual host's task, scheduler or runner capabilities. Reuse the
  existing goal-bound task first. If it provides persistent decision-making and
  result callbacks, verify those identities and keep it running.
- Otherwise, when an authorized scheduler/automation tool can invoke an agent
  with this edition and the durable project checkpoint, create or update one
  goal-bound continuation task using that tool's supported schema. Use a supported
  cadence suited to the workload and current service limits, or a real completion
  callback. Do not prescribe a fictional universal frequency or a paid service.
  List/reconcile matching tasks before creation; a lost response requires readback,
  not another create. A reminder that only notifies the user is insufficient.
- The continuation prompt must tell the invoked agent to load the selected edition,
  read the latest canonical checkpoint, honor pause/stop and remaining budgets,
  reconcile existing jobs/owners, restore the program cursor, execute the assigned
  node, read back results and persist receipts. Program code advances only after
  acceptance and controls repetition. It must not merely summarize or
  ask the user to wake the project. Bind the project ID, durable locator, adopted
  procedure and scope; never embed credentials or a stale full checkpoint.
- Save the returned provider/task ID, goal binding, enabled state, actual executor,
  last observation, next trigger or live-service state, and readback receipt in the
  existing project control record. Distinguish configured, observed active,
  successfully invoked, unavailable and unknown. A local status flag is not proof
  that a remote scheduler or decision agent is alive.
- For an existing Simple runner, read its actual installed/pinned simple-runner.md
  interface (not a guessed file in another edition), then use its checked supervisor and configured bounded
  decision-agent command, or a real host continuation task that consumes its inbox.
  A process runner without a decision consumer only completes the queued commands;
  it cannot autonomously invent the next research round. Preserve runner IDs,
  cumulative budgets and history. Idle polling must not call a model.
- For an optional full runtime, use its existing supervisor, trusted decision and
  verification hooks and finite delegation. Do not launch a second competing
  controller. Work and Simple remain on the local agent; main uses a
  human-mediated Web GPT/local handoff; Chat remains in its CPU/4 GB host profile.
  A trigger alone establishes neither an executor nor a live decision consumer.

Before yielding with unfinished work, persist the checkpoint and read back the
continuation binding. An already supported active task/callback can handle the
next event; do not create a redundant timer for every round. On each invocation,
obtain existing coordinator ownership/fencing before mutation. A duplicate tick
observes or exits; it does not submit duplicate jobs. Use the existing project's
coordination/runtime mechanism, not a JSON flag presented as a distributed lock.

If no available mechanism can invoke the decision agent after this turn, complete
all feasible work now and report `capability_blocked` for unattended continuation,
with the precise missing capability and durable next action. Do not claim an
active service, fabricate a schedule, silently downgrade to manual wakeup, or
promise that a skill file can keep a destroyed host running. The goal stays
unfinished. Where an existing task's state is unknown, reconcile it first.

## Storage failure at a continuation boundary

When GitHub cannot preserve or verify the checkpoint, apply
[github-zip-fallback.md](github-zip-fallback.md) now and return the verified download
link. Keep remote synchronization and unattended continuation status separate.
Continue only safe locally supported work; do not launch duplicate jobs or claim
shared ownership from an offline archive. Preserve explicit pause/stop and cumulative
limits, and reconcile remote state before resuming affected shared work.

## Pause, limits and installation

An explicit user pause/stop wins over any timer, runner or source update. Persist
it first; disable the goal-owned continuation trigger when supported and verify
that change. Reconcile in-flight jobs under their retained stop policy. Do not
kill unrelated tasks or turn off a report-only watcher. Scheduler invocations
must re-read pause before dispatch. Only sourced user resumption can clear it.
Stop new dispatch at cumulative budget/deadline exhaustion; continue necessary
observation and safe settlement without inventing new research allowance.
A temporary missing dependency blocks only affected child actions; other admitted
work for the current node may continue without advancing past its acceptance.
For a truly blocked goal retain a bounded real dependency retry/callback where
available, rather than repeated model calls with no new evidence.

Package editing, installation and procedure adoption do not themselves authorize
starting research, migrating a live task or resuming a paused project. Activate
continuation only for a currently authorized research goal. Report source version,
installed version, adopted procedure, configured trigger and observed execution
separately. Successful package tests do not establish live unattended operation.

For executable CPU/RAM/disk admission and automatic resource rechecks, read [resource-queue.md](resource-queue.md). Temporary contention keeps the goal active; preserve original deadlines and explicit pauses.
