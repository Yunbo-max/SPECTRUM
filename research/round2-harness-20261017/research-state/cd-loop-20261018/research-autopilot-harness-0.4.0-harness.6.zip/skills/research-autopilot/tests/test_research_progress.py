"""Engineering-only observation tests; no dispatch, provider or scientific work."""
import concurrent.futures
import datetime as dt
import importlib.util
import json
import pathlib
import sqlite3
import subprocess
import sys
import tempfile
import unittest


SCRIPT = pathlib.Path(__file__).resolve().parents[1] / "scripts/research_progress.py"
try:
    SPEC = importlib.util.spec_from_file_location("research_progress", SCRIPT)
    P = importlib.util.module_from_spec(SPEC)
    SPEC.loader.exec_module(P)
except FileNotFoundError:
    P = None


def stamp(value):
    return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))


class ProgressObservationTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(P, "read-only progress observer is missing")
        self.tmp = tempfile.TemporaryDirectory(prefix="progress-engineering-")
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name) / "project"
        self.root.mkdir()
        self.now = stamp("2026-10-09T12:00:00Z")

    def record(self, task_id="sources", **values):
        fields = dict(project_id="project-a", title="Evidence project", edition="main",
                      task_id=task_id, task_title="Read sources", description="Compare source evidence",
                      stage=2, status="running", owner="Web", now=self.now)
        fields.update(values)
        return P.record(self.root, **fields)

    def snapshot(self, **values):
        fields = dict(projects=[self.root], timezone="Europe/London", now=self.now,
                      freshness_seconds=300)
        fields.update(values)
        return P.export_snapshot(**fields)

    def test_independent_parallel_stages_preserve_descriptions_and_clocks(self):
        self.record(now=stamp("2026-10-09T11:00:00Z"))
        self.record("code", task_title="Implement candidate", description="Implement the approved candidate",
                    stage=4, owner="Local", now=stamp("2026-10-09T11:01:00Z"))
        self.record(status="waiting", blocker="Need source access", next_action="Owner supplies access",
                    now=stamp("2026-10-09T11:02:00Z"))
        snapshot = self.snapshot()
        self.assertEqual(snapshot["schema_version"], 1)
        self.assertEqual(snapshot["timezone"], "Europe/London")
        tasks = {task["task_id"]: task for task in snapshot["projects"][0]["tasks"]}
        self.assertEqual(tasks["sources"]["status"], "waiting")
        self.assertEqual(tasks["sources"]["blocker"], "Need source access")
        self.assertEqual(tasks["sources"]["timing"][0], {
            "start_at": "2026-10-09T11:00:00Z", "end_at": "2026-10-09T11:02:00Z",
            "status": "running", "stage": 2})
        self.assertEqual(tasks["code"]["timing"][0]["start_at"], "2026-10-09T11:01:00Z")
        self.assertEqual(tasks["code"]["stage"], 4)
        self.assertEqual(tasks["code"]["description"], "Implement the approved candidate")
        self.assertNotIn("completion_percentage", snapshot)

    def test_completion_is_terminal_observation_without_filling_other_stages(self):
        self.record(now=stamp("2026-10-09T11:59:00Z"))
        self.record(status="complete", summary="Source comparison saved")
        task = self.snapshot()["projects"][0]["tasks"][0]
        self.assertEqual(task["status"], "complete")
        self.assertEqual({segment["stage"] for segment in task["timing"]}, {2})
        self.assertEqual(task["timing"][-1]["end_at"], task["timing"][-1]["start_at"])
        self.assertEqual(task["events"][-1]["summary"], "Source comparison saved")

    def test_record_concurrency_keeps_every_complete_json_line(self):
        def write(index):
            return self.record(str(index), summary="Observed parallel task")
        with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
            list(pool.map(write, range(50)))
        journal = self.root / ".research-autopilot/progress/events.jsonl"
        rows = [json.loads(line) for line in journal.read_text().splitlines()]
        self.assertEqual(len(rows), 50)
        self.assertEqual(len(self.snapshot()["projects"][0]["tasks"]), 50)

    def test_corrupt_tail_is_preserved_and_valid_prefix_remains_observable(self):
        self.record()
        journal = self.root / ".research-autopilot/progress/events.jsonl"
        with journal.open("ab") as stream:
            stream.write(b'{"unfinished":')
        before = journal.read_bytes()
        project = self.snapshot()["projects"][0]
        self.assertEqual(len(project["tasks"]), 1)
        self.assertTrue(any("corrupt" in item.lower() for item in project["warnings"]))
        with self.assertRaises(ValueError):
            self.record("other")
        self.assertEqual(journal.read_bytes(), before)

    def test_naive_or_reversed_timestamps_do_not_enter_journal(self):
        self.record()
        journal = self.root / ".research-autopilot/progress/events.jsonl"
        before = journal.read_bytes()
        with self.assertRaises(ValueError):
            self.record(now=stamp("2026-10-09T11:00:00Z"))
        with self.assertRaises(ValueError):
            self.record(now=dt.datetime(2026, 10, 9, 12))
        self.assertEqual(journal.read_bytes(), before)

    def test_repeated_observation_after_freshness_gap_does_not_count_offline_time(self):
        self.record(now=stamp("2026-10-09T11:00:00Z"))
        self.record(now=stamp("2026-10-09T11:20:00Z"))
        task = self.snapshot()["projects"][0]["tasks"][0]
        self.assertEqual(task["timing"][0]["end_at"], "2026-10-09T11:05:00Z")
        self.assertEqual(task["timing"][1]["start_at"], "2026-10-09T11:20:00Z")

    def test_stale_open_manual_interval_ends_at_freshness_expiry(self):
        self.record(now=stamp("2026-10-09T11:00:00Z"))
        task = self.snapshot()["projects"][0]["tasks"][0]
        self.assertEqual(task["timing"][-1]["end_at"], "2026-10-09T11:05:00Z")
        self.assertEqual(task["updated_at"], "2026-10-09T11:00:00Z")

    def database(self):
        path = pathlib.Path(self.tmp.name) / "controller.sqlite3"
        db = sqlite3.connect(path)
        db.executescript("""
            CREATE TABLE projects(project_id TEXT, contract TEXT);
            CREATE TABLE tasks(project_id TEXT,task_id TEXT,contract TEXT,state TEXT,run_id TEXT,outputs TEXT);
            CREATE TABLE runs(run_id TEXT,project_id TEXT,task_id TEXT,owner TEXT,state TEXT,
                started_at REAL,lease_until REAL,reason TEXT);
            CREATE TABLE events(event_id INTEGER PRIMARY KEY,project_id TEXT,task_id TEXT,
                run_id TEXT,kind TEXT,timestamp REAL,data TEXT);
        """)
        project = {"project_id": "project-a", "root": str(self.root), "skill_root": None}
        db.execute("INSERT INTO projects VALUES(?,?)", ("project-a", json.dumps(project)))
        action = {"task_id": "sources", "action": "source_read", "dependencies": [],
                  "instructions": [{"path": "private-prompt.md", "sha256": "a" * 64}],
                  "parameters": {"prompt": "PRIVATE_TOOL_PAYLOAD_DO_NOT_EXPORT"}}
        start = stamp("2026-10-09T11:00:00Z").timestamp()
        db.execute("INSERT INTO tasks VALUES(?,?,?,?,?,?)",
                   ("project-a", "sources", json.dumps(action), "running", "retained-run", "[]"))
        db.execute("INSERT INTO runs VALUES(?,?,?,?,?,?,?,?)",
                   ("retained-run", "project-a", "sources", "Local", "running", start, start + 60, None))
        for index, kind in enumerate(("task_registered", "claimed", "worker.tool_update"), 1):
            db.execute("INSERT INTO events VALUES(?,?,?,?,?,?,?)", (index, "project-a", "sources",
                "retained-run" if index > 1 else None, kind, start + index - 2,
                json.dumps({"prompt": "PRIVATE_TOOL_PAYLOAD_DO_NOT_EXPORT"})))
        db.commit()
        db.close()
        return path

    def test_expired_controller_is_readonly_retains_identity_and_does_not_rerun(self):
        path = self.database()
        before = path.read_bytes()
        project = self.snapshot(projects=[], controller_dbs=[path])["projects"][0]
        task = project["tasks"][0]
        self.assertEqual(project["edition"], "unknown")
        self.assertEqual(task["status"], "reconcile_required")
        self.assertEqual(task["run_id"], "retained-run")
        self.assertEqual(task["owner"], "Local")
        self.assertEqual(task["stage"], 2)
        self.assertEqual(task["timing"][-1]["end_at"], "2026-10-09T11:01:00Z")
        self.assertNotIn("PRIVATE_TOOL_PAYLOAD", json.dumps(project))
        self.assertTrue(any("expired" in item.lower() for item in project["warnings"]))
        self.assertEqual(path.read_bytes(), before)
        with sqlite3.connect(path) as db:
            self.assertEqual(db.execute("SELECT state FROM runs").fetchone()[0], "running")
            self.assertEqual(db.execute("SELECT COUNT(*) FROM events").fetchone()[0], 3)

    def test_delayed_controller_expiry_event_never_extends_known_running_lease(self):
        path = self.database()
        with sqlite3.connect(path) as db:
            db.execute("UPDATE runs SET state='reconcile_required'")
            db.execute("UPDATE tasks SET state='reconcile_required'")
            db.execute("INSERT INTO events VALUES(4,'project-a','sources','retained-run',"
                       "'reconcile_required',?, '{}')", (self.now.timestamp(),))
        task = self.snapshot(projects=[], controller_dbs=[path])["projects"][0]["tasks"][0]
        running = [segment for segment in task["timing"] if segment["status"] == "running"]
        self.assertEqual(running[-1]["end_at"], "2026-10-09T11:01:00Z")
        self.assertEqual(task["events"][-1]["run_id"], "retained-run")

    def test_terminal_reconciliation_preserves_the_expired_running_time_bound(self):
        path = self.database()
        with sqlite3.connect(path) as db:
            db.execute("UPDATE runs SET state='completed'")
            db.execute("UPDATE tasks SET state='completed'")
            db.execute("INSERT INTO events VALUES(4,'project-a','sources','retained-run',"
                       "'reconcile_required',?, '{}')", (self.now.timestamp() - 60,))
            db.execute("INSERT INTO events VALUES(5,'project-a','sources','retained-run',"
                       "'completed',?, '{}')", (self.now.timestamp(),))
        task = self.snapshot(projects=[], controller_dbs=[path])["projects"][0]["tasks"][0]
        running = [segment for segment in task["timing"] if segment["status"] == "running"]
        self.assertEqual(running[-1]["end_at"], "2026-10-09T11:01:00Z")
        self.assertEqual(task["status"], "complete")

    def test_renewed_lease_does_not_fill_unobserved_historical_running_gap(self):
        path = self.database()
        with sqlite3.connect(path) as db:
            db.execute("UPDATE runs SET lease_until=?", (stamp("2026-10-09T12:01:00Z").timestamp(),))
            db.execute("DELETE FROM events WHERE event_id > 2")
            db.execute("INSERT INTO events VALUES(4,'project-a','sources','retained-run',"
                       "'reconcile_required',?, '{}')", (self.now.timestamp(),))
            db.execute("INSERT INTO events VALUES(5,'project-a','sources','retained-run',"
                       "'reconciled_running',?, '{}')", (self.now.timestamp() + 1,))
        project = self.snapshot(projects=[], controller_dbs=[path],
                                now=stamp("2026-10-09T12:00:30Z"))["projects"][0]
        task = project["tasks"][0]
        running = [segment for segment in task["timing"] if segment["status"] == "running"]
        self.assertEqual(running[0]["end_at"], "2026-10-09T11:05:00Z")
        self.assertEqual(running[-1]["start_at"], "2026-10-09T12:00:01Z")
        self.assertIsNone(running[-1]["end_at"])
        self.assertEqual(task["status"], "running")
        self.assertTrue(any("gap" in warning.lower() and "coverage" in warning.lower()
                            for warning in project["warnings"]))

    def test_invalid_controller_run_timestamp_is_visible_as_unknown(self):
        path = self.database()
        with sqlite3.connect(path) as db:
            db.execute("UPDATE runs SET lease_until=started_at-1")
        project = self.snapshot(projects=[], controller_dbs=[path])["projects"][0]
        self.assertEqual(project["tasks"][0]["task_id"], "sources")
        self.assertEqual(project["tasks"][0]["status"], "unknown")
        self.assertTrue(project["warnings"])

    def test_missing_controller_timestamp_does_not_invent_observation_time(self):
        path = self.database()
        with sqlite3.connect(path) as db:
            db.execute("UPDATE runs SET started_at=NULL,lease_until=NULL")
        task = self.snapshot(projects=[], controller_dbs=[path],
                             now=stamp("2030-01-01T00:00:00Z"))["projects"][0]["tasks"][0]
        self.assertEqual(task["status"], "unknown")
        self.assertIsNone(task["started_at"])

    def test_dependency_ids_are_bounded_as_identifiers(self):
        with self.assertRaises(ValueError):
            self.record(dependencies=["x" * 257])

    def test_merged_evidence_is_bounded_for_browser_import(self):
        self.record(evidence=[f"local-{index}" for index in range(1000)])
        path = self.database()
        with sqlite3.connect(path) as db:
            db.execute("UPDATE tasks SET outputs=?", (json.dumps([
                {"path": f"runtime-{index}", "sha256": "a" * 64} for index in range(1000)]),))
        project = self.snapshot(controller_dbs=[path])["projects"][0]
        self.assertEqual(len(project["tasks"][0]["evidence"]), 1000)
        self.assertTrue(any("evidence" in warning for warning in project["warnings"]))

    def test_timestamps_use_browser_compatible_millisecond_precision(self):
        self.record(now=self.now.replace(microsecond=123456))
        snapshot = self.snapshot(now=self.now.replace(microsecond=234567))
        self.assertEqual(snapshot["generated_at"], "2026-10-09T12:00:00.234Z")
        self.assertEqual(snapshot["projects"][0]["tasks"][0]["updated_at"],
                         "2026-10-09T12:00:00.123Z")

    def test_missing_timestamp_in_journal_is_rejected_without_inventing_now(self):
        self.record()
        journal = self.root / ".research-autopilot/progress/events.jsonl"
        row = json.loads(journal.read_text())
        row.pop("timestamp")
        journal.write_text(json.dumps(row) + "\n")
        project = self.snapshot()["projects"][0]
        self.assertEqual(project["tasks"], [])
        self.assertTrue(project["warnings"])

    def test_controller_overlay_uses_explicit_labels_but_actual_runtime_state(self):
        self.record(status="complete", task_title="Explicit source comparison")
        project = self.snapshot(controller_dbs=[self.database()])["projects"][0]
        self.assertEqual(len(project["tasks"]), 1)
        task = project["tasks"][0]
        self.assertEqual(task["title"], "Explicit source comparison")
        self.assertEqual(task["description"], "Compare source evidence")
        self.assertEqual(task["status"], "reconcile_required")
        self.assertEqual(task["source"], "local_observation+controller_sqlite")

    def test_controller_never_merges_same_id_from_a_different_project_root(self):
        self.record()
        path = self.database()
        other = pathlib.Path(self.tmp.name) / "different-project"
        other.mkdir()
        with sqlite3.connect(path) as db:
            db.execute("UPDATE projects SET contract=?", (json.dumps({
                "project_id": "project-a", "root": str(other), "skill_root": None}),))
        with self.assertRaises(ValueError):
            self.snapshot(controller_dbs=[path])

    def test_pending_controller_tasks_explain_unsatisfied_dependencies(self):
        path = self.database()
        with sqlite3.connect(path) as db:
            db.execute("INSERT INTO tasks VALUES(?,?,?,?,?,?)", ("project-a", "writing",
                json.dumps({"task_id": "writing", "action": "writing", "dependencies": ["sources"]}),
                "pending", None, "[]"))
            db.execute("INSERT INTO events VALUES(4,'project-a','writing',NULL,'task_registered',?, '{}')",
                       (self.now.timestamp() - 10,))
        task = next(task for task in self.snapshot(projects=[], controller_dbs=[path])["projects"][0]["tasks"]
                    if task["task_id"] == "writing")
        self.assertEqual(task["status"], "waiting")
        self.assertIn("sources", task["blocker"])
        self.assertEqual(task["stage"], 8)
        self.assertIsNone(task["started_at"])

    def test_pending_controller_admission_denial_is_a_visible_blocker(self):
        path = self.database()
        with sqlite3.connect(path) as db:
            db.execute("UPDATE tasks SET state='pending',run_id=NULL")
            db.execute("DELETE FROM runs")
            db.execute("DELETE FROM events WHERE event_id > 1")
            db.execute("INSERT INTO events VALUES(4,'project-a','sources',NULL,'admission_denied',?, '{}')",
                       (self.now.timestamp() - 10,))
        task = self.snapshot(projects=[], controller_dbs=[path])["projects"][0]["tasks"][0]
        self.assertEqual(task["status"], "blocked")
        self.assertIn("admission", task["blocker"].lower())

    def test_edition_comes_from_existing_metadata_not_action_or_title(self):
        path = self.database()
        skill = pathlib.Path(self.tmp.name) / "checkout/skills/research-autopilot"
        skill.mkdir(parents=True)
        (skill.parent.parent / "EDITION.json").write_text('{"branch":"autonomous-rsi-chat"}')
        with sqlite3.connect(path) as db:
            db.execute("UPDATE projects SET contract=?", (json.dumps({"project_id": "project-a",
                "root": str(self.root), "skill_root": str(skill)}),))
        project = self.snapshot(projects=[], controller_dbs=[path])["projects"][0]
        self.assertEqual(project["edition"], "autonomous-rsi-chat")

    def test_export_cannot_clobber_db_even_when_named_json(self):
        path = self.database()
        renamed = path.with_suffix(".json")
        path.rename(renamed)
        child = subprocess.run([sys.executable, str(SCRIPT), "export", "--controller-db", str(renamed),
            "--output", str(renamed)], capture_output=True, text=True)
        self.assertNotEqual(child.returncode, 0)
        with sqlite3.connect(renamed) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM tasks").fetchone()[0], 1)

    def test_unknown_action_has_honest_fallback_and_no_invented_stage_history(self):
        path = self.database()
        with sqlite3.connect(path) as db:
            db.execute("UPDATE tasks SET contract=?,state='completed'", (json.dumps({
                "task_id": "sources", "action": "unrecognized", "dependencies": []}),))
            db.execute("UPDATE runs SET state='completed'")
            db.execute("INSERT INTO events VALUES(4,'project-a','sources','retained-run',"
                       "'completed',?, '{}')", (self.now.timestamp(),))
        project = self.snapshot(projects=[], controller_dbs=[path])["projects"][0]
        self.assertIn("unrecognized", project["tasks"][0]["description"])
        self.assertTrue(any("stage" in item.lower() for item in project["warnings"]))
        self.assertEqual(project["tasks"][0]["status"], "complete")

    def test_symlinks_oversized_text_and_nonprogress_outputs_fail_closed(self):
        linked = pathlib.Path(self.tmp.name) / "linked"
        linked.symlink_to(self.root, target_is_directory=True)
        with self.assertRaises(ValueError):
            P.record(linked, project_id="p", title="p", edition="main", task_id="t",
                     description="d", stage=1, status="running", owner="Web")
        with self.assertRaises(ValueError):
            self.record(description="x" * 16001)
        self.record()
        existing = self.root / "research-state.json"
        existing.write_text('{"scientific_state":"keep"}')
        before = existing.read_bytes()
        with self.assertRaises(ValueError):
            P.write_snapshot(self.snapshot(), existing)
        self.assertEqual(existing.read_bytes(), before)
        with self.assertRaises(ValueError):
            P.write_snapshot(self.snapshot(), self.root / "controller.sqlite3")

    def test_export_atomic_output_and_bounded_watch_cli(self):
        self.record()
        output = self.root / ".research-autopilot/progress/snapshot.json"
        command = [sys.executable, str(SCRIPT), "export", "--project", str(self.root),
                   "--output", str(output), "--timezone", "Europe/London"]
        child = subprocess.run(command, capture_output=True, text=True)
        self.assertEqual(child.returncode, 0, child.stderr)
        self.assertEqual(json.loads(output.read_text())["timezone"], "Europe/London")
        child = subprocess.run([sys.executable, str(SCRIPT), "watch", "--project", str(self.root),
            "--output", str(output), "--cycles", "1", "--interval", "1"],
            capture_output=True, text=True, timeout=10)
        self.assertEqual(child.returncode, 0, child.stderr)
        self.assertFalse(list(output.parent.glob("*.tmp")))
        child = subprocess.run([sys.executable, str(SCRIPT), "watch", "--project", str(self.root),
            "--output", str(output), "--cycles", "0"], capture_output=True, text=True)
        self.assertNotEqual(child.returncode, 0)

    def test_london_dst_timestamps_are_utc_without_ambiguous_local_clock_values(self):
        self.record(now=stamp("2026-10-25T01:30:00+01:00"))
        self.record(status="waiting", now=stamp("2026-10-25T01:30:00+00:00"))
        task = self.snapshot(now=stamp("2026-10-25T03:00:00Z"))["projects"][0]["tasks"][0]
        self.assertEqual([event["timestamp"] for event in task["events"]],
                         ["2026-10-25T00:30:00Z", "2026-10-25T01:30:00Z"])


if __name__ == "__main__":
    unittest.main()
