"""Engineering regression tests; these packets are not scientific eval evidence."""
import copy
import types
import unittest
from fixtures import C, ProjectFixture, sample_artifacts, write
from test_workflow import to_gate, evaluate_persisted
import _evidence as E


def validated_project(f):
    p, pref = to_gate(f)
    first, _, _ = evaluate_persisted(f, p, pref, "gate-a")
    f.transition("gate_a_PASS", {"decision_ref": first["decision_ref"]})
    full = f.protocol("full-validation", frozen=False)
    full.update(protocol_id="full-p1", evidence_snapshot_ref=p["evidence_snapshot_ref"],
                inventory_run_ids=["full-p1-r1-main", "full-p1-r2-main"])
    source = write(f.root, "full-input.json", full)
    with C.locked(f.root):
        frozen = C.freeze_gate(types.SimpleNamespace(protocol=str(f.root / source["path"]), gate="full-validation"), f.root)
    full = C.verify_ref(f.root, frozen["protocol_ref"], "full-validation-protocol")
    result, runs, refs = evaluate_persisted(f, full, frozen["protocol_ref"], "full-validation")
    s = copy.deepcopy(f.snapshot)
    s.update(snapshot_id="writing-ready", created_at=C.now())
    s["artifact_refs"] += refs + [result["decision_ref"]]
    s["closure"] = {"claims": [{"claim_id": "claim-1", "status": "closed", "unresolved_confounds": [],
        "criterion_ids": ["effect"], "evidence_refs": refs}],
        "result_inventory_run_ids": sorted(r["run_id"] for r in runs), "decision_ref": result["decision_ref"]}
    sref = write(f.root, "evidence/snapshots/writing-ready.json", s)
    f.transition("full_validation_PASS", {"decision_ref": result["decision_ref"], "evidence_snapshot_ref": sref})
    return full, result, s, sref, refs


class EvidenceLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.f = ProjectFixture()
        self.addCleanup(self.f.close)

    def test_changed_snapshot_revokes_old_validation_and_writing(self):
        _, _, s, _, _ = validated_project(self.f)
        s.update(snapshot_id="new-evidence", created_at=C.now())
        sref = write(self.f.root, "evidence/snapshots/new-evidence.json", s)
        self.f.transition("update_evidence", {"evidence_snapshot_ref": sref})
        state = C.project(self.f.root)[0]
        self.assertNotEqual(state["validation_state"], "pass")
        self.assertEqual(state["writing_state"], "not_ready")
        self.assertEqual(state["current_route"], "full_experiments")

    def test_same_snapshot_update_keeps_verified_binding(self):
        _, _, _, sref, _ = validated_project(self.f)
        self.f.transition("update_evidence", {"evidence_snapshot_ref": sref})
        self.assertEqual(C.project(self.f.root)[0]["validation_state"], "pass")

    def test_generic_source_is_not_a_claim_run_proof(self):
        p = self.f.protocol("full-validation")
        s = copy.deepcopy(self.f.snapshot)
        s["closure"] = {"claims": [{"claim_id": "claim-1", "status": "closed", "unresolved_confounds": [],
            "criterion_ids": ["effect"], "evidence_refs": [self.f.source]}], "result_inventory_run_ids": []}
        decision = {"criteria_results": [{"criterion_id": "effect", "passed": True}], "eligible_run_ids": []}
        with self.assertRaises(C.Failure):
            E.verify_claim_closure(self.f.root, s, p, decision)

    def test_handoff_versions_and_stage_are_bound_to_validated_state(self):
        _, _, _, sref, refs = validated_project(self.f)
        handoff = copy.deepcopy(sample_artifacts()["handoff"])
        handoff.update(evidence_snapshot_ref=sref, source_refs=refs, method_version="unvalidated-method")
        handoff["provenance"]["evidence_mode"] = "prospective_confirmatory"
        with self.assertRaises(C.Failure):
            E.verify_handoff(self.f.root, handoff)

    def test_new_gate_a_rejects_retrospective_rule_setting(self):
        p = self.f.protocol()
        p["evidence_mode"] = "retrospective_audit"
        p["protocol_digest"] = C.protocol_hash(p)
        runs, refs = self.f.runs(p)
        self.assertEqual(C.evaluate(self.f.root, p, runs, refs, "gate-a")["outcome"], "INCONCLUSIVE")


if __name__ == "__main__":
    unittest.main()
