# Rolling research batches and flexible review times

**Chat RSI scope:** follow chat-execution.md for execution host, continuation
and candidate count. The current host may run authorized feasible checks; new
discovery defaults to one candidate with the recorded target_override. Local
acceptance and 20-to-15 references describe optional legacy-backend/broad-discovery
modes. Preserve the evidence requirements for the actual action and claim.

**Autonomous branch:** read [autonomous-rsi](autonomous-rsi.md) with this module. Its finite delegated machine supervisor replaces routine human step-7 selection and selects the startup-authorized delivery branch; scientific evidence, existing goals, budgets and same-attempt recovery remain binding. Older human-at-every-batch/main-only wording below describes the baseline and is superseded only within that explicit delegation.

Apply the owner's working pattern: the web chat inspects evidence, navigates the
research map and prepares code/plans in GitHub; a local agent controls an actual
SSH-connected GPU worker, verifies/collects results and pushes a pinned review
packet to the selected project GitHub repo. The human brings that locator to the
web chat for joined evidence analysis, next-round design and consolidated decision.
Local then fetches the approved revision and resumes eligible work. Reuse existing
project identities, budgets and native eval. Apply the default responsibility split
and result-packet contract in [repository-round-trips.md](repository-round-trips.md).
These are worker instructions, not a deployed scheduler or remote connection.

Confirm the scientific project's GitHub delivery repo and Hugging Face output
destination (or explicit non-use) at startup under
[initial-intake.md](initial-intake.md), before its first idea/time-budgeted batch.
Retain this sourced target map and deliver the initial investigation/idea record,
plan and ready code through [repository-round-trips.md](repository-round-trips.md).
Each review reads actual latest content from the same targets; version explicit
changes rather than asking again each window. Input repos do not select outputs.

## Human-chosen review time

The 2026-10-07 owner instruction supersedes the former eight-hour execution/window
assumption. **Eight hours is only a soft progress/report cadence; approved Local
work may run continuously for up to 24 elapsed hours per execution cycle** on
the existing authorized resources. A 10-, 12- or 20-hour comparison is not late
merely because it crosses a report point. Reuse flexible human review times;
do not force 08:00/16:00/23:00 appointments or ask for the same duration again.
Resolve actual launch/remaining elapsed time and timezone. This policy does not
install reminders, prove continuous host availability or reset cumulative costs.

Long Web paper/code/benchmark analysis, mathematical reasoning, complete source
and command generation follow [web-background-work.md](web-background-work.md):
prefer supported hosted Work, save material milestones and continue to its scoped
completion criteria. Neither the eight-hour report nor the Local 24-hour cycle
cuts off Web authoring; actual platform/user budgets and human decisions still bind.

Keep two limits distinct:

- **Window/report boundary:** retain progress and a consolidated evidence report.
  Unfinished approved work carries into the next window. A running job can cross
  this boundary under its existing execution contract; the clock alone does not
  invalidate a comparison, change its protocol or require killing it.
- **Total execution authorization:** actual GPU allocation, global/per-job wall
  time, spend, attempts and stop conditions. These still bind across windows.
  Neither a new window nor three daily slots reset usage or grant new spending.

For a new Local cycle, use the lesser of the owner's 24-hour elapsed allowance
and remaining actual lease/global/time/spend/attempt limits. Include setup,
downloads, tests, scoring, E04 and export overhead. Do not make a new run's native
`wall_time_seconds`, `attempt_timeout_seconds` or harness `total_wall_seconds`
equal to 28800 just because `window_seconds` is 28800. Give required long jobs
reviewed runtime bounds that can cross reports within the remaining cycle. Do
not truncate the native protocol or allocate longer jobs than admitted resources.

If the human explicitly sets an eight-hour hard execution limit as well as a review boundary,
honor it. Save a compatible checkpoint only when the actual implementation and
frozen protocol permit; otherwise retain partial outputs and the truthful status.
The owner's new 24-hour instruction replaces a previously inferred/default
eight-hour cap for future admitted plans; it does not change a queryable running
plan's digest or watchdog. Inspect old outer/inner limits before reuse and record
the sourced time-policy change. Preserve live jobs; apply supported reconciliation
or a new operational plan for pending eligible units, retaining elapsed usage,
stable scientific IDs and receipts. Never edit active plan/state/receipts in place,
reset counters or restart a completed unit. At a real 24-hour/earlier hard bound,
retain compatible checkpoints/partial work and remaining comparisons for a later
cycle; do not relabel time exhaustion as scientific failure.
Without a reporting/background host, report when invoked with the last observed
snapshot time. Do not claim that an ordinary web chat will wake or contact a GPU.

## Durable task backlog

For new/reopened method discovery within one scientific project/navigation goal,
perform mathematical reasoning to generate **about 20 justified candidates
(target 20), verify every card, rank all candidates and select the top 15 before
code design**, under [method-verification.md](method-verification.md). Retain at
most 20 active independent ideas. If fewer candidates are sound, report the target
deficit rather than inventing ideas or calling the default selection complete;
an explicit changed user scope can change the targets. A resume reuses valid
pool/selection records rather than generating another slate. The cap includes
carried candidates, new candidates and candidate reserves admitted to the current
slate; archived/stopped candidates stay in history. Later rounds have no minimum
and normally converge to 2–5, then 1–2 when the evidence supports it. Do not count
controls, ablations, configurations, seeds or repeated task groups as new ideas.
Run-unit count follows G01's indispensable contrasts, precision and actual cost.

Prepare a finite priority backlog sufficient for useful work across windows;
full comparisons may need longer than eight hours. Preserve the official benchmark,
data, labels, metric and scorer. Never invent ideas/eval cases, blind parameter
sweeps or unnecessary repeats to fill time or reach a count. An active-idea cap
is not a promise that all selected candidates finish in one window.

### Core batch, reserve and human review

At H03/G01, retain each selected idea's complete required experiment design,
including strong/simple baselines, controls, eligible sampling, native scoring,
E04 verification and saving/reporting. Plan the current window's feasible dispatch
from actual GPU capacity, dependencies, measured/estimated runtime ranges and
complete overhead. Identify what is expected to finish, what may remain running
and what will carry. Full comparisons may span windows; do not drop controls or
weaken precision to fit the clock. Partial runs/results do not close a comparison.

Keep scientifically justified ready/conditional/blocked reserves explicit, with
preset admission/stop conditions and dependencies. They can replace a frozen skip
or fill early completion within existing scope and total limits. Count candidate
reserves toward the active cap of 20, while their runs remain separate. Retain
excess work for later windows rather than promising completion of the whole slate.
If no valid ready task remains, report the blocker/idle time instead of inventing work.

During the window, execute agreed work, verify each result and retain per-idea
positive, adverse, mixed or unresolved evidence under frozen stop/repair rules.
A single failure does not initiate a new direction or restart idea generation.
At each boundary, save one consolidated report and propose the next-window plan.
**Unfinished approved work may continue unchanged without repeated intake or
approval**, provided its dependencies remain valid and existing scope, resource
leases, total budget, attempt/time limits and protocol allow it. Reconcile the
real job first; never relaunch a still-running job or consume confirmation twice.
A new window ID is not a new scientific protocol, trial or confirmation draw.

**New directions, expansion, materially changed designs and validation/writing
branches follow the human's consolidated review decision** under
[state-and-routing.md](state-and-routing.md), or an earlier explicit decision whose
actual conditions have been met. When the human is absent, continue only unchanged
approved eligible work; hold new scientific branches. Changed goals/resources may
return to step 1; human-selected reassessment returns to contextual steps 2/3/4.
A boundary does not extend a spent budget or override a job timeout/expired lease.

### Evidence-driven convergence between rounds

Classify evidence validity before scientific meaning. Propose a next slate that
reduces decision-relevant uncertainty while preserving the important original
problem, rather than restoring the initial idea count each round:

| Candidate evidence | Proposed next action |
| --- | --- |
| Reliable positive | Independently confirm; deepen strong/simple comparisons, mechanism necessity, closest-work differences and generalization/boundaries. A selected development winner is not fresh confirmation or paper readiness. |
| Valid adverse/refuting evidence | Stop or park that candidate with the falsified prediction and revisit trigger; retain all negative costs/results. One refuted candidate does not refute every direction. |
| Bug, scoring fault, missing controls or inadequate precision | Repair/pending evidence, not a scientific loss or a rescued success. Continue only authorized diagnosis and preserve unresolved obligations. |
| Mixed across scenarios | Group by competing causes: implementation/scoring, parameters/selection, budget, task assumptions, or a real applicability boundary. Prioritize useful distinguishing contrasts; tuning is a hypothesis, not proof the method is correct. |

For the example 2 positive / 12 adverse / 6 mixed, first check those labels against
E04 records. Propose confirming/deepening the two positive candidates, stopping or
parking only genuinely refuted ones, and grouping the six mixed candidates into
causal questions. Usually prioritize 2–3 informative diagnostic candidates and
park the rest with revisit triggers. This is an example, not a fixed allocation
or guaranteed success rate; no candidate is retained merely for a favorable score.

After human review, later active slates normally narrow to 2–5 and then 1–2 ideas,
with no minimum and a hard cap of 20. Prefer complete, useful comparisons over
re-expansion. Expand only when named evidence warrants it: a material new natural
failure, contradiction of the current explanation, closest-work collision or a
qualified simple baseline that removes the claimed gap, or changed human goals/
constraints. Read relevant primary papers, actual GitHub files and existing
benchmark contents before pairing new explanations with H03/G01 designs. Do not
shrink to favorable data or an unimportant claim merely to save a paper. A changed
parent problem follows the existing restart contract; no silent parent rewrite.

The next-window card retains: active/carried/repair/parked/stopped idea IDs and
reasons; each next question, prediction/falsifier, full baseline/control/benchmark
and frozen configuration; completed and remaining units; estimated costs and
uncertainty; confirmation status; actual bounds and the human decision/unchanged
carry basis. Reuse qualified unchanged readings/checks; update affected ones when
evidence or versions change. Full rigor continues every round, with no quick-test
waiver and no duty to repeat unaffected checks.

Keep the backlog in the selected durable project destination. An existing task
store may be reused; otherwise `research-backlog.json` is a planning record, not
an added canonical ledger/schema supported by the bundled validator. Retain:

| Field | Retained meaning |
| --- | --- |
| Identity and ownership | Stable idea/task/run/project/route IDs, lineage and actual owner |
| Scientific purpose | Important question, competing explanations, distinguishing observation and full comparison obligations |
| Dependencies and priority | Required results/assets, evidence-based ordering, parked/stopped reasons and revisit triggers |
| Pinned scope | Code/model/data/evaluator/protocol versions, native group/seed, confirmation eligibility and intended outputs |
| Resource estimate | Timing basis/range, setup/scoring/E04/saving costs, GPU/VRAM, dependencies and estimated remaining work |
| Window and continuation | Window ID/start/end, expected completions, running/queued carry, admission rules, unchanged authorization or human decision |
| Cumulative bounds | Actual execution/spend/attempt limits, observed total use and held unknown usage across all windows |
| Observed state and evidence | Timestamp, actual worker/job, completed/remaining units, compatible checkpoint, outputs and all failed/unselected trials |

Reconcile actual worker state on resume. Preserve still-valid unfinished tasks;
block/supersede obsolete ones with reason and lineage rather than blindly resume.
Only use a real compatible checkpoint allowed by the frozen training/evaluation
contract. Otherwise retain the attempt and report whether a new attempt is legal;
confirmation's no-retry/no-inspected-output rules remain unchanged.

## Dispatch and carryover

Before the first experiment plan, apply G01 in
[full-validation-and-review.md](full-validation-and-review.md). Confirm current
usable GPU count/model/per-device VRAM, allocation and exclusivity/concurrency;
inspect actual inventory before asking. Historical hardware and a suggested
worker are not current capacity. Reuse the soft-report/up-to-24-hour policy and
any explicit change; resolve only genuinely ambiguous start/end times or missing execution/
spend bounds. A subscription is not an API budget or verified GPU allocation.

Measure representative native workload costs, including setup, scoring and
checkpoint/report overhead within the authorized budget, or label extrapolation.
Dispatch only ready work by priority and real GPU/memory/I/O capacity. Retain shared
upstream stages and serial dependencies. Card-hours are a capacity ceiling, not
throughput or proof of parallel speedup. Unknown costs yield a bounded calibration
plan and conditional queue, not an eight-hour completion guarantee.

Use [dependency-resource-scheduling.md](dependency-resource-scheduling.md) for an
actual task DAG and separate agent/GPU admission limits. Follow
single-experiment-batching.md: one active experimental program across the project,
with same-card sharing disabled and supported batch calibration descending.
Independent reading/code/CPU preparation may overlap; dependent work waits for its
pinned inputs. Record actual host contention, headroom and useful throughput.

When a window ends, retain running/queued/paused units and actual completed work;
continue eligible unchanged work in the next window under the same scientific
contract and cumulative bounds. A result-affecting code/config/evaluator/data
change creates the required versioned child protocol and fresh confirmation,
not a silent resume. Do not regenerate finished units to pad the next window.

Use the real runner's finite inventory, timeouts, attempt limits and receipts.
The bundled runner is serial and enforces hard timeouts; it does not implement
persistent concurrent scheduling itself. The required local harness implements
single-host resource admission and window reports around those native plans;
neither executor binds future artifacts, creates Codex subagents or performs
Git pushes. The local agent organizes those authorized delivery tasks, including
a readable packet at each window and when the finite queue finishes. Running
continuously for up to 24 hours requires the actual persistent host and remaining
finite authorization; reports do not require pausing eligible work for human arrival.
Keep executing revisions stable and one integration writer with readback receipts.

## Evidence and uncertainty at each review

Reuse or refresh the joined primary-paper/GitHub-file/benchmark-content reading
and hypothesis-to-experiment record in [literature-evidence.md](literature-evidence.md).
Retain E04's scoped verification before interpreting each completed run/coherent
batch. Distinguish verified individual results from completed required comparisons;
remaining seeds/controls/scoring leave the corresponding conclusion pending.

Return a concise report with actual window/snapshot times, source revisions and
synchronization state; completed/running/carried/failed/blocked tasks and cumulative
usage; each idea's supported/refuted/unresolved predictions, validity concerns and
remaining obligations; proposed convergence and next-window work. Separate
unchanged authorized carry from branches awaiting human review. Statistical
uncertainty requires eligible independent units/native analysis; never invent a
global confidence percentage or infer certainty from the number of runs.

Assess problem value, substantive originality, baseline validity, mechanism
necessity, measured effect and generalization separately. Negative results may
justify stopping; reading or formal inspection may be more useful than another
GPU run. Paper readiness follows evidence closure and full-validation/writing
contracts, not eight elapsed hours, tuned development scores or task totals.
