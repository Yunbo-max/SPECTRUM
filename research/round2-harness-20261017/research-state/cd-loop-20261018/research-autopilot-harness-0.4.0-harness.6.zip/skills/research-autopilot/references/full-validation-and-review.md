# Claim-driven validation, submission and review

Before blocking a stage on scorer availability/isolation, apply
[native-scoring-stages.md](native-scoring-stages.md). Restore real deferred scoring
support from the project. Independent training/export may proceed with saved
unscored artifacts; final metric claims wait for actual native scoring. No Docker
on any host. Requirements for a scorer that executes generated programs belong
to that operation, not automatically to training or prediction generation.


**Chat RSI scope:** follow chat-execution.md for execution host, continuation
and candidate count. The current host may run authorized feasible checks; new
discovery defaults to one candidate with the recorded target_override. Local
acceptance and 20-to-15 references describe optional legacy-backend/broad-discovery
modes. Preserve the evidence requirements for the actual action and claim.

These contracts augment gate-a.md and execution-and-handoffs.md. Read current
official venue instructions. Leading-conference rigor is evidence closure and
honest scope, not a fixed number of experiments/seeds or a promised acceptance.

## G01 NeurIPS-aligned minimum experiment

### GPT instructions for complete evaluation delivery

Read the current math/code evidence, primary papers, actual GitHub implementation
and native benchmark contents before generating the design; reuse unchanged
verified sources. Use [paper-grounded-experiment-design.md](paper-grounded-experiment-design.md)
to extract published designs, review transfer choices and bind actual compute to
an executable claim-to-experiment contract. Apply the generation boundary in method-verification.md. Do
not call a list of benchmark names, a single working adapter or a proposed plan
a complete evaluation implementation.

For an agreed complete or multi-benchmark evaluation, produce a coverage matrix
linking every selected benchmark to its exact revision/split/sample rules,
native loader/scorer and metric/denominator, claim and necessary baseline/control
arms, implemented commands/configs, collection outputs, precision, costs and
remaining obligations. Implement every required adapter and comparison when
complete code is requested; retain unavailable paths as incomplete. Distinguish
designed, implemented, software-checked, native-qualified, executed and verified.
Never invent future run receipts to mark a design or implementation complete.

Choose benchmark/data/model/condition coverage to test the actual claims; broad
cross-dataset claims need independent relevant conditions. Preserve the selected
coverage after agreement. Do not silently switch to fewer/easier datasets, a tiny
arbitrary subset, missing controls or a smoke test to finish faster. A bounded
Gate A comparison has its own declared scope and cannot stand in for an agreed
full validation. Engineering health checks are separate from scientific eval.

Schedule complete comparisons under actual resources and cumulative limits.
Finite windows can contain part of that work; retain pending comparisons across
windows instead of declaring the reduced subset complete. A material change
beyond the sourced goal needs the owner's decision; routine in-scope adaptation
uses a versioned protocol. Continue independent authorized work while other jobs
are queued or blocked. Do not convert resource shortage into scientific success.

### Scientific design contract

Apply chat-execution.md's current-host contract. Generate the complete requested
evaluation code and design, qualify available native interfaces, execute authorized
feasible comparisons and retain actual receipts using the host's real tools.
Use a separate Local/remote backend only when actually selected and authorized;
it receives the exact pinned revision. An implementation draft can be complete
as generated source while execution readiness remains pending. Never fill future
passed receipts or require a Local handoff to run a feasible current-host check.

Plan experiments alongside hypotheses from the initial scientific discussion and
every received result/feedback in later rounds, using [literature-evidence.md](literature-evidence.md)'s primary-
paper, GitHub-file and benchmark-content links. A conditional diagnostic design
can identify missing evidence; actual method execution still requires the existing
prerequisites. Improve the comparison when new reading or results change what it
can distinguish, with versioned protocols and fresh confirmation where required.

Apply this design contract before the first empirical diagnostic/experiment plan,
including initial discussion and a time-budgeted batch, and through Gate A/V expansion.
Use the owner's existing-benchmark preference from research-quality-bar.md;
this preference is distinct from a universal conference rule. Read the current
official guidance for the actual venue/year/track before a submission-specific
review. A skill can impose and audit a design standard, not certify acceptance.

Retain the same scientific design obligations for debug, tuning and small-scope
experiments. No "quick test" label waives them. Choose a scope whose controls,
native scoring and precision can answer the bounded question; missing essentials
stay explicit. Engineering checks and exploratory signals cannot close a method
claim. Scenario-dependent effects use E04's diagnosis/fair tuning contract before
new configuration selection or broader generalization. Every completed run/coherent
batch gets its post-run verification record before a scientific verdict; PASS and
other gate decisions continue to require the actual frozen protocol and evidence.

For each finite batch retain the selected candidate's complete required comparisons,
scoring, verification and saving obligations. Derive dispatch from current measured
capacity, dependencies, timing ranges and remaining cumulative limits. State
expected completions, queued/running carryover, repair reserve and shortfalls.
Snapshots do not shorten required jobs or become outer/inner runner timeouts.
Necessary comparisons may span windows; no control or precision waiver fills a
timing gap. E04 verifies each completed result; partial work remains pending.
Use the autonomous next-route decision in chat-execution.md within existing scope
and authority; no routine human-at-every-batch gate is introduced.

Return a compact experiment-design card before execution, identifying the stage
being launched and its actual dependencies. A supported training/export stage can
be ready while final scoring remains pending under native-scoring-stages.md:

| Required item | Design obligation |
|---|---|
| Scientific question | Central claim, strongest rival explanation, discriminating prediction, falsifier and practically meaningful task effect. |
| Existing evaluation | Identify the relevant benchmark/data revision/split, intended native scorer and exact metric/aggregation/sampling. Record qualification status separately for training, export and scoring; unresolved final-scoring setup does not block independent supported stages. Keep B01/S01 evidence and pending obligations. |
| Strong comparison | Qualified strongest relevant published and simple alternatives; matched information, inference/tuning budget and stated selection rules. |
| Decisive control | Necessary mechanism/replacement or interaction contrast; exclude extra compute, labels, parameters or selection as competing explanations. Record why each contrast changes the decision. |
| Precision and scope | Independent/paired unit, sample selection, variability sources, appropriate uncertainty method and assumptions; choose sample/repetition counts for the effect and budget, without a universal seed count. |
| Host runtime compatibility | Native host execution using the actual pinned environment; preparation, training, inference, scoring and replay must work without Docker or another container runtime. Record exact interpreter/environment, dependency lock and source/time of current CPU/GPU inventory and authorized allocation. Use an optional backend's environment requirements only on that backend. An evaluator without a qualified native path leaves that scoring operation pending; independent training/export can proceed through its supported route. Do not invent a substitute score. |
| Hardware-bound placement and calibration | Bind step 1's single-/multi-device or multi-host allocation, topology and CPU/RAM/I/O to actual per-task dependencies and queues. Supply source-inspected native pre-run diagnosis/performance-calibration commands, tunable development keys/ranges, finite repair/attempt costs, measured-throughput/peak/headroom selection, effective-batch/sampling invariants and independent next-task rules. Pending measurements stay pending; no generic autotuner or cluster executor is implied. |
| Execution and interpretation | Actual code/config/environment, run/collect/scoring commands, current GPU count/model/VRAM/allocation, timing basis, window start/end and expected completions/carryover, cumulative execution/cost bounds, dependencies/run order, stop/recovery rules and frozen PASS/REVISE/KILL/INCONCLUSIVE conditions; retain all raw and failed runs. |

Apply [gpu-host-runtime.md](gpu-host-runtime.md) before marking the queue ready.
Use the current sourced allocation, not a GPU count inherited from another project.
Separate owned inventory from reachable, authorized, presently available capacity.
Do not infer model/VRAM, multi-GPU availability or resource leases. Apply
dependency-resource-scheduling.md before placement and local-code-handoff.md's
pre-run calibration obligations on the selected execution host before full dispatch.
The active executor may adjust approved development
settings inside their finite envelope and version pending plans; frozen confirmation
and complete comparison obligations remain separate.
Keep native-only benchmark compatibility separate from software installation and
scientific qualification. A Conda rewrite of a Docker command alone establishes
neither scorer parity nor benchmark readiness.

Before freezing, review whether the native metric measures the claim, the baseline
is competitive, the contrast separates explanations and the feasible precision
allows a decision. Use independent reviewer contexts/human review when authorized
and available; label a same-context self-review accurately. Unresolved omissions
remain named obligations. Reconcile this card with the existing Gate A protocol,
not a replacement free-form verdict. Missing prerequisites block only stages
that actually depend on them. Restore supported delayed scoring before deciding:
independent training/export may proceed with its real data/code/protocol/resource
requirements satisfied, while final scoring and empirical verdicts remain pending.
A scorer used for reward, filtering or model selection is a genuine dependency
of that operation; do not silently remove it.
Readiness is task- and dependency-scoped: one candidate's failed acceptance does
not hold every other candidate. After bounded supported repair is exhausted,
retain that task/benchmark as incomplete and continue independent qualified work;
never count the omitted evidence as PASS, refutation or complete validation.

Report design reliability through inspected prerequisites and explicit remaining
obligations, not through the names of skills read. Show sample/cohort identity,
qualified baseline and native-scoring evidence, cost/VRAM timing basis and which
controls can isolate the claim. If any essential item is absent, label the affected
experiment a design draft or blocked/conditional design; do not release it as a
fully ready end-to-end evaluation queue or claim G01 complete. Admit a separately
identified training/export stage when its own dependencies are satisfied, keeping
scoring pending rather than pretending the whole pipeline has been qualified. A source-reading checklist
alone establishes neither successful execution nor reliable scientific evidence.
Planned work can lack future candidate run receipts; this is not a requirement to
have run an experiment before designing it. Keep bounded baseline/evaluator/resource
calibration tasks separate from method tests and confirmation. Their own source,
resource and authorization dependencies must be satisfied. Estimate a new method's
cost transparently and schedule an eligible bounded calibration after its scientific
prerequisites, rather than presenting unmeasured throughput as an observation.

Reduce scope, models or prospectively sampled official development cases to fit
resources; preserve the task, fair comparator and indispensable control. If those
cannot fit, report INCONCLUSIVE or pause investment rather than weakening the
comparison. Leave broader generalization, boundary and replication obligations
explicit for V. Eval-unit and mechanism evaluation checks use existing benchmark
cases/tests, native scoring and actual run records. Never create synthetic eval
cases or replacement benchmarks, including for eval debugging. Keep ordinary
non-evaluation engineering tests separate. A pilot is not a complete conference
validation.

Official calibration sources, checked 2026-10-03:
- https://neurips.cc/Conferences/2026/ReviewerGuidelines (Quality, Significance, Originality).
- https://neurips.cc/public/guides/PaperChecklist (claims, reproducibility, settings, uncertainty and compute).

## V01 Claim-to-experiment matrix

Carry the current importance/originality review and benchmark readiness from
[research-quality-bar.md](research-quality-bar.md). Every empirical central claim
needs a credible existing task/evaluator mapping. Never create hand-made eval
diagnostics, datasets or tasks to supply missing evidence; pause the blocked check
or retrieve appropriate existing assets.
Recheck substantive novelty after claim/method changes before expensive expansion.

For each central claim record its type, target population, strongest anti-claim,
minimum evidence, comparator/control, split/unit, metric/uncertainty, protocol,
cost, run order, result locator, supported scope and unresolved obligation.
Prioritize decision-changing evidence before showcase experiments. Reuse valid
existing evidence with an explicitly retrospective audit; don't relabel it
prospective. New experiments close named obligations rather than fill a checklist.

## V02 Baselines and repeats

Include strongest relevant published and simple/training-free alternatives with
qualified implementations and fair tuning/information/compute. Explain exclusions.
Select repetitions and sample size for the estimand, variance/precision and budget;
three seeds is not a universal law. Identify independent unit, paired structure,
training/decoding randomness, all runs and uncertainty calculation. An aggregate
without a denominator or qualified scorer does not close a claim.
Bind exact native evaluation contracts per benchmark/group, per-arm receipt
inventories, and live scorer/harness parity checks using
[native-evaluation.md](native-evaluation.md). Same metric name across tasks does
not imply the same scorer, sample denominator or budget. Every frozen criterion
uses only its own group's native results.

## V03 Mechanism, ablation and replacement

Test each component's responsibility, competing causal explanation and simpler
replacement. Adding parameters/search/information can explain an apparent gain.
An A vs A+B ablation does not identify B alone or an A×B interaction. Use the
appropriate factorial/substitution controls when claiming complementarity. Keep
negative/null controls and failure cases visible. Observed association is not
automatically a causal mechanism.

## V04 Generalization and boundaries

Choose model/data/task/scale/time/condition axes tied to scope claims; don't require
an arbitrary full Cartesian product. Use genuinely independent conditions and
freeze choices before confirmation. Inspect worst groups, drift, long tails and
failure regimes when material. Record unknown boundaries and narrow wording to
tested conditions. New broad claims need additional evidence.

## V05 Quality, cost and failures

Measure actual task endpoint alongside latency/memory/tokens/API/energy or training
cost when claimed. State warmup, batching, hardware, cache and throughput vs latency.
Analyze naturally sampled failures with denominator, consequence and competing
causes. Distinguish measurement error, implementation invalidity and valid adverse
evidence. Central unfavorable evidence belongs in the main explanation, even if
details go in the appendix. All failed exploration contributes to total resources.

## V06 Statistical audit and evidence freeze

Check selection bias, dependence, missing/unscored samples, multiple comparisons,
uncertainty source and appropriate analysis. No blanket p-value or n threshold.
Audit raw-to-table calculations and claims before freezing evidence identity.
Every claim receives supported/partial/unsupported/contradicted plus scope, locator,
uncertainty and next action. Freeze the complete package; retain negative/unselected
runs. NeurIPS checklist is a current reporting reference: scope, limitations,
assumptions/proofs, reproducibility, tuning, uncertainty and per-run/total compute.
It is not a publication guarantee. Feed W with allowed and forbidden statements.
Execute the frozen independent-unit/multiplicity policy in
[statistics-and-claims.md](statistics-and-claims.md). Unsupported dependent designs
need a trusted live project analysis adapter. Close each claim against its own
passed eligible runs and native proof refs, not a generic source or another claim's
result. Freeze supported wording, scope, limitations and implementation/project
versions. Changed evidence requires a new anchored decision/closure before writing.

## R01 Submission package

Resolve current venue/year/track/stage rules from official sources. Check page
limits/template/anonymity, abstract/author list/conflicts, data/code attachments,
ethics/disclosures and PDF consistency only as applicable. Produce a reviewable
package with version/digest and a submission checklist. Actual upload/final submit
uses the named account and authorization; record real portal submission ID,
timestamp/status/version. A prepared PDF is not a submission receipt.

## R02 Independent review and issue ledger

When multi-agent/model review is requested or appropriate, give independent
reviewers the same manuscript/evidence snapshot and no prior consensus. Assign
scientific claims, math, evaluation, implementation and presentation scopes; retain
all reports and dissent. Model diversity alone does not prove independence.
Each issue needs manuscript/evidence locator, factual premise, consequence,
confidence and feasible remedy. Distinguish unreported from unperformed.
Human subject experts adjudicate material technical disagreements; AI reviewers
can request checks but cannot validate experiments by voting. No compulsory
review-until-high-score loop. Review scope/budget and actual model identities are
recorded; unavailable reviewers remain unavailable.

## R03 Rebuttal priorities

Map reviewer IDs and every issue to factual correction, explanation, missing
evidence, method defect, novelty collision or scope preference. Inspect the
premise before agreeing. Rank by likely decision impact, existing evidence,
discussion window and authorized resources. Draft concrete answers first; run
only informative, feasible supplement experiments with real scope. Preserve
original submission evidence and label post-review results/version separately.

## R04 Response and revision

For each issue answer directly, give verified evidence/locator, clarify uncertainty,
and state exact manuscript change if made. Never claim a planned experiment was
performed. Maintain issue → response → evidence → change-location mapping and
respect current response format/limits/anonymity. A shared editor reconciles
conflicting model drafts against evidence; a human confirms author-only facts.
Keep response, manuscript, tables and released code consistent.

## R05 Decision, retargeting and final version

Record actual decision and grounds. Accept, retarget, repair, pause or stop according
to evidence and human goal. A template-only retarget does not restart trustworthy
experiments; a changed central claim/problem reopens affected obligations. For
camera-ready verify author/venue/copyright/disclosure rules and final cross-asset
version links. Archive the submitted and accepted snapshots independently.
