"""Host integration checks. Fixtures do not establish mathematical correctness."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

S=Path(__file__).resolve().parents[1]/'scripts'
sys.path.insert(0,str(S))

class HostReasoningIntegration(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
    def module(self,name):
        path=S/(name+'.py')
        if not path.exists():self.skipTest('Other edition host adapter is not bundled')
        spec=importlib.util.spec_from_file_location(name+'_integration',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
    def ref(self,name,text):
        p=self.root/name;p.write_text(text);return dict(path=name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    def test_tagged_method_rejected_by_actual_task_intake(self):
        bad=self.ref('bad.json',json.dumps({'math_verified':True}))
        if (S/'simple_runner.py').exists():
            m=self.module('simple_runner');r=m.SimpleRunner(self.root)
            task=dict(task_id='method',argv=[sys.executable,'-c','print(1)'],phase='code',purpose='test',timeout_seconds=1,
                      research_scope='method',reasoning_ref=bad,input_refs=[bad])
            with self.assertRaisesRegex((m.RunnerError,ValueError),'reasoning|trace|decision'):
                r._tasks({'tasks':{}},[task],{'status':'active','active_idea':'candidate','revision':1})
        else:
            m=self.module('chat_cycle')
            task=dict(id='method',action='implement candidate',candidate_id='candidate',research_scope='method',reasoning_ref=bad,input_refs=[bad])
            with self.assertRaisesRegex(ValueError,'reasoning|trace|decision'):m._task(self.root,task)
    def test_simple_family_feedback_survives_new_hashes_and_issue_names(self):
        m=self.module('simple_loop');loop=m.SimpleLoop(self.root);loop.initialize('candidate','goal',max_repairs=3)
        for i in range(4):
            ref=self.ref('repair%d.txt'%i,'new actual bytes%d'%i)
            event=dict(event_id='e%d'%i,kind='implementation_error',issue='new-issue%d'%i,family_id='stable-family',reason='repair',change_evidence=[ref],evidence=[ref])
            state=loop.record(event,loop.status()['version'])
        self.assertEqual(state['phase'],'analysis')
        self.assertEqual(state['research_family_effort']['stable-family']['feedback_total'],4)
        self.assertTrue(state['research_family_effort']['stable-family']['review_due'])
        self.assertEqual(state['status'],'active')
    def test_simple_snapshot_contains_math_and_checker(self):
        m=self.module('_simple_source')
        for name in ['references/math-handoff.md','references/math-operation-graph.md','references/research-reasoning.md','scripts/research_reasoning.py']:
            self.assertIn(name,m.SOURCE_FILES)
        self.assertTrue(hasattr(m,'PRE_REASONING_SOURCE_FILES'))
    def test_chat_task_preserves_explicit_reasoning_scope(self):
        m=self.module('chat_cycle')
        t=m._task(self.root,dict(id='diagnostic',action='collect missing evidence',candidate_id='candidate',research_scope='diagnostic'))
        self.assertEqual(t.get('research_scope'),'diagnostic')
    def test_chat_preserves_github_only_cooperation(self):
        if not (S/'chat_cycle.py').exists():self.skipTest('Chat-only policy')
        text=(S.parent/'references/project-cooperation.md').read_text().lower()
        self.assertIn('github',text);self.assertIn('same github account',text)
    def test_both_entries_require_trajectory_without_48_move_quota(self):
        text=(S.parent/'SKILL.md').read_text()
        self.assertIn('research-reasoning.md',text)
        math=(S.parent/'references/math-handoff.md').read_text()
        self.assertNotIn('about 20 qualified candidates',math)
        self.assertIn('mathematical_trace',math)

if __name__=='__main__':unittest.main()
