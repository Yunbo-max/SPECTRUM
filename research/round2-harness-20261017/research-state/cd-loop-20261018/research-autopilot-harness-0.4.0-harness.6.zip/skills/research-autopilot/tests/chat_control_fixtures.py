"""Sourced synthetic contracts for old Chat behavior tests.

These records exercise guards, never establish scientific qualification, actual
reviewer independence, provider authentication or measured research consumption.
The numerical usage is explicitly simulated; original execution/science fixtures
retain their own real output and independent admission assertions.
"""
import copy
import hashlib
import json
from pathlib import Path
import uuid


class ChatControlFixture:
    def __init__(self, root, module=None):
        self.root = Path(root)
        self.module = module
        self.sequence = 0
        self.invocation_id = 'test-invocation-' + uuid.uuid4().hex
        self.scopes = {}
        self.qualifications = {}
        self.context = None
        self.source = self.write('source', 'Synthetic engineering fixture scope, policy, '
            'execution and review evidence only. No real scientific or resource claim.')
        if module:
            self.context = module._science_module('chat_session').host_invocation(self.invocation_id)
            self.context.__enter__()

    def close(self):
        if self.context:
            self.context.__exit__(None, None, None)
            self.context = None

    def write(self, label, value):
        self.sequence += 1
        path = self.root / ('control-' + str(self.sequence) + '-' + label + '.json')
        path.write_text(json.dumps(value, sort_keys=True))
        return dict(path=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest())

    def configure(self, config):
        self.config = copy.deepcopy(config)
        if (config.get('goal_contract') or {}).get('mode') != 'research':
            return config
        self.goal_id = config['goal_id']
        self.scopes = {}
        self.qualifications = {}
        limits = dict(max_attempts=100, wall_seconds=100000, gpu_seconds=100000, cost=100000)
        strategy = dict(kind='chat_research_strategy', goal_id=self.goal_id,
            request_ref=config['goal_contract']['request_ref'], source_ref=self.source,
            obligations=[dict(id='original-goal', description='Synthetic original fixture obligations',
                priority='required', criterion_ids=config['criteria'], delivery_ids=config['deliveries'])],
            families=[dict(id='fixture-family', mechanism='Synthetic structural engineering mechanism',
                mechanism_ref=self.source, diagnostic_limits=limits)],
            limits=dict(max_no_progress_attempts=100, max_diagnostic_attempts=100,
                diagnostic_wall_seconds=100000, diagnostic_gpu_seconds=100000, diagnostic_cost=100000))
        config['strategy_ref'] = self.write('strategy', strategy)
        config['session_contract'] = dict(package_id='synthetic-test-skill', release='engineering-fixture',
            source_revision='synthetic-fixed-source', destination='test-project-fixture',
            required_source_refs=[config['procedure']['ref'], self.source], max_unsaved_revisions=1000)
        config['tasks'] = [self.task(task) for task in config['tasks']]
        return config

    def task(self, task):
        task = copy.deepcopy(task)
        if not hasattr(self, 'goal_id'):
            return task
        candidate = task['candidate_id']
        if candidate not in self.scopes:
            scope = dict(kind='chat_research_scope', candidate_id=candidate, claim_kind='comparison',
                implementation_ref=self.source, protocol_ref=self.source, default_parameters_ref=self.source,
                baselines=[dict(implementation_kind='qualified_port', implementation_ref=self.source,
                    protocol_ref=self.source, default_parameters_ref=self.source)],
                limitation='Synthetic source bindings exercise structural guards; no science qualification claim')
            self.scopes[candidate] = self.write('scope', scope)
            self.qualifications[candidate] = self.write('qualification', dict(
                kind='chat_research_qualification', goal_id=self.goal_id, candidate_id=candidate,
                family_id='fixture-family', scope_ref=self.scopes[candidate],
                proposal_task_id='fixture-proposal', review_task_id='fixture-review',
                execution_ref=self.source, raw_evidence=[self.source], checks={
                    name: dict(verdict='known_comparison' if name == 'nearest_work' else 'verified',
                        evidence_refs=[self.source], finding='Synthetic engineering fixture only')
                    for name in ('source', 'baseline', 'nearest_work')}))
        kind = task.get('kind', 'action')
        purpose = ('acquire' if kind == 'preflight' else 'analysis' if kind != 'research_experiment'
                   else 'main_evidence' if task.get('experiment_phase') == 'confirmation' else 'diagnostic')
        task['intent_ref'] = self.write('intent', dict(kind='chat_task_intent', goal_id=self.goal_id,
            candidate_id=candidate, family_id='fixture-family', obligation_ids=['original-goal'],
            purpose=purpose, decision='Observe fixture behavior for task ' + task['id'],
            falsifier='A mismatch in the original regression assertions rejects this engineering fixture',
            scope_ref=self.scopes[candidate], estimate=dict(wall_seconds=1, gpu_seconds=0, cost=0)))
        return task

    def bootstrap_event(self, state):
        contract = state['session_contract']
        receipt = dict(kind='chat-session-bootstrap', project_uuid=state['session']['project_uuid'],
            host_invocation_id=self.invocation_id, procedure=state['procedure'],
            read_source_refs=contract['required_source_refs'], observation_ref=self.source)
        for key in ('package_id', 'release', 'source_revision'):
            receipt[key] = contract[key]
        return dict(op='session_bootstrap', receipt_ref=self.write('bootstrap', receipt))

    def activate(self, path):
        state = self.module.status(path)
        if (state.get('goal_contract') or {}).get('mode') != 'research':
            return state
        self.module.record(path, state['revision'], self.bootstrap_event(state))
        for ref in self.qualifications.values():
            state = self.module.status(path)
            self.module.record(path, state['revision'], dict(op='strategy_qualify', qualification_ref=ref))
        return self.module.status(path)

    def qualify_new_candidates(self, path):
        state = self.module.status(path)
        if not state.get('strategy'):
            return
        for ref in self.qualifications.values():
            if ref not in state['strategy']['qualifications']:
                state = self.module.record(path, state['revision'], dict(op='strategy_qualify', qualification_ref=ref))

    def usage(self, attempt_id, raw_evidence=None):
        totals = dict(wall_seconds=1, gpu_seconds=0, cost=0)
        receipt = self.write('usage', dict(kind='chat_strategy_usage', attempt_id=attempt_id,
            totals=totals, terminal=True, raw_evidence=raw_evidence or [self.source],
            observation_kind='explicitly simulated engineering test usage'))
        return dict(totals=totals, receipt_ref=receipt)

    def migrate_research(self, path):
        """Explicitly adopt controls after the old test extends a bounded scope."""
        state = self.module.status(path)
        config = self.configure(copy.deepcopy(state))
        historical = [dict(attempt_id=a['id'], family_id='fixture-family', diagnostic=False,
            reservation=dict(wall_seconds=1, gpu_seconds=0, cost=0), reservation_source_ref=self.source,
            usage=self.usage(a['id'], [a['evidence_ref']])) for a in state['attempts']]
        review = self.write('migration', dict(kind='chat_strategy_adoption', goal_id=state['goal_id'],
            strategy_ref=config['strategy_ref'], previous_strategy_ref=None,
            attempt_ids=[a['id'] for a in state['attempts']], historical_attempts=historical,
            proposal_task_id='fixture-migration-proposal', review_task_id='fixture-migration-review',
            execution_ref=self.source, raw_evidence=[self.source], reason='Explicit test scope extension'))
        self.module.record(path, state['revision'], dict(op='strategy_adopt',
            strategy_ref=config['strategy_ref'], review_ref=review))
        state = self.module.status(path)
        self.module.record(path, state['revision'], dict(op='session_policy',
            contract=config['session_contract'], source_ref=self.source, reason='Explicit test scope extension'))
        return self.activate(path)
