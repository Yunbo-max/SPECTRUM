# One experiment at a time; descending batch calibration

Apply this when designing, preparing, dispatching or resuming experiments. It takes
precedence over inherited parallel-experiment and same-device-sharing guidance.
Main/Work/Simple apply it on the actual authorized execution target, including an
existing SSH GPU server. Chat applies serial CPU execution within its total
4,000,000,000-byte planning ceiling or lower observed availability; this policy
adds no GPU, SSH or local-agent route to Chat. Use native environments everywhere.

## One active experiment program

The project runs one experimental workload at a time, including batch calibration,
baselines, method trials, seeds and standalone scoring. Queue these sequentially
across the project's devices and hosts. A program's data-loader workers, native
subprocesses and supported distributed ranks belong to that same bounded job;
this is not a literal one-OS-process restriction. A wrapper program must not run
multiple independent seeds/methods in parallel to bypass the one-experiment rule. They share its resource budget
and must not launch independent competing experiments. Use multiple GPUs only
for that one program when already allocated and justified by the actual workload.

Reading, code work and independent CPU data preparation may overlap within measured
CPU/RAM/I/O limits without starving the experiment. A standalone GPU scorer or
locally hosted GPU agent also competes for the selected allocation: queue it until
the experiment has settled. Reconcile existing jobs, including unknown remote jobs,
before dispatch; SSH disconnection or a missing heartbeat does not free the slot.
Preserve unrelated users' jobs and active source pins. Adopt changed limits at an
authorized quiet boundary, never by editing a live plan or killing existing work.

Use the selected runner's implemented controls. For new native harness plans set
`limits.max_parallel_tasks: 1`, `gpus.max_tasks_per_gpu: 1` and each task's
`resources.allow_gpu_share: false`. For a Simple runner use the existing budget's
`max_concurrency: 1`. A single project coordinator must also serialize experiments
across separate plans/runners/hosts; per-plan limits do not enforce project-wide
ownership. With direct SSH or Chat tools, await/reconcile the previous actual job
before starting the next. These settings do not constrain unrelated host jobs.
Do not invent a new universal runner flag or claim prose enforces allocation.

## Try supported batches from large to small

Before a substantial run, inspect the native entry point and available batch knob,
actual target capacity, previous profiles, representative inputs and allowed tuning
budget. Reuse an unchanged qualified profile when available. Otherwise choose a
finite descending list within the supported range, for example
`64 -> 32 -> 16 -> 8 -> 4 -> 2`. This is an example: skip unsupported values or sizes
already ruled out by trustworthy workload/capacity evidence. Batch 1 or another
native value is allowed if necessary and supported; a larger upper bound needs a
credible resource estimate and remaining allowance. No fixed six-attempt quota.

Run one short, bounded development probe at a time using real representative data
and worst permitted shapes/lengths. Include the workload's transient and steady
state: training includes backward, optimizer state/step and checkpoint peaks;
inference includes permitted output lengths/cache and export. Record the exact
command/config, batch, accumulation, data/model versions, shapes, elapsed time,
useful samples/tokens per second, peak RAM/VRAM, device utilization, headroom and
OOM/error outcome. Charge all calibration attempts to the existing budget.

On OOM or inadequate headroom, retain the failure, stop/reconcile that attempt and
its owned children, release its actual resources, and restore declared model,
optimizer, RNG and input state before trying the next smaller candidate. Never
reset the whole GPU or kill other users' processes. A non-memory error needs its
actual diagnosis; reducing batch is not a generic repair. If no permitted setting
qualifies, retain the resource/implementation gap and replan within scope.

Start with the largest candidate and step down until a stable feasible setting is
qualified. Stop there when useful throughput is satisfactory; do not run every
smaller size merely to complete the list. If measurements show stalls, insufficient
headroom or a possible throughput penalty, compare a bounded number of lower
candidates. Prefer a large stable batch when performance is comparable; retain a
smaller setting when it measurably completes useful work faster or more reliably.
Tune supported loader/prefetch controls within the same CPU/RAM/I/O budget to keep
the GPU productively busy. Aim for high useful utilization with measured headroom;
VRAM occupancy alone does not establish performance or justify another experiment.
Freeze the selected settings/profile for the full run. Requalify changed workload,
shape, environment or capacity identities; do not retune frozen confirmation on
inspected outcomes. Retain failures and selected-setting rationale in existing
plans/receipts, without a new mandatory database or strict-schema extension.

## Preserve the scientific comparison

Determine whether the knob is operational microbatch/inference batching or the
scientific batch hyperparameter. Change an operational microbatch only when the
native accumulation/loss implementation preserves the planned effective batch,
optimizer updates, learning-rate schedule, data/sample weighting and protocol.
For equal-sized batches, effective batch is microbatch per rank times accumulation
steps times world size; handle uneven/token-weighted batches explicitly. A larger
microbatch may be invalid when the fixed effective batch cannot be preserved.
Batch-dependent layers, cross-example losses or RNG changes may also alter the
method despite equal effective batch. Treat those changes as a design revision.

Keep precision, sequence limits, seeds, dataset/split/cases, sample counts,
decoding and native scoring fixed unless the research plan explicitly changes them.
Preserve case identities and per-case randomness during inference batching. Apply
comparable tuning allowances to methods and strong baselines, include tuning costs,
and separate resource failures from scientific negative findings. A larger batch
or busier GPU is not evidence that the research method improves the native metric.
