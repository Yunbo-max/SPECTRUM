# Fixed research workflow and generation harness

Local means the control agent on the user's computer. Before execution restore
the authorized SSH GPU route and choose the workload target under local-execution.md;
sync the pinned code there and monitor/collect its real results. No Docker anywhere.


Retain the selected field and cumulative knowledge under research-cycle.md. A failed
candidate invalidates only the supported scope of its claim. Before replacing it,
consider missing reading, baseline reproduction and causal diagnosis; all are valid
next actions. An in-field successor does not reset evidence or budgets. Use this
edition's host and decision ownership from edition-policy.md.

Current edition and continuation: read [edition-policy.md](edition-policy.md) and
[round-continuation.md](round-continuation.md) first. They supersede older host,
human/machine selection and manual-resume defaults in examples below.

## Edition route and restoration

Use local-execution.md and edition-policy.md for this edition. Work/Simple
supervise local or authorized SSH jobs from the local agent; main retains human scientific direction and Web/local handoffs.
Scientific modules specify evidence requirements. Restore the field, accumulated
knowledge, goal, versions, question, attempts, artifacts and remaining bounds.
Use current pinned skill modules and re-read only changed or newly needed parts.
Reuse supplied destinations and authorizations. Do not restart intake or repeat
passed checks because a new message arrived. Record explicit changed protocols.

## Action loop

For Work Harness and DSH Harness, [skill-sequence.md](skill-sequence.md) owns the
canonical node order and acceptance. Interpret all routing below as work within
the currently assigned node; it never grants a model the next-node cursor.

For each action: identify the observable output and actual capability; execute
with a real host tool; inspect outputs/errors; classify evidence; save the
checkpoint; submit the current node for separate acceptance. Code assigns its
successor only after acceptance. A route/ticket is not execution.
Milestone reporting does not end an unfinished goal. Poll actual in-flight jobs
by returned identities with bounded waits while doing independent ready work.

When a requirement is absent, perform the earliest concrete source, baseline,
diagnostic, derivation, acquisition or review action that can obtain it.
Do not require a final method gate to run the baseline needed to establish it.
Candidate investment and final claims retain their applicable evidence.
Missing evidence blocks descendants, not every task. Each retry addresses a
recorded cause; repeated no-progress actions replan or record a real blocker.

## Host execution and evidence levels

| Stage | Evidence | Does not establish |
|---|---|---|
| Source/derivation | Primary sources, explicit assumptions, consequential steps, review | Empirical benefit |
| Candidate selection | Actual card, semantic review, reasons and originality comparison | Code correctness |
| Authored code/design | Complete implementation/design, exact versions and source review | Execution |
| Executed check | Actual command/tool receipt, current-attempt outputs, versions and logs | Broad effectiveness |
| Scientific finding | Native comparisons, relevant E04, scoped independent review and uncertainty | Wider claims |
| Goal delivery | Requested outcomes' acceptance evidence and actual delivery readback | Unrequested future work |

Run feasible authorized code/checks here after inspecting capabilities and
untrusted code. Preserve native data/splits/scoring/comparison semantics.
No Docker, assumed GPU, new paid service or invented credentials.
Missing scorers/reviewers create specific claim obligations. Other work and
complete labelled code/design drafts may continue. Restore and read the runbook for an existing authorized SSH target. Read optional
full-runtime setup only when that runtime is selected.

## Candidate and method boundaries

Default to one candidate. Record pool_target=1, selection_target=1 and the
explicit edition target_override in the real batch and matching selection
packet. Keep mathematical, semantic and selection evidence. A broader pool is
an intentional mode. Restore qualified pools without silently changing targets.

Use verify_methods.py on actual records at applicable boundaries: --before code
checks selection; --before experiment-design checks code before executable
acceptance; --before dispatch checks design; --before verdict checks canonical
outcome evidence. Authored design may precede executable acceptance. Checkers
cannot create measurements, grant authority or prove arbitrary mathematical truth.

Complete G01 for the agreed scope before its empirical queue. Preserve agreed
comparisons; developmental subsets support only their stated scope. Keep frozen
confirmation fresh and separate from development. Gate A PASS is not a full-paper
claim. Apply E04 before verdicts to implementation, semantics, baseline/scoring
correctness and relevant sensitivity.

## Feedback and closure

Environment/configuration errors route to setup; derivation defects to math;
implementation/scorer defects to repair; evidence gaps to collection/review;
valid refutation to recording the scoped failure and supplying the reading,
reproduction or diagnosis needed by the current node. Retain successor hypotheses
as scientific evidence; program code controls when their prescribed steps run.
Canonical KILL recovery requires the decision-bound payload in autonomous-rsi.md.
Explicit project stop and old terminal records are not silently reopened.
Rebuild affected pending consumers against actual replacement artifacts, keeping
live input pins unchanged. Preserve partial outputs on acknowledged length limits.
Reconcile original operations before retrying uncertain side effects.

Save artifacts and the workflow checkpoint at material changes and before
yielding. Optional chat_cycle.py provides revision-checked action bookkeeping;
it is not a scientific ledger, executor or wakeup service. On continuation,
reconcile real operations/versions and perform the saved unfinished action.
Only program rules close or repeat the accepted sequence. User stop, exhausted
limits and genuine blockers retain their own states and cursor. Positive/no-gap
feedback alone is not acceptance or completion.
