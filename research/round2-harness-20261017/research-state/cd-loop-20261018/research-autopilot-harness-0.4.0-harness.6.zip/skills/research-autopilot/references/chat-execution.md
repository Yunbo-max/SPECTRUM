# Shared execution and recovery mechanics

Local means the control agent on the user's computer. Before execution restore
the authorized SSH GPU route and choose the workload target under local-execution.md;
sync the pinned code there and monitor/collect its real results. No Docker anywhere.


Current edition and continuation: read [edition-policy.md](edition-policy.md) and
[round-continuation.md](round-continuation.md) first. They supersede older host,
human/machine selection and manual-resume defaults in examples below.

## Edition and precedence

This is a reusable execution/recovery reference. The active edition's host and
decision ownership are defined in edition-policy.md and local-execution.md:
Work/Simple execute through a local agent; main uses Web GPT, local execution
and human scientific direction. Chat-named helper records below remain compatible
bookkeeping, not a requirement to move this project into Chat or Work.

Read this contract and autonomous-rsi.md on each actual invocation, reusing
unchanged pinned source captures when accessible, then load only the current
action's applicable evidence modules. Record the source/plugin version actually
available, the procedure actually adopted by this project and any scheduled
instruction version separately. A copied old prompt is not proof the plugin
loaded. Read an authorized pinned project procedure when the installed skill is
missing; otherwise retain the specific capability gap. Never claim a newer
installed version from a repository push. This
edition follows its own human/machine decisions and local execution role.
Existing authorized SSH routes are restored and reused; separate full-runtime
setup applies only when that runtime is selected.
Detailed scientific modules retain their evidence meaning, not their obsolete
executor assignment or candidate quota. Preserve valid existing project contracts;
record an explicit changed policy before changing an already frozen protocol.

Installation supplies instructions/resources, not a background lifecycle. Do not
create another host or paid service as a fallback. Use a supported same-host
continuation task under round-continuation.md for an authorized active goal. Use the actual authorized local host for maintenance.
Account limits, permissions and real tool capabilities still apply.

The owner also requires operational anomalies, including unavailable CPU, to be
reported. Follow [incident reporting](chat-incident-reporting.md) using host-native
output independently of the failing Python/tool path. An actually configured,
authorized background invocation must report the fault in its own result even
when no experiment can start. A saved outbox is not delivered notification, and
the skill cannot run a monitor while the host/scheduler is inactive. Preserve a
user pause while adding reporting or reconciling earlier work.

## Preserve the requested goal

Record the original user request and relevant later steering with their actual
conversation/artifact source. Keep the project goal, its acceptance obligations
and the current milestone separate. The optional helper stores goal_contract
with mode=research or bounded_task, request_ref={path,sha256} for the saved request,
and continuation_action for the concrete next authorized work. A hash binds saved
bytes; it does not prove user authority or replace reading the source request.

If the user authorizes ongoing autonomous research, use research. CPU feasibility
is a milestone, not a substitute goal. After it passes, continue source/native
baseline verification, a falsifiable hypothesis and mathematical justification,
an executed comparison, review and the evidence-driven next decision. Preserve
remaining obligations after positive or negative results. One candidate at a
time limits concurrent focus, not the number of research cycles.

If the user asks to only choose a runnable paper, reproduce a stated result,
audit an artifact or produce code without execution, use bounded_task with that
scope's actual criteria. Do not expand that request into autonomous research.
The plugin name alone is not evidence that new hypotheses or a paper are wanted.
When earlier context already authorizes continuing research, a short request to
find the next feasible paper is a milestone within that goal. Preserve that
context instead of treating the latest sentence as a narrower replacement.

Before completed, perform an explicit goal_review against the sourced request,
all acceptance obligations and delivery evidence. A research goal also needs
evidence-bound scientific cycles as defined in autonomous-rsi.md; run counts or
preflight alone cannot supply them. A completed cycle does not itself complete
the goal. The helper records these checks but cannot certify their scientific
truth. Missing tasks call for a concrete continuation plan and execution, not
an automatic conclusion that every remaining obligation is blocked.

For an incorrectly narrowed saved goal, preserve the old goal, results and stop
record, then append a sourced correction with revise_goal before continuing.
Retain cumulative usage, failures, attempts and existing valid evidence. A truly
completed bounded request followed by newly authorized research is an explicit
scope extension, not a fabricated earlier research cycle. Explicit user stops
remain stops until the user actually authorizes continuation.
If the earlier bounded task had no research budget, carry forward its observed
usage without inventing or backdating a research allowance. Establish prospective
working limits for the newly authorized scope and retain their real source.

## Finite active-turn loop

1. Restore the current project, requested outcomes, artifacts, candidate,
   procedure revision, real running operations and cumulative limits. Check
   existing state before planning; do not ask again for supplied destinations.
   A missing optional HF destination or a classification label does not block
   useful investigation. Ask only when a missing choice affects an actual action.
2. Compare ready actions against the remaining goal, unresolved predictions and
   critical dependencies using [research decisions](chat-research-decisions.md).
   Select the next feasible parent action, why it changes a decision and its
   observable output; do not simply choose the first convenient pending task. Check the
   required tools/data/runtime and current subagent capacity. Where useful,
   select an independent ready wave under that action using
   [Chat parallel work](chat-parallel-work.md); one candidate may have several
   readers, disjoint implementers or admitted experiment jobs. Keep dependent
   work ordered and one coordinator for integration. Derive finite packet bounds
   from remaining project resources without inventing measured usage or charges.
3. Execute the action or wave using the current host's actual tools. Writing a plan,
   setting next_action or emitting a status sentence is not execution.
   Poll an actual in-flight operation by its returned identity, at bounded
   intervals; do independent ready work while waiting. Bind each actual child
   identity before treating it as running. A queued task is not lost; an unknown
   state requires reconciliation, not a duplicate dispatch.
4. Inspect actual outputs, command errors and evidence, integrate accepted child
   artifacts against their pinned inputs, then classify the parent result
   using the feedback table below. Immediately report a newly observed operational
   anomaly through the live host's user-facing channel; do not wait for a repair
   or successful CPU checkpoint to make it visible. Retain its delivery status
   under [incident reporting](chat-incident-reporting.md). Dispatch the resulting repair/review/next
   action in this same turn when feasible. A subtask finish or progress report
   does not end the whole goal. Do not finish merely with an offer to continue.
5. Persist coherent artifacts, versions, failure evidence and the exact next
   action after a milestone, before risky/long operations and before yielding.
   Verify the actual save/readback. Continue from step 2 while eligible work and
   budget remain; do not repeatedly reload the whole skill or recheck unchanged
   evidence. A no-progress cycle must change the action or record a real blocker.

Preserve the source of every binding cumulative limit. A per-command timeout or
finite action batch is not a new whole-project budget. Do not reset or invent a
one-round budget on resume. Reports, successful preflight and a single candidate
decision are not budget-exhaustion events. If a real host boundary interrupts
work, record continuation_pending and the exact next action rather than completed.

Close the goal only when every requested outcome has its required evidence and
delivery receipt, the owner stops, a binding cumulative limit is reached, or all
remaining work is genuinely blocked. These are different stop reasons:
completed, user_stopped, budget_exhausted, needs_user, capability_blocked,
continuation_pending, or last_run_unknown. A host interruption can prevent the
last checkpoint; reconcile the last durable state on return. Missing observability
never proves either current activity or successful completion.

Select actions using [research decisions](chat-research-decisions.md). Carry
forward missing main-task coverage, qualified baselines, critical blockers,
hypothesis/family evidence, independent review and deliveries. Apply the declared
stagnation and diagnostic bounds before another campaign of the same family.
Neither an available task nor a valid record establishes that the task is worth
the next investment. Valid refutations and dependency recovery count as progress;
more runs or a new stage number do not establish it.

## Feedback and repair

| Observation | Next action | Evidence retained |
|---|---|---|
| Environment/setup/access fault | Repair the available environment or choose an authorized feasible dependency/path; block only affected work | Exact command/error, capability gap and attempted repair |
| Invalid task/configuration | Correct the not-yet-dispatched contract; preserve original rejection; reconcile any partial registration | Old/new contract identities and rejection |
| Mathematical defect | Repair the specific assumption/step or reject that construction | Failed step, counterexample, revised derivation and review |
| Implementation/scoring defect | Fix the affected version and rerun meaningful checks before interpreting efficacy | Old/new code, logs and affected protocol |
| Missing data/control/precision | Perform a concrete acquisition/control/replication task, or narrow an explicitly versioned claim | Missing predicate and next check |
| Valid counterevidence | Identify the claim and conditions actually refuted; select focused reading, reproduction, diagnosis or a justified in-field revision under edition decision ownership | Scoped finding, unresolved alternatives and next knowledge/evidence question |
| Positive scoped evidence | Perform the remaining required checks or deliver the supported result | Exact scope, comparisons and limitations |
| Length/context limit with acknowledged response | Preserve partial artifacts and continuation instructions; resume their actual versions | Attempt/session, stop reason, partial evidence and unfinished work |
| Lost acknowledgement/uncertain side effect | Query and reconcile the original operation before any retry | Stable operation identity and last observation |

Infrastructure failures and unqualified outputs are not scientific refutations.
Do not spend scientific failure allowances on them, although their actual time
and usage still count. Bound retries per failure signature; a retry needs an
actionable change. Fixing A as A2 does not make A pass: rebind/recreate pending
consumers to the actual A2 output versions, preserve supersession and revalidate
their inputs. Never silently rewrite a running consumer's pinned inputs.

## One candidate and scoped verification

For new discovery, default to one consequential hypothesis at a time. Read the
primary paper, actual implementation and native protocol relevant to it; derive
the formal object, assumptions, method, prediction and falsifier. Verify that
candidate and its selection before candidate code. Broader discovery is optional
when justified by the question or explicitly requested, not a prerequisite for
every iteration. Reuse qualified pools and unaffected reviews.
This bounds expensive verification, not low-cost parallel reasoning about rival
mechanisms. Before substantial investment, qualify source/default settings and
strong simple controls, review prior-art overlap and define the discriminating
prediction. Acquisition and qualification work can establish missing evidence
without already passing the candidate's final gate. Retire redundant or refuted
families; a rename or another parameter sweep is not a substantive successor.

When using the canonical method checker, record this edition's scope choice in
the real batch: pool_target=1, selection_target=1, with a nonempty target_override
citing the owner's Chat RSI policy and date. Match these counts in the selection
packet. Supply the real mathematical card, semantic review, ranking reasons and
selection review. This field changes the search scope; it is not a science pass
or permission token. Do not fabricate 20 cards or silently mutate an old batch.

Keep four levels distinct: authored artifact; executed check; supported scoped
finding; final requested claim. A source-reviewed draft may be complete while
its execution remains pending. Source review cannot become measured performance.
Run resource checks, published baselines and diagnostic implementation tests to
obtain missing prerequisite evidence; do not require the intended method's final
Gate PASS before the baseline/check needed to establish that gate.

Before empirical candidate execution, follow
[paper-grounded experiment design](paper-grounded-experiment-design.md). Read the
closest primary papers, their appendices and actual configs; retain exact source
locators and reasoned transfer choices. Bind each claim and mathematical prediction
to its necessary comparisons, uncertainty, native evaluation scope and executable
jobs. Cover strong/simple baselines, mechanism, generalization/boundaries,
precision, quality/cost and reproducibility as applicable; explain non-applicability
instead of silently dropping a dimension. One candidate can require many jobs.

Use the experiment contract to carry every required comparison across batches.
Inspect its design and dispatch readiness and the real scientific evidence before
closing empirical obligations. A contract check establishes consistency and
coverage, not scientific truth; canonical native/E04/result verification still
applies. An inconclusive cycle or a review with unresolved essential gaps creates
specific next work and cannot alone close the goal. A valid negative result can
close a suitably scoped question after its required checks; positive results are
not a universal completion requirement. Preserve partial evidence and pending
jobs when resource limits prevent completion.

Use official native data/splits/metrics/scorers for benchmark claims. When an
official scorer is unavailable, first try legitimate source recovery or a
feasible established benchmark. An independently reviewed protocol implementation
may support clearly labelled development observations; it does not establish
official parity or close the existing canonical native verdict. Keep that claim
pending and continue independent work. Never make a benchmark, lower a threshold
or alter holdouts to manufacture a pass.

Use genuinely separate review tasks when available. If independent review is
unavailable, preserve that missing obligation and continue unrelated work.
Self-review is useful diagnosis, not independent acceptance. Scientific
verification must fit the actual claim: a math correction need not run a GPU
benchmark, while an empirical performance claim needs real comparative evidence.

## Host execution and boundaries

At startup/resume, inspect the advertised subagent operations and live child
states when observable. Use available capacity for useful independent work,
without requiring a fixed number of agents or spending a new task merely to
claim capability. The first useful spawn supplies real execution evidence.
Read [Chat parallel work](chat-parallel-work.md) before dispatch. Unsupported
parallelism falls back to serial work; it does not require Local or another
service. Account for shared CPU/RAM/GPU allocations and additive model/device
usage. More agents do not create more hardware or guarantee lower total cost.

Inspect actual CPU/RAM, time, filesystem, network, available libraries and tools
before promising an execution. Within the user's research scope and budget,
the current host may run code/tests, published CPU-compatible experiments,
evaluation and lawful asset acquisition. Inspect untrusted code before running
it. Separate historically owned resources from currently authorized, reachable,
available allocations. Record actual GPU models/counts/free memory, topology,
queue/time limits and source/timestamp; do not turn a previous hardware mention
into an allocation. Measure bounded calibration on the actual target hardware
before full dispatch and account for baselines, tuning, failed exploration,
confirmation, scoring and recovery in the cumulative budget. Do not infer paid
compute authorization from scientific scope.

Restore the existing authorized SSH GPU target and job state before choosing
execution placement. Reuse it without treating it as a new project/permission.
Read local-execution.md, sync the pinned code to the selected target, measure its
actual allocation and collect remote receipts. A new unapproved target stays
pending; the control computer is not the automatic fallback for heavy jobs.

For a feasible native run retain input/code/scorer revisions, actual commands,
logs, outputs and relevant E04 checks. For an unavailable capability save the
specific gap and finish other possible work. A theoretical/source/code-only
deliverable can finish at its explicitly requested scope; an unexecuted empirical
claim cannot be closed merely to keep the loop moving.

Reuse the checked project runner for comparable work instead of rewriting timing,
logging and aggregation each round. Use stable attempt-specific output paths,
atomic finalized records and a terminal process receipt distinct from scientific
validity. Preserve launch errors, partial output and actual timing on timeout.
An unobserved terminal receipt is unknown, not zero cost or successful completion.
Do not consume a log that is still being written as final evidence, accept an old
file as a new result, or bind scientific source identity to mutable JIT caches.

## Checkpoint, continuation and procedure versions

Save goal criteria, candidate lineage, current procedure/source revision, task
inputs and attempt identity, completed/pending/blocked obligations, artifacts
and hashes, failed predicates, budget observations, next action and stop reason.
Persist to the authorized project destination and read it back. If durable
storage is unavailable, follow [github-zip-fallback.md](github-zip-fallback.md):
create and verify a downloadable ZIP of actual code, evidence, logs and checkpoint.
Mark GitHub synchronization pending or unknown. If file delivery itself is unavailable,
provide a complete visible checkpoint and mark its durability unverified; never
claim it was saved elsewhere.
Maintain one authoritative checkpoint with revision ancestry and globally stable
experiment identities; repeated R/batch labels cannot identify a branch. Resume
instructions point to this checkpoint and expected revision, rather than copying
an expanding contract into every prompt. Preserve user pause during maintenance,
migration and version adoption; a recurring trigger is not authority to resume.

Use the optional scripts/chat_cycle.py helper when a Python/filesystem tool is
available; see [action records](chat-cycle-records.md) for its exact commands. It records action state with revision checks; it neither executes
actions nor certifies science. The agent must call the next actual host tool
after reading an eligible action. Prefer advance: it resumes acknowledged partial
work, creates bounded repairs for classified engineering failures, rebuilds
pending consumers against actual replacement outputs, and returns the pinned
procedure text for the selected attempt. Read and follow that text before the
next actual tool call. If classification is missing, inspect the error and record
classify_failure with real evidence; do not automatically treat a hypothesis
refutation as an engineering retry. Canonical scientific evidence remains in its
existing ledger. Missing Python never makes the helper a new gate: retain the
same fields through actual artifact/repository tools.

For parallel work, checkpoint the parent/wave/packet identities, actual child
sessions and last observations, pinned inputs/procedure, exclusive outputs and
job ownership, partial artifacts, unsettled usage and each next action. See
[action records](chat-cycle-records.md) for the optional parallel event API.
Only the coordinator updates the shared checkpoint or publishes. A completed
child still needs integration and the applicable canonical science checks.

On another active turn, reconcile the saved operation and artifacts first.
Continue unfinished work without a new intake, repeated direction selection,
duplicate experiment or budget reset. An acknowledged partial model response
can continue in its supported session; an uncertain dispatch must be reconciled.
If the host offers no live operation/session API, record that limitation rather
than guessing. Before yielding, verify the automatic continuation binding under
round-continuation.md; if no such capability exists, report the specific blocker.

For procedure improvements, keep a separate candidate patch, baseline, fixed
behavior checks and independent review. Save the accepted procedure revision,
then explicitly read/adopt it at the next round boundary; running attempts
retain their previous version. Record rollback on a regression. This can change
the project-local procedure the agent reads; it does not update an installed
plugin, system instructions, model weights or permissions. Shared installation
and publication use their real authorized update mechanisms and receipts.

## Delivery and token use

Keep one integration writer and expected-parent/exact-file readback. Deliver
this plugin fork to autonomous-rsi-chat; scientific projects retain their
confirmed destinations. Do not require LOCAL_AGENT_RUNBOOK or WEB_HANDOFF for
a host-contained project. Supply reproducible commands, outputs, limitations
and the exact next action relevant to the selected host.

Reuse pinned source notes and unchanged checks. Load only needed modules and
sections. Report meaningful progress during active work without making each
report a final answer. Use one verified goal-bound continuation mechanism;
do not create a separate schedule for each progress report. No fixed price, token
saving, free usage or indefinite execution is promised.

## Prospective trace and investment binding

At substantive method intake/revision and meaningful batch decisions, apply
[research-reasoning.md](research-reasoning.md). Preserve the public mathematical
work product from selected operations to the executable rule, its rival prediction
and falsifier. Conditional premises and accumulated error do not disappear at a
handoff. Check the selected action against the parent goal and a real alternative;
new repair hashes or issue names do not reset mechanism-family effort. Record the
current accepted decision and tag actual method tasks with research_scope=method
and reasoning_ref; keep source/baseline/evaluator acquisition scoped as diagnostic.
Use quiet-boundary adoption for old tasks and never overwrite their evidence or
resume a pause. Structural checks are not mathematical or scientific acceptance.
