## 10. Closest-work and adversarial collision audit

### Candidate screen before code

During Stage 3 method discovery, screen **every mathematically justified
candidate**, including reserves, for already-existing work before ranking it as
a new method and before candidate code is written. Search from its actual
objective, operator/update, assumptions and predicted behavior, including aliases
and equivalent formulations; a different name or derivation is insufficient.
Freeze its atomic claim as a provisional hypothesis before retrieval; keep the
generator's hypothesis separate from equivalence and novelty adjudication under
the roles below.
Join relevant primary-paper/full-text reading with actual author/baseline GitHub
files and native benchmark/data/config/scorer inspection under
[literature-evidence.md](literature-evidence.md). Record inaccessible or
not-applicable portions explicitly. Missing released code, unread implementation
or unrun reproduction is an implementation unknown, never evidence of no prior
work; a verified paper can already establish that a mechanism exists.

Retain a compact record for each `candidate_id` in the existing H03/math/source
evidence and collision report:

| Record | Required content and existing binding |
|---|---|
| Sources and locators | Dated query families and coverage; primary work/version plus page/section/equation/algorithm spans, actual repository/commit/file/function/config and benchmark/task/scorer versions and locators. Use `search_run_refs`, `work_refs` and `evidence_refs`; connect the same retained evidence through the IdeaAtom's `source_evidence_refs` and math card's `source_refs`. |
| Semantic comparison | Map the candidate's essential claim, objective, estimator/update, state/information flow, assumptions and prediction to the closest work. State which functions are equivalent and which consequential difference remains, with a discriminating comparison/falsifier. Use `closest_alternative`, `decisive_comparison` and selection `rationale.closest_work_delta`; report paper/code discrepancies. |
| Scope and gaps | State cutoff, inspected versus inaccessible/full-text-only/static/unrun scope, exclusions, unresolved priority and implementation/benchmark questions. Retain these in linked evidence and keep the existing `coverage` record current; located metadata is not inspected source or qualification. |
| Result and disposition | State the bounded match finding and next action: retain a supported distinct hypothesis for the full audit, use existing work as an attributed comparator/baseline subject to qualification, replace a covered construction with a substantively distinct justified hypothesis, or investigate the gap. Record the scientific routing decision through the existing collision/IPCG/H03 vocabulary. |

If verified prior work already implements or specifies the core mechanism, do
not advertise that mechanism as novel. Retain it as an attributed comparator or
baseline and qualify its actual implementation/native evaluation, or replace the
new-method candidate with a substantive hypothesis not already implied by that
work. A legitimate replication, explanation or boundary contribution must state
its actual scoped claim. Replacement requires its own derivation, screen and
review, not a renamed variant; retain the old candidate and collision history.
Neither comparator disposition nor replacement is an irreversible `KILL` or
permission to evade Parent/IPCG restart rules.

Reuse current qualified source reads and screens on resume. Refresh affected
candidate comparisons after substantive changes to the claim, mechanism,
assumptions, computation/information flow or benchmark contract, and after newly
relevant closest work or feedback. Preserve prior snapshots and re-review affected
ranking/code/design bindings. This screen uses existing evidence fields and
review judgments; it adds no schema, outcome enum or automated novelty claim and
does not replace the complete audit and coverage requirements below.

### Complete adversarial audit

Freeze atomic novelty claims before retrieval. Search independently by problem, mechanism, objective, operator, differentiator, assumptions, observable behavior, component combinations, historical aliases, and cross-domain terminology.

Use distinct roles and artifacts:

1. claim registrar;
2. high-recall retriever;
3. collision prosecutor;
4. difference defender;
5. method-equivalence verifier;
6. provenance auditor;
7. blinded adjudicator;
8. human approval for irreversible high-confidence kills.

Generation, retrieval, prosecution, defense, and adjudication run in separate fresh contexts. The adjudicator receives anonymous candidate IDs and verified evidence spans but not generator identity, vote counts, or previous verdict language. A single agent may not retrieve, score, and adjudicate the same match.

Compare computation graphs, objective equivalence, state transitions, training and inference traces, assumptions, complexity, guarantees, and observable effects. Shared vocabulary, dataset, optimizer, scale, or benchmark is not a mechanism collision by itself.

The coverage/equivalence report may record one of the following low-level findings.
These findings do not approve continuation; the final research decision must pass
[importance-preserving-gate.md](importance-preserving-gate.md):

- `ADVANCE`;
- `REFINE`;
- `REROUTE_EVIDENCE`;
- `REROUTE_MECHANISM`;
- `REROUTE_REPLICATION_OR_TRANSFER`;
- `KILL`;
- `INCONCLUSIVE_EXPAND_SEARCH`.

After each actual functional collision, compare the residual claim to the frozen
Parent Problem. Record CONCURRENT, REROUTE or KILL with retained natural evidence,
task consequences and the strongest simple alternative. Record major functional
work IDs; after two distinct collisions return to failure census even if new
literature arrived. Legacy REFINE and mechanism/transfer reroutes are historical
findings, not executable permission to keep narrowing a contribution. A new
failure, population or task endpoint needs a fresh parent and Natural Gate 0.

The report says “no collision found under this protocol and snapshot,” never “no prior work exists.” Multiple agents citing the same source count as one evidence unit.

Collision search stops only after every required query family runs, high-risk neighbors receive citation expansion, each decisive neighbor has full text or an explicit inaccessible status, two rounds add no new high-risk family, and recorded coverage meets the configured threshold. Missing full text, unresolved priority, insufficient coverage, or wide evidence uncertainty returns `INCONCLUSIVE_EXPAND_SEARCH`, never `ADVANCE` or `KILL`. A `KILL` requires one pre-cutoff primary source that covers the frozen essential claim elements, verified provenance and locators, and explicit human approval.
