#!/usr/bin/env python3
"""Optional, stdlib-only bookkeeping for an active Chat turn.

No experiment dispatch, wakeup, model call or canonical ledger update. Scientific
checks delegate to the existing verifier and explicitly installed live host
callbacks, which may replay a scorer. Supply bounded callbacks on the actual host.
All refs are {"path": ..., "sha256": ...}; relative paths use the state directory.
Evidence is an attempt-bound JSON envelope, not a trusted scientific verdict.
Host receipts/reviewer identities remain externally verified observations.

CLI: init --state FILE --config CONFIG; status|next --state FILE;
advance --state FILE --expected-revision N;
record --state FILE --expected-revision N --event EVENT_JSON;
resume --state FILE --expected-revision N;
adopt --state FILE --expected-revision N --event ADOPTION_JSON.
Use record events: begin, result, checkpoint, add_task, classify_failure, usage,
revise_goal, revise_task, bind_resources, research_cycle, goal_review. Resume/adopt also
work as record events. Status/next do not write the checkpoint; next may perform
configured scientific verification. Begin reserves one finite attempt
and returns its ID, but does not launch anything. Adoption changes only this
checkpoint's procedure pointer for future attempts, never installed skill files.
Advance prepares a verified handoff for the active Chat host, including actual
procedure text. The host must execute it with real tools and record observations.
Advance does not replay an active/unknown action or wake a finished Chat turn.
Optional team_* events bind real host child operations inside the one current
attempt; chat_team.py records them but never calls an agent SDK or grants credit.
"""
from __future__ import annotations

import argparse
import copy
import contextvars
from contextlib import contextmanager
from functools import wraps
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import sys
import tempfile
import uuid

MAX_BYTES = 8 * 1024 * 1024
OUTCOMES = {'completed', 'failed', 'refuted', 'blocked'}
REPAIR_CLASSES = {'environment', 'implementation', 'evaluation'}
FAILURE_CLASSES = REPAIR_CLASSES | {'hypothesis', 'unknown'}
TASK_KINDS = {'action', 'preflight', 'research_experiment', 'research_analysis'}
SCIENCE_FIELDS = ('experiment_phase', 'experiment_contract_ref', 'experiment_review_ref',
                  'canonical_batch_ref', 'experiment_job_ids', 'intent_ref', 'research_scope', 'reasoning_ref')
_FORMAL_COMPLETION = contextvars.ContextVar('chat_formal_completion', default=None)


def _science_module(name):
    directory = str(Path(__file__).resolve().parent)
    if directory not in sys.path:
        sys.path.insert(0, directory)
    return importlib.import_module(name)


def _incident(path, *, category, scope, summary, next_action, evidence_refs=None,
              severity='error'):
    """Keep notification observations separate from scientific checkpoint credit."""
    try:
        return _science_module('chat_alerts').safe_report(Path(path).absolute().parent,
            category=category, source='chat_cycle', scope=str(scope), summary=summary,
            next_action=next_action, evidence_refs=evidence_refs or [], severity=severity)
    except Exception:
        # Even a broken reporter must not hide the original result or trigger a replay.
        notice = dict(stored=False, notification_status='unsaved', category=category,
                      summary='Incident reporting unavailable; report the original operation through the host.')
        try:
            print(json.dumps(notice), file=sys.stderr)
        except Exception:
            pass
        return notice


def _report_errors(function):
    @wraps(function)
    def observed(path, *args, **kwargs):
        try:
            return function(path, *args, **kwargs)
        except Exception as error:
            _incident(path, category='controller_error',
                scope=Path(path).name + '/' + function.__name__,
                summary=type(error).__name__ + ': ' + str(error),
                next_action='Report the failure through the host; inspect the saved checkpoint and reconcile before retrying.')
            raise
    return observed


def _report_decision(path, decision):
    # A deliberate pause and a request to observe an active job are expected states.
    reason = decision.get('reason')
    if decision.get('kind') == 'parallel':
        uncertain = [c['child_id'] for c in decision.get('children', [])
                     if c.get('status') in {'unknown', 'reconcile_required'}]
        if decision.get('capability_reason') or uncertain:
            reason = 'parallel_observation_requires_reconciliation'
            decision = dict(decision, reason=reason,
                detail=decision.get('capability_reason') or ('Uncertain child identities: ' + ', '.join(uncertain)))
    if (reason in {'user_stopped', 'active_attempt_requires_observation'} or
            decision.get('kind') in {'action', 'execute', 'continuation', 'bookkeeping_complete'}):
        return decision
    if reason and decision.get('kind') not in {'team_running', 'team_ready'}:
        incident = _incident(path, category='workflow_blocked',
            scope=Path(path).name + '/' + str(decision.get('attempt_id', 'scheduler')),
            summary=str(reason) + (': ' + str(decision['detail']) if decision.get('detail') else ''),
            next_action=decision.get('action') or 'Inspect the missing evidence or capability; report impact and continue independent eligible work.',
            severity='warning')
        decision = dict(decision, notification=incident)
    return decision


@contextmanager
def scientific_runtime(*, formal_completion_validator=None, **trusted_contexts):
    """Host-only live callbacks; never deserialize callbacks or approvals from JSON."""
    if formal_completion_validator is not None and not callable(formal_completion_validator):
        raise ValueError('formal completion requires a live host callback')
    token = _FORMAL_COMPLETION.set(formal_completion_validator)
    try:
        with _science_module('_autoresearch').evaluation_runtime(**trusted_contexts):
            yield
    finally:
        _FORMAL_COMPLETION.reset(token)


def _canonical(root, batch_ref, candidate_id, protocol_ref, through, contract=None):
    module = _science_module('verify_methods')
    try:
        return module.verify_chat_science(root, batch_ref, candidate_id, protocol_ref, through=through, contract=contract)
    except module.C.Failure as error:
        raise ValueError('canonical scientific verification pending: ' + error.code) from error


def _experiment_admission(root, task, state):
    if task.get('kind') != 'research_experiment':
        return
    phase = task.get('experiment_phase')
    if phase not in {'diagnostic', 'confirmation'}:
        raise ValueError('legacy research task needs an explicit diagnostic or confirmation successor; preserve prior attempts')
    if phase == 'diagnostic':
        return  # Diagnostic evidence cannot close empirical research below.
    for key in ('experiment_contract_ref', 'experiment_review_ref', 'canonical_batch_ref'):
        if task.get(key) not in task['input_refs']:
            raise ValueError('confirmation requires pinned ' + key)
    contract_ref = task['experiment_contract_ref']
    contract = _ref(root, contract_ref, as_json=True)
    if contract.get('candidate_id') != task['candidate_id'] or contract.get('stage') != 'confirmation':
        raise ValueError('confirmation contract candidate or stage mismatch')
    report = _science_module('experiment_contract').inspect_contract(
        root, contract_ref, phase='design', review_ref=task['experiment_review_ref'])
    jobs = _ids(task.get('experiment_job_ids'), 'experiment jobs', nonempty=True)
    if not set(jobs) <= set(report['eligible_job_ids']):
        raise ValueError('confirmation jobs are not eligible: ' + json.dumps(report['pending']))
    budgets = contract['resources']['budgets']
    limits, usage = state['budget'].get('limits', {}), state['usage']
    units = ('wall_seconds', 'gpu_seconds', 'cost')
    if not all(unit in limits and unit in usage['totals'] for unit in units):
        raise ValueError('confirmation needs sourced cumulative wall_seconds, gpu_seconds and cost limits with actual usage observations')
    if usage.get('observed_attempt_ids') != [a['id'] for a in state['attempts']]:
        raise ValueError('refresh actual cumulative usage after all prior attempts, including failed retries')
    selected = [job for job in contract['jobs'] if job['id'] in jobs]
    for unit in units:
        if usage['totals'][unit] < budgets['consumed'][unit]:
            raise ValueError('current usage cannot erase the frozen resource consumption')
        if usage['totals'][unit] + sum(j['estimate'][unit] for j in selected) > min(limits[unit], budgets[unit]):
            raise ValueError('selected confirmation batch exceeds remaining observed ' + unit)
    for attempt in state['attempts']:
        if (attempt.get('experiment_contract_ref') == contract_ref and attempt['outcome'] in {'completed', 'refuted'}
                and set(jobs).intersection(attempt.get('experiment_job_ids', []))):
            raise ValueError('settled frozen jobs cannot be replayed; version any newly required replication')
    _canonical(root, task['canonical_batch_ref'], task['candidate_id'], contract['protocol_ref'], 'design', contract)


def _science_completion(root, state, review, valid_cycles):
    """Bind current full scientific validation to the requested operational criteria."""
    cycles = {c['cycle_id']: (c, r) for c, r in valid_cycles}
    packets = review.get('scientific_evidence')
    if not isinstance(packets, list) or not packets:
        raise ValueError('research completion requires current scientific_evidence; diagnostic/legacy records remain pending')
    coverage = review.get('claim_coverage')
    if not isinstance(coverage, dict) or set(coverage) != set(state['criteria']):
        raise ValueError('claim_coverage must map every requested criterion to verified scientific claims')
    verified, seen = {}, set()
    allowed = state['goal_contract'].get('allowed_outcomes', ['supported'])
    latest = {c['candidate_id']: (c, r) for c, r in valid_cycles}
    retired = set()
    for retirement in review.get('retired_cycles', []):
        old_id, new_id = retirement.get('cycle_id'), retirement.get('successor_cycle_id')
        if (old_id not in cycles or new_id not in {p.get('cycle_id') for p in packets}
                or new_id not in cycles or old_id == new_id):
            raise ValueError('retired cycle needs a valid verified successor')
        old_cycle, new_cycle = cycles[old_id][0], cycles[new_id][0]
        if old_cycle['hypothesis_ref'] == new_cycle['hypothesis_ref']:
            raise ValueError('retirement must preserve a materially changed successor hypothesis')
        receipt = _ref(root, retirement.get('review_ref'), as_json=True)
        binding = dict(kind='research-cycle-retirement', cycle_id=old_id, successor_cycle_id=new_id,
            cycle_review_ref=old_cycle['review_ref'], successor_hypothesis_ref=new_cycle['hypothesis_ref'])
        if any(receipt.get(key) != value for key, value in binding.items()):
            raise ValueError('retirement review binding mismatch')
        _independent_review(receipt)
        _text(receipt.get('reason'), 'retirement reason and obligation transfer')
        _ref(root, receipt.get('execution_ref'))
        if retirement['review_ref'] not in review['raw_evidence']:
            raise ValueError('goal review must retain the retirement evidence')
        retired.add(old_id)
    if any((r['verdict'] == 'inconclusive' or r.get('unresolved_obligations')) and c['cycle_id'] not in retired
           for c, r in latest.values()):
        raise ValueError('unresolved scientific review obligations require further work')
    _ref(root, review.get('execution_ref'))
    for packet in packets:
        cycle_id = packet.get('cycle_id')
        if cycle_id not in cycles or cycle_id in seen:
            raise ValueError('scientific evidence needs distinct valid cycle bindings')
        seen.add(cycle_id)
        cycle, cycle_review = cycles[cycle_id]
        if latest[cycle['candidate_id']][0]['cycle_id'] != cycle_id:
            raise ValueError('a superseded cycle cannot supply current scientific completion')
        if cycle_review['verdict'] == 'inconclusive' or cycle_review.get('unresolved_obligations'):
            raise ValueError('unresolved scientific review obligations require further work')
        if cycle_review['verdict'] not in allowed:
            raise ValueError('scientific outcome does not satisfy the sourced goal allowed_outcomes')
        _ref(root, cycle_review.get('execution_ref'))
        design = _ref(root, cycle['design_ref'], as_json=True)
        if design['mode'] == 'theoretical':
            proof_ref = packet.get('formal_evidence_ref')
            proof = _ref(root, proof_ref, as_json=True)
            expected = dict(kind='formal-goal-evidence', candidate_id=cycle['candidate_id'],
                cycle_id=cycle_id, hypothesis_ref=cycle['hypothesis_ref'], design_ref=cycle['design_ref'])
            if any(proof.get(k) != v for k, v in expected.items()):
                raise ValueError('formal proof obligation binding mismatch')
            _refs(root, proof.get('proof_refs'), nonempty=True)
            claims = _ids(proof.get('claim_ids'), 'formal claim ids', nonempty=True)
            raw = [ref for a in state['attempts'] if a['id'] in cycle['attempt_ids']
                   for ref in _evidence(root, a, a['evidence_ref'], a['outcome'])['raw_evidence']]
            if any(ref not in raw for ref in proof['proof_refs']):
                raise ValueError('formal proof must be attached to actual analysis attempts')
            validator = _FORMAL_COMPLETION.get()
            if not callable(validator):
                raise ValueError('formal verification capability required: provide actual independent proof review on the current host')
            checked = validator(copy.deepcopy(dict(evidence_ref=proof_ref, evidence=proof,
                cycle_review_ref=cycle['review_ref'], verdict=cycle_review['verdict'])))
            if (not isinstance(checked, dict) or checked.get('verified') is not True
                    or checked.get('evidence_ref') != proof_ref or checked.get('claim_ids') != claims
                    or checked.get('verdict') != cycle_review['verdict']):
                raise ValueError('formal verification did not establish the bound proof obligations')
            _ref(root, checked.get('execution_ref'))
            if proof_ref not in review['raw_evidence']:
                raise ValueError('goal review must include actual formal evidence')
            for claim in claims:
                verified[(cycle_id, claim)] = cycle_review['verdict']
            continue
        contract_ref = packet.get('contract_ref')
        contract = _ref(root, contract_ref, as_json=True)
        if (contract.get('candidate_id') != cycle['candidate_id']
                or contract.get('hypothesis_ref') != cycle['hypothesis_ref']):
            raise ValueError('scientific contract differs from reviewed hypothesis/candidate')
        attempts = [a for a in state['attempts'] if a['id'] in cycle['attempt_ids']]
        if not any(a.get('experiment_phase') == 'confirmation' and
                   a.get('experiment_contract_ref') == contract_ref for a in attempts):
            raise ValueError('completion needs an actually pinned confirmation attempt')
        result = _science_module('experiment_contract').inspect_contract(
            root, contract_ref, phase='completion', review_ref=packet.get('design_review_ref'),
            completion_ref=packet.get('completion_ref'))
        if not result['coverage_complete'] or not result['ready']:
            raise ValueError('scientific experiment coverage pending: ' + json.dumps(result['pending']))
        usage = state['usage']
        if usage.get('observed_attempt_ids') != [a['id'] for a in state['attempts']]:
            raise ValueError('refresh cumulative actual usage through the final settled attempt before goal completion')
        _ref(root, usage.get('receipt_ref'))
        for unit, actual in result['actual_job_usage'].items():
            consumed = contract['resources']['budgets']['consumed'].get(unit)
            observed = usage['totals'].get(unit)
            if consumed is None or observed is None or observed < consumed + actual:
                raise ValueError('completion accounting omits actual experiment usage: ' + unit)
        canonical = _canonical(root, packet.get('canonical_batch_ref'), cycle['candidate_id'],
                               contract['protocol_ref'], 'results', contract)
        if not set(result['criterion_ids']) <= set(canonical['criterion_ids']):
            raise ValueError('experiment obligations are outside the canonical criterion scope')
        expected = 'PASS' if cycle_review['verdict'] == 'supported' else 'KILL'
        if canonical['outcome'] != expected:
            raise ValueError('cycle verdict disagrees with recomputed canonical outcome')
        completion = _ref(root, packet['completion_ref'], as_json=True)
        by_id = {a['id']: a for a in state['attempts']}
        attached_run_refs = []
        for receipt in completion['receipts']:
            attempt = by_id.get(receipt['attempt_id'])
            if (not attempt or attempt['candidate_id'] != cycle['candidate_id']
                    or attempt.get('experiment_contract_ref') != contract_ref
                    or receipt['job_id'] not in attempt.get('experiment_job_ids', [])
                    or attempt['outcome'] != receipt['outcome']
                    or receipt.get('verification_ref') != canonical['result_ref']):
                raise ValueError('experiment receipt must bind its actual job attempt and canonical result')
            envelope = _evidence(root, attempt, attempt['evidence_ref'], attempt['outcome'])
            attached_run_refs.extend(receipt['raw_evidence'])
            if not set((r['path'], r['sha256']) for r in receipt['raw_evidence']) <= set(
                    (r['path'], r['sha256']) for r in envelope['raw_evidence']):
                raise ValueError('experiment receipt raw evidence differs from actual attempt')
        if any(ref not in attached_run_refs for ref in canonical['run_manifest_refs']):
            raise ValueError('canonical run inventory is not attached to the actual experiment attempts')
        for claim, outcome in completion['claim_outcomes'].items():
            if claim not in canonical['claim_ids'] or outcome != canonical['claim_outcomes'][claim]:
                raise ValueError('claim outcome is outside the recomputed canonical claim scope')
            if outcome in allowed:
                verified[(cycle_id, claim)] = outcome
        for key in ('contract_ref', 'design_review_ref', 'completion_ref', 'canonical_batch_ref'):
            if packet[key] not in review['raw_evidence']:
                raise ValueError('goal review must include current scientific evidence references')
    for criterion, bindings in coverage.items():
        if not isinstance(bindings, list) or not bindings:
            raise ValueError('criterion has no verified scientific claim: ' + criterion)
        for binding in bindings:
            if (binding.get('cycle_id'), binding.get('claim_id')) not in verified:
                raise ValueError('criterion maps to an unverified scientific claim: ' + criterion)


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + ' must be nonempty text')
    return value


def _ids(value, label, *, nonempty=False):
    if not isinstance(value, list) or (nonempty and not value):
        raise ValueError(label + ' must be a list')
    if len(set(_text(item, label) for item in value)) != len(value):
        raise ValueError(label + ' must be unique')
    return value


def _number(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
        raise ValueError(label + ' must be a finite nonnegative number')
    return value


def _read(path):
    with Path(path).open('rb') as stream:
        data = stream.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise ValueError('checkpoint/evidence exceeds bounded size')
    return data


def _json(path):
    value = json.loads(_read(path))
    if not isinstance(value, dict):
        raise ValueError('JSON object required')
    return value


def _ref(root, reference, *, as_json=False):
    if not isinstance(reference, dict):
        raise ValueError('evidence reference required')
    path = root / _text(reference.get('path'), 'reference path')
    data = _read(path)
    if hashlib.sha256(data).hexdigest() != reference.get('sha256'):
        raise ValueError('reference hash mismatch: ' + str(path))
    if as_json:
        value = json.loads(data)
        if not isinstance(value, dict):
            raise ValueError('evidence JSON object required')
        return value
    return reference


def _refs(root, refs, *, nonempty=False):
    if not isinstance(refs, list) or (nonempty and not refs):
        raise ValueError('raw evidence references required')
    for ref in refs:
        _ref(root, ref)


def _procedure(root, procedure):
    if not isinstance(procedure, dict):
        raise ValueError('procedure id and reference required')
    _text(procedure.get('id'), 'procedure id')
    _ref(root, procedure.get('ref'))


def _procedure_text(root, procedure):
    reference = procedure['ref']
    data = _read(root / reference['path'])
    if hashlib.sha256(data).hexdigest() != reference['sha256']:
        raise ValueError('procedure reference hash mismatch')
    return data.decode('utf-8')


def _unique_refs(refs):
    return list({(ref['path'], ref['sha256']): ref for ref in refs}.values())


def _goal_contract(root, contract):
    if not isinstance(contract, dict) or contract.get('mode') not in {'research', 'bounded_task'}:
        raise ValueError('sourced goal_contract with research or bounded_task mode required')
    _ref(root, contract.get('request_ref'))
    _text(contract.get('continuation_action'), 'goal continuation action')
    if 'allowed_outcomes' in contract:
        outcomes = _ids(contract['allowed_outcomes'], 'allowed scientific outcomes', nonempty=True)
        if not set(outcomes) <= {'supported', 'refuted'}:
            raise ValueError('allowed scientific outcomes must be supported or refuted')


def _independent_review(review):
    if _text(review.get('review_task_id'), 'review task') == _text(review.get('proposal_task_id'), 'proposal task'):
        raise ValueError('separate independent review task required')


def _cycle(root, state, cycle):
    """Validate bindings and bytes, not scientific truth or reviewer authenticity."""
    if not isinstance(cycle, dict):
        raise ValueError('research cycle object required')
    cycle_id = _text(cycle.get('cycle_id'), 'research cycle id')
    candidate_id = _text(cycle.get('candidate_id'), 'research candidate id')
    attempt_ids = _ids(cycle.get('attempt_ids'), 'research attempt ids', nonempty=True)
    attempts = {a['id']: a for a in state['attempts']}
    selected = []
    for attempt_id in attempt_ids:
        attempt = attempts.get(attempt_id)
        if (not attempt or attempt.get('kind') not in {'research_experiment', 'research_analysis'}
                or attempt['candidate_id'] != candidate_id
                or attempt['outcome'] not in {'completed', 'refuted'}):
            raise ValueError('actual settled research attempts for the same candidate required; preflight is not a cycle')
        _evidence(root, attempt, attempt.get('evidence_ref'), attempt['outcome'])
        selected.append(attempt)
    hypothesis = _ref(root, cycle.get('hypothesis_ref'), as_json=True)
    if hypothesis.get('kind') != 'research_hypothesis' or hypothesis.get('candidate_id') != candidate_id:
        raise ValueError('research hypothesis candidate binding mismatch')
    for key in ('hypothesis', 'derivation', 'prediction', 'falsifier', 'proposal_task_id'):
        _text(hypothesis.get(key), 'research ' + key)
    design = _ref(root, cycle.get('design_ref'), as_json=True)
    if (design.get('kind') != 'research_design' or design.get('candidate_id') != candidate_id
            or design.get('hypothesis_ref') != cycle['hypothesis_ref']):
        raise ValueError('research design hypothesis binding mismatch')
    for key in ('comparison', 'protocol'):
        _text(design.get(key), 'research design ' + key)
    for attempt in selected:
        if any(cycle[key] not in attempt['input_refs'] for key in ('hypothesis_ref', 'design_ref')):
            raise ValueError('research hypothesis and design must be pinned as inputs before the attempt begins')
    required_kind = {'empirical': 'research_experiment', 'theoretical': 'research_analysis'}.get(design.get('mode'))
    if required_kind is None or not any(a['kind'] == required_kind for a in selected):
        raise ValueError('research design needs its actual empirical experiment or theoretical analysis')
    review = _ref(root, cycle.get('review_ref'), as_json=True)
    binding = dict(kind='research_cycle_review', cycle_id=cycle_id, candidate_id=candidate_id,
        attempt_ids=attempt_ids, hypothesis_ref=cycle['hypothesis_ref'], design_ref=cycle['design_ref'],
        proposal_task_id=hypothesis['proposal_task_id'])
    if any(review.get(key) != value for key, value in binding.items()):
        raise ValueError('research cycle review binding mismatch')
    _independent_review(review)
    if review.get('verdict') not in {'supported', 'refuted', 'inconclusive'}:
        raise ValueError('research cycle review needs a supported, refuted or inconclusive verdict')
    if any(a['outcome'] == 'refuted' for a in selected) and review['verdict'] != 'refuted':
        raise ValueError('refuted attempt cannot be relabeled as a supported cycle')
    _text(review.get('next_action'), 'research cycle next action')
    if 'unresolved_obligations' in review:
        _ids(review['unresolved_obligations'], 'unresolved scientific obligations')
    _refs(root, review.get('raw_evidence'), nonempty=True)
    if any(a['evidence_ref'] not in review['raw_evidence'] for a in selected):
        raise ValueError('research review must bind every actual attempt evidence reference')
    return review


def _research_cycles(root, state):
    valid, invalid, ids, used = [], [], set(), set()
    for cycle in state.get('research_cycles', []):
        try:
            if cycle.get('cycle_id') in ids or used.intersection(cycle.get('attempt_ids', [])):
                raise ValueError('duplicate cycle or reused research attempts')
            ids.add(cycle.get('cycle_id'))
            used.update(cycle.get('attempt_ids', []))
            review = _cycle(root, state, cycle)
        except (OSError, ValueError, TypeError, KeyError) as error:
            invalid.append({'cycle_id': cycle.get('cycle_id'), 'reason': str(error)})
        else:
            valid.append((cycle, review))
    return valid, invalid


def _remaining(state, refuted):
    return [t for t in state['tasks'] if t['status'] in {'pending', 'active', 'partial', 'blocked'}
            and t['candidate_id'] not in refuted and not t.get('replacement_task_id')]


def _goal_review(root, state, reference, reviewed_revision, valid_cycles):
    _goal_contract(root, state.get('goal_contract'))
    review = _ref(root, reference, as_json=True)
    binding = dict(kind='goal_review', goal_id=state['goal_id'], goal=state['goal'],
        goal_revision=state.get('goal_revision', 0), state_revision=reviewed_revision,
        goal_contract=state['goal_contract'], criteria=state['criteria'], deliveries=state['deliveries'],
        attempt_ids=[a['id'] for a in state['attempts']],
        cycle_ids=[c['cycle_id'] for c, _ in valid_cycles], outcome='complete')
    if any(review.get(key) != value for key, value in binding.items()):
        raise ValueError('goal review binding or revision mismatch')
    _independent_review(review)
    if state['goal_contract']['mode'] == 'research' and not valid_cycles:
        raise ValueError('research goal review requires a valid scientific cycle')
    for attempt in state['attempts']:
        if attempt.get('evidence_ref'):
            _evidence(root, attempt, attempt['evidence_ref'], attempt['outcome'])
    _refs(root, review.get('raw_evidence'), nonempty=True)
    required = [a['evidence_ref'] for a in state['attempts'] if a.get('evidence_ref')]
    required.extend(c['review_ref'] for c, _ in valid_cycles)
    if any(ref not in review['raw_evidence'] for ref in required):
        raise ValueError('goal review must bind current attempt and cycle evidence')
    if state['goal_contract']['mode'] == 'research':
        _science_completion(root, state, review, valid_cycles)
    return review


@contextmanager
def _locked(path):
    # The sidecar is stable across atomic state replacements; lock release is OS-owned.
    flags = os.O_RDWR | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0)
    fd = os.open(str(path) + '.lock', flags, 0o600)
    try:
        try:
            import fcntl
        except ImportError:
            import msvcrt
            if os.fstat(fd).st_size == 0:
                os.write(fd, b'\0')
            os.lseek(fd, 0, os.SEEK_SET)
            msvcrt.locking(fd, msvcrt.LK_LOCK, 1)
            try:
                yield
            finally:
                os.lseek(fd, 0, os.SEEK_SET)
                msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
        else:
            fcntl.flock(fd, fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        os.close(fd)


def _save(path, state):
    _science_module('chat_session').record_revision(state)
    data = (json.dumps(state, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')
    if len(data) > MAX_BYTES:
        raise ValueError('checkpoint exceeds bounded size')
    fd, temporary = tempfile.mkstemp(prefix=path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _task(root, value):
    if not isinstance(value, dict):
        raise ValueError('task object required')
    task = {key: _text(value.get(key), 'task ' + key) for key in ('id', 'action', 'candidate_id')}
    task['kind'] = value.get('kind', 'action')
    if task['kind'] not in TASK_KINDS:
        raise ValueError('unsupported task kind')
    task['dependencies'] = _ids(value.get('dependencies', []), 'dependencies')
    task['input_refs'] = value.get('input_refs', [])
    _refs(root, task['input_refs'])
    for key in SCIENCE_FIELDS:
        if key in value:
            task[key] = copy.deepcopy(value[key])
    if 'experiment_phase' in task and task['experiment_phase'] not in {'diagnostic', 'confirmation'}:
        raise ValueError('experiment_phase must be diagnostic or confirmation')
    if 'repairs' in value:
        task['repairs'] = _text(value['repairs'], 'repair predecessor')
    task['input_refs'] = _science_module('research_reasoning').require_task(
        root, task, candidate_id=task['candidate_id'], expand=True)
    task['status'] = 'pending'
    return task


def _graph(tasks):
    by_id = {task['id']: task for task in tasks}
    if len(by_id) != len(tasks):
        raise ValueError('task ids must be unique')
    visited, visiting = set(), set()
    def visit(task_id):
        if task_id not in by_id or task_id in visiting:
            raise ValueError('missing dependency or dependency cycle')
        if task_id in visited:
            return
        visiting.add(task_id)
        task = by_id[task_id]
        if 'repairs' in task and (task['repairs'] not in by_id or task['repairs'] == task_id):
            raise ValueError('repair predecessor must exist and remain distinct')
        for dependency in task['dependencies']:
            visit(dependency)
        visiting.remove(task_id)
        visited.add(task_id)
    for task_id in by_id:
        visit(task_id)


@_report_errors
def initialize(path, config):
    """Create once from explicit goal/criteria/deliveries/budget/procedure/tasks."""
    path = Path(path).absolute()
    root = path.parent
    state = copy.deepcopy(config)
    for key in ('goal_id', 'goal'):
        _text(state.get(key), key)
    for key in ('criteria', 'deliveries'):
        _ids(state.get(key), key, nonempty=(key == 'criteria'))
    if state.get('goal_contract') is not None:
        _goal_contract(root, state['goal_contract'])
    budget = state.get('budget', {})
    if not isinstance(budget, dict) or type(budget.get('max_attempts')) is not int or budget['max_attempts'] < 1:
        raise ValueError('explicit finite positive max_attempts is required')
    limits = budget.get('limits', {})
    if not isinstance(limits, dict):
        raise ValueError('budget limits must be an object')
    for name, limit in limits.items():
        _text(name, 'budget unit')
        _number(limit, 'budget limit')
    repair_limit = state.setdefault('max_repair_generations', 3)
    if type(repair_limit) is not int or not 0 <= repair_limit <= 3:
        raise ValueError('max_repair_generations must be an integer from 0 to 3')
    _procedure(root, state.get('procedure'))
    if not isinstance(state.get('tasks'), list):
        raise ValueError('tasks must be a list')
    state['tasks'] = [_task(root, task) for task in state['tasks']]
    _graph(state['tasks'])
    state.update(schema_version=1, authority='operational_bookkeeping_only', revision=0,
                 goal_revision=0, goal_history=[], research_cycles=[], goal_review=None,
                 started_attempts=0, current_attempt=None, attempts=[], history=[],
                 procedure_versions={state['procedure']['id']: state['procedure']['ref']['sha256']},
                 usage={'totals': {}, 'receipt_ref': None})
    _science_module('chat_session').initialize(root, state)
    _science_module('chat_strategy').initialize(root, state, config, _ref)
    root.mkdir(parents=True, exist_ok=True)
    with _locked(path):
        if path.exists():
            raise ValueError('checkpoint already exists')
        _save(path, state)
    return state


def status(path):
    """Read the saved observations. This is not a scientific or host status API."""
    state = _json(path)
    if state.get('schema_version') != 1 or state.get('authority') != 'operational_bookkeeping_only':
        raise ValueError('not a Chat bookkeeping checkpoint')
    _science_module('chat_session').validate_lineage(state)
    return state


def _evidence(root, attempt, reference, outcome):
    envelope = _ref(root, reference, as_json=True)
    binding = {'attempt_id': attempt['id'], 'task_id': attempt['task_id'],
               'candidate_id': attempt['candidate_id'], 'procedure_id': attempt['procedure']['id'],
               'outcome': outcome}
    if any(envelope.get(key) != value for key, value in binding.items()):
        raise ValueError('evidence binding differs from the pinned attempt')
    invalidated_team = attempt.get('team') and outcome in {'failed', 'blocked'}
    if not invalidated_team:
        _procedure(root, attempt['procedure'])
        _refs(root, attempt['input_refs'])
        _refs(root, attempt.get('dependency_evidence_refs', []))
    _refs(root, envelope.get('raw_evidence'), nonempty=True)
    if attempt.get('team'):
        child_refs = _science_module('chat_team').assert_joined(root, attempt, _ref,
            tolerate_invalid=bool(invalidated_team))
        if not invalidated_team and any(ref not in envelope['raw_evidence'] for ref in child_refs):
            raise ValueError('parent evidence must retain every settled child result receipt')
    if 'output_refs' in envelope:
        _refs(root, envelope['output_refs'])
        if any(ref not in envelope['raw_evidence'] for ref in envelope['output_refs']):
            raise ValueError('output refs must be attached raw evidence')
    bindings = envelope.get('output_bindings', {})
    if not isinstance(bindings, dict):
        raise ValueError('output bindings must be an object')
    for name, ref in bindings.items():
        _text(name, 'logical output name')
        if ref not in envelope['raw_evidence']:
            raise ValueError('output binding must reference attached raw evidence')
    _ids(envelope.get('criteria_met', []), 'criteria_met')
    receipts = envelope.get('delivery_receipts', {})
    if not isinstance(receipts, dict):
        raise ValueError('delivery receipts must be an object')
    for receipt_ref in receipts.values():
        receipt = _ref(root, receipt_ref, as_json=True)
        digest = receipt.get('delivered_sha256', '')
        if (receipt.get('attempt_id') != attempt['id'] or not isinstance(digest, str)
                or len(digest) != 64 or any(char not in '0123456789abcdef' for char in digest)
                or receipt.get('readback_sha256') != digest
                or digest not in {ref['sha256'] for ref in envelope['raw_evidence']}):
            raise ValueError('delivery receipt lacks matching attempt/hash readback')
        _text(receipt.get('destination'), 'delivery destination')
    return envelope


def _credits(root, state):
    satisfied, delivered, complete, invalid = set(), set(), set(), []
    tasks = {task['id']: task for task in state['tasks']}
    refuted = {a['candidate_id'] for a in state['attempts'] if a['outcome'] == 'refuted'}
    refuted.update(c['candidate_id'] for c in state.get('research_cycles', [])
                   if c.get('recorded_verdict') == 'refuted')
    accept_negative = 'refuted' in (state.get('goal_contract') or {}).get('allowed_outcomes', [])
    for attempt in state['attempts']:
        if (attempt['outcome'] not in ({'completed', 'refuted'} if accept_negative else {'completed'})
                or (attempt['candidate_id'] in refuted and not accept_negative)):
            continue
        try:
            # Attempts settle in order; their predecessors must already have valid credit.
            if not set(tasks[attempt['task_id']]['dependencies']) <= complete:
                raise ValueError('prerequisite evidence is no longer valid')
            evidence = _evidence(root, attempt, attempt['evidence_ref'], attempt['outcome'])
        except (OSError, ValueError) as error:
            invalid.append({'task_id': attempt['task_id'], 'reason': str(error)})
        else:
            complete.add(attempt['task_id'])
            satisfied.update(evidence.get('criteria_met', []))
            delivered.update(evidence.get('delivery_receipts', {}))
    return satisfied, delivered, complete, invalid


def _next(root, state):
    satisfied, delivered, complete, invalid = _credits(root, state)
    valid_cycles, invalid_cycles = _research_cycles(root, state)
    refuted = {a['candidate_id'] for a in state['attempts'] if a['outcome'] == 'refuted'}
    refuted.update(c['candidate_id'] for c in state.get('research_cycles', [])
                   if c.get('recorded_verdict') == 'refuted')
    gaps = {'missing_criteria': [i for i in state['criteria'] if i not in satisfied],
            'missing_deliveries': [i for i in state['deliveries'] if i not in delivered],
            'invalid_evidence': invalid, 'scientific_cycle_count': len(valid_cycles),
            'invalid_research_cycles': invalid_cycles}
    latest = {}
    for cycle, review in valid_cycles:
        latest[cycle['candidate_id']] = (cycle, review)
    gaps['scientific_pending'] = [dict(cycle_id=c['cycle_id'], candidate_id=c['candidate_id'],
        reason='inconclusive_or_unresolved_review', next_action=r['next_action'],
        obligations=r.get('unresolved_obligations', [])) for c, r in latest.values()
        if r['verdict'] == 'inconclusive' or r.get('unresolved_obligations')]
    if state.get('strategy'):
        gaps['research_progress'] = _science_module('chat_strategy').summary(state)
    if state.get('user_pause') or state.get('stop_reason') == 'user_stopped':
        return dict(kind='blocked', reason='user_stopped',
                    action='Preserve pause; observe and settle existing operations only until sourced user resumption', **gaps)
    current = state['current_attempt']
    contract = state.get('goal_contract')
    if contract is not None:
        try:
            _goal_contract(root, contract)
        except (OSError, ValueError) as error:
            return dict(kind='needs_goal_review', reason='goal_source_invalid', detail=str(error),
                        action='Restore the actual request source and record revise_goal without resetting prior work', **gaps)
    remaining = _remaining(state, refuted)
    ready = not current and not remaining and not gaps['missing_criteria'] and not gaps['missing_deliveries']
    if ready and contract:
        if contract['mode'] == 'bounded_task':
            return dict(kind='bookkeeping_complete', authority=state['authority'], **gaps)
        saved_review = state.get('goal_review')
        if saved_review:
            try:
                if saved_review['reviewed_revision'] + 1 != state['revision']:
                    raise ValueError('goal review is stale after further state changes')
                _goal_review(root, state, saved_review['ref'], saved_review['reviewed_revision'], valid_cycles)
            except (OSError, ValueError, KeyError) as error:
                gaps['invalid_goal_review'] = str(error)
            else:
                return dict(kind='bookkeeping_complete', authority=state['authority'], **gaps)
    if current and current.get('team'):
        team = _science_module('chat_team').summary(root, state, _ref)
        if team['children'] or team['unaccounted_child_ids']:
            # Observation and settlement remain available after execution limits.
            return dict(team, **gaps)
    for unit, limit in state['budget'].get('limits', {}).items():
        observed = state['usage']['totals'].get(unit)
        if observed is None:
            return dict(kind='blocked', reason='usage_observation_required', unit=unit, **gaps)
        if observed > limit or (limit > 0 and observed == limit):
            return dict(kind='blocked', reason='observed_budget_exhausted', unit=unit, **gaps)
    if current:
        task = next(t for t in state['tasks'] if t['id'] == current['task_id'])
        if not set(task['dependencies']) <= complete:
            return dict(kind='blocked', reason='prerequisite_evidence_unavailable', **gaps)
        if state.get('session_contract') and (state.get('goal_contract') or {}).get('mode') == 'research':
            session_decision = _science_module('chat_session').predispatch_guard(root, state, continuation=True)
            if session_decision:
                return dict(session_decision, **gaps)
        return dict(kind='continuation', task_id=current['task_id'], attempt_id=current['id'],
                    action=current['next_action'], stop_reason=current.get('stop_reason'), **gaps)
    if state['started_attempts'] >= state['budget']['max_attempts']:
        return dict(kind='blocked', reason='attempt_budget_exhausted', **gaps)
    if (state.get('goal_contract') or {}).get('mode') == 'research':
        strategy_decision = _science_module('chat_strategy').guard(root, state, _ref)
        if strategy_decision:
            return dict(strategy_decision, **gaps)
        session_decision = _science_module('chat_session').predispatch_guard(root, state)
        if session_decision:
            return dict(session_decision, **gaps)
    blocked_inputs = []
    ordered_tasks = _science_module('chat_strategy').order_tasks(root, state, state['tasks'], _ref)
    for task in ordered_tasks:
        if (task['status'] == 'pending' and not task.get('replacement_task_id')
                and task['candidate_id'] not in refuted and set(task['dependencies']) <= complete):
            try:
                _refs(root, task['input_refs'])
                _science_module('research_reasoning').require_host_feedback(root, task,
                    (state.get('strategy') or {}).get('reasoning_experiment_receipts', []))
                _science_module('research_reasoning').require_task(root, task,
                    candidate_id=task['candidate_id'], goal_id=state['goal_id'],
                    accepted_ref=(state.get('strategy') or {}).get('reasoning_ref'), require_accepted=True)
                _science_module('chat_strategy').validate_task(root, task, state, _ref)
                _science_module('chat_strategy').admit_task(root, task, state, _ref)
                _experiment_admission(root, task, state)
            except (ValueError, OSError) as error:
                blocked_inputs.append({'task_id': task['id'], 'reason': str(error)})
                continue
            return dict(kind='action', task_id=task['id'], action=task['action'], **gaps)
    if contract is None:
        return dict(kind='needs_goal_review', reason='legacy_goal_scope_unreviewed',
                    action='Read the original request and record revise_goal with its sourced research or bounded-task scope', **gaps)
    if contract['mode'] == 'research':
        action = valid_cycles[-1][1]['next_action'] if valid_cycles else contract['continuation_action']
        reasons = ' '.join(item['reason'] for item in blocked_inputs)
        if 'strategy_review_required' in reasons:
            return dict(kind='needs_strategy_review', reason='research_stagnation',
                        action='Review prior attempt evidence and retain original obligations; record a changed decision with strategy_review before new investment',
                        blocked_inputs=blocked_inputs, **gaps)
        if 'cumulative diagnostic' in reasons:
            return dict(kind='needs_strategy_review', reason='diagnostic_allowance_exhausted',
                        action='Review and retire or change the exhausted diagnostic route within remaining original limits; preserve spent family and project allowances',
                        blocked_inputs=blocked_inputs, **gaps)
        if blocked_inputs:
            action = 'Repair the experiment admission or create a versioned successor: ' + blocked_inputs[0]['reason']
        elif gaps['scientific_pending']:
            action = gaps['scientific_pending'][0]['next_action']
        return dict(kind='replan', reason='no_eligible_action', action=action,
                    goal_review_required=True, blocked_inputs=blocked_inputs, **gaps)
    return dict(kind='blocked', reason='no_eligible_action', blocked_inputs=blocked_inputs, **gaps)


@_report_errors
def next_action(path):
    """Suggest an eligible action using the sourced research priorities."""
    path = Path(path).absolute()
    return _report_decision(path, _next(path.parent, status(path)))


def _dependency_refs(root, state, dependencies):
    refs = []
    allowed = {'completed', 'refuted'} if 'refuted' in (state.get('goal_contract') or {}).get('allowed_outcomes', []) else {'completed'}
    for task_id in dependencies:
        attempt = next(a for a in reversed(state['attempts'])
                       if a['task_id'] == task_id and a['outcome'] in allowed)
        envelope = _evidence(root, attempt, attempt['evidence_ref'], attempt['outcome'])
        refs.extend([attempt['evidence_ref'], *envelope['raw_evidence']])
    return _unique_refs(refs)


def _reconnect_repairs(root, state):
    """Version pending consumers, preserving their original contracts and history."""
    complete = _credits(root, state)[2]
    by_id = {task['id']: task for task in state['tasks']}
    for repair in state['tasks']:
        predecessor = repair.get('repairs')
        if predecessor and repair['id'] in complete:
            original = by_id[predecessor]
            existing = original.get('replacement_task_id')
            if existing is None or existing == repair['id']:
                original['replacement_task_id'] = repair['id']
    changed = []
    # Snapshot iteration; descendants resolve to newly created pending successors.
    pending = [task for task in state['tasks'] if task['status'] == 'pending']
    while pending:
        progress = False
        for task in list(pending):
            replacements = {}
            for dependency in task['dependencies']:
                cursor, seen = dependency, set()
                while by_id[cursor].get('replacement_task_id'):
                    if cursor in seen:
                        raise ValueError('replacement cycle requires reconciliation')
                    seen.add(cursor)
                    cursor = by_id[cursor]['replacement_task_id']
                if cursor != dependency and (cursor in complete or by_id[cursor]['status'] == 'pending'):
                    replacements[dependency] = cursor
            if not replacements:
                continue
            refs = copy.deepcopy(task['input_refs'])
            rebound_refs = {}
            unmapped = []
            for old_id, new_id in replacements.items():
                if new_id not in complete:
                    continue  # Its actual producer refs are pinned on later begin.
                old_attempt = next((a for a in reversed(state['attempts'])
                                    if a['task_id'] == old_id), None)
                if not old_attempt or not old_attempt.get('evidence_ref'):
                    continue
                old_envelope = _evidence(root, old_attempt, old_attempt['evidence_ref'], old_attempt['outcome'])
                new_attempt = next(a for a in reversed(state['attempts'])
                                   if a['task_id'] == new_id and a['outcome'] == 'completed')
                new_envelope = _evidence(root, new_attempt, new_attempt['evidence_ref'], 'completed')
                old_keys = {(r['path'], r['sha256']) for r in old_envelope.get('output_refs', old_envelope['raw_evidence'])}
                new_by_path = {r['path']: r for r in new_envelope.get('output_refs', new_envelope['raw_evidence'])}
                old_names = {(ref['path'], ref['sha256']): name
                             for name, ref in old_envelope.get('output_bindings', {}).items()}
                old_keys.update(old_names)
                for index, ref in enumerate(refs):
                    if (ref['path'], ref['sha256']) in old_keys:
                        name = old_names.get((ref['path'], ref['sha256']))
                        replacement = (new_envelope.get('output_bindings', {}).get(name)
                                       if name else new_by_path.get(ref['path']))
                        if replacement is None:
                            unmapped.append(ref)
                        else:
                            refs[index] = copy.deepcopy(replacement)
                            rebound_refs[(ref['path'], ref['sha256'])] = copy.deepcopy(replacement)
            successor_id = task['id'] + '-successor-' + uuid.uuid4().hex[:12]
            successor = dict(id=successor_id, action=task['action'], kind=task.get('kind', 'action'), status='pending',
                candidate_id=task['candidate_id'], input_refs=refs,
                dependencies=[replacements.get(d, d) for d in task['dependencies']])
            for key in ('repairs', 'repair_generation', 'repair_root', 'failure_context'):
                if key in task:
                    successor[key] = copy.deepcopy(task[key])
            for key in SCIENCE_FIELDS:
                if key in task:
                    value = task[key]
                    successor[key] = copy.deepcopy(rebound_refs.get((value['path'], value['sha256']), value)
                        if key.endswith('_ref') else value)
            successor['supersedes'] = task['id']
            if unmapped:
                successor.update(status='blocked', blocked_reason='replacement_output_unmapped',
                                 unmapped_input_refs=unmapped)
            task.update(status='superseded', original_status='pending', replacement_task_id=successor_id)
            state['tasks'].append(successor)
            by_id[successor_id] = successor
            changed.append({'task_id': task['id'], 'successor_id': successor_id,
                            'dependencies': replacements})
            pending.remove(task)
            progress = True
        if not progress:
            break
    _graph(state['tasks'])
    return changed


def _prepare_repair(root, state):
    """Create one bounded engineering successor from a classified observed failure."""
    refuted = {a['candidate_id'] for a in state['attempts'] if a['outcome'] == 'refuted'}
    refuted.update(c['candidate_id'] for c in state.get('research_cycles', [])
                   if c.get('recorded_verdict') == 'refuted')
    for failure in reversed(state['attempts']):
        if (failure['outcome'] != 'failed' or failure['candidate_id'] in refuted
                or failure.get('failure_class') not in REPAIR_CLASSES):
            continue
        task = next(t for t in state['tasks'] if t['id'] == failure['task_id'])
        if any(t.get('repairs') == task['id'] for t in state['tasks']):
            continue
        by_id = {t['id']: t for t in state['tasks']}
        cursor, lineage = task, set()
        while cursor.get('repairs'):
            if cursor['id'] in lineage:
                raise ValueError('repair lineage cycle requires reconciliation')
            lineage.add(cursor['id'])
            cursor = by_id[cursor['repairs']]
        generation = len(lineage) + 1
        if generation > state.get('max_repair_generations', 3):
            continue
        evidence = _evidence(root, failure, failure['evidence_ref'], 'failed')
        task_id = task['id'] + '-repair-' + failure['id'][:12]
        repair = _task(root, dict(id=task_id, action=failure['next_action'],
            kind=task.get('kind', 'action'),
            candidate_id=task['candidate_id'], dependencies=task['dependencies'],
            input_refs=copy.deepcopy(task['input_refs']), repairs=task['id'],
            **{key: copy.deepcopy(task[key]) for key in SCIENCE_FIELDS if key in task}))
        repair.update(repair_generation=generation,
            repair_root=task.get('repair_root', task['id']),
            failure_context={'attempt_id': failure['id'], 'reason': failure['stop_reason'],
                             'failure_class': failure['failure_class'],
                             'evidence_ref': failure['evidence_ref'],
                             'raw_evidence': copy.deepcopy(evidence['raw_evidence'])})
        state['tasks'].append(repair)
        task['replacement_task_id'] = repair['id']
        _graph(state['tasks'])
        return repair['id']
    return None


@_report_errors
def advance(path, expected_revision):
    """Atomically hand one action to the active Chat host; never execute or replay it."""
    path = Path(path).absolute()
    if type(expected_revision) is not int or expected_revision < 0:
        raise ValueError('explicit expected revision required')
    with _locked(path):
        state = status(path)
        if state['revision'] != expected_revision:
            raise ValueError('revision conflict; reload and reconcile before writing')
        root = path.parent
        current = state['current_attempt']
        if current and current['status'] != 'partial':
            valid_cycles, invalid_cycles = _research_cycles(root, state)
            if current.get('team'):
                return _report_decision(path, dict(_science_module('chat_team').summary(root, state, _ref),
                            revision=state['revision']))
            return dict(kind='blocked', reason='active_attempt_requires_observation',
                        attempt_id=current['id'], revision=state['revision'],
                        scientific_cycle_count=len(valid_cycles), invalid_research_cycles=invalid_cycles)
        rewired = _reconnect_repairs(root, state)
        decision = _next(root, state)
        # Ready supplementary tasks must not starve an already classified repair.
        repair_id = (_prepare_repair(root, state) if state.get('strategy')
                     and not state.get('user_pause') and state.get('stop_reason') != 'user_stopped' else None)
        if repair_id:
            decision = _next(root, state)
        if decision['kind'] in {'blocked', 'replan'} and decision.get('reason') == 'no_eligible_action':
            repair_id = _prepare_repair(root, state)
            decision = _next(root, state)
        if decision['kind'] not in ('action', 'continuation'):
            if decision.get('reason') == 'no_eligible_action':
                refuted = {a['candidate_id'] for a in state['attempts'] if a['outcome'] == 'refuted'}
                refuted.update(c['candidate_id'] for c in state.get('research_cycles', [])
                               if c.get('recorded_verdict') == 'refuted')
                failures = [a for a in reversed(state['attempts']) if a['outcome'] == 'failed'
                            and a['candidate_id'] not in refuted
                            and not any(t.get('repairs') == a['task_id'] for t in state['tasks'])]
                unknown = next((a for a in failures if a.get('failure_class', 'unknown') == 'unknown'), None)
                exhausted = next((a for a in failures if a.get('failure_class') in REPAIR_CLASSES), None)
                if unknown:
                    decision.update(kind='blocked', reason='needs_classification', attempt_id=unknown['id'])
                elif exhausted:
                    decision.update(kind='blocked', reason='repair_limit_or_evidence_block', attempt_id=exhausted['id'])
            if rewired or repair_id:
                state['revision'] += 1
                state['history'].append({'revision': state['revision'], 'event': {
                    'op': 'advance', 'repair_task_id': repair_id, 'rewired_dependencies': rewired}})
                _save(path, state)
            return _report_decision(path, dict(decision, revision=state['revision']))
        if decision['kind'] == 'action':
            _apply(root, state, {'op': 'begin', 'task_id': decision['task_id']})
        else:
            _apply(root, state, {'op': 'resume'})
        attempt = state['current_attempt']
        task = next(t for t in state['tasks'] if t['id'] == attempt['task_id'])
        handoff = dict(kind='execute', executor='active_chat_host',
            scientific_cycle_count=decision['scientific_cycle_count'],
            invalid_research_cycles=copy.deepcopy(decision['invalid_research_cycles']),
            attempt=copy.deepcopy(attempt), action=attempt['next_action'],
            procedure_text=_procedure_text(root, attempt['procedure']),
            procedure_ref=copy.deepcopy(attempt['procedure']['ref']),
            input_refs=copy.deepcopy(attempt['input_refs']),
            dependency_evidence_refs=copy.deepcopy(attempt.get('dependency_evidence_refs', [])),
            checkpoint_refs=copy.deepcopy(attempt.get('checkpoint_refs', [])),
            failure_context=copy.deepcopy(task.get('failure_context')),
            repair_generation=task.get('repair_generation', 0))
        state['revision'] += 1
        state['history'].append({'revision': state['revision'], 'event': {
            'op': 'advance', 'attempt_id': attempt['id'], 'repair_task_id': repair_id,
            'rewired_dependencies': rewired}})
        handoff['revision'] = state['revision']
        _save(path, state)
        return handoff


@_report_errors
def record(path, expected_revision, event):
    """CAS one observation; invalid or concurrent updates leave the file intact."""
    path = Path(path).absolute()
    if type(expected_revision) is not int or expected_revision < 0 or not isinstance(event, dict):
        raise ValueError('explicit expected revision and event object required')
    with _locked(path):
        state = status(path)
        if state['revision'] != expected_revision:
            raise ValueError('revision conflict; reload and reconcile before writing')
        _apply(path.parent, state, copy.deepcopy(event), checkpoint_path=path)
        state['revision'] += 1
        state['history'].append({'revision': state['revision'], 'event': copy.deepcopy(event)})
        _save(path, state)
    if event.get('op') == 'result' and event.get('outcome') in {'failed', 'blocked'}:
        _incident(path, category=str(event.get('failure_class') or 'execution') + '_failure',
            scope=event['attempt_id'], summary=event.get('reason', event['outcome']),
            next_action=event.get('next_action') or 'Inspect the actual failure and report the recovery action.',
            evidence_refs=[event['evidence_ref']] if event.get('evidence_ref') else [])
    if str(event.get('op', '')).startswith('team_') and (state.get('current_attempt') or {}).get('team'):
        try:
            if event['op'] in {'team_result', 'team_observe'}:
                reference = event.get('result_ref') or event.get('receipt_ref')
                observation = _ref(path.parent, reference, as_json=True)
                if observation.get('outcome', observation.get('state')) == 'failed':
                    _incident(path, category='child_failure',
                        scope=state['current_attempt']['id'] + '/' + event['child_id'],
                        summary='Child operation reported failure; parent completion remains unverified.',
                        next_action='Report the child failure and inspect its evidence; reconcile or repair while preserving unaffected siblings.',
                        evidence_refs=[reference])
            _report_decision(path, _science_module('chat_team').summary(path.parent, state, _ref))
        except Exception:
            # The event already committed. A report failure must not imply rollback.
            _incident(path, category='reporting_failure', scope=event['op'],
                summary='Team event committed, but its incident summary could not be collected.',
                next_action='Read the committed checkpoint and report through the host; do not replay the event.')
    if event.get('op') == 'checkpoint' and event.get('reason') in {
            'max_tokens', 'max_turn_requests', 'timeout', 'host_boundary',
            'tool_unavailable', 'cpu_unavailable', 'context_limit'}:
        _incident(path, category='execution_interrupted', scope=event['attempt_id'],
            summary='Execution checkpointed at ' + event['reason'],
            next_action=event['next_action'], evidence_refs=event.get('evidence_refs', []), severity='warning')
    return state


def _apply(root, state, event, checkpoint_path=None):
    op = event.get('op')
    current = state['current_attempt']
    paused = state.get('user_pause') or state.get('stop_reason') == 'user_stopped'
    if paused and op in {'begin', 'resume', 'team_prepare', 'team_continue'}:
        raise ValueError('user-stopped research requires a sourced resume_goal before dispatch')
    if (op in {'team_prepare', 'team_continue'} and state.get('session_contract')
            and (state.get('goal_contract') or {}).get('mode') == 'research'):
        session_decision = _science_module('chat_session').predispatch_guard(root, state, continuation=True)
        if session_decision:
            raise ValueError(session_decision['reason'] + ': ' + session_decision.get('detail', ''))
    if op == 'pause':
        _ref(root, event.get('request_ref'))
        state['user_pause'] = dict(request_ref=copy.deepcopy(event['request_ref']),
                                  reason=_text(event.get('reason'), 'pause reason'))
        state['stop_reason'] = 'user_stopped'
    elif op == 'resume_goal':
        if not paused:
            raise ValueError('resume_goal requires an existing user pause')
        _ref(root, event.get('request_ref'))
        if event['request_ref'] == (state.get('user_pause') or {}).get('request_ref'):
            raise ValueError('resumption needs a new user request, not the pause request')
        _text(event.get('reason'), 'sourced user resumption reason')
        state.setdefault('pause_history', []).append(copy.deepcopy(state.get('user_pause')))
        state['user_pause'] = None
        state['stop_reason'] = 'continuation_pending'
    elif isinstance(op, str) and op.startswith('strategy_'):
        if not _science_module('chat_strategy').apply(root, state, event, _ref):
            raise ValueError('unknown strategy operation')
    elif isinstance(op, str) and op.startswith('session_'):
        if not _science_module('chat_session').apply(root, state, event, _ref):
            raise ValueError('unknown session operation')
    elif isinstance(op, str) and op.startswith('team_'):
        _science_module('chat_team').apply(root, state, event, _ref,
            protected_paths=[checkpoint_path] if checkpoint_path else [],
            experiment_admission=lambda task: _experiment_admission(root, task, state))
    elif op == 'revise_goal':
        if current:
            raise ValueError('settle the current attempt before revising the goal')
        contract = event.get('goal_contract')
        _goal_contract(root, contract)
        previous_contract = state.get('goal_contract')
        if previous_contract and previous_contract.get('mode') == 'research' and contract['mode'] != 'research':
            raise ValueError('a research goal cannot be silently reduced to a bounded task')
        goal = _text(event.get('goal'), 'revised goal')
        for key in ('criteria', 'deliveries'):
            _ids(event.get(key), 'revised ' + key, nonempty=(key == 'criteria'))
            if not set(state[key]) <= set(event[key]):
                raise ValueError('goal revision cannot remove existing obligations')
        snapshot = {key: copy.deepcopy(state.get(key)) for key in
                    ('goal', 'goal_contract', 'criteria', 'deliveries', 'stop_reason', 'goal_review')}
        snapshot.update(goal_revision=state.get('goal_revision', 0), state_revision=state['revision'])
        state.setdefault('goal_history', []).append(snapshot)
        state.update(goal=goal, goal_contract=copy.deepcopy(contract),
            criteria=copy.deepcopy(event['criteria']), deliveries=copy.deepcopy(event['deliveries']),
            goal_revision=state.get('goal_revision', 0) + 1, goal_review=None)
        if 'stop_reason' in state and not paused:
            state['stop_reason'] = 'continuation_pending'
    elif op == 'research_cycle':
        cycle = event.get('cycle')
        if not isinstance(cycle, dict):
            raise ValueError('research cycle object required')
        existing = state.get('research_cycles', [])
        if (cycle.get('cycle_id') in {c['cycle_id'] for c in existing}
                or set(cycle.get('attempt_ids', [])).intersection(
                    a for c in existing for a in c['attempt_ids'])):
            raise ValueError('duplicate cycle id or reused research attempts')
        if any(all(c.get(key) == cycle.get(key) for key in ('candidate_id', 'hypothesis_ref', 'design_ref'))
               for c in existing):
            raise ValueError('the same hypothesis and design are already counted; additional runs are not a new cycle')
        review = _cycle(root, state, cycle)
        stored = copy.deepcopy(cycle)
        stored['recorded_verdict'] = review['verdict']
        state.setdefault('research_cycles', []).append(stored)
    elif op == 'goal_review':
        valid_cycles, invalid_cycles = _research_cycles(root, state)
        _goal_review(root, state, event.get('review_ref'), state['revision'], valid_cycles)
        satisfied, delivered, _, invalid = _credits(root, state)
        refuted = {a['candidate_id'] for a in state['attempts'] if a['outcome'] == 'refuted'}
        refuted.update(c['candidate_id'] for c in state.get('research_cycles', [])
                       if c.get('recorded_verdict') == 'refuted')
        if (current or _remaining(state, refuted) or not set(state['criteria']) <= satisfied
                or not set(state['deliveries']) <= delivered or invalid or invalid_cycles):
            raise ValueError('goal review requires settled work and valid evidence for all obligations')
        state['goal_review'] = {'ref': event['review_ref'], 'reviewed_revision': state['revision']}
    elif op == 'add_task':
        state['tasks'].append(_task(root, event.get('task')))
        _graph(state['tasks'])
    elif op == 'revise_task':
        previous = next((t for t in state['tasks'] if t['id'] == event.get('task_id')), None)
        if not previous or previous['status'] not in {'pending', 'blocked'} or previous.get('replacement_task_id'):
            raise ValueError('only unstarted pending/blocked task contracts can be revised')
        replacement = _task(root, event.get('task'))
        if (replacement['id'] == previous['id'] or replacement['candidate_id'] != previous['candidate_id']
                or not set(previous['dependencies']) <= set(replacement['dependencies'])):
            raise ValueError('task revision needs a new identity and must retain candidate/dependency obligations')
        _text(event.get('reason'), 'task revision reason')
        replacement['supersedes'] = previous['id']
        previous.update(original_status=previous['status'], status='superseded', replacement_task_id=replacement['id'])
        state['tasks'].append(replacement)
        _graph(state['tasks'])
    elif op == 'begin':
        eligible = _next(root, state)
        if eligible['kind'] != 'action' or eligible['task_id'] != event.get('task_id'):
            raise ValueError('task is not the next eligible action')
        task = next(t for t in state['tasks'] if t['id'] == event['task_id'])
        _procedure(root, state['procedure'])
        _refs(root, task['input_refs'])
        dependency_refs = _dependency_refs(root, state, task['dependencies'])
        state['started_attempts'] += 1
        state['current_attempt'] = dict(id=uuid.uuid4().hex, task_id=task['id'],
            kind=task.get('kind', 'action'),
            candidate_id=task['candidate_id'], input_refs=copy.deepcopy(task['input_refs']),
            dependency_evidence_refs=dependency_refs,
            procedure=copy.deepcopy(state['procedure']), status='active', next_action=task['action'])
        for key in SCIENCE_FIELDS:
            if key in task:
                state['current_attempt'][key] = copy.deepcopy(task[key])
        _science_module('chat_strategy').before_begin(root, state, task, state['current_attempt'], _ref)
        task['status'] = 'active'
    elif op in ('checkpoint', 'result', 'resume'):
        if not current or (op != 'resume' and event.get('attempt_id') != current['id']):
            raise ValueError('current attempt binding required')
        task = next(t for t in state['tasks'] if t['id'] == current['task_id'])
        if op == 'checkpoint':
            current.update(status='partial', stop_reason=_text(event.get('reason'), 'stop reason'),
                           next_action=_text(event.get('next_action'), 'next action'))
            if event.get('evidence_refs') is not None:
                _refs(root, event['evidence_refs'])
                current['checkpoint_refs'] = event['evidence_refs']
            task['status'] = 'partial'
        elif op == 'resume':
            if current['status'] != 'partial':
                raise ValueError('only an acknowledged partial checkpoint can resume')
            if current.get('team'):
                _science_module('chat_team').assert_joined(root, current, _ref)
            if _next(root, state)['kind'] != 'continuation':
                raise ValueError('current attempt needs reconciliation or remaining budget')
            _procedure(root, current['procedure'])
            _refs(root, current['input_refs'])
            _refs(root, current.get('dependency_evidence_refs', []))
            _refs(root, current.get('checkpoint_refs', []))
            current['status'] = task['status'] = 'active'
            current['stop_reason'] = None
        else:
            outcome = event.get('outcome')
            if current.get('team'):
                _science_module('chat_team').assert_joined(root, current, _ref,
                    tolerate_invalid=outcome in {'failed', 'blocked'})
                current['invalidated_parent_pins'] = _science_module('chat_team')._invalid_pins(root, current, _ref)
            if outcome not in OUTCOMES:
                raise ValueError('unsupported operational outcome')
            if outcome == 'completed' and not set(task['dependencies']) <= _credits(root, state)[2]:
                raise ValueError('prerequisite evidence is no longer valid')
            if outcome != 'blocked' or event.get('evidence_ref') is not None:
                evidence = _evidence(root, current, event.get('evidence_ref'), outcome)
                if (not set(evidence.get('criteria_met', [])) <= set(state['criteria'])
                        or not set(evidence.get('delivery_receipts', {})) <= set(state['deliveries'])):
                    raise ValueError('evidence names undeclared goal obligations')
                current['evidence_ref'] = event['evidence_ref']
            if outcome != 'completed':
                current['stop_reason'] = _text(event.get('reason'), 'stop reason')
                current['next_action'] = _text(event.get('next_action'), 'next action')
            if outcome == 'failed':
                failure_class = event.get('failure_class', 'unknown')
                if failure_class not in FAILURE_CLASSES:
                    raise ValueError('unsupported failure classification')
                current['failure_class'] = failure_class
            current.update(outcome=outcome, status=outcome)
            _science_module('chat_strategy').after_result(root, state, current, event, _ref)
            task['status'] = outcome
            state['attempts'].append(current)
            state['current_attempt'] = None
    elif op == 'classify_failure':
        failure = next((a for a in state['attempts'] if a['id'] == event.get('attempt_id')
                        and a['outcome'] == 'failed'), None)
        if failure is None or failure.get('failure_class', 'unknown') != 'unknown':
            raise ValueError('an unclassified failed attempt is required')
        failure_class = event.get('failure_class')
        if failure_class not in FAILURE_CLASSES - {'unknown'}:
            raise ValueError('concrete failure classification required')
        _ref(root, event.get('evidence_ref'))
        failure.update(failure_class=failure_class, classification_ref=event['evidence_ref'],
                       next_action=_text(event.get('next_action'), 'classified next action'))
    elif op == 'adopt':
        procedure = event.get('procedure')
        _procedure(root, procedure)
        if procedure['id'] in state['procedure_versions']:
            raise ValueError('procedure update needs an unused version id')
        review = _ref(root, event.get('review_ref'), as_json=True)
        binding = {'kind': 'procedure_review', 'base_procedure_id': state['procedure']['id'],
                   'base_procedure_sha256': state['procedure']['ref']['sha256'],
                   'candidate_procedure_id': procedure['id'], 'candidate_sha256': procedure['ref']['sha256'],
                   'outcome': 'supported'}
        if any(review.get(key) != value for key, value in binding.items()):
            raise ValueError('procedure review binding mismatch')
        if _text(review.get('review_task_id'), 'review task') == _text(review.get('proposal_task_id'), 'proposal task'):
            raise ValueError('separate review task required')
        _refs(root, review.get('raw_evidence'), nonempty=True)
        state['procedure'] = procedure
        state['procedure_versions'][procedure['id']] = procedure['ref']['sha256']
    elif op == 'bind_resources':
        if current:
            raise ValueError('settle the current attempt before binding resource limits')
        _ref(root, event.get('source_ref'))
        limits = event.get('limits')
        if not isinstance(limits, dict) or not {'wall_seconds', 'gpu_seconds', 'cost'} <= set(limits):
            raise ValueError('resource limits require wall_seconds, gpu_seconds and cost')
        previous = state['budget'].get('limits', {})
        if any(limits.get(key) != value for key, value in previous.items()):
            raise ValueError('resource binding cannot remove or change prior cumulative limits')
        for key, value in limits.items():
            _text(key, 'resource unit')
            _number(value, 'resource limit')
        state['budget']['limits'] = copy.deepcopy(limits)
        state['resource_budget_ref'] = event['source_ref']
        _apply(root, state, dict(op='usage', totals=event.get('totals'), receipt_ref=event.get('receipt_ref')))
    elif op == 'usage':
        if current and current.get('team'):
            raise ValueError('use team_usage to account live team usage without releasing unknown reservations')
        totals = event.get('totals')
        limits = state['budget'].get('limits', {})
        if not isinstance(totals, dict) or set(totals) != set(limits) or not limits:
            raise ValueError('usage totals must cover exactly the declared external limits')
        _ref(root, event.get('receipt_ref'))
        for unit, amount in totals.items():
            if _number(amount, unit) < state['usage']['totals'].get(unit, 0):
                raise ValueError('cumulative observed usage cannot decrease')
        state['usage'] = {'totals': totals, 'receipt_ref': event['receipt_ref'],
                          'observed_attempt_ids': [a['id'] for a in state['attempts']]}
    else:
        raise ValueError('unknown record operation')


def resume(path, expected_revision):
    return record(path, expected_revision, {'op': 'resume'})


def adopt(path, expected_revision, procedure, review_ref):
    return record(path, expected_revision, {'op': 'adopt', 'procedure': procedure, 'review_ref': review_ref})


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('command', choices=('init', 'status', 'next', 'record', 'resume', 'adopt', 'advance'))
    parser.add_argument('--state', required=True)
    parser.add_argument('--config')
    parser.add_argument('--event')
    parser.add_argument('--expected-revision', type=int)
    parser.add_argument('--host-invocation-id', help='Host-observed ID or fresh coordinator nonce for this invocation')
    args = parser.parse_args(argv)
    try:
        with _science_module('chat_session').host_invocation(args.host_invocation_id):
            if args.command == 'init':
                if not args.config:
                    raise ValueError('--config is required')
                result = initialize(args.state, _json(args.config))
            elif args.command == 'status':
                result = status(args.state)
            elif args.command == 'next':
                result = next_action(args.state)
            elif args.command == 'resume':
                result = resume(args.state, args.expected_revision)
            elif args.command == 'advance':
                result = advance(args.state, args.expected_revision)
            else:
                if not args.event:
                    raise ValueError('--event is required')
                event = _json(args.event)
                if args.command == 'adopt':
                    event['op'] = 'adopt'
                result = record(args.state, args.expected_revision, event)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
    except (OSError, ValueError, TypeError, KeyError) as error:
        print(str(error), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
