# Background exception reporting

Contents: [worker](#report-from-the-worker), [watcher](#independent-watch),
[record](#incident-record), [delivery](#delivery-and-recovery).

The owner requires background reports for abnormalities, including unavailable
CPU execution. Apply this on every Work Auto invocation and to actual scheduled
task prompts. An exception report is independent of a scientific result. A skill
file supplies instructions; it does not install a notification transport or make
the current CPU/process continuously available.

## Report from the worker

Report a newly observed abnormality during the current invocation, before long
diagnosis or retries and without waiting for the next normal progress summary.
Include resolved-in-round incidents in the report rather than silently hiding
them. Cover at least:

| Observation | What to report and preserve |
| --- | --- |
| CPU/shell/executor absent, refused or unreachable | Identify the missing capability or returned error and affected step. Do not call this a scientific failure or invent a process exit code. |
| Resource quota lower than admitted needs, memory failure, OOM indication | State measured limits and observations. An unexplained process kill is not automatically an OOM. |
| Command failure, timeout, cancellation or interrupted response | Preserve attempt/session identity, exit/timeout evidence, known outputs and remaining reservations. |
| Worker, backend, scheduler or source connection unavailable | Distinguish observed failure from unknown live execution state; retain last observed time. |
| Lost heartbeat, unchanged checkpoint beyond its expected deadline | Report overdue/unknown status with its actual deadline; do not infer CPU failure from silence. |
| Corrupt/missing output, hash/CRC mismatch, failed metric or verifier check | Mark affected evidence unusable/pending, retain failure and identify affected claims. |
| Write conflict, failed persistence/delivery, exhausted budget, version or ownership conflict | Preserve current records and pending work; report the exact blocked action. |

Unexpected abnormalities also require a scoped report. An ordinary negative
scientific result belongs in the research report; it is not an infrastructure
failure. Never suppress a failed check merely because a fallback produced output.

If the CPU tool itself is absent or broken, use the current host conversation or
supported notification channel immediately. Saving an incident or executing a
diagnostic script is NOT a prerequisite for telling the owner. Use an available
authorized connector to persist the record; if that also fails, report that
failure in the same message. Do not keep retrying a broken tool to earn permission
to report it. Redact secrets and private payloads; retain safe error codes and
evidence locators rather than dumping arbitrary environment variables or logs.

Stop only affected dispatches and continue independent admitted work within the
existing scope. Preserve finite repair limits. A lost acknowledgment requires
reconciliation of the same attempt, not a new run. Do not restart a paused project,
buy compute, change host/model, reduce scientific criteria or reset budgets to
make an incident disappear.

## Independent watch

When the owner requests background exception notifications, use a real supported
automation/monitor if exposed. Reuse an existing matching watcher; privately look
up tasks before creating one. This is an explicitly requested report-only watch,
separate from the production worker and its resource pool. It is not a substitute
for Work production and must never resume, run or change the research task.

Bind it to an actual task ID plus project/repository and checkpoint locator, not
a title alone or every task in the account. Verify each required external app
with a harmless read before activation. Use the owner's IANA timezone. For a
condition watch use the platform's supported cadence; ChatGPT scheduled watches
currently allow at most hourly checks. Do not promise immediate detection of a
worker that dies between checks, nor a notification while the notification
platform itself is unavailable. Do not create a paid service or install another
backend to implement reporting.

At each check:

1. Privately inspect the actual target task and current checkpoint/status source.
   Restore previous incident reports when accessible. Read source records through
   connectors, so the watch does not require the failed research CPU. A watcher
   CPU working or failing says nothing by itself about the research CPU.
2. Respect explicit pause/completion and the user's latest stop. No CPU activity
   in that state is expected. A task disappearing is unknown until its deletion,
   replacement or completion is established; do not guess or switch to a similar
   task. If identity/source access cannot be checked, report monitoring unavailable
   once as its own incident, not research/CPU failure.
3. For expected-active work, check real error receipts, pending incident records,
   actual run state and progress deadlines. A schedule's last-run timestamp proves
   a trigger only, not CPU execution or completion. A newer unrelated commit is
   not research progress. Use the saved admitted run/report deadline plus queue
   grace. If no deadline exists, a configurable fallback is two missed expected
   report opportunities; label it a monitoring threshold, not a process timeout.
   Record a first active observation and wait the threshold if the activation
   time is unknown; never treat a long prior pause as time spent stuck.
4. Notify on a new incident, material change/escalation, or evidence-supported
   recovery. Keep monitoring reports separate from experiment progress. Do not
   write research results, change task enablement or launch diagnostics/experiments.

Record the real watcher ID, target ID, enabled state, schedule, source locators and
last verified setup time in the actual task configuration or approved project
record. Preserve existing tasks' cadence, triggers, goals, pins and enablement
when adding the reporting instruction. Source updates do not migrate live research
policy. If notification setup fails, state exactly what is unavailable and keep
the worker's direct-report obligation; do not claim background alerts are active.

## Incident record

Use a compact record in the existing project incident log or watcher report
history, not a second authoritative task state machine. Include:

- project, real task/run/attempt identity when known;
- stable incident key (project + run/attempt + component + error category),
  first observed time, last observed time, user timezone and last healthy evidence;
- category, open/changed/recovered state, impact and affected step;
- observed facts, unknowns, safe error/evidence locator and current checkpoint;
- bounded actions actually attempted, their outcomes, next action and whether
  owner action is necessary;
- notification state: pending, submitted, confirmed or unknown, with an actual
  host receipt only where exposed. A saved file alone is not a delivered report.

Do not fabricate a missing incident ID, process ID, receipt or timestamp. Use a
clear unknown value. Error wording, memory addresses and changing timestamps
alone do not create new incident keys. Separate incidents on different attempts
or components must not be collapsed into one generic "CPU error".

## Delivery and recovery

Send a concise Chinese report through the user's requested host/task channel:
what happened, when and where, impact, verified action and next step. If work is
blocked, state that it is blocked; never leave the visible status at "running"
without qualification. Routine healthy checks need no extra alert. Deduplicate
using actual accessible incident/report history; do not claim guaranteed exactly-
once delivery if the host exposes no notification receipt or durable history.
An unknown or failed delivery stays pending and must not be silently treated as
notified. A bounded retry may cause a duplicate; prefer honesty about that fact.

Keep reporting errors visible separately from scientific execution errors. If
the process, connector and notification service all fail, later recovery must
report the observation gap; no same-process handler can promise notification
during that outage. A recovered connection is not proof that the original
experiment completed: reconcile its original attempt and receipts first.
