# Edition policy and decision ownership

## Work Harness C/D profile

Restore `sequence.flow_profile` before applying inherited workflow rules. For
`work-harness-cd-v1`, read [C/D mathematical diagnosis and executable idea development](cd-math-code-loop.md).
The versioned catalog `assets/skill-sequence-cd-v1.json` and its overriding node
guides govern C's condition/failure/dependency diagnosis, D's mechanism construction
and real local experiments, reviewed B/C/D revisits and M05 `VERIFIED_FOR_SCALEUP`.
B05 validates a supported problem contract; old Natural Gate 0/IPCG prerequisites
do not apply to this profile's local diagnostic/development work. Independent
verified review plus program checks advances automatically into E, which retains
full settings, freezing, fair comparisons, scale and confirmation.

The worker proposes typed revisits and code applies approved transitions; no raw
skip/jump is allowed. Preserve source/evidence lineage, failed findings, external
jobs, cumulative usage and pause state. Omitted `flow_profile` retains legacy
catalog/transition behavior. Profile-specific rules override conflicting inherited
C/D ordering/admission text below only when the profile is actually adopted.
Installation alone does not migrate a running project or change another edition.

This edition policy, skill-sequence.md, research-harness.md and round-continuation.md take precedence
over inherited routing, candidate quotas and round-end defaults throughout this package.
This checkout is autonomous-rsi-harness, version 0.4.0-harness.6: the fifth,
Work-derived edition, keeping existing Codex and other local agents.
Scientific evidence requirements still apply to the actual claim.

## Control-agent ownership and physical execution targets

EDITION.json's authoring_host and execution_host identify the agent environment
and execution-control responsibility. execution_host=local_agent means the agent
on the user's computer supervises execution; it does not assign every workload
to that computer. Main/Work/Work Harness/Simple first restore the existing authorized SSH target
and task needs, then record actual job host/path/environment/allocation in project
plans and receipts. Reuse an already authorized SSH GPU route without new permission.
Chat remains inside its own CPU/4 GB profile; this distinction adds no SSH route to
Chat. Metadata is not a measured allocation or a resource-enforcement mechanism.

## Native execution everywhere; no Docker

The owner excludes Docker on every host and in every edition: the user's computer,
SSH GPU servers and Chat execution tools. Do not install/start Docker or a daemon,
run/build images, use Compose/Docker-in-Docker, or make a Docker-based helper a
prerequisite. Use qualified native Conda/venv/system-Python paths and inspect helper
scripts for hidden container launches. An upstream Dockerfile can inform native
dependency setup but does not authorize execution. Do not substitute another
container runtime to evade this rule. If no faithful native implementation/scorer
is available, retain that evidence gap and continue other useful work.

## Native scoring does not create a universal training gate

Use native-scoring-stages.md. Training, prediction/export and final scoring have
separate dependencies. Restore the project's implemented deferred/offline scoring
mode before declaring a blocker. Missing final-scoring capability holds that
operation and its claim; independent authorized training/export can proceed and
save unscored outputs. Native scoring later consumes the real saved artifacts.
Only actual training-time feedback is a training dependency. Never invent scores,
discard failed cases or require Docker for any phase.

## Serial experiments and descending batches

Use [single-experiment batching](single-experiment-batching.md): one active
experiment program, sequential descending batch calibration (for example
64 → 32 → 16 → 8 → 4 → 2), preserved scientific semantics and measured useful
throughput/headroom. Queue other experiments; keep Chat within CPU/4 GB.
This rule overrides inherited multi-experiment and same-card-sharing defaults.

## GitHub is direct source and evidence storage

Use GitHub only for direct pull/read and push/write of authorized source,
checkpoints and evidence. Scoped connector reads of files, commits, trees and
blobs and conditional Git commits/ref updates are valid equivalents of pull/push.
Normal Git is also valid on an actually authorized host with working access.
Keep the selected repository, branch and paths; read current HEAD before writing,
preserve concurrent changes, never force-push, and read back exact bytes/hashes at
the delivered commit before reporting a successful save. A lost write response
requires readback before retrying. A denied write remains blocked; do not switch
credentials, interfaces or hosts to evade the denial.

Do not explicitly dispatch, inspect, rerun, poll or depend on GitHub Actions, workflow runs,
workflow_dispatch or CI control APIs. Do not create workflows or use pull requests
to persist routine research. Run experiments, software checks and package builds
on the actual authorized host; use that host's supported continuation mechanism.
GitHub stores progress; it does not run the decision agent or the experiment.
Keep `.github/workflows` absent in this source repository's five branches;
do not recreate workflow definitions. Repository Actions has been disabled by
the owner-requested repository setting; do not re-enable it. Do not modify another
repository's automation or settings without its own authorization.

Record actual host execution in plain `.log` files, then push the authorized,
reviewed logs as ordinary GitHub files. Include the source revision, exact command,
start/end times when observed, exit status and actual stdout/stderr; never invent
missing historical metadata. Use `logs/maintenance/` for source maintenance and
the existing goal-bound evidence path for a research project. Preserve failures,
negative findings and cumulative budgets; redact credentials/private environment
values without converting a failed result into success. Read back the uploaded
log bytes or hashes. Do not use workflow runs, Actions artifacts or CI statuses
as log storage. Historical CI records are not a current required gate.

The owner explicitly authorized autonomous-rsi-harness as a fifth Work-derived
source branch alongside main, autonomous-rsi, autonomous-rsi-chat and rsi-simple.
That request supersedes the old four-branch limit. Update each selected edition on
its own observed parent; do not merge editions or create publication/staging branches.
Other research repositories retain their own explicitly authorized branch/path
contracts; this five-branch rule does not
authorize deleting their branches. Fixed source pins, including a running .14
task, remain fixed until separately adopted at an authorized quiet boundary.

## GitHub unavailable: downloadable ZIP

Apply [github-zip-fallback.md](github-zip-fallback.md) whenever an authorized read,
write or exact readback cannot complete. Create and verify a real ZIP containing
current code, results, ordinary logs, checkpoint and a hash manifest; expose it
through the host's supported user download channel without waiting indefinitely
for GitHub. Mark remote synchronization pending or unknown as observed. Preserve
failed evidence, source pins, pauses, budgets and coordination requirements. This
fallback takes precedence over inherited GitHub-only delivery wording, not access
controls or scientific gates. Reconcile the remote state before a later push.

## Optional Xiaohongshu idea discovery

At new research/idea intake, offer or reuse the optional source choice under
[xiaohongshu-idea-discovery.md](xiaohongshu-idea-discovery.md). Disabled, deferred
or unavailable access never blocks ordinary paper/code investigation. This choice
does not install/connect a provider, delegate human scientific decisions, expand
resources, start a crawler or import fixed candidate quotas. Treat public technical
discussions as leads and verify closest work with primary papers and actual code.

## Shared field research and mathematical tools

Apply [research-cycle.md](research-cycle.md) throughout the project. Keep one selected
field while accumulating relevant papers, code knowledge and purposeful reproductions.
Investigate concrete limitations or changed conditions; use modeling, derivation,
optimization and targeted experiments to resolve those questions. Retain strong
baselines, native evaluation, full costs and negative evidence. A new formula or
experiment is not required at every round. This governs inherited research ordering.

## Program-owned ordered Skill execution

Read [skill-sequence.md](skill-sequence.md). The program owns the canonical
84-node order, active/inactive scope decisions, current cursor, per-step
acceptance and repeat/once transitions. The legacy `planner` role performs the
current assigned step; neither worker nor reviewer may select a successor, skip
a node or declare the goal finished. Child results must be read back and bound
to fixed requirements before separate acceptance advances the cursor.

Research stays mandatory. Manuscript, revision, release and communication scopes
are included only for the actual user objective, without extra publication or
message authority. New schema-2 contracts select `repeat` or `once`; retained
schema-1 contracts are recovery-only and never silently migrated. Repeat carries
knowledge gaps and negative findings forward after ordered steps and the current
frozen empirical matrix are accepted/verified. Once also requires full-goal
coverage. Pause, original cumulative limits and real blockers remain binding.

## Pure local-agent execution

Work Harness is the fifth full local-agent edition, derived from Auto Work;
neither edition requires ChatGPT Work mode. Use research-harness.md for the
persistent ordered Skill loop, current-step command worker and independent reviewer, v4
decision bindings, native tasks and archived-result recovery. The full program
requires the source runtime installed from this selected branch; importing the
four-skill ZIP alone supplies instructions and cannot activate the program. Use local-execution.md and the actual local terminal,
filesystem and tools for research control, development and result review. Restore
the existing authorized SSH GPU target before deciding workload placement; sync
pinned code and supervise remote jobs when that route fits the task. Use measured
CPU/RAM/GPU resources of the actual execution target, without a universal 4 GB cap.
Execute the program-assigned node within scope and cumulative limits; only code
advances or repeats the accepted sequence.
Use a real local-agent continuation/decision consumer when available; report a
missing continuation capability without inventing a Work handoff or cloud task.
A resident driver may continue bounded rounds within retained cumulative limits;
a 24-hour task or reporting boundary is not whole-goal completion. Persisted state
alone is not a scheduler. Preserve explicit program pause even when the host has
no active goal object. No default daemon or live-project migration is authorized
by source publication.

## Shared research improvements

Frame the object, information, objective and cost before choosing a familiar
method (inquiry-generation.md). Link the goal, native/proxy metrics, strongest
compatible comparator, actual population and full cost (goal-linked-quality.md).
Use consequential mathematical derivation DAGs, falsifiers and independent
review; reuse valid prefixes and invalidate affected descendants (math-handoff.md).
Choose evidence that can change the parent decision, bound repeated work on a
mechanism family, and consume actual diagnostics before investing again
(research-reasoning.md). Do not require a fixed 20-to-15 pool. Use the assigned node to address the relevant unresolved
knowledge or evidence question within the field. Advance a construction when its
premises and nearest alternatives are understood sufficiently for the proposed claim.

For canonical full-edition batches record pool_target=1, selection_target=1 and
a sourced target_override for this edition, or an explicitly chosen broader
scope. Simple retains its own claim-scoped admission rather than importing those
batch gates. Preserve native evaluation meaning, independent confirmation,
negative findings and actual uncertainty. Shared checkers establish record
consistency, not novelty, mathematical truth or scientific effectiveness.

Restore resources, source versions and unknown jobs before retries. Adopt updates
at a quiet boundary, preserve cumulative usage and pauses, and verify durable
readback (operational-recovery.md). Source publication, installation, adopted
procedure and observed service execution are separate facts.

For executable CPU/RAM/disk admission and automatic resource rechecks, read [resource-queue.md](resource-queue.md). Temporary contention keeps the goal active; preserve original deadlines and explicit pauses.
