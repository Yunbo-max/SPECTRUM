"""Real files, CLI and lineage branches; no provider, model or research calls."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts/chat_session.py'
SPEC = importlib.util.spec_from_file_location('chat_session_tests_module', SCRIPT)
S = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(S)


class ChatSessionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.state_path = self.root / 'state.json'
        self.procedure = dict(id='procedure-v1', ref=self.write('procedure.md', 'Pinned procedure v1'))
        self.source = self.write('contract.md', 'Pinned source .8')
        self.contract = dict(package_id='research-autopilot-auto-chat', release='chat.8',
            source_revision='source-sha8', required_source_refs=[self.source],
            destination='authorized-project/checkpoint', max_unsaved_revisions=32)
        self.state = dict(revision=0, goal_id='whole-project', history=[], procedure=self.procedure,
            session_contract=self.contract, attempts=[], current_attempt=None, tasks=[])
        S.initialize(self.root, self.state)
        S.record_revision(self.state)
        self.persist()

    def write(self, name, value):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value if isinstance(value, str) else json.dumps(value), encoding='utf-8')
        return dict(path=name, sha256=hashlib.sha256(path.read_bytes()).hexdigest())

    def persist(self, path=None, state=None):
        (path or self.state_path).write_text(json.dumps(state or self.state), encoding='utf-8')

    def event(self, op, **values):
        clone = copy.deepcopy(self.state)
        event = dict(op=op, **values)
        self.assertTrue(S.apply(self.root, clone, event))
        clone['revision'] += 1
        clone['history'].append(dict(revision=clone['revision'], event=event))
        S.record_revision(clone)
        self.state = clone
        self.persist()

    def bootstrap(self, invocation='turn-1', **changes):
        value = dict(kind='chat-session-bootstrap', project_uuid=self.state['session']['project_uuid'],
            host_invocation_id=invocation, package_id=self.contract['package_id'],
            release=self.contract['release'], source_revision=self.contract['source_revision'],
            procedure=self.procedure, read_source_refs=[self.source, self.procedure['ref']],
            observation_ref=self.write('observe-' + str(self.state['revision']) + '.txt', 'Observed actual host source reads'))
        value.update(changes)
        ref = self.write('bootstrap-' + invocation + '-' + str(self.state['revision']) + '.json', value)
        self.event('session_bootstrap', receipt_ref=ref)
        return ref

    def guard(self, invocation='turn-1', **kwargs):
        return S.predispatch_guard(self.root, self.state, invocation_id=invocation, **kwargs)

    def export(self, name='manifest.json'):
        self.persist()
        return S.export_manifest(self.state_path, self.root / name)

    def saved(self, manifest_ref):
        manifest = S.verify_manifest(self.root, manifest_ref)
        receipt = self.write('save-' + str(self.state['revision']) + '.json', dict(
            kind='chat-checkpoint-save', project_uuid=self.state['session']['project_uuid'],
            destination=self.contract['destination'], manifest_sha256=manifest_ref['sha256'],
            revision=manifest['revision'], operation_id='save-' + str(self.state['revision']),
            execution_ref=self.write('save-observed-' + str(self.state['revision']) + '.txt', 'actual save observation')))
        self.event('session_saved', manifest_ref=manifest_ref, receipt_ref=receipt)
        return receipt

    def readback(self, **changes):
        pending = self.state['session']['pending_save']
        manifest = S.verify_manifest(self.root, pending['manifest_ref'])
        save_receipt = S._ref(self.root, pending['receipt_ref'], as_json=True)
        readback_manifest = self.write('download-' + str(self.state['revision']) + '.json',
            (self.root / pending['manifest_ref']['path']).read_text())
        value = dict(kind='chat-checkpoint-readback', project_uuid=self.state['session']['project_uuid'],
            destination=self.contract['destination'], save_operation_id=save_receipt['operation_id'],
            revision=manifest['revision'], operation_id='read-' + str(self.state['revision']),
            readback_manifest_ref=readback_manifest,
            restored_artifact_refs=[manifest['checkpoint_ref']] + manifest['artifacts'],
            execution_ref=self.write('read-observed-' + str(self.state['revision']) + '.txt', 'actual readback observation'))
        value.update(changes)
        receipt = self.write('readback-' + str(self.state['revision']) + '.json', value)
        self.event('session_readback', receipt_ref=receipt)
        return receipt

    def test_missing_bootstrap_blocks_new_work(self):
        self.assertIn('bootstrap required', self.guard()['detail'])

    def test_pinned_loaded_sources_and_live_invocation_allow_dispatch(self):
        self.bootstrap()
        with S.host_invocation('turn-1'):
            self.assertIsNone(S.predispatch_guard(self.root, self.state))
        with S.host_invocation(None):
            self.assertIn('invocation identity', S.predispatch_guard(self.root, self.state)['detail'])

    def test_saved_bootstrap_cannot_authenticate_a_new_invocation(self):
        self.bootstrap()
        self.assertIn('another host invocation', self.guard('turn-2')['detail'])

    def test_fresh_coordinator_nonce_supports_host_without_provider_turn_id(self):
        invocation = S.new_invocation()
        self.bootstrap(invocation['id'], invocation_origin=invocation['origin'])
        self.assertIsNone(self.guard(invocation['id']))
        self.assertEqual(self.state['session']['bootstrap']['invocation_origin'], 'coordinator_nonce')
        next_turn = S.new_invocation()
        self.assertNotEqual(invocation['id'], next_turn['id'])
        self.assertIn('another host invocation', self.guard(next_turn['id'])['detail'])

    def test_malformed_nonce_and_unknown_origin_are_not_provider_observations(self):
        with self.assertRaisesRegex(ValueError, 'UUID required'):
            self.bootstrap('copied-stage-R014', invocation_origin='coordinator_nonce')
        with self.assertRaisesRegex(ValueError, 'invocation origin'):
            self.bootstrap(invocation_origin='authenticated-by-model')

    def test_loaded_release_source_revision_and_package_are_each_checked(self):
        for field in ('release', 'source_revision', 'package_id'):
            with self.subTest(field=field):
                self.bootstrap(**{field: 'old'})
                self.assertIn(field, self.guard()['detail'])

    def test_required_source_must_be_observed_read_and_unchanged(self):
        self.bootstrap(read_source_refs=[self.procedure['ref']])
        self.assertIn('not observed as read', self.guard()['detail'])
        self.bootstrap()
        (self.root / self.source['path']).write_text('Changed source after bootstrap')
        self.assertIn('hash mismatch', self.guard()['detail'])

    def test_current_host_context_rejects_receipt_for_other_host(self):
        with S.host_invocation('real-invocation'):
            with self.assertRaisesRegex(ValueError, 'differs from current host'):
                self.bootstrap('different-invocation')

    def test_procedure_adoption_requires_rebootstrap_without_mutating_old_attempt(self):
        self.bootstrap()
        old = copy.deepcopy(self.procedure)
        new = dict(id='procedure-v2', ref=self.write('procedure-v2.md', 'Changed procedure'))
        self.state['current_attempt'] = dict(id='attempt-1', task_id='task-1', status='partial', procedure=old)
        self.state['procedure'] = new
        self.assertIn('pinned procedure', self.guard()['detail'])
        self.assertIsNone(self.guard(continuation=True))
        self.assertEqual(self.state['current_attempt']['procedure'], old)

    def test_old_attempt_recovery_does_not_require_unavailable_new_release_sources(self):
        self.bootstrap()
        self.state['current_attempt'] = dict(id='old', procedure=self.procedure, status='partial')
        self.state['session_contract']['required_source_refs'] = [{'path': 'unavailable-new.md', 'sha256': '0' * 64}]
        self.assertIsNone(self.guard(continuation=True))
        self.assertIsNotNone(self.guard())

    def test_new_invocation_can_bootstrap_exact_old_partial_when_new_release_is_missing(self):
        self.bootstrap('first-turn')
        old = copy.deepcopy(self.procedure)
        self.state['current_attempt'] = dict(id='old-attempt', task_id='old-task', procedure=old, status='partial')
        self.state['session_contract']['required_source_refs'] = [{'path': 'missing-next-release.md', 'sha256': '0' * 64}]
        self.state['revision'] += 1
        S.record_revision(self.state)
        self.assertIn('another host invocation', self.guard('second-turn', continuation=True)['detail'])
        with self.assertRaises(OSError):
            self.bootstrap('second-turn')
        self.bootstrap('second-turn', scope='continuation', attempt_id='old-attempt', procedure=old)
        self.assertIsNone(self.guard('second-turn', continuation=True))
        self.assertIsNotNone(self.guard('second-turn'))
        self.assertEqual(self.state['current_attempt']['procedure'], old)
        self.assertEqual(self.state['current_attempt']['id'], 'old-attempt')

    def test_continuation_bootstrap_cannot_target_another_attempt_or_create_new_work(self):
        self.state['current_attempt'] = dict(id='old', task_id='task', status='partial', procedure=self.procedure)
        self.state['revision'] += 1
        S.record_revision(self.state)
        with self.assertRaisesRegex(ValueError, 'exact current attempt'):
            self.bootstrap(scope='continuation', attempt_id='different')
        self.bootstrap(scope='continuation', attempt_id='old')
        self.assertIsNone(self.guard(continuation=True))
        self.assertIn('cannot authorize a new attempt', self.guard()['detail'])

    def test_legacy_checkpoint_readable_but_new_dispatch_requires_migration(self):
        legacy = dict(revision=10, goal_id='old-goal', attempts=[{'id': 'old'}], history=[],
                      current_attempt=None, procedure=self.procedure)
        self.assertIsNone(S.validate_lineage(legacy))
        self.assertIn('migration', S.predispatch_guard(self.root, legacy, invocation_id='turn-1')['detail'])
        S.apply(self.root, legacy, dict(op='session_policy', contract=self.contract,
            source_ref=self.source, reason='Explicitly adopt current source at boundary'))
        self.assertEqual(legacy['attempts'], [{'id': 'old'}])
        self.assertEqual(legacy['revision'], 10)
        S.record_revision(legacy)
        self.assertIsNotNone(S.validate_lineage(legacy))

    def test_policy_change_cannot_repin_live_attempt(self):
        self.state['current_attempt'] = dict(id='live', procedure=self.procedure)
        with self.assertRaisesRegex(ValueError, 'settle current attempt'):
            self.event('session_policy', contract=self.contract, source_ref=self.source, reason='Update')

    def test_session_migration_preserves_missing_historical_refs_for_reconciliation(self):
        legacy = dict(revision=10, history=[], current_attempt=None, procedure=self.procedure,
            attempts=[dict(id='old', evidence_ref={'path': 'missing.json', 'sha256': '0' * 64})])
        S.apply(self.root, legacy, dict(op='session_policy', contract=self.contract,
            source_ref=self.source, reason='Explicit migration with old evidence still unresolved'))
        self.assertEqual(legacy['attempts'][0]['evidence_ref']['path'], 'missing.json')

    def test_checkpoint_hash_detects_same_revision_edit(self):
        self.state['goal_id'] = 'silently-changed'
        with self.assertRaisesRegex(ValueError, 'lineage content'):
            S.validate_lineage(self.state)
        with self.assertRaisesRegex(ValueError, 'new revision'):
            S.record_revision(self.state)

    def test_checkpoint_revisions_are_contiguous_and_idempotent(self):
        old = copy.deepcopy(S.record_revision(self.state))
        self.assertEqual(S.record_revision(self.state), old)
        self.state['revision'] += 2
        with self.assertRaisesRegex(ValueError, 'exactly one'):
            S.record_revision(self.state)

    def test_export_is_immutable_and_captures_actual_attempt_ids(self):
        self.state['attempts'] = [dict(id='unique-attempt', task_id='R015', status='completed',
            outcome='completed', procedure=self.procedure, experiment_job_ids=['unique-job'])]
        self.state['revision'] += 1
        S.record_revision(self.state)
        ref = self.export()
        manifest = S.verify_manifest(self.root, ref)
        self.assertEqual(manifest['attempts'][0]['attempt_id'], 'unique-attempt')
        self.assertEqual(manifest['attempts'][0]['experiment_job_ids'], ['unique-job'])
        self.assertIsNone(self.state['session']['acknowledged_head'])
        with self.assertRaisesRegex(ValueError, 'already exists'):
            self.export()

    def test_transitive_raw_evidence_included_and_corruption_rejected(self):
        raw = self.write('raw.csv', 'a,b\n1,2\n')
        evidence = self.write('nested-receipt.json', {'raw_evidence': [raw]})
        self.state['evidence_ref'] = evidence
        self.state['revision'] += 1
        S.record_revision(self.state)
        ref = self.export()
        self.assertIn(raw, S.verify_manifest(self.root, ref)['artifacts'])
        (self.root / raw['path']).write_text('corrupted')
        with self.assertRaisesRegex(ValueError, 'hash mismatch'):
            S.verify_manifest(self.root, ref)

    def test_manifest_cannot_invent_completed_attempts(self):
        ref = self.export()
        manifest = S.verify_manifest(self.root, ref)
        manifest['attempts'] = [{'attempt_id': 'invented', 'status': 'completed'}]
        forged = self.write('forged.json', manifest)
        with self.assertRaisesRegex(ValueError, 'actual checkpoint'):
            S.verify_manifest(self.root, forged)

    def test_saved_is_not_durable_until_separate_matching_readback(self):
        self.bootstrap()
        ref = self.export()
        revision = self.state['revision']
        self.saved(ref)
        self.assertIsNone(self.state['session']['acknowledged_head'])
        self.readback()
        self.assertEqual(self.state['session']['acknowledged_head']['revision'], revision)
        self.assertIsNone(self.state['session']['pending_save'])
        self.assertIsNone(self.guard())

    def test_readback_requires_saved_operation_and_complete_artifacts(self):
        with self.assertRaisesRegex(ValueError, 'record actual save'):
            self.event('session_readback', receipt_ref=self.source)
        ref = self.export()
        save = self.saved(ref)
        with self.assertRaisesRegex(ValueError, 'separate observed operation'):
            self.readback(operation_id=S._ref(self.root, save, as_json=True)['operation_id'])
        with self.assertRaisesRegex(ValueError, 'every manifest artifact'):
            self.readback(restored_artifact_refs=[self.procedure['ref']])

    def test_readback_changed_bytes_cannot_advance_authority(self):
        ref = self.export()
        self.saved(ref)
        wrong = self.write('wrong-manifest.json', {'unrelated': True})
        with self.assertRaisesRegex(ValueError, 'differs from saved bytes'):
            self.readback(readback_manifest_ref=wrong)
        self.assertIsNone(self.state['session']['acknowledged_head'])

    def test_unacknowledged_save_cannot_be_overwritten_or_forked(self):
        ref = self.export()
        receipt = self.saved(ref)
        with self.assertRaisesRegex(ValueError, 'pending save readback'):
            self.event('session_saved', manifest_ref=ref, receipt_ref=receipt)
        with self.assertRaisesRegex(ValueError, 'pending save readback'):
            self.export('fork.json')

    def test_resumed_invocation_must_observe_authoritative_head(self):
        self.bootstrap()
        ref = self.export()
        self.saved(ref)
        self.readback()
        with self.assertRaisesRegex(ValueError, 'observed authoritative'):
            self.bootstrap('turn-2')
        self.bootstrap('turn-2', authoritative_head_ref=ref)
        self.assertIsNone(self.guard('turn-2'))

    def test_restored_pre_ack_snapshot_retains_observed_publication_parent(self):
        ref = self.export()
        self.bootstrap('turn-2', authoritative_head_ref=ref)
        self.assertIsNone(self.state['session']['acknowledged_head'])
        next_ref = self.export('next-manifest.json')
        self.assertEqual(S.verify_manifest(self.root, next_ref)['parent_manifest_ref'], ref)

    def test_observed_head_without_ack_cannot_roll_back_or_be_omitted_next_turn(self):
        old = self.export('old.json')
        self.bootstrap('turn-1')
        newer = self.export('newer.json')
        self.bootstrap('turn-2', authoritative_head_ref=newer)
        observed = copy.deepcopy(self.state['session']['observed_head'])
        self.assertIsNone(self.state['session']['acknowledged_head'])
        with self.assertRaisesRegex(ValueError, 'newest known checkpoint'):
            self.bootstrap('turn-3', authoritative_head_ref=old)
        self.assertEqual(self.state['session']['observed_head'], observed)
        with self.assertRaisesRegex(ValueError, 'observed authoritative'):
            self.bootstrap('turn-3')
        next_ref = self.export('latest.json')
        self.assertEqual(S.verify_manifest(self.root, next_ref)['parent_manifest_ref'], newer)

    def test_manifest_destination_and_parent_cannot_be_changed_by_repinning_manifest(self):
        ref = self.export()
        original = S.verify_manifest(self.root, ref)
        wrong_destination = copy.deepcopy(original)
        wrong_destination['destination'] = 'unapproved/destination'
        changed = self.write('changed-destination.json', wrong_destination)
        with self.assertRaisesRegex(ValueError, 'destination differs'):
            S.verify_manifest(self.root, changed)
        wrong_parent = copy.deepcopy(original)
        wrong_parent['parent_manifest_ref'] = {'path': 'nonexistent-parent.json', 'sha256': '0' * 64}
        changed = self.write('changed-parent.json', wrong_parent)
        with self.assertRaisesRegex(ValueError, 'parent differs'):
            S.verify_manifest(self.root, changed)

    def test_same_revision_different_manifest_identity_requires_reconciliation(self):
        first = self.export('first.json')
        alias = self.export('second-name.json')
        self.assertNotEqual(first['sha256'], alias['sha256'])
        self.bootstrap('turn-2', authoritative_head_ref=first)
        with self.assertRaisesRegex(ValueError, 'conflicting manifest identities'):
            self.bootstrap('turn-3', authoritative_head_ref=alias)
        self.assertEqual(self.state['session']['observed_head']['manifest_ref'], first)

    def test_manifest_parent_chain_requires_existing_valid_ancestral_content(self):
        first = self.export('first.json')
        self.bootstrap('turn-2', authoritative_head_ref=first)
        second = self.export('second.json')
        self.assertEqual(S.verify_manifest(self.root, second)['parent_manifest_ref'], first)
        (self.root / first['path']).unlink()
        with self.assertRaises(OSError):
            S.verify_manifest(self.root, second)

    def test_bounded_unsaved_progress_does_not_require_endless_receipt_resaves(self):
        self.state['session_contract']['max_unsaved_revisions'] = 4
        self.state['revision'] += 1
        S.record_revision(self.state)
        self.bootstrap()
        ref = self.export()
        self.saved(ref)
        self.readback()
        self.assertIsNone(self.guard())  # Exported revision2, receipt bookkeeping revisions3/4.
        for _ in range(2):
            self.state['revision'] += 1
            S.record_revision(self.state)
        self.assertIn('interval exhausted', self.guard()['detail'])

    def test_divergent_same_number_branches_cannot_be_auto_selected(self):
        origin = copy.deepcopy(self.state)
        first = self.export('origin.json')
        self.bootstrap('branch-a')
        branch_a = self.export('a.json')
        self.state = origin
        self.bootstrap('branch-b')
        branch_b = self.export('b.json')
        self.assertEqual(S.compare_heads(self.root, first, branch_b)['relation'], 'second_descends_from_first')
        self.assertEqual(S.compare_heads(self.root, branch_a, branch_b)['relation'], 'divergent')
        with self.assertRaisesRegex(ValueError, 'divergent or newer'):
            self.bootstrap('branch-b', authoritative_head_ref=branch_a)

    def test_other_project_head_never_restores_under_same_stage_label(self):
        other = copy.deepcopy(self.state)
        S.initialize(self.root, other)
        other.pop('lineage')
        S.record_revision(other)
        self.persist(self.root / 'other.json', other)
        ref = S.export_manifest(self.root / 'other.json', self.root / 'other-manifest.json')
        with self.assertRaisesRegex(ValueError, 'another project'):
            self.bootstrap(authoritative_head_ref=ref)

    def test_cli_export_verify_compare_and_nonzero_corruption(self):
        command = [sys.executable, str(SCRIPT)]
        nonce = subprocess.run(command + ['nonce'], text=True, capture_output=True)
        self.assertEqual(nonce.returncode, 0)
        self.assertEqual(json.loads(nonce.stdout)['origin'], 'coordinator_nonce')
        exported = subprocess.run(command + ['export', '--state', str(self.state_path),
            '--output', str(self.root / 'cli.json')], text=True, capture_output=True)
        self.assertEqual(exported.returncode, 0, exported.stderr + exported.stdout)
        ref = json.loads(exported.stdout)
        verified = subprocess.run(command + ['verify', '--root', str(self.root), '--manifest', json.dumps(ref)],
                                  text=True, capture_output=True)
        self.assertEqual(verified.returncode, 0, verified.stdout)
        compared = subprocess.run(command + ['compare', '--root', str(self.root), '--first', json.dumps(ref),
            '--second', json.dumps(ref)], text=True, capture_output=True)
        self.assertEqual(json.loads(compared.stdout)['relation'], 'same_checkpoint')
        (self.root / self.procedure['ref']['path']).write_text('corrupt')
        invalid = subprocess.run(command + ['verify', '--root', str(self.root), '--manifest', json.dumps(ref)],
                                 text=True, capture_output=True)
        self.assertEqual(invalid.returncode, 2)
        self.assertIn('hash mismatch', invalid.stdout)


if __name__ == '__main__':
    unittest.main()
