#!/usr/bin/env python3
"""Goal-linked protocol, investment and claim checks; never a scientific PASS.

Input metadata is a declaration, not authenticated scientific evidence. Numeric
summaries are descriptive. The coordinator must review semantics and statistics.
"""
from __future__ import annotations
import argparse
import math
from pathlib import Path
import statistics
from research_reasoning import Check, _strict_json, _text, read_ref

STAGES={'acquire','diagnostic','derive','compare','expand','confirm','deliver','repair','park'}
BASELINE_STATES={'planned','qualified','executed','unavailable'}
CLAIM_KINDS={'effect','proxy','mechanism','efficiency','novelty','formal','risk','boundary'}


def paired_summary(rows, direction):
    """Summarize declared paired units without manufacturing confidence/independence."""
    if direction not in {'lower','higher'} or not isinstance(rows,list) or not rows:
        raise ValueError('nonempty paired units and direction are required')
    seen=set();a=[];b=[]
    for row in rows:
        if not isinstance(row,dict) or not _text(row.get('unit_id')) or row['unit_id'] in seen:
            raise ValueError('each declared independent unit must occur exactly once')
        seen.add(row['unit_id'])
        for key in ('method','baseline'):
            if type(row.get(key)) not in {int,float} or not math.isfinite(row[key]):
                raise ValueError('finite numeric measurements are required')
        a.append(row['method']);b.append(row['baseline'])
    sign=1 if direction=='lower' else -1
    return dict(n_declared_units=len(rows),method_mean=statistics.fmean(a),baseline_mean=statistics.fmean(b),
        mean_improvement=statistics.fmean(sign*(y-x) for x,y in zip(a,b)),
        confidence_interval=None,independence_verified=False,statistical_significance=None)


def _evaluate(root, packet, *, task_id=None, candidate_id=None, goal_id=None):
    c=Check(root);limits=[];priority=[];summaries={}
    if not isinstance(packet,dict):packet={}
    def limit(code,claim,action):limits.append(dict(code=code,claim_id=claim,next_action=action))
    def need_fields(obj,fields,path):
        if not isinstance(obj,dict):obj={}
        for name in fields:c.need(obj.get(name),'missing_quality_field',path+'.'+name)
        return obj
    def ref(reference,path):
        c.refs([reference] if reference is not None else [],path,required=True)
    if packet.get('kind')!='research_quality' or packet.get('schema_version')!=1:
        c.gap('quality_kind','kind','Use a research_quality version-1 record, not a PASS label.')
    for key in ('goal_id','candidate_id','protocol_id'):
        c.need(packet.get(key),'missing_quality_field',key)
    for key,expected in [('goal_id',goal_id),('candidate_id',candidate_id)]:
        if expected is not None and packet.get(key)!=expected:c.gap('quality_identity_mismatch',key,'Bind the actual goal/candidate.')
    stage=packet.get('stage')
    if stage not in STAGES:c.gap('invalid_stage','stage','Separate inquiry, comparison, expansion, confirmation and delivery.')
    tasks=c.ids(packet.get('selected_task_ids'),'selected_task_ids',True)
    if task_id is not None and task_id not in tasks:c.gap('task_not_selected','selected_task_ids','Select this exact task in a new decision.')
    metrics=c.entries(packet.get('metrics'),'metrics');primary=packet.get('primary_metric_id')
    if not isinstance(primary,str) or primary not in metrics or sum(m.get('role')=='primary' for m in metrics.values())!=1 or metrics.get(primary,{}).get('role')!='primary':
        c.gap('primary_metric_missing','primary_metric_id','Name one primary objective; guardrails and proxies remain separate.')
    for name,m in metrics.items():
        need_fields(m,('unit','denominator','independent_unit'),f'metrics.{name}')
        if m.get('direction') not in {'lower','higher'} or m.get('role') not in {'primary','proxy','guardrail','secondary'}:
            c.gap('invalid_metric','metrics.'+name,'State direction and objective/proxy/guardrail role.')
        ref(m.get('definition_ref'),f'metrics.{name}.definition_ref')
    info=need_fields(packet.get('information'),('signature','decision_time'),'information');ref(info.get('mapping_ref'),'information.mapping_ref')
    impl=packet.get('implementation',{});impl=impl if isinstance(impl,dict) else {}
    ref(impl.get('mapping_ref'),'implementation.mapping_ref');terms=c.entries(impl.get('terms'),'implementation.terms')
    for name,term in terms.items():
        if term.get('state') not in {'implemented','omitted','approximated','unchecked'}:
            c.gap('term_state','implementation.terms.'+name,'Name exact, approximate, omitted or unchecked implementation.')
        c.refs(term.get('evidence_refs',[]),'implementation.terms.'+name,required=term.get('state') in {'implemented','approximated'})
        if term.get('state')=='approximated':
            need_fields(term,('approximation_obligation',),'implementation.terms.'+name)
    pop=need_fields(packet.get('population'),('target','observed','status'),'population');ref(pop.get('manifest_ref'),'population.manifest_ref')
    baselines=c.entries(packet.get('baselines'),'baselines')
    for name,b in baselines.items():
        need_fields(b,('role','information_signature'),'baselines.'+name)
        if b.get('status') not in BASELINE_STATES:c.gap('baseline_state','baselines.'+name,'Retain planned, qualified, executed or unavailable status.')
        c.refs(b.get('evidence_refs',[]),'baselines.'+name,required=b.get('status') in {'qualified','executed'})
    strong=any(b.get('role') in {'strongest','strong_simple'} and b.get('status') in {'qualified','executed'} for b in baselines.values())
    if stage in {'expand','confirm'} and not strong:
        c.gap('strong_baseline_unqualified','baselines','Qualify the strongest compatible simple/exact method before expansion. Inquiry remains possible.')
    novelty=need_fields(packet.get('novelty'),('status','delta'),'novelty')
    c.refs(novelty.get('closest_refs',[]),'novelty.closest_refs')
    if novelty.get('discriminator_ref'):ref(novelty['discriminator_ref'],'novelty.discriminator_ref')
    stats=need_fields(packet.get('statistics'),('estimand','independent_unit','sampling','exposure'),'statistics')
    ref(stats.get('analysis_ref'),'statistics.analysis_ref')
    if isinstance(primary,str) and primary in metrics and stats.get('independent_unit')!=metrics[primary].get('independent_unit'):
        c.gap('analysis_unit_mismatch','statistics','Explain the target/analysis unit mapping in a versioned protocol, not by multiplying dependent rows.')
    if stage=='confirm' and stats.get('exposure')!='prospective_confirmation':
        c.gap('confirmation_exposed','statistics.exposure','Do not relabel development data or an exposed case with new seeds as untouched confirmation.')
    costs=need_fields(packet.get('costs'),('scope',),'costs');c.refs(costs.get('evidence_refs',[]),'costs.evidence_refs')
    obligations=c.entries(packet.get('obligations'),'obligations')
    for name,o in obligations.items():
        status=o.get('status');required=c.ids(o.get('required_before'),'obligations.'+name+'.required_before')
        if status not in {'pending','blocked','resolved','waived'}:c.gap('obligation_state',name,'Retain the actual obligation state.')
        next_ids=c.ids(o.get('next_task_ids',[]),'obligations.'+name+'.next_task_ids')
        if status=='resolved':c.refs(o.get('evidence_refs',[]),'obligations.'+name,required=True)
        elif status=='waived':
            ref(o.get('scope_revision_ref'),'obligations.'+name+'.scope_revision_ref')
            c.need(o.get('retained_original_claim'),'waiver_erases_goal','obligations.'+name)
        else:
            if not next_ids:c.gap('missing_obligation_action',name,'Name the concrete acquisition/control/recovery task, not merely next round.')
            priority.extend(next_ids)
            if stage in required and task_id not in next_ids:
                c.gap('critical_obligation_open',name,'Resolve the prerequisite before more dependent expansion; unrelated inquiry remains eligible.')
    previous=packet.get('previous_ref')
    if previous:
        old=c.document(previous,'previous_ref')
        if old.get('goal_id')!=packet.get('goal_id') or old.get('candidate_id')!=packet.get('candidate_id'):
            c.gap('quality_ancestry_mismatch','previous_ref','Keep the actual goal/candidate lineage.')
        semantic_keys=('primary_metric_id','metrics','information','implementation','population','statistics')
        def baseline_semantics(record):
            return [{k:v for k,v in b.items() if k not in {'status','evidence_refs'}} for b in record.get('baselines',[])]
        if old.get('protocol_id')==packet.get('protocol_id') and (any(old.get(k)!=packet.get(k) for k in semantic_keys) or baseline_semantics(old)!=baseline_semantics(packet)):
            c.gap('protocol_reused_after_semantic_change','protocol_id','Version the metric, information, algorithm or sampling protocol; preserve old evidence.')
        for o in old.get('obligations',[]):
            if isinstance(o,dict) and o.get('id') not in obligations and o.get('status') in {'pending','blocked'}:
                c.gap('lost_obligation','obligations','A new plan cannot delete an unresolved core comparison.')
    results=packet.get('results',[])
    if not isinstance(results,list):c.gap('invalid_results','results','Reference the actual result records.');results=[]
    for i,result in enumerate(results):
        if not isinstance(result,dict):c.gap('invalid_results','results','Each result binds a metric and comparator.');continue
        mid,bid=result.get('metric_id'),result.get('baseline_id')
        if not isinstance(mid,str) or mid not in metrics or not isinstance(bid,str) or bid not in baselines:
            c.gap('unknown_result_binding','results','Do not borrow another metric or comparator result.');continue
        try:
            r=result['paired_ref'];rows=_strict_json(read_ref(root,r));ref(r,'results.paired_ref')
            summary=paired_summary(rows,metrics[mid]['direction'])
            if (mid,bid) in summaries:raise ValueError('duplicate contrast')
            summaries[(mid,bid)]=summary
        except (ValueError,KeyError,TypeError) as e:c.gap('invalid_paired_result',f'results[{i}]',str(e))
    claims=c.entries(packet.get('claims'),'claims')
    for cid,claim in claims.items():
        kind=claim.get('kind');status=claim.get('status')
        if kind not in CLAIM_KINDS:c.gap('claim_kind','claims.'+cid,'Name a supported claim type.')
        if status not in {'supported','not_supported','inconclusive','pending'}:c.gap('claim_state',cid,'Use a scoped evidence status.')
        c.refs(claim.get('evidence_refs',[]),'claims.'+cid,required=status in {'supported','not_supported'})
        if status!='supported':continue
        mid=claim.get('metric_id')
        if not isinstance(mid,str) or mid not in metrics:
            limit('unknown_claim_metric',cid,'Bind the actual measured quantity.');continue
        m=metrics[mid]
        if kind in {'effect','risk'} and mid!=primary:
            limit('proxy_not_primary',cid,'Report the proxy finding only; test the primary objective or a separately qualified bridge.')
        if claim.get('scope')!=pop.get('observed'):
            limit('scope_mismatch',cid,'Preserve diagnostic/native/real-world populations separately.')
        for term in c.ids(claim.get('required_terms',[]),'claims.'+cid+'.required_terms'):
            if terms.get(term,{}).get('state')!='implemented':
                limit('claimed_term_not_implemented',cid,'Do not support a formal-model term absent from the tested implementation.')
        bids=c.ids(claim.get('baseline_ids',[]),'claims.'+cid+'.baseline_ids')
        if kind in {'effect','efficiency','risk'} and not bids:limit('measured_contrast_missing',cid,'Report actual comparator results.')
        for bid in bids:
            b=baselines.get(bid,{})
            if b.get('information_signature')!=info.get('signature'):
                limit('information_mismatch',cid,'Separate information advantage from method advantage.')
            if b.get('status') not in {'qualified','executed'}:limit('baseline_unqualified',cid,'Retain the missing baseline qualification.')
            s=summaries.get((mid,bid))
            if kind in {'effect','efficiency','risk'} and s is None:limit('measured_contrast_missing',cid,'Bind actual raw paired measurements.')
            if kind=='effect' and s is not None and s['mean_improvement']<=0:
                limit('observed_primary_not_improved',cid,'A nonpositive descriptive improvement cannot support this improvement wording.')
        if kind=='efficiency' and (costs.get('scope')!='end_to_end' or costs.get('unmeasured') or not costs.get('evidence_refs')):
            limit('full_cost_missing',cid,'Include baseline and method startup, maintenance, fallback and end-to-end costs.')
        if kind=='novelty' and (novelty.get('status')!='reviewed_distinction' or not novelty.get('closest_refs') or not novelty.get('discriminator_ref')):
            limit('novelty_unestablished',cid,'Classical component validity is not a new-mechanism claim; review the incremental distinction.')
        if kind in {'formal','risk'} and not claim.get('assumption_review_ref'):
            limit('guarantee_assumptions_unchecked',cid,'Qualify calibration unit, policy/feedback law, assumptions and finite-selection protocol.')
        elif claim.get('assumption_review_ref'):ref(claim['assumption_review_ref'],'claims.'+cid+'.assumption_review_ref')
    if stage=='deliver':
        for x in limits:c.gap(x['code'],'claims.'+x['claim_id'],x['next_action'])
    return dict(status='needs_scoped_work' if c.gaps else 'ready_for_scoped_work',stage=stage,gaps=c.gaps,claim_limits=limits,
        priority_task_ids=sorted(set(priority)),required_input_refs=list(c.bound_refs.values()),
        descriptive_contrasts=[dict(metric_id=m,baseline_id=b,**s) for (m,b),s in summaries.items()],
        aggregate_score=None,scientific_certification=False,semantic_validity_verified=False,
        statistical_validity_verified=False,novelty_verified=False,
        claim_readiness='restricted' if limits else 'requires_substantive_review')



def evaluate(root, packet, *, task_id=None, candidate_id=None, goal_id=None):
    try:
        return _evaluate(root,packet,task_id=task_id,candidate_id=candidate_id,goal_id=goal_id)
    except (TypeError,KeyError,AttributeError,ValueError,OverflowError) as error:
        return dict(status='needs_scoped_work',gaps=[dict(code='malformed_quality_record',path='packet',
            next_action='Repair this metadata only: '+str(error))],claim_limits=[],priority_task_ids=[],required_input_refs=[],
            descriptive_contrasts=[],aggregate_score=None,scientific_certification=False,semantic_validity_verified=False,
            statistical_validity_verified=False,novelty_verified=False,claim_readiness='restricted')


def main():
    import json
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',required=True);p.add_argument('--packet',required=True)
    a=p.parse_args()
    try:
        from research_reasoning import metadata_reference
        r=metadata_reference(a.root,a.packet);report=evaluate(a.root,_strict_json(read_ref(a.root,r)))
    except (ValueError,OSError) as e:
        print(json.dumps({'error':str(e),'scientific_certification':False}));return 2
    print(json.dumps(report,indent=2,allow_nan=False));return 2 if report['gaps'] else 0
if __name__=='__main__':raise SystemExit(main())
